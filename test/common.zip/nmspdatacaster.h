////////////////////////////////////////////////////////////////////////////////
//
// �ۼ���: huelee
// ��  ��:
//
#pragma once
#ifndef __NMSPDATACASTER_H__
#define __NMSPDATACASTER_H__

namespace nmsp {

/*
class get_data_caster : public std::stringbuf
{
	using __super_t = std::stringbuf;
	template <typename T, typename D, bool CON> struct _call_t
	{
		static inline void call(T& t, D& d)
		{
			t.m_t.Traverse(d);
		}
	};
	template <typename T, typename D> struct _call_t<T, D, false>
	{
		static inline void call(T& t, D& d)
		{
		}
	};
public:
	template <typename X> inline void operator ()(X& x)
	{
		short loc = static_cast<short>(X::INDEX);
		__super_t::sputn(reinterpret_cast<char*>(&loc), sizeof(loc));
		if (true == std::is_base_of<nmsp::type_container_base, X::_T>::value)
		{
			_call_t<X, get_data_caster, std::is_base_of<nmsp::type_container_base, X::_T>::value>::call(x, *this);
			return;
		}

		__super_t::sputn(reinterpret_cast<char*>(&x.m_t), sizeof(x.m_t));
	}
};

class set_data_caster : public std::stringbuf
{
	using __super_t = std::stringbuf;
	template <typename T, typename D, bool CON> struct _call_t
	{
		static inline void call(T& t, D& d)
		{
			t.m_t.Traverse(d);
		}
	};
	template <typename T, typename D> struct _call_t<T, D, false>
	{
		static inline void call(T& t, D& d)
		{
		}
	};
public:
	set_data_caster()
	{
		m_readId = false;
		m_loc = -1;
	}
	template <typename X> inline void operator ()(X& x)
	{
		if (false == m_readId)
		{
			__super_t::sgetn(reinterpret_cast<char*>(&m_loc), sizeof(m_loc));
			m_readId = true;
		}

		if (m_loc != X::INDEX)
			return;

		m_readId = false;

		if (true == std::is_base_of<nmsp::type_container_base, X::_T>::value)
		{
			_call_t<X, set_data_caster, std::is_base_of<nmsp::type_container_base, X::_T>::value>::call(x, *this);
			return;
		}

		__super_t::sgetn(reinterpret_cast<char*>(&x.m_t), sizeof(x.m_t));
	}

private:
	bool m_readId;
	short m_loc;
};
*/

namespace serialize {

// std::pair�� ���� ������.. Ȯ���ϱ� ���� ���ø�..
template <typename X>
struct is_pair
{
	enum { VALUE = false, };
};

template <typename T1, typename T2>
struct is_pair<std::pair<T1, T2>>
{
	enum { VALUE = true, };
};

// stl�� �ĺ�
template <typename X>
struct is_iterator_supported
{
	enum { VALUE = false, };
};

#ifdef _STRING_
template <class T, class Alloc>
struct is_iterator_supported <std::basic_string <T, std::char_traits<T>, Alloc>>
{
	using _container_t = std::basic_string <T, std::char_traits<T>, Alloc>;
	using type = T;
	enum { VALUE = true, };
	static inline void clear(_container_t& container)
	{
		container.clear();
	}
	static inline void update(_container_t& container, type& val)
	{
		container.push_back(val);
	}
};
#endif

#ifdef _VECTOR_
template <class T, class Alloc>
struct is_iterator_supported<std::vector<T, Alloc>>
{
	using _container_t = std::vector<T, Alloc>;
	using type = T;
	enum { VALUE = true, };
	static inline void clear(_container_t& container)
	{
		container.clear();
	}
	static inline void update(_container_t& container, type& val)
	{
		container.push_back(val);
	}
};
#endif

#ifdef _LIST_
template <class T, class Alloc>
struct is_iterator_supported<std::list<T, Alloc>>
{
	using _container_t = std::list<T, Alloc>;
	using type = T;
	enum { VALUE = true, };
	static inline void clear(_container_t& container)
	{
		container.clear();
	}
	static inline void update(_container_t& container, type& val)
	{
		container.push_back(val);
	}
};
#endif

#ifdef _ARRAY_
template <class T, std::size_t N>
struct is_iterator_supported<std::array<T, N>>
{
	using _container_t = std::array<T, N>;
	using type = T;
	enum { VALUE = true, };
	static inline void clear(_container_t& container)
	{
	}
	static inline void update(_container_t& container, type& val)
	{
		if (nIndex >= container.size() || nIndex < 0)
			return;

		container[nIndex] = val;
	}
};
#endif

#ifdef _SET_
template <class T, class Compare, class Alloc>
struct is_iterator_supported<std::set<T, Compare, Alloc>>
{
	using _container_t = std::set<T, Compare, Alloc>;
	using type = T;
	enum { VALUE = true, };
	static inline void clear(_container_t& container)
	{
		container.clear();
	}
	static inline void update(_container_t& container, type& val)
	{
		container.insert(val);
	}
};
#endif

#ifdef _MAP_
template <class Key, class T, class Compare, class Alloc>
struct is_iterator_supported<std::map<Key, T, Compare, Alloc>>
{
	template <typename X, typename D, bool COND = false>
	struct _assign_t
	{
		static inline void Assign(X& d, D& s)
		{
			d = s;
		}
	};
	template <typename X, typename D>
	struct _assign_t<X, D, true>
	{
		static inline void Assign(X& d, D& s)
		{
			d.AssignMod(s);
		}
	};

	using _container_t = std::map<Key, T, Compare, Alloc>;
	using type = std::pair<Key, T>;
	enum { VALUE = true, };
	static inline void clear(_container_t& container)
	{
		container.clear();
	}
	static inline void update(_container_t& container, type& val)
	{
		auto ret = container.insert(val);
		if (false == ret.second)
			_assign_t<decltype(ret.first->second), decltype(val.second), std::is_base_of<nmsp::type_container_base, nmsp::find_type_of<decltype(val.second)>::type>::value>::Assign(ret.first->second, val.second);
	}
};
#endif

#ifdef _UNORDERED_SET_
template <class Key, class Hash, class Pred, class Alloc>
struct is_iterator_supported<std::unordered_set<Key, Hash, Pred, Alloc>>
{
	using _container_t = std::unordered_set<Key, Hash, Pred, Alloc>;
	using type = Key;
	enum { VALUE = true, };
	static inline void clear(_container_t& container)
	{
		container.clear();
	}
	static inline void update(_container_t& container, type& val)
	{
		container.insert(val);
	}
};
#endif

#ifdef _UNORDERED_MAP_
template <class Key, class T, class Hash, class Pred, class Alloc>
struct is_iterator_supported<std::unordered_map<Key, T, Hash, Pred, Alloc>>
{
	template <typename X, typename D, bool COND = false>
	struct _assign_t
	{
		static inline void Assign(X& d, D& s)
		{
			d = s;
		}
	};
	template <typename X, typename D>
	struct _assign_t<X, D, true>
	{
		static inline void Assign(X& d, D& s)
		{
			d.AssignMod(s);
		}
	};

	using _container_t = std::unordered_map<Key, T, Hash, Pred, Alloc>;
	using type = std::pair<Key, T>;
	enum { VALUE = true, };
	static inline void clear(_container_t& container)
	{
		container.clear();
	}
	static inline void update(_container_t& container, type& val)
	{
		auto ret = container.insert(val);
		if (false == ret.second)
			_assign_t<decltype(ret.first->second), decltype(val.second), std::is_base_of<nmsp::type_container_base, nmsp::find_type_of<decltype(val.second)>::type>::value>::Assign(ret.first->second, val.second);
	}
};
#endif

//
enum class eCategory
{
	eFuncfundamental = 0,
	eTyper = 1,
	eIterator = 2,
	ePair = 3,
	eEtc = 4,
};

template <typename X>
struct what_is_category
{
	using type = typename nmsp::find_type_of<X>::type;
	enum {
		category = std::is_base_of<nmsp::type_container_base, type>::value == true ? eCategory::eTyper :
		is_iterator_supported<type>::VALUE == true ? eCategory::eIterator :
		std::is_fundamental<type>::value == true ? eCategory::eFuncfundamental :
		is_pair<X>::VALUE == true ? eCategory::ePair : eCategory::eEtc,
	};
};

template <typename T, typename D, eCategory> struct _call_t;
template <typename T, typename D> struct _call_t<T, D, eCategory::eFuncfundamental>
{
	static inline void call(T& t, D& d)
	{
		d.sputn(reinterpret_cast<const char*>(&t), sizeof(t));
	}
	static inline void called(T& t, D& d)
	{
		d.sgetn(reinterpret_cast<char*>(&t), sizeof(t));
	}
};

template <typename T, typename D> struct _call_t<T*, D, eCategory::eFuncfundamental>
{
	static inline void call(T* t, D& d)
	{
		d.sputn(reinterpret_cast<const char*>(t), sizeof(*t));
	}
	static inline void called(T* t, D& d)
	{
		d.sgetn(reinterpret_cast<char*>(t), sizeof(*t));
	}
};

template <typename T, std::size_t SIZE, typename D> struct _call_t<T[SIZE], D, eCategory::eFuncfundamental>
{
	using _param_t = T[SIZE];
	static inline void call(_param_t& t, D& d)
	{
		for (auto& step : t)
		{
			d.sputn(reinterpret_cast<const char*>(&step), sizeof(step));
		}
	}
	static inline void called(_param_t& t, D& d)
	{
		for (auto& step : t)
		{
			d.sgetn(reinterpret_cast<char*>(&step), sizeof(step));
		}
	}
};

template <typename T, std::size_t SIZE, typename D> struct _call_t<T*[SIZE], D, eCategory::eFuncfundamental>
{
	using _param_t = T*[SIZE];
	static inline void call(_param_t& t, D& d)
	{
		for (auto& step : t)
		{
			d.sputn(reinterpret_cast<const char*>(step), sizeof(*step));
		}
	}
	static inline void called(_param_t& t, D& d)
	{
		for (auto& step : t)
		{
			d.sgetn(reinterpret_cast<char*>(step), sizeof(*step));
		}
	}
};

template <typename T, typename D> struct _call_t<T, D, eCategory::eTyper>
{
	static inline void call(T& t, D& d)
	{
		int count = 0;
		auto pos = d.pubseekoff(std::streamoff(0), std::ios_base::cur, std::ios_base::out);
		d.sputn(reinterpret_cast<const char*>(&count), sizeof(count));

		t.Traverse(d, count);

		pos = d.pubseekoff(pos, std::ios_base::beg, std::ios_base::out);
		d.sputn(reinterpret_cast<const char*>(&count), sizeof(count));
		pos = d.pubseekoff(std::streamoff(0), std::ios_base::end, std::ios_base::out);
	}
	static inline void called(T& t, D& d)
	{
		int count = 0;
		d.sgetn(reinterpret_cast<char*>(&count), sizeof(count));

		if (count)
			t.Traverse(d);
	}
};

template <typename T, typename D> struct _call_t<T*, D, eCategory::eTyper>
{
	static inline void call(T* t, D& d)
	{
		int count = 0;
		auto pos = d.pubseekoff(std::streamoff(0), std::ios_base::cur, std::ios_base::out);
		d.sputn(reinterpret_cast<const char*>(&count), sizeof(count));

		t->Traverse(d, count);

		d.pubseekoff(pos, std::ios_base::beg, std::ios_base::out);
		d.sputn(reinterpret_cast<const char*>(&count), sizeof(count));
		d.pubseekoff(std::streamoff(0), std::ios_base::end, std::ios_base::out);
	}
	static inline void called(T* t, D& d)
	{
		int count = 0;
		d.sgetn(reinterpret_cast<char*>(&count), sizeof(count));

		if (count)
			t->Traverse(d);
	}
};

template <typename T, std::size_t SIZE, typename D> struct _call_t<T[SIZE], D, eCategory::eTyper>
{
	using _param_t = T[SIZE];
	static inline void call(_param_t& t, D& d)
	{
		int size = static_cast<int>(SIZE);
		d.sputn(reinterpret_cast<const char*>(&size), sizeof(size));

		for (auto& step : t)
		{
			int count = 0;
			auto pos = d.pubseekoff(std::streamoff(0), std::ios_base::cur, std::ios_base::out);
			d.sputn(reinterpret_cast<const char*>(&count), sizeof(count));

			step.Traverse(d, count);

			d.pubseekoff(pos, std::ios_base::beg, std::ios_base::out);
			d.sputn(reinterpret_cast<const char*>(&count), sizeof(count));
			d.pubseekoff(std::streamoff(0), std::ios_base::end, std::ios_base::out);
		}
	}
	static inline void called(_param_t& t, D& d)
	{
		int size = static_cast<int>(SIZE);
		d.sgetn(reinterpret_cast<char*>(size), sizeof(size));

		for (int step = 0; step < size; ++step)
		{
			int count = 0;
			d.sgetn(reinterpret_cast<char*>(&count), sizeof(count));

			if (count)
				step[step].Traverse(d, count);
		}
	}
};

template <typename T, std::size_t SIZE, typename D> struct _call_t<T*[SIZE], D, eCategory::eTyper>
{
	using _param_t = T*[SIZE];
	static inline void call(T& t, D& d)
	{
		int size = static_cast<int>(SIZE);
		d.sputn(reinterpret_cast<const char*>(&size), sizeof(size));

		for (std::size_t s = 0; s < SIZE; ++s)
		{
			int count = 0;
			auto pos = d.pubseekoff(std::streamoff(0), std::ios_base::cur, std::ios_base::out);
			d.sputn(reinterpret_cast<const char*>(&count), sizeof(count));

			t[s]->Traverse(d, count);

			d.pubseekoff(pos, std::ios_base::beg, std::ios_base::out);
			d.sputn(reinterpret_cast<const char*>(&count), sizeof(count));
			d.pubseekoff(std::streamoff(0), std::ios_base::end, std::ios_base::out);
		}
	}
	static inline void called(T& t, D& d)
	{
		int size = static_cast<int>(SIZE);
		d.sgetn(reinterpret_cast<char*>(size), sizeof(size));

		for (int step = 0; step < size; ++step)
		{
			int count = 0;
			d.sgetn(reinterpret_cast<char*>(&count), sizeof(count));

			if (count)
				t[step]->Traverse(d, count);
		}
	}
};

template <typename T, typename D> struct _call_t<T, D, eCategory::eIterator>
{
	static inline void call(T& t, D& d)
	{
		int size = static_cast<int>(t.size());
		d.sputn(reinterpret_cast<const char*>(&size), sizeof(size));

		for (auto& itr : t)
		{
			_call_t<nmsp::find_type_of<decltype(itr)>::type, D, static_cast<eCategory>(what_is_category<nmsp::find_type_of<decltype(itr)>::type>::category)>::call(itr, d);
		}
	}
	static inline void called(T& t, D& d)
	{
		int size = 0;
		d.sgetn(reinterpret_cast<char*>(&size), sizeof(size));

		is_iterator_supported<T>::clear(t); // append�� �����ϱ� ���ؼ� �ʱ�ȭ�Ѵ�

		for (int step = 0; step < size; ++step)
		{
			is_iterator_supported<T>::type val;
			_call_t<is_iterator_supported<T>::type, D, static_cast<eCategory>(what_is_category<nmsp::find_type_of<decltype(t.begin())::value_type>::type>::category)>::called(val, d);

			is_iterator_supported<T>::update(t, val);
		}
	}
};

template <typename T, typename D> struct _call_t<T*, D, eCategory::eIterator>
{
	static inline void call(T* t, D& d)
	{
		int size = static_cast<int>(t->size());
		d.sputn(reinterpret_cast<const char*>(&size), sizeof(size));

		for (auto& itr : *t)
		{
			_call_t<nmsp::find_type_of<decltype(itr)>::type, D, static_cast<eCategory>(what_is_category<nmsp::find_type_of<decltype(itr)>::type>::category)>::call(itr, d);
		}
	}
	static inline void called(T* t, D& d)
	{
		int size = 0;
		d.sgetn(reinterpret_cast<char*>(size), sizeof(size));

		is_iterator_supported<T>::clear(t); // append�� �����ϱ� ���ؼ� �ʱ�ȭ�Ѵ�

		for (int step = 0; step < size; ++step)
		{
			is_iterator_supported<T>::type val;
			_call_t<is_iterator_supported<T>::type, D, static_cast<eCategory>(what_is_category<nmsp::find_type_of<decltype(itr)>::type>::category)>::called(val, d);

			is_iterator_supported<T>::update(*t, val);
		}
	}
};

template <typename T, std::size_t SIZE, typename D> struct _call_t<T[SIZE], D, eCategory::eIterator>
{
	using _param_t = T[SIZE];
	static inline void call(_param_t& t, D& d)
	{
		for (auto& step : t)
		{
			for (auto& itr : step)
			{
				_call_t<nmsp::find_type_of<decltype(itr)>::type, D, static_cast<eCategory>(what_is_category<nmsp::find_type_of<decltype(itr)>::type>::category)>::call(itr, d);
			}
		}
	}
	static inline void called(_param_t& t, D& d)
	{
		for (auto& step : t)
		{
			for (auto& itr : step)
			{
				is_iterator_supported<T>::type val;
				_call_t<is_iterator_supported<T>::type, D, static_cast<eCategory>(what_is_category<nmsp::find_type_of<decltype(itr)>::type>::category)>::called(val, d);

				is_iterator_supported<T>::update(step, val);
			}
		}
	}
};

template <typename T, std::size_t SIZE, typename D> struct _call_t<T*[SIZE], D, eCategory::eIterator>
{
	using _param_t = T*[SIZE];
	static inline void call(_param_t& t, D& d)
	{
		for (std::size_t s = 0; s < SIZE; ++s)
		{
			for (auto itr = t[s]->begin(); itr != t[s]->end(); ++itr)
			{
				_call_t<decltype(itr)::value_type, D, static_cast<eCategory>(what_is_category<decltype(itr)::value_type>::category)>::call(*itr, d);
			}
		}
	}
	static inline void called(_param_t& t, D& d)
	{
		for (std::size_t s = 0; s < SIZE; ++s)
		{
			for (auto itr = t[s]->begin(); itr != t[s]->end(); ++itr)
			{
				is_iterator_supported<T>::type val;
				_call_t<is_iterator_supported<T>::type, D, static_cast<eCategory>(what_is_category<decltype(itr)::value_type>::category)>::called(val, d);

				is_iterator_supported<T>::update(*(t[s]), val);
			}
		}
	}
};

template <typename T, typename D> struct _call_t<T, D, eCategory::ePair>
{
	static inline void call(T& t, D& d)
	{
		_call_t<decltype(t.first), D, static_cast<eCategory>(what_is_category<decltype(t.first)>::category)>::call(t.first, d);
		_call_t<decltype(t.second), D, static_cast<eCategory>(what_is_category<decltype(t.second)>::category)>::call(t.second, d);
	}
	static inline void called(T& t, D& d)
	{
		_call_t<nmsp::find_type_of<decltype(t.first)>::type, D, static_cast<eCategory>(what_is_category<decltype(t.first)>::category)>::called(t.first, d);
		_call_t<nmsp::find_type_of<decltype(t.second)>::type, D, static_cast<eCategory>(what_is_category<decltype(t.second)>::category)>::called(t.second, d);
	}
};

template <typename T, typename D> struct _call_t<T, D, eCategory::eEtc>
{
	static inline void call(T& t, D& d)
	{
		d.sputn(reinterpret_cast<char*>(&t), sizeof(t));
	}
	static inline void called(T& t, D& d)
	{
		d.sgetn(reinterpret_cast<char*>(&t), sizeof(t));
	}
};

} // serialize

//
class get_data_caster : public std::stringbuf
{
	using __super_t = std::stringbuf;
public:
	get_data_caster(bool modifyOnly = false)
		: __super_t() 
		, m_modifyOnly(modifyOnly)
		, m_index(-1)
	{
	}

	template <typename X> inline void operator ()(X& x)
	{
		++m_index;

		if (!m_modifyOnly || (m_modifyOnly == x.m_f))
		{
			short loc = m_index;// static_cast<short>(X::INDEX);
			__super_t::sputn(reinterpret_cast<const char*>(&loc), sizeof(loc));

			serialize::_call_t<X::_T, get_data_caster, static_cast<serialize::eCategory>(serialize::what_is_category<nmsp::find_type_of<X::_T>::type>::category)>::call(x.m_t, *this);
		}
	}
	template <typename X> inline void operator ()(X& x, int& count)
	{
		++m_index;

		if (!m_modifyOnly || (m_modifyOnly == x.m_f))
		{
			//short loc = static_cast<short>(X::INDEX);
			short loc = m_index;
			__super_t::sputn(reinterpret_cast<const char*>(&loc), sizeof(loc));

			serialize::_call_t<X::_T, get_data_caster, static_cast<serialize::eCategory>(serialize::what_is_category<nmsp::find_type_of<X::_T>::type>::category)>::call(x.m_t, *this);

			++count;
		}
	}

private:
	bool m_modifyOnly;
	int16_t m_index;
};

//
class set_data_caster : public std::stringbuf
{
	using __super_t = std::stringbuf;
public:
	set_data_caster()
	{
		m_readId = false;
		m_loc = -1;
		m_index = -1;
	}
	template <typename X> inline void operator ()(X& x)
	{
		++m_index;

		if (false == m_readId)
		{
			__super_t::sgetn(reinterpret_cast<char*>(&m_loc), sizeof(m_loc));
			m_readId = true;
		}

		if (m_index != m_loc)
			return;
	
		m_readId = false;
		x.m_f = true;

		serialize::_call_t<X::_T, set_data_caster, static_cast<serialize::eCategory>(serialize::what_is_category<nmsp::find_type_of<X::_T>::type>::category)>::called(x.m_t, *this);
	}
	template <typename X> inline void operator ()(X*& x)
	{
		++m_index;

		if (false == m_readId)
		{
			__super_t::sgetn(reinterpret_cast<char*>(&m_loc), sizeof(m_loc));
			m_readId = true;
		}

		if (m_index != m_loc)
			return;

		m_readId = false;
		x->m_f = true;

		serialize::_call_t<X::_T, set_data_caster, static_cast<serialize::eCategory>(serialize::what_is_category<nmsp::find_type_of<X::_T>::type>::category)>::called(x->m_t, *this);
	}

private:
	bool m_readId;
	short m_loc;
	short m_index;
};

} // nmsp

#endif
