﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __NMSPMEMORYPOOL_H__
#define __NMSPMEMORYPOOL_H__

//
namespace nmsp { namespace pool {

// 메모리 메모리풀 관리자를 만든다 mmgr을 이용해서
template <int MIN, int MAX, int ALIGNMENTSIZE, typename ALLOC>
class pool_mmgr : protected nmsp::mmgr<ALLOC, ALIGNMENTSIZE>
{
	using __parent_t = nmsp::mmgr<nmsp::default_allocator, ALIGNMENTSIZE>;

public:
	pool_mmgr()
	{
		m_bInitFlag = __parent_t::Init(MIN, MAX);
	}
	virtual ~pool_mmgr()
	{
		__parent_t::Uninit();
	}

public:
	inline void* Allocate(int nSize)
	{
		void* pRet;

		m_cLk.lock();

		pRet = __parent_t::Allocate(nSize);

		m_cLk.unlock();
		return pRet;
	}
	inline void Deallocate(void* pBack)
	{
		m_cLk.lock();

		__parent_t::Deallocate(pBack);

		m_cLk.unlock();
	}
	inline bool CheckMemory()
	{
		bool bRet;

		m_cLk.lock();

		bRet = __parent_t::CheckMemory();

		m_cLk.unlock();
		return bRet;
	}
	inline bool GetFreeStatus()
	{
		int nCount;

		m_cLk.lock();

		nCount = __parent_t::GetAllocationCount();

		m_cLk.unlock();

		return nCount ? false : true;
	}
	inline int GetAllocationCount()
	{
		int nCount;

		m_cLk.lock();

		nCount = __parent_t::GetAllocationCount();

		m_cLk.unlock();

		return nCount;
	}
	inline int GetCorruptCount()
	{
		int nCount;

		m_cLk.lock();

		nCount = __parent_t::GetCorruptCount();

		m_cLk.unlock();

		return nCount;
	}
	inline int GetFreeCount()
	{
		int nCount;

		m_cLk.lock();

		nCount = __parent_t::GetFreeCount();

		m_cLk.unlock();

		return nCount;
	}

public:
	inline bool GetInitFlag() const
	{
		return m_bInitFlag;
	}

private:
	std::mutex m_cLk;

private:
	bool m_bInitFlag;
};

// 의의 메모리 관리자를 이용해서... custom allocator를 만든다
#if defined(_DEBUG) || defined(_NMSP_MEMORY_POOL_CHECK_)
template <int MIN = 4, int MAX = 32768, int ALIGNMENTSIZE = (ALIGNMENT_DEFAULT_SIZE >> 1), typename ALLOC = nmsp::default_allocator>
#else
template <int MIN = 32, int MAX = 32768, int ALIGNMENTSIZE = ALIGNMENT_DEFAULT_SIZE, typename ALLOC = nmsp::default_allocator>
#endif
struct allocator_from_pool
{
public:
	allocator_from_pool()
	{
	}
	virtual ~allocator_from_pool()
	{
	}
	template <class T, class ..._ARGS_T>
	static T* Create(_ARGS_T&&... _ARGX)
	{
		void* pObject = m_cPoolMngr.Allocate(sizeof(T));
		if (nullptr == pObject)
		{
			return nullptr;
		}

		//
		new (pObject) T(std::forward<_ARGS_T>(_ARGX) ...);
		//

		return reinterpret_cast<T*>(pObject);
	}
	template <class T>
	static void Destroy(T* pT)
	{
		if (nullptr == pT)
		{
			return;
		}

		pT->~T();
		m_cPoolMngr.Deallocate(reinterpret_cast<void*>(pT));
	}
	template <class T>
	static T* CreateArray(int nSize)
	{
		T* pObject = reinterpret_cast<T*>(m_cPoolMngr.Allocate(sizeof(T) * nSize));
		if (nullptr == pObject)
		{
			return nullptr;
		}

		//
		for (int nStep = 0; nStep < nSize; nStep++)
		{
			new (pObject + nStep) T;
		}
		//

		return reinterpret_cast<T*>(pObject);
	}
	template <class T>
	static void DestroyArray(int nSize, T* pT)
	{
		if (nullptr == pT)
		{
			return;
		}

		for (int nStep = 0; nStep < nSize; nStep++)
		{
			pT[nStep].~T();
		}

		m_cPoolMngr.Deallocate(reinterpret_cast<void*>(pT));
	}
	static void* CreateMemory(int nSize)
	{
		void* pObject = m_cPoolMngr.Allocate(nSize);
		if (nullptr == pObject)
		{
			return nullptr;
		}

		return reinterpret_cast<void*>(pObject);
	}
	template <class T>
	static void* CreateMemory(int nSize, T _t)
	{
		void* pObject = m_cPoolMngr.Allocate(nSize);
		if (nullptr == pObject)
		{
			return nullptr;
		}

		return reinterpret_cast<void*>(pObject);
	}
	static void* RecreateMemory(void* pT, int nSizeForCopy, int nSize)
	{
		// 새로운 사이즈가 0일경우는 기존 버퍼를 해제한다.
		if (0 == nSize)
		{
			m_cPoolMngr.Deallocate(pT);
			return nullptr;
		}

		//
		void* pObject = m_cPoolMngr.Allocate(nSize);
		if (nullptr == pObject)
		{
			return nullptr;
		}

		//
		if (pT)
		{
			memcpy(pObject, pT, min(nSizeForCopy, nSize));
			m_cPoolMngr.Deallocate(pT);
		}

		return reinterpret_cast<void*>(pObject);
	}
	static void DestroyMemory(void* pT)
	{
		if (nullptr == pT)
		{
			return;
		}

		m_cPoolMngr.Deallocate(pT);
	}

private:
	static pool_mmgr<MIN, MAX, ALIGNMENTSIZE, ALLOC> m_cPoolMngr;
};

template <int MIN, int MAX, int ALIGNMENTSIZE, typename ALLOC>
pool_mmgr<MIN, MAX, ALIGNMENTSIZE, ALLOC> allocator_from_pool<MIN, MAX, ALIGNMENTSIZE, ALLOC>::m_cPoolMngr;

} } // pool		// nmsp

#endif

