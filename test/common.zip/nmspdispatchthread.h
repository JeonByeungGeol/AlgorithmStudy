﻿////////////////////////////////////////////////////////////////////////////////
//
// 작성자 : huelee
// 설  명 : 
//

#pragma once
#ifndef __NMSPDISPATCHTHREAD_H__
#define __NMSPDISPATCHTHREAD_H__

//
namespace nmsp {

// _QUEUE는 thread-safty하여야 한다..
template <typename _PARAMETER, typename _ALLOCATOR, template <typename T = _PARAMETER, typename A = _ALLOCATOR> class _QUEUE>
class dispatch_thread
{
public:
	using _queue_param_t = _PARAMETER;

protected:
	using _allocator_t = _ALLOCATOR;
	using _queue_t = _QUEUE<_queue_param_t, _allocator_t>;

public:
	dispatch_thread()
	{
		m_bEnd = false;
	}
	virtual ~dispatch_thread() = default;
	bool Init(int cnt, int timeout = 0x7FFFFFFF)
	{
		try
		{
			if (false == m_vecThr.empty())
				return false;

			for (int nI = 0; nI < cnt; ++nI)
			{
				std::unique_ptr<std::thread> thr = std::make_unique<std::thread>([this, timeout]()
				{
					while (false == m_bEnd)
					{
						_queue_param_t n;
						if (false == m_queue.try_pop(n))
						{
							PreIdle();

							std::cv_status cv = m_cSync.Wait(timeout, [this]() -> bool {
								return !m_queue.empty() || true == m_bEnd;
							});

							PostIdle(cv);
							continue;
						}

						this->Pop(std::move(n));
					}
				});

				m_vecThr.push_back(std::move(thr));
			}
		}
		catch (std::exception&)
		{
			return false;
		}

		return true;
	}
	bool DoEnd()
	{
		m_bEnd = true;
		m_cSync.SetNotificationAll();

		return true;
	}
	void Uninit()
	{
		for (auto& itr : m_vecThr)
		{
			if (true == (*itr).joinable())
				(*itr).join();
		}
	}
	// queue
	bool Push(_queue_param_t&& n)
	{
		m_queue.push(std::forward<_queue_param_t>(n));

		m_cSync.SetNotification([this]() -> bool {
			return !m_queue.empty();
		});
		return true;
	}
	virtual void Pop(_queue_param_t&& n) = 0;
	virtual void PreIdle() {}
	virtual void PostIdle(std::cv_status cv) {}
	bool Empty()
	{
		return m_queue.empty();
	}
	const _queue_t * const GetQueue() const
	{
		return &m_queue;
	}

private:
	_queue_t m_queue;
	std::vector<std::unique_ptr<std::thread>> m_vecThr;
	nmsp::thread_for_condition m_cSync;
	bool m_bEnd;
};

}

#endif
