////////////////////////////////////////////////////////////////////////////////
//
// �ۼ��� : huelee
// ��  �� : 
//

#pragma once

namespace nmsp {

// floating-point exception ������ ����..Ŭ����.
// �����  windows��
class control_fp_em
{
public:
	static const uint32_t NEXACT = _EM_INEXACT;
	static const uint32_t NDERFLOW = _EM_UNDERFLOW;
	static const uint32_t VERFLOW = _EM_OVERFLOW;
	static const uint32_t ERODIVIDE = _EM_ZERODIVIDE;
	static const uint32_t NVALID = _EM_INVALID;
	static const uint32_t ENORMAL = _EM_DENORMAL;

public:
	control_fp_em(uint32_t newCheck = 0)
	{
		_controlfp_s(&m_save, 0, 0);  
		_clearfp();
		_controlfp_s(0, ~newCheck, _MCW_EM);
	}
	~control_fp_em()
	{
		_clearfp();
		_controlfp_s(0, m_save, _MCW_EM);
	}

private:
	uint32_t m_save;
};

}
