////////////////////////////////////////////////////////////////////////////////
// �ۼ��� : huelee
// ��  �� : 
//

#pragma once
#ifndef __NMSPCOMPONENTMAIN_H__
#define __NMSPCOMPONENTMAIN_H__

#define IMPLEMENT_NMSPMODULE(T)	\
extern "C" int ComGetClassObject(const nmsp::UUID* iid, void** ppv) \
{ \
	T* piComponent = new T(); \
	if (nullptr == piComponent) \
		return nmsp::make_nmsp_error(nmsp::_NMSP_RESERVED_SERVICETYPE_CONTAINER, nmsp::_CONTAINER_ERROR_CREATION_COMPONENT ); \
	int nRet = piComponent->QueryInterface(iid, ppv); \
	piComponent->Release(); \
	return nRet; \
}

#endif
