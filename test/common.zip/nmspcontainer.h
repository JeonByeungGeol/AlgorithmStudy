////////////////////////////////////////////////////////////////////////////////
// �ۼ���: 
// ��  ��:
//
//

// ȣȯ���� ���ؼ�..
#pragma once
#ifndef __NMSPCONTAINER_H__
#define __NMSPCONTAINER_H__

#ifdef _DEBUG
using _allocator_t = nmsp::default_allocator;
#else
using _allocator_t = nmsp::pool::allocator_from_pool<>;
#endif

template <typename Ty>
using _stl_allocator_t = nmsp::stl_default_allocator<Ty, _allocator_t>;

namespace nmsp 
{
namespace type
{
template <typename _Kty, typename _Ty>
using unordered_map = std::unordered_map< _Kty, _Ty, std::hash<_Kty>, std::equal_to<_Kty>, _stl_allocator_t<std::pair<const _Kty, _Ty>>>;

template <typename _Kty, typename _Ty>
using map = std::map<_Kty, _Ty, std::less<_Kty>, _stl_allocator_t<std::pair<const _Kty, _Ty>>>;

template <typename _Kty>
using set = std::set<_Kty, std::less<_Kty>, _stl_allocator_t<_Kty>>;

template <typename _Ty>
using vector = std::vector<_Ty, _stl_allocator_t<_Ty>>;

template <typename _Ty>
using list = std::list<_Ty, _stl_allocator_t<_Ty>>;

template <typename _Ty>
using queue = std::queue<_Ty, std::deque<_Ty, _stl_allocator_t<_Ty>>>;
}
} // nmsp

#endif
