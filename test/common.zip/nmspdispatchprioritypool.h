﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __NMSPDISPATCHPRIORITYPOOL_H__
#define __NMSPDISPATCHPRIORITYPOOL_H__

//
namespace nmsp {

////////////////////////////////////////////////////////////////////////////////
// 전방선언
template <class KEY, class ALLOC> class dispatch_priority_queue_element;
template <class KEY, class ALLOC> class dispatch_priority_queue;
template <class KEY, class ALLOC> class dispatch_priority_thr;
template <class KEY, class ALLOC> class dispatch_priority_pool;

////////////////////////////////////////////////////////////////////////////////
// dispatch_priority_pool의 queue에 등록될 객체의 베이스 클래스로서 사용할 클래스
template <class KEY, class ALLOC>
class dispatch_priority_queue_element
{
	template <class KEY, class ALLOC> friend class dispatch_priority_queue;

public:
	typedef KEY _key_t;
	typedef ALLOC _allocator_t;
	typedef unsigned __int64 _dpqe_time_t; // milisecond 
	typedef dispatch_priority_queue<_key_t, _allocator_t> _dpq_t;
	typedef dispatch_priority_thr<_key_t, _allocator_t> _dpt_t;

	// Process() 가상 함수에 의해 리턴되는 값을 정의함.
	typedef enum
	{
		_DPQE_RET_PROCESS_DONT_WANT_ENQUEUE,		// 다시 queue에 넣지 말기를 바라는...
		_DPQE_RET_PROCESS_WANT_ENQUEUE,				// queue에 넣어주기를 원하는..
	} _dpqe_ret_process_t;
	//

private:
	typedef dispatch_priority_queue_element<_key_t, _allocator_t> __this_t;

public:
	dispatch_priority_queue_element() 
		: m_nRefs(0)
	{
		m_kVal = 0;
		m_dpVal = 0;
		m_dpVal2 = 0;
		m_bReg = false;
		m_bEnqueue = false;
	}
	dispatch_priority_queue_element(const _key_t& kVal) 
		: m_nRefs(0)
	{
		m_kVal = kVal;
		m_dpVal = 0;
		m_dpVal2 = 0;
		m_bReg = false;
		m_bEnqueue = false;
	}
	virtual ~dispatch_priority_queue_element()
	{
	}
	dispatch_priority_queue_element(const __this_t&) = delete;
	void operator =(const __this_t&) = delete;

public:
	virtual _dpqe_ret_process_t Process(_dpt_t* pcThr, _dpq_t* pcQueue, _dpqe_time_t* pdpVal)
	{
		*pdpVal = m_dpVal;

		return _DPQE_RET_PROCESS_WANT_ENQUEUE;
	}

protected:
	inline void SetKeyValue(const _key_t& kVal) 
	{
		m_kVal = kVal;
	}

public:
	inline const _key_t& GetKeyValue() const
	{
		return m_kVal;
	}
	inline const _dpqe_time_t& GetPriority() const
	{ 
		return m_dpVal; 
	}
	inline int AddRef()
	{
		return ++m_nRefs;
	}
	inline int Release()
	{
		int nRefs = --m_nRefs;
		if (0 == nRefs)
		{
			ALLOC::Destroy(this);
			return 0;
		}

		return nRefs;
	}

private:
	inline void SetPriority(const _dpqe_time_t& dpVal) 
	{ 
		m_dpVal = dpVal; 
	}
	inline void SetPriority2(const _dpqe_time_t& dpVal2) 
	{ 
		m_dpVal2 = dpVal2; 
	}
	inline const _dpqe_time_t& GetPriority2() const
	{ 
		return m_dpVal2; 
	}
	inline void SetRegFlag(bool bFlag) 
	{
		m_bReg = bFlag;
	}
	inline bool GetRegFlag() const
	{
		return m_bReg;
	}
	inline void SetEnqueueFlag(bool bFlag) 
	{
		m_bEnqueue = bFlag;
	}
	inline bool GetEnqueueFlag() const
	{
		return m_bEnqueue;
	}
	inline bool operator <(const __this_t& cFromObj) const
	{
		if (m_dpVal < cFromObj.m_dpVal)
		{
			return true;
		}

		if (m_dpVal == cFromObj.m_dpVal && m_dpVal2 < cFromObj.m_dpVal2)
		{
			return true;
		}

		return false;
	}

private:
	_key_t m_kVal;
	_dpqe_time_t m_dpVal;
	_dpqe_time_t m_dpVal2;
	bool m_bReg;
	bool m_bEnqueue;
	std::atomic_int m_nRefs;
};

////////////////////////////////////////////////////////////////////////////////
// dispatch_priority_pool의 queue 구현 클래스
template <class KEY, class ALLOC>
class dispatch_priority_queue
{
public:
	typedef KEY _key_t;
	typedef ALLOC _allocator_t;
	typedef std::less<_key_t> _compare_t;
	typedef dispatch_priority_queue_element<_key_t, _allocator_t> _value_t;
	typedef dispatch_priority_thr<_key_t, _allocator_t> _thr_t;
	typedef dispatch_priority_pool<_key_t, _allocator_t> _container_t;
	typedef std::vector<_value_t*, stl_default_allocator<_value_t*,_allocator_t>> _vec_value_t;

	friend class _thr_t;
	friend class _container_t;

private:
	struct CLess
	{	
		inline bool operator()(const typename _value_t* pcVal1, const typename _value_t* pcVal2) const
		{
			return (*pcVal1 < *pcVal2);
		}
	};

public:
	typedef typename _value_t::_dpqe_time_t _dpqe_time_t;

private:
	typedef std::pair<_value_t* const, _value_t*> _DPQE_PRIORITY_PAIR_T;
	typedef std::multimap<_value_t*, _value_t*, CLess, stl_default_allocator<_DPQE_PRIORITY_PAIR_T, _allocator_t>> _DPQE_QUEUE_T;
	typedef std::map<_key_t, _value_t*, _compare_t, stl_default_allocator<std::pair<const _key_t, _value_t*>, _allocator_t>> _MAP_T;

public:
	// dequeue에 의해 리턴되는 값의 종류
	typedef enum
	{
		_DPQ_DEQUEUE_RET_NO_ELEMENT,					// queue가 비였음
		_DPQ_DEQUEUE_RET_NO_ELEMENT_IN_PRIORITY,		// 해당 priority에 해당하는 element가 없음
		_DPQ_DEQUEUE_RET_OK,							// element를 리턴
	} _dpqe_dequeue_ret;

private:
	dispatch_priority_queue()
	{
		m_dpSeq = 0;
		m_dpVal = 0;
	}
	virtual ~dispatch_priority_queue()
	{
		for_each(m_cObjes.begin(), m_cObjes.end(), [](const _MAP_T::value_type& _t) { _t.second->Release(); });
		for_each(m_cDpoeQueue.begin(), m_cDpoeQueue.end(), [](const _DPQE_QUEUE_T::value_type& _t) { _t.second->Release(); });
	}

	bool Init();
	void Uninit();
	bool Add(const _key_t& kVal, _value_t* pcVal);
	bool Del(const _key_t& kVal);
	template <typename T> bool Find(const _key_t& kVal, T** ppcVal);
	bool Is(const _key_t& kVal);
	void FetchAll(_vec_value_t& vecValue);
	template <typename F>void Fetch(_vec_value_t& vecValue, F& f);

	// SetPriority에 의해 설정된 priority를 가지고 dequeue를 수행한다.
	// _DPQ_DEQUEUE_RET_NO_ELEMENT가 리턴되는 경우는 dpNext, ppcVal 이 인수가 모두 유효하지 않음
	// _DPQ_DEQUEUE_RET_NO_ELEMENT_IN_PRIORITY가 리턴되는 경우는 dpNext 만 유효함
	// _DPQ_DEQUEUE_RET_OK가 리턴되는 경우는 dpNext, ppcVal 유효함
	_dpqe_dequeue_ret Dequeue(_dpqe_time_t* pdpNext, _value_t** ppcVal);
	//

	// 강제로 queue에서 빼내기 위하여 사용하는 함수.
	bool Dequeue(const _key_t& kVal);
	//

	// dpVal은 milisecond단위의 시간이어야 한다.. 
	bool Enqueue(const _dpqe_time_t& dpVal, _value_t* pcVal);
	bool Enqueue(const _key_t& kVal, const _dpqe_time_t& dpVal);
	//

	unsigned int GetQueueCount();
	unsigned int GetCount();

	//
	inline _dpqe_time_t GetPriority() const
	{
		return m_dpVal;
	}
	// dpVal은 milisecond단위의 시간이어야 한다.. 
	inline void SetPriority(const _dpqe_time_t& dpVal)
	{
		m_dpVal = dpVal;
	}

private:
	std::shared_mutex m_cRwLock;
	std::mutex m_cLock;

private:
	_MAP_T m_cObjes;
	_DPQE_QUEUE_T m_cDpoeQueue;
	_dpqe_time_t m_dpSeq;
	std::atomic<_dpqe_time_t> m_dpVal;
};

template <class KEY, class ALLOC>
bool
dispatch_priority_queue<KEY, ALLOC>::Init()
{
	return true;
}

template <class KEY, class ALLOC>
void
dispatch_priority_queue<KEY, ALLOC>::Uninit()
{
	_MAP_T cObjes;
	_DPQE_QUEUE_T cDpoeQueue;

	//
	{
		m_cRwLock.lock();

		cObjes = m_cObjes;
		m_cObjes.clear();

		m_cRwLock.unlock();
	}

	//
	{
		m_cLock.lock();

		cDpoeQueue = m_cDpoeQueue;
		m_cDpoeQueue.clear();

		m_cLock.unlock();
	}

	// 객체의 참조수를 감소시킨다
	for_each(cObjes.begin(), cObjes.end(), [](const _MAP_T::value_type& _t) { _t.second->Release(); });
	for_each(cDpoeQueue.begin(), cDpoeQueue.end(), [](const _DPQE_QUEUE_T::value_type& _t) { _t.second->Release(); });
}

//
// SetPriority에 의해 설정된 priority를 가지고 dequeue를 수행한다.
// _DPQ_DEQUEUE_RET_NO_ELEMENT가 리턴되는 경우는 dpNext, ppcVal 이 인수가 모두 유효하지 않음
// _DPQ_DEQUEUE_RET_NO_ELEMENT_IN_PRIORITY가 리턴되는 경우는 dpNext 만 유효함
// _DPQ_DEQUEUE_RET_OK가 리턴되는 경우는 dpNext, ppcVal 유효함
//
template <class KEY, class ALLOC>
typename dispatch_priority_queue<KEY, ALLOC>::_dpqe_dequeue_ret
dispatch_priority_queue<KEY, ALLOC>::Dequeue(_dpqe_time_t* pdpNext, _value_t** ppcVal)
{
	_DPQE_QUEUE_T::iterator itrFirst;

	//
	m_cLock.lock();

	//
	if ((itrFirst = m_cDpoeQueue.begin()) == m_cDpoeQueue.end())
	{
		m_cLock.unlock();

		return _DPQ_DEQUEUE_RET_NO_ELEMENT;
	}

	//
	if (itrFirst->first->GetPriority() >= m_dpVal)
	{
		*pdpNext = itrFirst->first->GetPriority();

		//
		m_cLock.unlock();

		return _DPQ_DEQUEUE_RET_NO_ELEMENT_IN_PRIORITY;
	}

	// 성공적인 결과를...
	*ppcVal = itrFirst->second;

	//
	*pdpNext = (*ppcVal)->GetPriority();
	
	//
	(*ppcVal)->SetEnqueueFlag(false);

	//
	m_cDpoeQueue.erase(itrFirst);

	//
	m_cLock.unlock();

	return _DPQ_DEQUEUE_RET_OK;
}

template <class KEY, class ALLOC>
bool
dispatch_priority_queue<KEY, ALLOC>::Dequeue(const _key_t& kVal)
{
	smartinterface<_value_t> cVal;

	//
	{
		m_cRwLock.lock_shared();

		// 검색
		auto itrEvent = m_cObjes.find(kVal);
		if (itrEvent == m_cObjes.end())
		{
			m_cRwLock.unlock_shared();
			return false;
		}

		cVal = itrEvent->second;

		m_cRwLock.unlock_shared();
	}

	// 찾는 객체가 없다면 오류..
	if (nullptr == cVal)
		return false;

	//
	{
		m_cLock.lock();

		// queue에 들어 있는 것을.. 조회한다.
		std::pair<_DPQE_QUEUE_T::iterator, _DPQE_QUEUE_T::iterator> itrRanges = m_cDpoeQueue.equal_range(cVal);
		if (itrRanges.first == itrRanges.second)
		{
			pcVal->SetEnqueueFlag(false);

			m_cLock.unlock();
			return true;
		}

		//
		for (_DPQE_QUEUE_T::iterator itrCurr = itrRanges.first; itrCurr != itrRanges.second; ++itrCurr)
		{
			if (itrCurr->second->GetKeyValue() != kVal)
				continue;

			//
			_value_t* pcVal2 = itrCurr->second;

			//
			m_cDpoeQueue.erase(itrCurr);

			//
			pcVal2->SetEnqueueFlag(false);

			//
			m_cLock.unlock();

			//
			pcVal2->Release();

			return true;
		}

		//
		cVal->SetEnqueueFlag(false);

		//
		m_cLock.unlock();
	}

	return true;
}

template <class KEY, class ALLOC>
bool
dispatch_priority_queue<KEY, ALLOC>::Enqueue(const _dpqe_time_t& dpVal, _value_t* pcVal)
{
	m_cLock.lock();

	//
	if (false == pcVal->GetRegFlag() || true == pcVal->GetEnqueueFlag())
	{
		m_cLock.unlock();
		return false;
	}

	//
	pcVal->SetPriority(dpVal);
	pcVal->SetPriority2(++m_dpSeq);

	//
	m_cDpoeQueue.emplace(pcVal, pcVal);
	
	//
	pcVal->AddRef();
	pcVal->SetEnqueueFlag(true);

	//
	m_cLock.unlock();

	return true;
}

template <class KEY, class ALLOC>
bool
dispatch_priority_queue<KEY, ALLOC>::Enqueue(const _key_t& kVal, const _dpqe_time_t& dpVal)
{
	smartinterface<_value_t> cVal;

	//
	{
		m_cRwLock.lock_shared();

		_MAP_T::iterator itrEvent = m_cObjes.find(kVal);
		if (itrEvent == m_cObjes.end())
		{
			m_cRwLock.unlock_shared();
			return false;
		}

		//
		cVal = itrEvent->second;

		m_cRwLock.unlock_shared();
	}

	//
	if (nullptr == cVal)
		return false;

	//
	{
		m_cLock.lock();

		//
		if (true == cVal->GetEnqueueFlag())
		{
			m_cLock.unlock();
			return false;
		}

		//
		cVal->SetPriority(dpVal);
		cVal->SetPriority2(++m_dpSeq);

		//
		m_cDpoeQueue.insert(_DPQE_PRIORITY_PAIR_T(cVal, cVal));

		//
		cVal->AddRef();
		cVal->SetEnqueueFlag(true);

		//
		m_cLock.unlock();
	}

	return true;
}

template <class KEY, class ALLOC>
unsigned int
dispatch_priority_queue<KEY, ALLOC>::GetQueueCount()
{
	unsigned int unCount;

	m_cLock.lock();
	
	//
	unCount = static_cast<unsigned int>(m_cDpoeQueue.size());
	//

	m_cLock.unlock();

	return unCount;
}

template <class KEY, class ALLOC>
unsigned int
dispatch_priority_queue<KEY, ALLOC>::GetCount()
{
	unsigned int unCount;

	m_cRwLock.lock_shared();
	
	//
	unCount = static_cast<unsigned int>(m_cObjes.size());
	//

	m_cRwLock.unlock_shared();

	return unCount;
}

template <class KEY, class ALLOC>
bool
dispatch_priority_queue<KEY, ALLOC>::Add(const _key_t& kVal, _value_t* pcVal)
{
	m_cRwLock.lock();

	//
	std::pair<_MAP_T::iterator, bool> pairRetEvent = m_cObjes.insert(_MAP_T::value_type(kVal, pcVal));
	if (false == pairRetEvent.second)
	{
		m_cRwLock.unlock();
		return false;
	}

	//
	pcVal->SetRegFlag(true);
	pcVal->SetEnqueueFlag(false);
	pcVal->AddRef();

	//
	m_cRwLock.unlock();

	return true;
}

template <class KEY, class ALLOC>
bool
dispatch_priority_queue<KEY, ALLOC>::Del(const _key_t& kVal)
{
	smartinterface<_value_t> cVal;
	{
		m_cRwLock.lock();

		//
		_MAP_T::iterator itrEvent = m_cObjes.find(kVal);
		if (itrEvent == m_cObjes.end())
		{
			m_cRwLock.unlock();
			return false;
		}

		// 보관을 하고
		cVal = itrEvent->second;
		// 참조를 하나 지운다
		itrEvent->second->Release();

		m_cObjes.erase(itrEvent);

		m_cRwLock.unlock();
	}

	//
	if (nullptr == cVal)
		return false;

	//
	{
		m_cLock.lock();

		auto itrRanges = m_cDpoeQueue.equal_range(cVal);
		if (itrRanges.first == itrRanges.second)
		{
			cVal->SetRegFlag(false);
			cVal->SetEnqueueFlag(false);

			//
			m_cLock.unlock();
			return true;
		}

		//
		for (auto itrCurr = itrRanges.first; itrCurr != itrRanges.second; ++itrCurr)
		{
			if (itrCurr->second->GetKeyValue() != kVal)
				continue;

			_value_t* pcVal2 = itrCurr->second;

			m_cDpoeQueue.erase(itrCurr);

			//
			cVal->SetRegFlag(false);
			pcVal2->SetEnqueueFlag(false);

			//
			m_cLock.unlock();

			//
			pcVal2->Release();

			return true;
		}

		//
		cVal->SetRegFlag(false);
		cVal->SetEnqueueFlag(false);

		//
		m_cLock.unlock();
	}

	return true;
}

template <class KEY, class ALLOC>
template <typename T>
bool
dispatch_priority_queue<KEY, ALLOC>::Find(const _key_t& kVal, T** ppcVal)
{
	m_cRwLock.lock_shared();

	//
	_MAP_T::iterator itrEvent = m_cObjes.find(kVal);
	if (itrEvent == m_cObjes.end())
	{
		m_cRwLock.unlock_shared();
		return false;
	}

	//
	*ppcVal = static_cast<T*>(itrEvent->second);

	// 참조 카운트를 증가한다..
	(*ppcVal)->AddRef();

	//
	m_cRwLock.unlock_shared();

	return true;
}

template <class KEY, class ALLOC>
bool
dispatch_priority_queue<KEY, ALLOC>::Is(const _key_t& kVal)
{
	m_cRwLock.lock_shared();

	//
	_MAP_T::iterator itrEvent = m_cObjes.find(kVal);
	if (itrEvent == m_cObjes.end())
	{
		m_cRwLock.unlock_shared();
		return false;
	}
	//

	m_cRwLock.unlock_shared();
	return true;
}

template <class KEY, class ALLOC>
void
dispatch_priority_queue<KEY, ALLOC>::FetchAll(_vec_value_t& vecValue)
{
	m_cRwLock.lock_shared();

	//
	//for_each(m_cObjes.begin(), m_cObjes.end(), CAdaptorFetch<_DPQE_ID_PAIR_T>(vecValue));
	vecValue.reserve(m_cObjes.size());
	for_each(m_cObjes.begin(), m_cObjes.end(), [&vecValue](_MAP_T::value_type& _t)
	{ 
		_t.second->AddRef(); 
		vecValue.push_back(_t.second); 
	});
	//

	m_cRwLock.unlock_shared();
}

template <class KEY, class ALLOC>
template <class F>
void
dispatch_priority_queue<KEY, ALLOC>::Fetch(_vec_value_t& vecValue, F& f)
{
	m_cRwLock.lock_shared();

	//
	//for_each(m_cObjes.begin(), m_cObjes.end(), CAdaptorFetch<_DPQE_ID_PAIR_T>(vecValue));
	vecValue.reserve(m_cObjes.size());
	for_each(m_cObjes.begin(), m_cObjes.end(), [&vecValue, &f](_MAP_T::value_type& _t)
	{
		if (false == f(_t.second))
			continue;

		_t.second->AddRef();
		vecValue.push_back(_t.second);
	});
	//

	m_cRwLock.unlock_shared();
}

////////////////////////////////////////////////////////////////////////////////
// dispatch_priority_pool의 쓰레드 구현 클래스
template <class KEY, class ALLOC>
class dispatch_priority_thr: public node
{
public:
	typedef KEY _key_t;
	typedef ALLOC _allocator_t;
	typedef dispatch_priority_queue_element<_key_t, _allocator_t> _value_t;
	typedef dispatch_priority_queue<_key_t, _allocator_t> _dpq_t;
	typedef dispatch_priority_pool<_key_t, _allocator_t> _container_t;
	typedef typename _dpq_t::_dpqe_time_t _dpqe_time_t;

	friend class _dpq_t;
	friend class _container_t;

public:
	dispatch_priority_thr(_dpq_t* pcQueue);
	virtual ~dispatch_priority_thr();

	virtual bool DoEnd();
	virtual bool Start();
	virtual void End();

	virtual int AddRef() override;
	virtual int Release() override;
	virtual int CompareTo(const node *pcNode) override;

	// 다음 타임아웃을.. 리턴한다.
	virtual unsigned int OnProcess();

public:
	inline void SetTimeout(unsigned int unTimeout) 
	{
		m_unTimeout = unTimeout;
	} 
	inline unsigned int GetTimeout() const
	{
		return m_unTimeout;
	}
	inline _dpq_t* GetQueue()
	{
		return m_pcQueue;
	}

private:
	bool m_bEnd;
	std::unique_ptr<std::thread> m_cThr;
	thread_for_condition m_cSync;
	int m_unTimeout;
	_dpq_t* m_pcQueue;

private:
	std::atomic_int m_nRefs;
};

template <class KEY, class ALLOC>
dispatch_priority_thr<KEY, ALLOC>::dispatch_priority_thr(_dpq_t* pcQueue)
	:m_pcQueue(pcQueue)
	,m_nRefs(1)
{
	m_bEnd = false;
	m_unTimeout = 0x7FFFFFFF;
}

template <class KEY, class ALLOC>
dispatch_priority_thr<KEY, ALLOC>::~dispatch_priority_thr()
{
}

template <class KEY, class ALLOC>
int
dispatch_priority_thr<KEY, ALLOC>::AddRef()
{
	return ++m_nRefs;
}

template <class KEY, class ALLOC>
int
dispatch_priority_thr<KEY, ALLOC>::Release()
{
	int nRefs = --m_nRefs;

	if (0 == nRefs)
	{
		_allocator_t::Destroy(this);
		return 0;
	}

	return nRefs;
}

template <class KEY, class ALLOC>
int
dispatch_priority_thr<KEY, ALLOC>::CompareTo(const node *pcNode)
{
	if (pcNode == static_cast<node*>(this))
		return 0;
	else
	if (pcNode > static_cast<node*>(this))
		return 1;

	return -1;
}

template <class KEY, class ALLOC>
bool
dispatch_priority_thr<KEY, ALLOC>::Start()
{
	try
	{
		if (nullptr == m_pcQueue)
			return false;

		m_cThr = std::make_unique<std::thread>([this]()
		{
			int unTimeout = m_unTimeout;

			while (false == m_bEnd)
			{
				m_cSync.Wait(unTimeout);
				unTimeout = OnProcess();
			}
		});
	}
	catch (std::exception&)
	{
		return false;
	}

	return true;
}

template <class KEY, class ALLOC>
bool
dispatch_priority_thr<KEY, ALLOC>::DoEnd()
{
	if (nullptr == m_pcQueue)
		return false;

	m_bEnd = true;
	m_cSync.SetNotificationAll();

	return true;
}

template <class KEY, class ALLOC>
void
dispatch_priority_thr<KEY, ALLOC>::End()
{
	m_cThr->join();
}

template <class KEY, class ALLOC>
unsigned int
dispatch_priority_thr<KEY, ALLOC>::OnProcess()
{
	_dpqe_time_t dpNext;
	_value_t* pcVal;

	// 일단 일하기 시작하면.. 멈추지 말자..
	do
	{
		switch (m_pcQueue->Dequeue(&dpNext, &pcVal))
		{
		// 아직 실행할게 없다면.. 쉬어야지..
		case _dpq_t::_DPQ_DEQUEUE_RET_NO_ELEMENT_IN_PRIORITY:
			dpNext -= m_pcQueue->GetPriority();
			if (dpNext <= 0)
			{
				return 1;
			}

			if (dpNext > m_unTimeout)
			{
				return m_unTimeout;
			}

			return static_cast<unsigned int>(dpNext);
		// 스케줄 대상이 되는게 있다면.. 루프를 돌면서 처리하자..
		case _dpq_t::_DPQ_DEQUEUE_RET_OK:
			// 개별 객체의 처리, 처리후에 Queue에 넣을때 사용할 priority값을 리턴한다.
			if (_value_t::_DPQE_RET_PROCESS_WANT_ENQUEUE == pcVal->Process(this, m_pcQueue, &dpNext))
			{
				// 다시 Queue에 넣는다..
				m_pcQueue->Enqueue(dpNext, pcVal);
			}
		
			//
			pcVal->Release();
			break;

		// 스케줄 Queue에 아무것도 없다.. 그럼 디폴트 SLEEP TIME으로 리턴하자...
		default:
			return m_unTimeout;
		} 
	} while (false == m_bEnd);

	// 종료 처리..(종료시가 아니면 여기에 올일이 없다)
	return m_unTimeout;
}

////////////////////////////////////////////////////////////////////////////////
// 우선순위 queue 구현
template <class KEY, class ALLOC>
class dispatch_priority_pool
{
public:
	typedef KEY _key_t;
	typedef ALLOC _allocator_t;
	typedef dispatch_priority_queue<_key_t, _allocator_t> _dpq_t;
	typedef typename _dpq_t::_vec_value_t _vec_value_t;
	typedef dispatch_priority_thr<_key_t, _allocator_t> _thr_t;
	typedef dispatch_priority_queue_element<_key_t, _allocator_t> _value_t;
	typedef both_list _container_list_t;

public:
	dispatch_priority_pool();
	virtual ~dispatch_priority_pool();

	template <class THREAD> bool Init(const typename _value_t::_dpqe_time_t& dpVal, unsigned int unThrCount, unsigned int unTimeout);
	void Uninit();

public:
	template <class OBJ, class ..._ARGS_T> bool Add(const _key_t& kVal, _ARGS_T&&... _ARGX);
	//inline bool Add(const _key_t& kVal, _value_t* pcVal) { return m_cQueue.Add(kVal, pcVal); }
	inline bool Del(const _key_t& kVal) { return m_cQueue.Del(kVal); }
	inline bool Enqueue(const _key_t& kVal, const typename _value_t::_dpqe_time_t& dpVal) { return m_cQueue.Enqueue(kVal, dpVal); }
	inline void SetPriority(const typename _value_t::_dpqe_time_t& dpVal) { m_cQueue.SetPriority(dpVal); }

	// 강제로 0으로 초기화했다면 몰라도...
	// return값이 0이면 한번도 초기화가 안된것으로 간주할수 있습니다...
	inline typename _value_t::_dpqe_time_t GetPriority() { return m_cQueue.GetPriority(); }
	//

	template <typename T> inline bool Find(const _key_t& kVal, T** value) { return m_cQueue.Find<T>(kVal, value); }
	inline bool Is(const _key_t& kVal) { return m_cQueue.Is(kVal); }
	inline void FetchAll(_vec_value_t& vecValues) { m_cQueue.FetchAll(vecValues);}
	inline unsigned int GetCount() { return m_cQueue.GetCount(); }

private:
	std::mutex m_cLock;

private:
	_dpq_t m_cQueue;
	_container_list_t m_cThrList;
};

template <class KEY, class ALLOC>
dispatch_priority_pool<KEY, ALLOC>::dispatch_priority_pool() 
{
}

template <class KEY, class ALLOC>
dispatch_priority_pool<KEY, ALLOC>::~dispatch_priority_pool() 
{
	_thr_t* pcCurr = static_cast<_thr_t*>(m_cThrList.GetBegin());
	while (pcCurr)
	{
		pcCurr->DoEnd();
		pcCurr = static_cast<_thr_t*>(pcCurr->GetNext());
	}

	pcCurr = static_cast<_thr_t*>(m_cThrList.GetBegin());
	while (pcCurr)
	{
		pcCurr->End();
		pcCurr = static_cast<_thr_t*>(pcCurr->GetNext());
	}

	while(false == m_cThrList.IsEmpty())
	{
		pcCurr = static_cast<_thr_t*>(m_cThrList.DelBeginWithLive());
		pcCurr->Release();
	}
}

template <class KEY, class ALLOC>
template <class THREAD> 
bool
dispatch_priority_pool<KEY, ALLOC>::Init(const typename _value_t::_dpqe_time_t& dpVal, unsigned int unThrCount, unsigned int unTimeout)
{
	//
	if (false == m_cQueue.Init())
		return false;

	m_cQueue.SetPriority(dpVal);
	//

	m_cLock.lock();

	//
	for (unsigned int unCnt = 0; unCnt < unThrCount; unCnt++)
	{
		_thr_t* pcThr = _allocator_t::Create<THREAD>(&m_cQueue);
		if (nullptr == pcThr)
		{
			m_cLock.unlock();
			return false;
		}

		//
		pcThr->SetTimeout(unTimeout);

		//
		if (false == pcThr->Start())
		{
			pcThr->Release();

			m_cLock.unlock();
			return false;
		}
	
		m_cThrList.Add(pcThr);
	}
	//

	m_cLock.unlock();

	return true;
}

template <class KEY, class ALLOC>
void
dispatch_priority_pool<KEY, ALLOC>::Uninit()
{
	m_cLock.lock();

	//
	_thr_t* pcCurr = static_cast<_thr_t*>(m_cThrList.GetBegin());
	while (pcCurr)
	{
		pcCurr->DoEnd();
		pcCurr = static_cast<_thr_t*>(pcCurr->GetNext());
	}

	pcCurr = static_cast<_thr_t*>(m_cThrList.GetBegin());
	while (pcCurr)
	{
		pcCurr->End();
		pcCurr = static_cast<_thr_t*>(pcCurr->GetNext());
	}
	//

	while(false == m_cThrList.IsEmpty())
	{
		pcCurr = static_cast<_thr_t*>(m_cThrList.DelBeginWithLive());
		pcCurr->Release();
	}
	//

	m_cLock.unlock();

	//
	m_cQueue.Uninit();
	//
}

template <class KEY, class ALLOC>
template <class OBJ, class ..._ARGS_T>
bool
dispatch_priority_pool<KEY, ALLOC>::Add(const _key_t& kVal, _ARGS_T&&... _ARGX)
{
	_value_t* pcValue = _allocator_t::Create<OBJ>(kVal, std::forward<_ARGS_T>(_ARGX) ...);
	if (nullptr == pcValue)
		return false;

	return m_cQueue.Add(kVal, pcValue);
}

} // namespace nmsp

#endif
