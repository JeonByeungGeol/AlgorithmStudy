﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __NMSPNET_H__
#define __NMSPNET_H__

#define __USE_SEND_STRAND__ 1
#define __USE_RECV_STRAND__ 1
#define __SEND_VECTOR__ 1

// 
namespace nmsp { 

// custom allocator를 만들자
template <typename ALLOC, typename HANDLER>
class custom_alloc_handler
{
public:
	using _allocator_t = ALLOC;

public:
	custom_alloc_handler(const HANDLER& h)
		: m_handler(h)
	{
	}
	template <typename ..._ARGX_T>
	void operator()(_ARGX_T&&... _ARGX)
	{
		m_handler(std::forward<_ARGX_T>(_ARGX) ...);
	}
	friend void* asio_handler_allocate(std::size_t size,
		custom_alloc_handler<_allocator_t, HANDLER>* this_handler)
	{
		return _allocator_t::CreateMemory(static_cast<int>(size));
	}

	friend void asio_handler_deallocate(void* pointer, std::size_t /*size*/,
		custom_alloc_handler<_allocator_t, HANDLER>* this_handler)
	{
		_allocator_t::DestroyMemory(pointer);
	}

private:
	HANDLER m_handler;
};

template <typename ALLOC, typename HANDLER>
inline custom_alloc_handler<ALLOC, HANDLER> make_custom_alloc_handler(const HANDLER& h)
{
	return custom_alloc_handler<ALLOC, HANDLER>(h);
}

// 모든 세션은 이것을 계승해야 한다..
template <typename ALLOC>
class session;

// 기본 컨테이너의 베이스 클래스..
template <typename ALLOC = nmsp::default_allocator>
class net_pump_base
{
	using _session_t = session<ALLOC>;
	using _shared_session_t = smartinterface<_session_t>;

public:
	net_pump_base()
	{
	}
	virtual ~net_pump_base()
	{
	}

	//
	virtual bool Allocate(int& nSlot, int &nIdentity, _shared_session_t& session) = 0;
	virtual void Deallocate(int nSlot, int nIdentity) = 0;
	virtual bool IsEnd() = 0;
	virtual bool Assemble(int nPktLen, int nMaxHdLen, int* pnLen, unsigned char* pchHd) = 0;
	virtual bool Disassemble(int nIndex, int nIdentity, int nLen, const unsigned char* pchData, int* pnTotalLen, int* pnHdLen, int* pnDataLen) = 0;
	virtual int GetInitReceiveBufferSize() = 0;

	// Handler들
	virtual void OnAccepted(int nIndex, int nIdentity, _session_t*) = 0;
	virtual void OnConnected(int nIndex, int nIdentity, _session_t*) = 0;
	virtual void OnClosed(int nIndex, int nIdentity, _session_t*) = 0;
	virtual void OnReceived(int nIndex, int nIdentity, int nLen, const unsigned char* pchData, _session_t*) = 0;
	virtual void OnSent(int nIndex, int nIdentity, int nSentBytes, _session_t*) = 0;
	virtual void OnPosted(int nIndex, int nIdentity, int nOption, int nLen, const unsigned char* pchData, _session_t*) = 0;

	// error reporting ...
	// 1. boost error
	virtual void OnError(const boost::system::error_code& error) = 0;
	// 2. boost error
	virtual void OnError(int32_t index, int32_t identify, const boost::system::error_code& error) = 0;
	// 3. c++ 기본 (stl 포함)
	virtual void OnError(const std::exception& error) = 0;
	// 4. 순수 처리 오류
	virtual void OnError(const char* pszError) = 0;

public:
	inline operator boost::asio::io_service& () { return m_ios; }

protected:
	boost::asio::io_service m_ios;
};

// 세션의 구현
// packet의 header사이즈는 1024를 넘어가지 않도록 한다..
// ** shared_ptr을 사용하지 않음.
template <typename ALLOC = nmsp::default_allocator>
class session : public nmsp::new_from_pool<ALLOC>
{
public:
	using _allocator_t = ALLOC;

private:
	// 추후에 allocator를 바꿀수 있으므로
	using __this_t = session<_allocator_t>;
	using _read_buffer_t = std::basic_string<char, std::char_traits<char>, nmsp::stl_default_allocator<char, _allocator_t>>;
	using _read_stream_t = boost::asio::basic_streambuf<nmsp::stl_default_allocator<char, _allocator_t>>;	
	using _error_stream_t = std::basic_stringstream<char, std::char_traits<char>, nmsp::stl_default_allocator<char, _allocator_t>>;
	// 버퍼의 삭제를 어떻게 처리해야 할 것인지를 _write_buffer_t를 확장해서 처리하도록 하자..
	class _write_buffer_t : public boost::asio::mutable_buffer
	{
		using _deallocator_func_t = void(*)(void*);
		using __super_t = boost::asio::mutable_buffer;
	public:
		_write_buffer_t(void* data, std::size_t size, _deallocator_func_t _da)
			: __super_t(data, size)
			, m_da(_da)
		{
		}
		virtual ~_write_buffer_t()
		{
		}
		inline void deallocator()
		{
			m_da(boost::asio::buffer_cast<unsigned char*>(*this));
		}
	private:
		_deallocator_func_t m_da;
	};
	struct _writevector_t : public nmsp::new_from_pool<_allocator_t>, public std::vector<_write_buffer_t, nmsp::stl_default_allocator<_write_buffer_t, _allocator_t>>
	{
		_writevector_t() = default;
		virtual ~_writevector_t() = default;
	};
	struct _read_ctrl_t : public nmsp::new_from_pool<_allocator_t>
	{
		_read_stream_t m_readStreamBuf;
		_read_buffer_t m_readBuffer;
	};

public:
	using _shared_write_buffer_t = std::shared_ptr<_write_buffer_t>;
	using _shared_writevector_t = std::shared_ptr<_writevector_t>;
	using _shared_read_ctrl_t = std::shared_ptr<_read_ctrl_t>;
	using _shared_session_t = smartinterface<session<_allocator_t>>;
	using _net_pump_base_t = net_pump_base<_allocator_t>;
	enum { MAX_HD_SIZE = 1024, };

public:
	explicit session(_net_pump_base_t& pumpbase)
		: m_pumpbase(pumpbase)
		, m_nRefs(0)
		, m_strand(pumpbase)
		, m_socket(pumpbase)
	{
		m_nIndex = -1;
		m_nIdentity = -1;
		m_nHdSize = -1;
		m_bConn = false;
		m_bSending = false;
		m_bConnecting = false;
		m_bReceiving = false;

		m_lastReceivedTime = std::time(nullptr);

		m_isDeallocated = false;
	}
	virtual ~session() noexcept
	{
	}
	// 자체 구현으로 다가
	int AddRef()
	{
		return ++m_nRefs;
	}
	int Release()
	{
		int nRefs = --m_nRefs;

		if (0 == nRefs)
		{
			delete this;
			return 0;
		}
		else
		if (1 == nRefs)
		{
			// 종료되는 시점에 clear하도록..한번만 실행될 수 있도록 하기 위해서..
			auto prevIsDeallocated = m_isDeallocated.exchange(true);
			if (false == prevIsDeallocated)
				m_pumpbase.Deallocate(GetIndex(), GetIdentity());
			return 1;
		}

		return nRefs;
	}
	inline _shared_session_t SharedFromThis()
	{
		return _shared_session_t{ this };
	}
	inline int UseCount()
	{
		return m_nRefs;
	}
	// strand를 이용하는..
	bool PostAccept(std::shared_ptr<boost::asio::ip::tcp::acceptor> _acceptor)
	{
		try
		{
			// 객체를 생존시키기 위해서 SharedFromThis를 꼭 해야 한다..
			_acceptor->async_accept(m_socket, make_custom_alloc_handler<_allocator_t>(m_strand.wrap(boost::bind(&__this_t::OnAccept, this, SharedFromThis(), _acceptor, boost::asio::placeholders::error))));
		}
		catch (const std::bad_weak_ptr& e)
		{
			m_pumpbase.OnError(e);
			return false;
		}
		catch (const std::exception& e)
		{
			m_pumpbase.OnError(e);
			return false;
		}

		return true;
	}
	// gather를 지원해야 한다
	bool PostReceive()
	{
		try
		{
#if (__USE_RECV_STRAND__ == 1)
			//static_cast<boost::asio::io_service&>(m_pumpbase).post(make_custom_alloc_handler<_allocator_t>(m_strand.wrap(boost::bind(&__this_t::OnPostReceive, this, SharedFromThis()))));
			m_strand.post(make_custom_alloc_handler<_allocator_t>(boost::bind(&__this_t::OnPostReceive, this, SharedFromThis())));
#else
			__this_t::OnPostReceive(SharedFromThis());
#endif
		}
		catch (const std::bad_weak_ptr& e)
		{
			m_pumpbase.OnError(e);
			this->PostClose();
			return false;
		}
		catch (const std::exception& e)
		{
			m_pumpbase.OnError(e);
			this->PostClose();
			return false;
		}

		return true;
	}

	// scatter를 지원해야 한다
	bool PostSend(int nLen, const unsigned char* pchData)
	{
		// header의 최대 사이즈가 이걸 넘어가지 않도록 한다..
		int nLenHd;
		unsigned char achHead[MAX_HD_SIZE];

		if (false == m_pumpbase.Assemble(nLen, sizeof(achHead), &nLenHd, achHead))
			return false;

		//
		int nTotal = nLen + nLenHd;
		unsigned char* pbyPkt = nullptr;

		try
		{
			if (0 < nTotal)
			{
				pbyPkt = reinterpret_cast<unsigned char*>(_allocator_t::CreateMemory(nTotal));
				if (nullptr == pbyPkt)
				{
					_error_stream_t error;
					error << "PostSend :: allocateion fail :: " << nTotal << std::endl;
					m_pumpbase.OnError(error.str().c_str());
					return false;
				}

				if (0 < nLenHd)
					memcpy(pbyPkt, achHead, nLenHd);

				if (0 < nLen)
					memcpy(pbyPkt + nLenHd, pchData, nLen);
			}

#if (__USE_SEND_STRAND__ == 1)
			//static_cast<boost::asio::io_service&>(m_pumpbase).post(make_custom_alloc_handler<_allocator_t>(m_strand.wrap(boost::bind(&__this_t::OnPostSend<void(*)(void*)>, this, SharedFromThis(), nTotal, pbyPkt, &_allocator_t::DestroyMemory))));
			m_strand.post(
				make_custom_alloc_handler<_allocator_t>(boost::bind(&__this_t::OnPostSend<void(*)(void*)>, this, SharedFromThis(), nTotal, pbyPkt, &_allocator_t::DestroyMemory))
			);
#else
			__this_t::OnPostSend(SharedFromThis(), nTotal, pbyPkt, _allocator_t::DestroyMemory);
#endif
		}
		catch (const std::bad_weak_ptr& e)
		{
			_allocator_t::DestroyMemory(pbyPkt);
			m_pumpbase.OnError(e);
			return false;
		}
		catch (std::exception& e)
		{
			_allocator_t::DestroyMemory(pbyPkt);
			m_pumpbase.OnError(e);
			return false;
		}

		return true;
	}
	// scatter를 지원해야 한다
	bool PostSend(int nLen, const unsigned char* pchData, int nLen2, const unsigned char* pchData2)
	{
		// header의 최대 사이즈가 이걸 넘어가지 않도록 한다..
		int nLenHd;
		unsigned char achHead[MAX_HD_SIZE];

		if (false == m_pumpbase.Assemble(nLen + nLen2, sizeof(achHead), &nLenHd, achHead))
			return false;

		//
		int nTotal = nLen + nLen2 + nLenHd;
		unsigned char* pbyPkt = nullptr;

		try
		{
			if (0 < nTotal)
			{
				pbyPkt = reinterpret_cast<unsigned char*>(_allocator_t::CreateMemory(nTotal));
				if (nullptr == pbyPkt)
				{
					_error_stream_t error;
					error << "PostSend :: allocateion fail :: " << nTotal << std::endl;
					m_pumpbase.OnError(error.str().c_str());
					return false;
				}

				if (0 < nLenHd)
					memcpy(pbyPkt, achHead, nLenHd);

				if (0 < nLen)
					memcpy(pbyPkt + nLenHd, pchData, nLen);

				if (0 < nLen2)
					memcpy(pbyPkt + nLenHd + nLen, pchData2, nLen2);
			}

#if (__USE_SEND_STRAND__ == 1)
			//static_cast<boost::asio::io_service&>(m_pumpbase).post(make_custom_alloc_handler<_allocator_t>(m_strand.wrap(boost::bind(&__this_t::OnPostSend<void(*)(void*)>, this, SharedFromThis(), nTotal, pbyPkt, &_allocator_t::DestroyMemory))));
			m_strand.post(
				make_custom_alloc_handler<_allocator_t>(boost::bind(&__this_t::OnPostSend<void(*)(void*)>, this, SharedFromThis(), nTotal, pbyPkt, &_allocator_t::DestroyMemory))
			);
#else
			__this_t::OnPostSend(SharedFromThis(), nTotal, pbyPkt, _allocator_t::DestroyMemory);
#endif
		}
		catch (const std::bad_weak_ptr& e)
		{
			_allocator_t::DestroyMemory(pbyPkt);
			m_pumpbase.OnError(e);
			return false;
		}
		catch (std::exception& e)
		{
			_allocator_t::DestroyMemory(pbyPkt);
			m_pumpbase.OnError(e);
			return false;
		}

		return true;
	}
	bool PostSend(int nLen, const unsigned char* pchData, int nLen2, const unsigned char* pchData2, int nLen3, const unsigned char* pchData3)
	{
		// header의 최대 사이즈가 이걸 넘어가지 않도록 한다..
		int nLenHd;
		unsigned char achHead[MAX_HD_SIZE];

		if (false == m_pumpbase.Assemble(nLen + nLen2 + nLen3, sizeof(achHead), &nLenHd, achHead))
			return false;

		//
		int nTotal = nLen + nLen2 + nLen3 + nLenHd;
		unsigned char* pbyPkt = nullptr;

		try
		{
			if (0 < nTotal)
			{
				pbyPkt = reinterpret_cast<unsigned char*>(_allocator_t::CreateMemory(nTotal));
				if (nullptr == pbyPkt)
				{
					_error_stream_t error;
					error << "PostSend :: allocateion fail :: " << nTotal << std::endl;
					m_pumpbase.OnError(error.str().c_str());
					return false;
				}

				if (0 < nLenHd)
					memcpy(pbyPkt, achHead, nLenHd);

				if (0 < nLen)
					memcpy(pbyPkt + nLenHd, pchData, nLen);

				if (0 < nLen2)
					memcpy(pbyPkt + nLenHd + nLen, pchData2, nLen2);

				if (0 < nLen3)
					memcpy(pbyPkt + nLenHd + nLen + nLen2, pchData3, nLen3);
			}

#if (__USE_SEND_STRAND__ == 1)
			//static_cast<boost::asio::io_service&>(m_pumpbase).post(make_custom_alloc_handler<_allocator_t>(m_strand.wrap(boost::bind(&__this_t::OnPostSend<void(*)(void*)>, this, SharedFromThis(), nTotal, pbyPkt, &_allocator_t::DestroyMemory))));
			m_strand.post(
				make_custom_alloc_handler<_allocator_t>(boost::bind(&__this_t::OnPostSend<void(*)(void*)>, this, SharedFromThis(), nTotal, pbyPkt, &_allocator_t::DestroyMemory))
			);
#else
			__this_t::OnPostSend(SharedFromThis(), nTotal, pbyPkt, _allocator_t::DestroyMemory);
#endif
		}
		catch (const std::bad_weak_ptr& e)
		{
			_allocator_t::DestroyMemory(pbyPkt);
			m_pumpbase.OnError(e);
			return false;
		}
		catch (std::exception& e)
		{
			_allocator_t::DestroyMemory(pbyPkt);
			m_pumpbase.OnError(e);
			return false;
		}

		return true;
	}
	template <typename T>
	bool PostSend(T&& _t)
	{
		try
		{
#if (__USE_SEND_STRAND__ == 1)
			//static_cast<boost::asio::io_service&>(m_pumpbase).post(make_custom_alloc_handler<_allocator_t>(m_strand.wrap(boost::bind(&__this_t::OnPostSend<T>, this, SharedFromThis(), std::forward<T>(_t)))));
			m_strand.post(
				make_custom_alloc_handler<_allocator_t>(boost::bind(&__this_t::OnPostSend<T>, this, SharedFromThis(), std::forward<T>(_t)))
			);
#else
			__this_t::OnPostSend(SharedFromThis(), std::forward<T>(_t));
#endif
		}
		catch (const std::bad_weak_ptr& e)
		{
			m_pumpbase.OnError(e);
			return false;
		}
		catch (std::exception& e)
		{
			m_pumpbase.OnError(e);
			return false;
		}

		return true;
	}
	bool PostClose()
	{
		try
		{
#if (__USE_SEND_STRAND__ == 1)
			//static_cast<boost::asio::io_service&>(m_pumpbase).post(make_custom_alloc_handler<_allocator_t>(m_strand.wrap(boost::bind(&__this_t::OnClose, this, SharedFromThis()))));
			m_strand.post(make_custom_alloc_handler<_allocator_t>(boost::bind(&__this_t::OnClose, this, SharedFromThis())));
#else
			__this_t::OnClose(SharedFromThis());
#endif
		}
		catch (const std::bad_weak_ptr& e)
		{
			m_pumpbase.OnError(e);
			return false;
		}
		catch (std::exception& e)
		{
			m_pumpbase.OnError(e);
			return false;
		}

		return true;
	}
	bool PostConnect(const boost::asio::ip::tcp::endpoint& endpoint_)
	{
		try
		{
#if (__USE_SEND_STRAND__ == 1)
			//static_cast<boost::asio::io_service&>(m_pumpbase).post(make_custom_alloc_handler<_allocator_t>(m_strand.wrap(boost::bind(&__this_t::OnPostConnect, this, SharedFromThis(), endpoint_))));
			m_strand.post(make_custom_alloc_handler<_allocator_t>(boost::bind(&__this_t::OnPostConnect, this, SharedFromThis(), endpoint_)));
#else
			__this_t::OnPostConnect(SharedFromThis(), endpoint_);
#endif
		}
		catch (const std::bad_weak_ptr& e)
		{
			m_pumpbase.OnError(e);
			return false;
		}
		catch (std::exception& e)
		{
			m_pumpbase.OnError(e);
			return false;
		}

		return true;
	}
	// scatter를 지원해야 한다
	bool Post(int nOption, int nLen, const unsigned char* pchData)
	{
		unsigned char* pbyPkt = nullptr;

		try
		{
			if (0 < nLen)
			{
				pbyPkt = reinterpret_cast<unsigned char*>(_allocator_t::CreateMemory(nLen));
				if (nullptr == pbyPkt)
				{
					_error_stream_t error;
					error << "Post :: allocateion fail :: " << nLen << std::endl;
					m_pumpbase.OnError(error.str().c_str());
					return false;
				}

				memcpy(pbyPkt, pchData, nLen);
			}
#if (__USE_SEND_STRAND__ == 1)
			//static_cast<boost::asio::io_service&>(m_pumpbase).post(make_custom_alloc_handler<_allocator_t>(m_strand.wrap(boost::bind(&__this_t::OnPost, this, SharedFromThis(), nOption, nLen, pbyPkt))));
			m_strand.post(make_custom_alloc_handler<_allocator_t>(boost::bind(&__this_t::OnPost, this, SharedFromThis(), nOption, nLen, pbyPkt)));
#else
			__this_t::OnPost(SharedFromThis(), nOption, nLen, pbyPkt);
#endif

		}
		catch (const std::bad_weak_ptr& e)
		{
			_allocator_t::DestroyMemory(pbyPkt);
			m_pumpbase.OnError(e);
			return false;
		}
		catch (std::exception& e)
		{
			_allocator_t::DestroyMemory(pbyPkt);
			m_pumpbase.OnError(e);
			return false;
		}

		return true;
	}
	// Handler
	virtual bool OnAccept(_shared_session_t& sess, std::shared_ptr<boost::asio::ip::tcp::acceptor>& _acceptor, const boost::system::error_code& error)
	{
		// 오류가 발생했으면서 종료할거면..
		if (error)
		{
			m_pumpbase.OnError(error);

			if (true == m_pumpbase.IsEnd())
				return false;
		}
		else
		{
			m_lastReceivedTime = std::time(nullptr);
			this->m_bConn = true;

			m_pumpbase.OnAccepted(m_nIndex, m_nIdentity, sess);

			this->PostReceive();
		}

		int nSlot;
		int nIdentity;
		_shared_session_t new_sess;

		if (false == m_pumpbase.Allocate(nSlot, nIdentity, new_sess))
		{
			m_pumpbase.OnError("allocation fail :: session object");
			return false;
		}

		return new_sess->PostAccept(_acceptor);
	}
	virtual bool OnReceive(_shared_session_t& sess, _shared_read_ctrl_t& read_ctrl, const boost::system::error_code& error, const std::size_t& trans)
	{
		// 수신 대기 상태 해제
		m_bReceiving = false;

		// 오류 처리
		if (error)
		{
			m_pumpbase.OnError(sess->GetIndex(), sess->GetIdentity(), error);

			this->PostClose();
			return false;
		}

		// 시간 설정
		m_lastReceivedTime = std::time(nullptr);

		// Header의 크기를 미리 알아온다.. 오류인 경우는 -1로 설정을..
		if (-1 == m_nHdSize)
		{
			int nTotal;
			int nHdSize;
			int nDataSize;

			if (false == m_pumpbase.Disassemble(0, 0, 0, nullptr, &nTotal, &nHdSize, &nDataSize))
			{
				this->PostClose();
				return false;
			}

			m_nHdSize = nHdSize;
		}

		// 데이터를 받아들인다...
		read_ctrl->m_readStreamBuf.commit(trans);

		// 충분히 받아졌는가 ?
		if (m_nHdSize > read_ctrl->m_readStreamBuf.size() + read_ctrl->m_readBuffer.length())
			return sess->PostReceive();

		// 그냥 합치자 
		_read_stream_t::const_buffers_type bufs = read_ctrl->m_readStreamBuf.data();
		read_ctrl->m_readBuffer.append(boost::asio::buffers_begin(bufs), boost::asio::buffers_begin(bufs) + read_ctrl->m_readStreamBuf.size());
		read_ctrl->m_readStreamBuf.consume(read_ctrl->m_readStreamBuf.size());

		// 데이터를 패킷으로 분리하여 처리한다.
		int nLeft = static_cast<int>(read_ctrl->m_readBuffer.length());
		int nOrgTotal = nLeft;
		const unsigned char* pbyData = reinterpret_cast<const unsigned char*>(read_ctrl->m_readBuffer.c_str());

		int nPktTotal = 0;
		int nPktHdSize = 0;
		int nPktDataSize = 0;

		auto start = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
		//static uint64_t aa_count = 0;

		while (nLeft >= m_nHdSize && nLeft > 0)
		{
			if (false == m_pumpbase.Disassemble(m_nIndex, m_nIdentity, nLeft, pbyData, &nPktTotal, &nPktHdSize, &nPktDataSize))
			{
				this->PostClose();
				return false;
			}

			if (0 >= nPktTotal || nPktTotal > nLeft)
				break;

			// 원하는 곳으로 보내준다 
			m_pumpbase.OnReceived(m_nIndex, m_nIdentity, nPktDataSize, pbyData + nPktHdSize, sess);
			//++aa_count;

			//
			nLeft -= nPktTotal;
			pbyData += nPktTotal;
		}

		// 남아 있다면 줄여야지..
		if (nLeft != nOrgTotal)
			read_ctrl->m_readBuffer.erase(0, nOrgTotal - nLeft);

		/*
		auto end = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
		static auto log = end;
		static int32_t total_cnt = 0;
		static uint64_t progress = 0;
		if (log + 1000 < end)
		{
			std::cout << "total time:" << progress << ", total cnt:" << total_cnt << ", average:" << progress << ", cccc:" << aa_count << std::endl;
			log = end;
			total_cnt = 0;
			progress = 0;
		}

		++total_cnt;
		progress += end - start;
		*/
		return sess->PostReceive();
	}

	virtual bool OnSend(_shared_session_t& sess, _shared_writevector_t& vecBuff, const boost::system::error_code& error, const std::size_t& trans)
	{
		m_bSending = false;

		// 사용한 메모리는 해제를
		for_each(vecBuff->begin(), vecBuff->end(), [](_writevector_t::value_type& v)
		{
			v.deallocator();
			//_allocator_t::DestroyMemory(boost::asio::buffer_cast<unsigned char*>(v));
		});

		// 오류라면 그냥 리턴하고..
		if (error)
		{
			m_pumpbase.OnError(sess->GetIndex(), sess->GetIdentity(), error);
			return false;
		}

		m_pumpbase.OnSent(m_nIndex, m_nIdentity, static_cast<int>(trans), sess);

		// 다시 보낼게 있는지 검사한다..
		try
		{
			if (nullptr == m_sendVector)
				return true;

#if (__USE_SEND_STRAND__ == 1)
			async_write(m_socket, *m_sendVector,
				make_custom_alloc_handler<_allocator_t>(m_strand.wrap(boost::bind(&__this_t::OnSend, this, SharedFromThis(), m_sendVector, boost::asio::placeholders::error, boost::asio::placeholders::bytes_transferred))));
#else
			async_write(m_socket, *m_sendVector,
				make_custom_alloc_handler<_allocator_t>(boost::bind(&__this_t::OnSend, this, SharedFromThis(), m_sendVector, boost::asio::placeholders::error, boost::asio::placeholders::bytes_transferred)));
#endif
			m_sendVector.reset();
			m_bSending = true;
		}
		catch (const std::bad_weak_ptr& e)
		{
			m_pumpbase.OnError(e);
			return false;
		}
		catch (const std::exception& e)
		{
			m_pumpbase.OnError(e);
			return false;
		}

		return true;
	}

	virtual bool OnSend2(_shared_session_t& sess, _shared_write_buffer_t& buffer, const boost::system::error_code& error, const std::size_t& trans)
	{
		m_bSending = false;

		buffer->deallocator();

		// 오류라면 그냥 리턴하고..
		if (error)
		{
			m_pumpbase.OnError(sess->GetIndex(), sess->GetIdentity(), error);
			return false;
		}

		m_pumpbase.OnSent(m_nIndex, m_nIdentity, static_cast<int>(trans), sess);

		return true;
	}

	virtual bool OnClose(_shared_session_t&)
	{
		// 종료를 알린다
		if (true == this->m_bConn)
			m_pumpbase.OnClosed(m_nIndex, m_nIdentity, this);

		// 접속 종료 상태로 만든다
		this->m_bConn = false;

		// 접속을 종료한다.
		try
		{
			m_socket.close();
		}
		catch (const std::bad_weak_ptr& e)
		{
			m_pumpbase.OnError(e);
			return false;
		}
		catch (std::exception& e)
		{
			m_pumpbase.OnError(e);
			return false;
		}

		//
		m_readCtrl.reset();
		m_sendVector.reset();
		return true;
	}
	virtual bool OnConnect(_shared_session_t& sess, const boost::system::error_code& error)
	{
		this->m_bConnecting = false;

		// 오류가 발생했으면서 종료할거면..
		if (error)
		{
			m_pumpbase.OnError(sess->GetIndex(), sess->GetIdentity(), error);
			return false;
		}

		m_lastReceivedTime = std::time(nullptr);
		this->m_bConn = true;

		m_pumpbase.OnConnected(m_nIndex, m_nIdentity, sess);

		return this->PostReceive();
	}
	virtual bool OnPostConnect(_shared_session_t& sess, const boost::asio::ip::tcp::endpoint& endpoint_)
	{
		try
		{
			// 이미 시도중이라면..
			if (true == m_bConnecting)
				return true;

#if (__USE_SEND_STRAND__ == 1)
			m_socket.async_connect(endpoint_,
				make_custom_alloc_handler<_allocator_t>(m_strand.wrap(boost::bind(&__this_t::OnConnect, this, SharedFromThis(), boost::asio::placeholders::error))));
#else
			m_socket.async_connect(endpoint_,
				make_custom_alloc_handler<_allocator_t>(boost::bind(&__this_t::OnConnect, this, SharedFromThis(), boost::asio::placeholders::error)));
#endif // __USE_SEND_STRAND__
			m_bConnecting = true;

		}
		catch (const std::bad_weak_ptr& e)
		{
			m_pumpbase.OnError(e);
			return false;
		}
		catch (std::exception& e)
		{
			m_pumpbase.OnError(e);
			return false;
		}

		return true;
	}
	template <typename DA>
	bool OnPostSend(_shared_session_t& sess, int nLenPkt, unsigned char* pbyPkt, DA& _da)
	{
		try
		{
			
#if (__SEND_VECTOR__ == 1)

			if (nullptr == m_sendVector)
				m_sendVector = std::make_shared<_writevector_t>();

			m_sendVector->push_back(_write_buffer_t(pbyPkt, nLenPkt, _da));

			// 작업중이 아니라면...
			if (false == m_bSending)
			{
#if (__USE_SEND_STRAND__ == 1)
				boost::asio::async_write(m_socket, *m_sendVector,
					make_custom_alloc_handler<_allocator_t>(m_strand.wrap(boost::bind(&__this_t::OnSend, this, SharedFromThis(), m_sendVector, boost::asio::placeholders::error, boost::asio::placeholders::bytes_transferred))));
#else
				boost::asio::async_write(m_socket, *m_sendVector,
					make_custom_alloc_handler<_allocator_t>(boost::bind(&__this_t::OnSend, this, SharedFromThis(), m_sendVector, boost::asio::placeholders::error, boost::asio::placeholders::bytes_transferred)));
#endif
				m_sendVector.reset();
				m_bSending = true;
			}

#else // __SEND_VECTOR__

			_shared_write_buffer_t buffer = std::make_shared<_write_buffer_t>(pbyPkt, nLenPkt, _da);
#if (__USE_SEND_STRAND__ == 1)
			boost::asio::async_write(m_socket, boost::asio::buffer(buffer->data(), buffer->size()),
				make_custom_alloc_handler<_allocator_t>(m_strand.wrap(boost::bind(&__this_t::OnSend2, this, SharedFromThis(), buffer, boost::asio::placeholders::error, boost::asio::placeholders::bytes_transferred)))
			);
#else
			boost::asio::async_write(m_socket, boost::asio::buffer(buffer->data(), buffer->size()),
				make_custom_alloc_handler<_allocator_t>(boost::bind(&__this_t::OnSend2, this, SharedFromThis(), buffer, boost::asio::placeholders::error, boost::asio::placeholders::bytes_transferred))
			);
#endif
			m_bSending = true;

#endif // __SEND_VECTOR__
			
		}
		catch (const std::bad_weak_ptr& e)
		{
			_allocator_t::DestroyMemory(pbyPkt);

			m_pumpbase.OnError(e);
			return false;
		}
		catch (const std::exception& e)
		{
			_allocator_t::DestroyMemory(pbyPkt);

			m_pumpbase.OnError(e);
			return false;
		}

		return true;
	}
	template <class T>
	bool OnPostSend(_shared_session_t& sess, T& _t)
	{
		try
		{
#if (__SEND_VECTOR__ == 1)

			if (nullptr == m_sendVector)
				m_sendVector = std::make_shared<_writevector_t>();

			// pbyPkt의 메모리 할당자는 이 객체의 _allocator_t에 의한 것이어야 한다
			if (false == _t->Reset([this](unsigned char* pbyPkt, int nLenPkt) 
			{ 
				_write_buffer_t _x(pbyPkt, nLenPkt, &T::element_type::_allocator_t::DestroyMemory);
				m_sendVector->push_back(_x);
			}))
				return false;

			// 작업중이 아니라면...
			if (false == m_bSending)
			{
#if (__USE_SEND_STRAND__ == 1)
				async_write(m_socket, *m_sendVector,
					make_custom_alloc_handler<_allocator_t>(m_strand.wrap(boost::bind(&__this_t::OnSend, this, SharedFromThis(), m_sendVector, boost::asio::placeholders::error, boost::asio::placeholders::bytes_transferred))));
#else
				async_write(m_socket, *m_sendVector,
					make_custom_alloc_handler<_allocator_t>(boost::bind(&__this_t::OnSend, this, SharedFromThis(), m_sendVector, boost::asio::placeholders::error, boost::asio::placeholders::bytes_transferred)));
#endif
				m_sendVector.reset();
				m_bSending = true;
			}

#else // __SEND_VECTOR__

			_shared_write_buffer_t buffer = nullptr;
			if (false == _t->Reset([this, &buffer](unsigned char* pbyPkt, int nLenPkt)
			{
				buffer = std::make_shared<_write_buffer_t>(pbyPkt, nLenPkt, &T::element_type::_allocator_t::DestroyMemory);
			}))
				return false;
			
#if (__USE_SEND_STRAND__ == 1)
			async_write(m_socket, boost::asio::buffer(buffer->data(), buffer->size()),
				make_custom_alloc_handler<_allocator_t>(m_strand.wrap(boost::bind(&__this_t::OnSend2, this, SharedFromThis(), buffer, boost::asio::placeholders::error, boost::asio::placeholders::bytes_transferred)))
			);
#else
			async_write(m_socket, boost::asio::buffer(buffer->data(), buffer->size()),
				make_custom_alloc_handler<_allocator_t>(boost::bind(&__this_t::OnSend2, this, SharedFromThis(), buffer, boost::asio::placeholders::error, boost::asio::placeholders::bytes_transferred))
			);
#endif
			m_bSending = true;

#endif // __SEND_VECTOR__
		}
		catch (const std::bad_weak_ptr& e)
		{
			m_pumpbase.OnError(e);
			return false;
		}
		catch (const std::exception& e)
		{
			m_pumpbase.OnError(e);
			return false;
		}

		return true;
	}
	virtual bool OnPostReceive(_shared_session_t& sess)
	{
		// 수신대기중이라면 그냥 리턴한다.
		if (true == m_bReceiving)
			return true;

		// 수신 대기 해봅시다
		try
		{
			// 
			if (nullptr == m_readCtrl)
				m_readCtrl = std::make_shared<_read_ctrl_t>();

			// 패킷 
			_read_stream_t::mutable_buffers_type mutableBuffer = m_readCtrl->m_readStreamBuf.prepare(m_pumpbase.GetInitReceiveBufferSize());

#if (__USE_RECV_STRAND__ == 1)
			m_socket.async_read_some(mutableBuffer,
				make_custom_alloc_handler<_allocator_t>(m_strand.wrap(boost::bind(&__this_t::OnReceive, this, SharedFromThis(), m_readCtrl, boost::asio::placeholders::error, boost::asio::placeholders::bytes_transferred))));
#else
			m_socket.async_read_some(mutableBuffer,
				boost::bind(&__this_t::OnReceive, this, SharedFromThis(), m_readCtrl, boost::asio::placeholders::error, boost::asio::placeholders::bytes_transferred));
#endif
			m_bReceiving = true;
		}
		catch (const std::bad_weak_ptr& e)
		{
			m_pumpbase.OnError(e);

			this->PostClose();
			return false;
		}
		catch (std::exception& e)
		{
			m_pumpbase.OnError(e);

			this->PostClose();
			return false;
		}

		return true;
	}

	virtual bool OnPost(_shared_session_t& sess, int nOption, int nLenPkt, unsigned char* pbyPkt)
	{
		try
		{
			m_pumpbase.OnPosted(m_nIndex, m_nIdentity, nOption, nLenPkt, pbyPkt, sess);
		}
		catch (const std::bad_weak_ptr& e)
		{
			_allocator_t::DestroyMemory(pbyPkt);

			m_pumpbase.OnError(e);
			return false;
		}
		catch (const std::exception& e)
		{
			_allocator_t::DestroyMemory(pbyPkt);

			m_pumpbase.OnError(e);
			return false;
		}

		_allocator_t::DestroyMemory(pbyPkt);
		return true;
	}
	virtual void SetTcpOption()
	{
	}
	void Cancel()
	{
		try
		{
			m_socket.cancel();
		}
		catch (...)
		{
		}
	}

public:
	inline void SetIndex(int nIndex) { m_nIndex = nIndex; }
	inline void SetIdentity(int nIdentity) { m_nIdentity = nIdentity; }
	inline int GetIndex() const { return m_nIndex; }
	inline int GetIdentity() const { return m_nIdentity; }
	inline bool IsConn() const { return m_bConn; }
	inline bool IsConnecting() const { return m_bConnecting; }
	inline time_t GetLastReceivedTime() const { return m_lastReceivedTime; }
	inline operator boost::asio::ip::tcp::socket& () { return m_socket; }
	inline boost::asio::ip::tcp::socket& GetSocket() { return m_socket; }

protected:
	_net_pump_base_t& m_pumpbase;

private:
	std::atomic_int m_nRefs;

private:
	int m_nIndex;
	int m_nIdentity;
	bool m_bConn;
	bool m_bSending;									// 전송중임을 나타내는
	bool m_bReceiving;									// 수신대기중임
	bool m_bConnecting;
	int m_nHdSize;
	boost::asio::ip::tcp::socket m_socket;
	boost::asio::io_service::strand m_strand;
	_shared_read_ctrl_t m_readCtrl;
	_shared_writevector_t m_sendVector;
	std::atomic<time_t> m_lastReceivedTime;				// 음 혹시 모를.. 경우를 감안해서.. 64비트에서 8byte 정렬이 아니거나.. 32bit에서 4바이트 정렬이 아닌 경우 문제가 될수 있어서.. 이렇게 함..
	std::atomic<bool> m_isDeallocated;
};

//
// asio를 기반으로한 클라이언트/서버 동시 지원하는 뭔가를 만들어 보자
// allocator는 아직 없는 걸로 시작하고..
// 
template <typename _SESSION_T, typename ALLOC = nmsp::default_allocator>
class net_pump: public net_pump_base<ALLOC>
{
public:
	using _allocator_t = ALLOC;

private:
	using __this_t = net_pump<_SESSION_T, _allocator_t>;
	using _error_stream_t = std::basic_stringstream<char, std::char_traits<char>, nmsp::stl_default_allocator<char, _allocator_t>>;

public:
	using _session_t = session<_allocator_t>;
	using _shared_session_t = smartinterface<_session_t>;
	using _net_pump_base_t = net_pump_base<_allocator_t>;

private:
	// 세션을 관리하기 위한 객체임..
	template <typename T>
	class session_pool
	{
		using _session_table_t = std::vector<_shared_session_t, nmsp::stl_default_allocator<_shared_session_t, _allocator_t>>;
		using _session_index_t = std::list<int, nmsp::stl_default_allocator<int, _allocator_t>>;

	public:
		session_pool(_net_pump_base_t& pumpbase)
			: m_pumpbase(pumpbase)
		{
			m_nIdentity = 0;
			m_nInitCount = 0;
			m_nExtCount = 0;
		}
		virtual ~session_pool()
		{
		}
		bool Init(int nInitCount, int nExtCount)
		{
			// 무조건 0보다 커야 한다
			if (0 >= nInitCount || 0 >= nExtCount)
			{
				_error_stream_t error;
				error << "session_pool :: invalid_parameter :: " << nInitCount << "," << nExtCount;
				m_pumpbase.OnError(error.str().c_str());
				return false;
			}

			// 
			std::unique_lock<std::shared_mutex> cLk(m_cLock);

			m_nInitCount = nInitCount;
			m_nExtCount = nExtCount;

			try
			{
				m_vecTables.reserve(m_nInitCount + m_nExtCount);

				for (int nI = 0; nI < m_nInitCount; ++nI)
				{
					int nCurr = static_cast<int>(m_vecTables.size());

					if (nCurr >= std::numeric_limits<int>::max())
					{
						_error_stream_t error;
						error << "session_pool :: full max :: " << nCurr;
						m_pumpbase.OnError(error.str().c_str());
						return false;
					}

					m_cIndices.push_back(nCurr);
					m_vecTables.push_back(nullptr);
				}
			}
			catch (std::bad_weak_ptr& e)
			{
				m_pumpbase.OnError(e);
				return false;
			}
			catch (std::exception& e)
			{
				m_pumpbase.OnError(e);
				return false;
			}

			return true;
		}
		void Cancel()
		{
			_session_table_t closeSesses;

			// close할 것들을 찾는다!
			{
				std::shared_lock<std::shared_mutex> cLk(m_cLock);

				for_each(m_vecTables.begin(), m_vecTables.end(), [&closeSesses](_session_table_t::value_type& v)
				{
					if (nullptr != v && 1 < v->UseCount())
						closeSesses.emplace_back(v);
				});
			}

			// close를 호출한다!
			for_each(closeSesses.begin(), closeSesses.end(), [&closeSesses](_session_table_t::value_type& v)
			{
				v->PostClose();
			});
		}
		void Uninit()
		{
		}
		bool Allocate(int& nSlot, int& nIdentity, _shared_session_t& sess)
		{
			// 일단 생성하고 본다
			try
			{
				sess = new _SESSION_T(m_pumpbase);
			}
			catch (std::bad_weak_ptr& e)
			{
				m_pumpbase.OnError(e);
				return false;
			}
			catch (const std::exception& e)
			{
				m_pumpbase.OnError(e);
				return false;
			}

			// 옵션을 설정할 수 있도록..
			sess->SetTcpOption();

			// array에 설정한다.
			std::unique_lock<std::shared_mutex> cLk(m_cLock);

			if (true == m_cIndices.empty())
			{
				if (false == this->Expand())
					return false;
			}

			try
			{
				nSlot = m_cIndices.front();
				nIdentity = ++m_nIdentity;

				sess->SetIndex(nSlot);
				sess->SetIdentity(nIdentity);

				m_vecTables[nSlot] = sess;
				m_cIndices.pop_front();
			}
			catch (std::bad_weak_ptr& e)
			{
				m_pumpbase.OnError(e);
				return false;
			}
			catch (std::exception& e)
			{
				m_pumpbase.OnError(e);
				return false;
			}

			return true;
		}
		void Deallocate(int nSlot, int nIdentity)
		{
			std::unique_lock<std::shared_mutex> cLk(m_cLock);

			try
			{
				// 이미 초기화 되었다면...
				if (nullptr == m_vecTables[nSlot])
					return;

				// 다른 객체라면
				if (m_vecTables[nSlot]->GetIdentity() != nIdentity)
					return;

				m_vecTables[nSlot] = nullptr;
				m_cIndices.push_front(nSlot);
			}
			catch (std::bad_weak_ptr& e)
			{
				m_pumpbase.OnError(e);
			}
			catch (std::exception& e)
			{
				m_pumpbase.OnError(e);
			}
		}
		bool Send(int nIndex, int nIdentity, int nLen, const unsigned char* pchData)
		{
			_shared_session_t sess;

			//
			{
				std::shared_lock<std::shared_mutex> cLk(m_cLock);

				if (m_vecTables.size() <= nIndex)
				{
					_error_stream_t error;
					error << "send :: invalid index :: " << m_vecTables.size() << "," << nIndex;
					m_pumpbase.OnError(error.str().c_str());
					return false;
				}

				_session_t* pcSess = m_vecTables[nIndex];

				if (nullptr == pcSess)
					return false;

				if (nIdentity != pcSess->GetIdentity())
					return false;

				// 1이라는건 사용중이 아니라는 것이므로...
				if (1 >= pcSess->UseCount())
					return false;

				sess = pcSess->SharedFromThis();
			}

			// 
			return sess->PostSend(nLen, pchData);
		}
		bool Close(int nIndex, int nIdentity)
		{
			_shared_session_t sess;

			//
			{
				std::shared_lock<std::shared_mutex> cLk(m_cLock);

				if (m_vecTables.size() <= nIndex)
				{
					_error_stream_t error;
					error << "close :: invalid index :: " << m_vecTables.size() << "," << nIndex;
					m_pumpbase.OnError(error.str().c_str());
					return false;
				}

				_session_t* pcSess = m_vecTables[nIndex];

				if (nullptr == pcSess)
					return false;

				if (nIdentity != pcSess->GetIdentity())
					return false;

				// 1보다 작거나 같다면.. 사용중이 아니라는 것이다
				if (1 >= pcSess->UseCount())
					return false;

				sess = pcSess->SharedFromThis();
			}

			// 
			return sess->PostClose();
		}
		bool Post(int nIndex, int nIdentity, int nOption, int nLen, const unsigned char* pchData)
		{
			_shared_session_t sess;

			//
			{
				std::shared_lock<std::shared_mutex> cLk(m_cLock);

				if (m_vecTables.size() <= nIndex)
				{
					_error_stream_t error;
					error << "post :: invalid index :: " << m_vecTables.size() << "," << nIndex;
					m_pumpbase.OnError(error.str().c_str());
					return false;
				}

				_session_t* pcSess = m_vecTables[nIndex];

				if (nullptr == pcSess)
					return false;

				if (nIdentity != pcSess->GetIdentity())
					return false;

				// 1이라는건 사용중이 아니라는 것이므로...
				if (1 >= pcSess->UseCount())
					return false;

				sess = pcSess->SharedFromThis();
			}

			// 
			return sess->Post(nOption, nLen, pchData);
		}
		template <class T> bool Post(int nIndex, int nIdentity, T&& _t)
		{
			_shared_session_t sess;

			//
			{
				std::shared_lock<std::shared_mutex> cLk(m_cLock);

				if (m_vecTables.size() <= nIndex)
				{
					_error_stream_t error;
					error << "post :: invalid index :: " << m_vecTables.size() << "," << nIndex;
					m_pumpbase.OnError(error.str().c_str());
					return false;
				}

				_session_t* pcSess = m_vecTables[nIndex];

				if (nullptr == pcSess)
					return false;

				if (nIdentity != pcSess->GetIdentity())
					return false;

				// 1이라는건 사용중이 아니라는 것이므로...
				if (1 >= pcSess->UseCount())
					return false;

				sess = pcSess->SharedFromThis();
			}

			// 
			return sess->PostSend(std::forward<T>(_t));
		}
		int GetFreeCount()
		{
			std::shared_lock<std::shared_mutex> cLk(m_cLock);

			return static_cast<int>(m_cIndices.size());
		}
		int GetCount()
		{
			std::shared_lock<std::shared_mutex> cLk(m_cLock);

			return static_cast<int>(m_vecTables.size());
		}
		bool Find(int nIndex, _shared_session_t& sess)
		{
			std::shared_lock<std::shared_mutex> cLk(m_cLock);

			if (m_vecTables.size() <= nIndex)
				return false;

			_session_t* pcSess = m_vecTables[nIndex];

			if (nullptr == pcSess)
				return false;

			if (1 >= pcSess->UseCount())
				return false;
			
			sess = pcSess->SharedFromThis();

			return true;
		}

	private:
		// 최소한 하나는 확장을 ...
		bool Expand()
		{
			try
			{
				m_vecTables.reserve(m_vecTables.size() + m_nExtCount);

				for (int nI = 0; nI < m_nExtCount; ++nI)
				{
					int nCurr = static_cast<int>(m_vecTables.size());

					// 할당이 도를 넘었음..
					if (nCurr >= std::numeric_limits<int>::max())
					{
						_error_stream_t error;
						error << "session_pool :: full max :: " << nCurr;
						m_pumpbase.OnError(error.str().c_str());
						return false;
					}

					m_cIndices.push_back(nCurr);
					m_vecTables.push_back(nullptr);
				}
			}
			catch (std::bad_weak_ptr& e)
			{
				m_pumpbase.OnError(e);
				return false;
			}
			catch (std::exception& e)
			{
				m_pumpbase.OnError(e);
				return false;
			}

			return true;
		}

	private:
		std::shared_mutex m_cLock;
		int m_nIdentity;
		int m_nInitCount;
		int m_nExtCount;
		_session_table_t m_vecTables;
		_session_index_t m_cIndices;
		_net_pump_base_t& m_pumpbase;
	};
	// timer..
	class pump_timers 
	{
		// 타이머
		class net_pump_timer : public boost::asio::basic_waitable_timer<std::chrono::steady_clock>
		{
			using __parent_t = boost::asio::basic_waitable_timer<std::chrono::steady_clock>;
		public:
			net_pump_timer(__this_t& pump, int nId, int nPeriod)
				: __parent_t(pump)
				, m_pump(pump)
				, m_nId(nId)
				, m_period(std::chrono::milliseconds(nPeriod))
				, m_strand(pump)
			{
			}
			template <typename T>
			bool Post(T& _t)
			{
				try
				{
					this->expires_from_now(m_period);
					this->async_wait(make_custom_alloc_handler<_allocator_t>(m_strand.wrap(_t)));
				}
				catch (std::bad_weak_ptr& e)
				{
					m_pump.OnError(e);
					return false;
				}
				catch (std::exception& e)
				{
					m_pump.OnError(e);
					return false;
				}

				return true;
			}
			inline void Cancel()
			{
				try
				{
					this->cancel();
				}
				catch (...)
				{
				}
			}
			inline int GetId() const
			{
				return m_nId;
			}
			inline const std::chrono::seconds& GetPeriod() const
			{
				return m_period;
			}

		private:
			__this_t& m_pump;
			int m_nId;
			std::chrono::milliseconds m_period;
			boost::asio::io_service::strand m_strand;
		};
		using _timer_map_t = std::unordered_map<int, std::shared_ptr<net_pump_timer>, std::hash<int>, std::equal_to<int>, nmsp::stl_default_allocator<std::pair<const int, std::shared_ptr<net_pump_timer>>, _allocator_t>>;
		//using _timer_map_t = std::unordered_map<int, std::shared_ptr<net_pump_timer>>;

	public:
		pump_timers(__this_t& pump)
			: m_pump(pump)
		{
		}
		virtual ~pump_timers()
		{
		}
		bool SetTimer(int nId, int nPeriod)
		{
			std::unique_lock<std::shared_mutex> cLk(m_cLock);

			try
			{
				std::shared_ptr<net_pump_timer> timer = std::make_shared<net_pump_timer>(m_pump, nId, nPeriod);

				auto pair = m_cTimers.insert(_timer_map_t::value_type(nId, timer));
				if (false == pair.second)
				{
					_error_stream_t error;
					error << "pump_timers :: dup :: " << nId;
					m_pump.OnError(error.str().c_str());
					return false;
				}

				pair.first->second->Post(boost::bind(&pump_timers::OnTimer, this, nId, timer, boost::asio::placeholders::error));
			}
			catch (std::bad_weak_ptr& e)
			{
				m_pump.OnError(e);
				return false;
			}
			catch (std::exception& e)
			{
				m_pump.OnError(e);
				return false;
			}

			return true;
		}
		bool ResetTimer(int nId)
		{
			std::unique_lock<std::shared_mutex> cLk(m_cLock);

			auto itr = m_cTimers.find(nId);
			if (itr == m_cTimers.end())
				return false;

			itr->second->Cancel();
			m_cTimers.erase(itr);

			return true;
		}
		template <typename T> bool Post(int nId, T& t)
		{
			std::shared_lock<std::shared_mutex> cLk(m_cLock);

			auto itr = m_cTimers.find(nId);
			if (itr == m_cTimers.end())
				return false;

			return itr->second->Post(t);
		}
		bool Init()
		{
			return true;
		}
		void Cancel()
		{
			std::shared_lock<std::shared_mutex> cLk(m_cLock);

			for_each(m_cTimers.begin(), m_cTimers.end(), [](_timer_map_t::value_type& v) {
				v.second->Cancel();
			});
		}
		void Uninit()
		{
			std::unique_lock<std::shared_mutex> cLk(m_cLock);

			m_cTimers.clear();
		}
		virtual void OnTimer(int nId, std::shared_ptr<net_pump_timer>& timer, const boost::system::error_code& error)
		{
			m_pump.OnTimer(nId, error);

			if (error)
				m_pump.OnError(error);

			if (true == m_pump.IsEnd())
				return;

			//
			this->Post(nId, boost::bind(&pump_timers::OnTimer, this, nId, timer, boost::asio::placeholders::error));
		}

	private:
		std::shared_mutex m_cLock;
		__this_t& m_pump;
		_timer_map_t m_cTimers;
	};

private:
	typedef std::vector<std::unique_ptr<std::thread>> _threads_t;
	typedef std::vector<std::shared_ptr<boost::asio::ip::tcp::acceptor>> _acceptors_t;

public:
	net_pump()
		: m_cPool(*this)
		, m_cTimers(*this)
	{
		m_bEnd = false;
		m_nNormalPacketSize = 0;
	}
	virtual ~net_pump()
	{
	}
	bool Init(int nInitCount, int nExpandCount, int nNormalPacketSize)
	{
		if (0 == nNormalPacketSize)
			return false;

		m_nNormalPacketSize = nNormalPacketSize;

		try
		{
			m_work = std::make_unique<boost::asio::io_service::work>(m_ios);

			//
			if (false == m_cTimers.Init())
				return false;

			// 풀의 초기화부터
			if (false == m_cPool.Init(nInitCount, nExpandCount))
				return false;
		}
		catch (std::bad_weak_ptr& e)
		{
			this->OnError(e);
			return false;
		}
		catch (std::exception& e)
		{
			this->OnError(e);
			return false;
		}

		return true;
	}
	//  작업을 실행할 쓰레드를 만들어야지
	bool InitThreads(int nCount)
	{
		try
		{
			for (int nI = 0; nI < nCount; ++nI)
			{
				auto thr = std::make_unique<std::thread>([this]() 
				{ 
					m_ios.run(); 
				});
				m_vecThreads.push_back(std::move(thr));
			}
		}
		catch (std::bad_weak_ptr& e)
		{
			this->OnError(e);
			return false;
		}
		catch (std::exception& e)
		{
			this->OnError(e);
			return false;
		}

		return true;
	}
	bool InitTcpServer(const char* pszIp, unsigned short uiPort, bool bReuse, int nCurrentAccepts)
	{
		try
		{
			boost::asio::ip::tcp::endpoint endpoint_;

			endpoint_.address(boost::asio::ip::address::from_string(pszIp));
			endpoint_.port(uiPort);

			std::shared_ptr<boost::asio::ip::tcp::acceptor> acceptor_ = std::make_shared<boost::asio::ip::tcp::acceptor>(m_ios);
			acceptor_->open(endpoint_.protocol());

			boost::asio::socket_base::reuse_address option(bReuse);
			acceptor_->set_option(option);
			acceptor_->bind(endpoint_);
			acceptor_->listen();

			for (int nI = 0; nI < nCurrentAccepts; ++nI)
			{
				int nSlot;
				int nIdentity;
				_shared_session_t sess;

				if (false == m_cPool.Allocate(nSlot, nIdentity, sess))
					return false;

				sess->PostAccept(acceptor_);
			}

			m_acceptors.push_back(std::move(acceptor_));
		}
		catch (std::bad_weak_ptr& e)
		{
			this->OnError(e);
			return false;
		}
		catch (std::exception& e)
		{
			this->OnError(e);
			return false;
		}

		return true;
	}
	bool ConnectTcpServer(const char* pszIp, unsigned short uiPort, int* pnIndex = nullptr, int* pnIdentity = nullptr)
	{
		boost::asio::ip::tcp::endpoint endpoint_;

		try
		{
			endpoint_.address(boost::asio::ip::address::from_string(pszIp));
			endpoint_.port(uiPort);
		}
		catch (std::bad_exception& e)
		{
			this->OnError(e);
			return false;
		}
		catch (std::exception& e)
		{
			this->OnError(e);
			return false;
		}

		int nSlot;
		int nIdentity;
		_shared_session_t sess;

		if (false == m_cPool.Allocate(nSlot, nIdentity, sess))
			return false;

		if (false == sess->PostConnect(endpoint_))
			return false;

		if (nullptr != pnIndex)
			*pnIndex = sess->GetIndex();

		if (nullptr != pnIdentity)
			*pnIdentity = sess->GetIdentity();

		return true;
	}
	void Uninit()
	{
		try
		{
			// 끝났다는 것을..
			m_bEnd = true;

			// accept 중인 것들을 우선으로 정리하고
			for_each(m_acceptors.begin(), m_acceptors.end(), [](_acceptors_t::value_type& v) {
				v->cancel();
				v->close();
			});

			// 살아 있는 세션이 있다면
			m_cPool.Cancel();
			m_cTimers.Cancel();

			// 작업이 없으면 io_service가 종료하도록
			m_work.reset();

			// 쓰레드가 종료하기를 기다린다
			for (const auto& itr : m_vecThreads)
			{
				if (true == itr->joinable())
					itr->join();
			}

			// 살아 있는 세션이 있다면
			m_cPool.Uninit();
			m_cTimers.Uninit();
		}
		catch (std::bad_exception& e)
		{
			this->OnError(e);
		}
		catch (std::exception& e)
		{
			this->OnError(e);
		}
	}
	inline bool SetTimer(int nId, int nPeriod)
	{
		return m_cTimers.SetTimer(nId, nPeriod);
	}
	inline bool ResetTimer(int nId)
	{
		return m_cTimers.ResetTimer(nId);
	}
	inline bool Send(int nIndex, int nIdentity, int nLen, const unsigned char* pchData)
	{
		return m_cPool.Send(nIndex, nIdentity, nLen, pchData);
	}
	inline bool Close(int nIndex, int nIdentity)
	{
		return m_cPool.Close(nIndex, nIdentity);
	}
	inline bool Post(int nIndex, int nIdentity, int nOption, int nLen, const unsigned char* pchData)
	{
		return m_cPool.Post(nIndex, nIdentity, nOption, nLen, pchData);
	}
	template <typename T>inline bool Post(int nIndex, int nIdentity, T&& _t)
	{
		return m_cPool.Post(nIndex, nIdentity, std::forward<T>(_t));
	}
	inline int GetPoolCount()
	{
		return m_cPool.GetCount();
	}
	inline int GetPoolFreeCount()
	{
		return m_cPool.GetFreeCount();
	}
	inline bool Find(int nIndex, _shared_session_t& sess)
	{
		return m_cPool.Find(nIndex, sess);
	}
	void CheckTimeout(time_t diff)
	{
		time_t curr = std::time(nullptr);

		int nPoolCount = m_cPool.GetCount();
		for (int nI = 0; nI < nPoolCount; ++nI)
		{
			_shared_session_t sess;
			if (false == m_cPool.Find(nI, sess))
				continue;

			if (false == sess->IsConn())
				continue;

			if (diff < curr - sess->GetLastReceivedTime())
				m_cPool.Close(sess->GetIndex(), sess->GetIdentity());
		}
	}
	virtual bool Allocate(int& nSlot, int& nIdentity, _shared_session_t& sess) override
	{ 
		return m_cPool.Allocate(nSlot, nIdentity, sess);
	}
	virtual void Deallocate(int nSlot, int nIdentity)  override
	{ 
		return m_cPool.Deallocate(nSlot, nIdentity);
	}
	virtual bool IsEnd() override
	{ 
		return m_bEnd; 
	}
	virtual bool Assemble(int nPktLen, int nMaxHdLen, int* pnLen, unsigned char* pchHd) override
	{
		*pnLen = 0;
		return true;
	}
	virtual bool Disassemble(int nIndex, int nIdentity, int nLen, const unsigned char* pchData, int* pnTotalLen, int* pnHdLen, int* pnDataLen) override
	{
		*pnTotalLen = nLen;
		*pnHdLen = 0;
		*pnDataLen = nLen;
		return true;
	}
	virtual int GetInitReceiveBufferSize() override
	{
		return m_nNormalPacketSize;
	}
	virtual void OnTimer(int nId, const boost::system::error_code& error)
	{
	}
	virtual void OnAccepted(int nIndex, int nIdentity, _session_t*) override
	{
	}
	virtual void OnConnected(int nIndex, int nIdentity, _session_t*) override
	{
	}
	virtual void OnClosed(int nIndex, int nIdentity, _session_t*) override
	{
	}
	virtual void OnReceived(int nIndex, int nIdentity, int nLen, const unsigned char* pchData, _session_t*) override
	{
#ifdef _DEBUG
		this->Send(nIndex, nIdentity, nLen, pchData);
#endif
	}
	virtual void OnSent(int nIndex, int nIdentity, int nSentBytes, _session_t*) override
	{
	}
	virtual void OnPosted(int nIndex, int nIdentity, int nOption, int nLen, const unsigned char* pchData, _session_t*) override
	{
	}
	// 1. boost error
	virtual void OnError(const boost::system::error_code& error) override
	{
//#ifdef _DEBUG
//		std::cout << "OnError boost :: " << error.message() << std::endl;
//#endif
	}

	// 2. boost error
	virtual void OnError(int32_t index, int32_t identify, const boost::system::error_code& error) override
	{
		//#ifdef _DEBUG
		//		std::cout << "OnError boost :: " << error.message() << std::endl;
		//#endif
	}

	// 3. c++ 기본 (stl 포함)
	virtual void OnError(const std::exception& error) override
	{
//#ifdef _DEBUG
//		std::cout << "OnError :: " << error.what() << std::endl;
//#endif
	}
	// 4. 순수 처리 오류
	virtual void OnError(const char* pszError) override
	{
//#ifdef _DEBUG
//		std::cout << "OnError X :: " << pszError << std::endl;
//#endif
	}

private:
	bool m_bEnd;
	int m_nNormalPacketSize;
	_threads_t m_vecThreads;
	session_pool<_SESSION_T> m_cPool;
	pump_timers m_cTimers;
	std::shared_ptr<boost::asio::io_service::work> m_work;
	_acceptors_t m_acceptors;
};

} // nmsp

#endif
