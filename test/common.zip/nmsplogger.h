﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: 
// 설  명:
//

// 호환성을 위해서..
#pragma once
#ifndef __NMSPLOGGER_H__
#define __NMSPLOGGER_H__

//
#include <boost/format.hpp>
#include <boost/filesystem.hpp>
#include <boost/log/core.hpp>
#include <boost/log/expressions.hpp>
#include <boost/log/expressions/predicates/is_in_range.hpp>
#include <boost/log/expressions/formatters/date_time.hpp>
#include <boost/log/trivial.hpp>
#include <boost/log/sinks/text_multifile_backend.hpp>
#include <boost/log/sinks/async_frontend.hpp>
#include <boost/log/sinks/sync_frontend.hpp>
#include <boost/log/sinks/text_file_backend.hpp>
#include <boost/log/sinks/text_ostream_backend.hpp>
#include <boost/log/sinks/bounded_fifo_queue.hpp>
#include <boost/log/sinks/drop_on_overflow.hpp>
#include <boost/log/sources/severity_logger.hpp>
#include <boost/log/sources/record_ostream.hpp>
#include <boost/log/sources/severity_logger.hpp>
#include <boost/log/sources/record_ostream.hpp>
#include <boost/log/utility/formatting_ostream.hpp>
#include <boost/log/utility/manipulators/to_log.hpp>
#include <boost/log/utility/setup/file.hpp>
#include <boost/log/utility/setup/console.hpp>
#include <boost/log/utility/setup/common_attributes.hpp>
#include <boost/log/attributes/mutable_constant.hpp>
#include <boost/log/attributes/scoped_attribute.hpp>
#include <boost/log/attributes/named_scope.hpp>
#include <boost/log/attributes/current_thread_id.hpp>
#include <boost/log/attributes/current_process_id.hpp>
#include <boost/log/attributes/current_process_name.hpp>
#include <boost/log/support/date_time.hpp>
#include <boost/log/detail/default_attribute_names.hpp>

#include "nmspInterface.h"
#include "loginterface.h"

//
namespace nmsp { namespace logger {

//
namespace logging = boost::log;
namespace attrs = boost::log::attributes;
namespace src = boost::log::sources;
namespace sinks = boost::log::sinks;
namespace expr = boost::log::expressions;
namespace keywords = boost::log::keywords;
namespace lv = boost::log::trivial;

// 전방선언...
struct nmsp::log::ILog;

//
class backend_linker :
	public sinks::basic_formatted_sink_backend<char, sinks::concurrent_feeding>
{
public:
	backend_linker(unsigned short uiServType, nmsp::log::ILog* piLog)
		: m_uiServType(uiServType)
		, m_piLog(piLog)
	{
		if (m_piLog)
			m_piLog->AddRef();

		m_bAutoFlush = true;
	}
	~backend_linker()
	{
		if (m_piLog)
			m_piLog->Release();
	}
	//void backend_linker::consume(logging::record_view const& rec, string_type const& command_line)
	void consume(logging::record_view const& rec, string_type const& command_line)
	{
		logging::trivial::severity_level eSeverity = logging::trivial::severity_level::info;
		auto itr = rec.attribute_values().find("Severity");
		if (itr != rec.attribute_values().end())
		{
			const logging::value_ref< logging::trivial::severity_level > level = itr->second.extract<logging::trivial::severity_level>();
			eSeverity = level.get();
		}

		if (m_piLog)
			m_piLog->LogAnsi(m_uiServType, eSeverity, command_line.c_str());
	}

private:
	bool m_bAutoFlush;
	unsigned short m_uiServType;
	nmsp::log::ILog* m_piLog;
};

class logger : public src::severity_logger_mt<logging::trivial::severity_level>
{
	typedef sinks::synchronous_sink<backend_linker> text_sink_t;
	typedef sinks::synchronous_sink<sinks::text_ostream_backend> console_sink_t;

public:
	logger() = default;
	~logger(void) = default;
	bool logger::init(unsigned short uiServiceType, nmsp::log::ILog* piLog, logging::trivial::severity_level sev_level, const std::string& prefix_name = "", bool use_console = false)
	{
		boost::shared_ptr<backend_linker> backend = boost::make_shared<backend_linker>(uiServiceType, piLog);
		boost::shared_ptr<text_sink_t> sink = boost::make_shared<text_sink_t>(backend);

		sink->set_formatter
		(
			expr::stream
			<< "[" << expr::format_date_time<boost::posix_time::ptime>(logging::aux::default_attribute_names::timestamp(), "%Y-%m-%d %H:%M:%S.%f") << "]"
			<< "[" << logging::trivial::severity << "]"
			<< "[" << expr::attr< logging::thread_id >(logging::aux::default_attribute_names::thread_id()) << "]"
			<< "[" << expr::smessage << "]"
			//<< "[" << expr::format_named_scope("Scopes", keywords::format = "%n", keywords::iteration = expr::forward, keywords::depth = 1) << "]"
		);

		if (true == prefix_name.empty())
		{
			sink->set_filter(logging::trivial::severity >= sev_level && expr::attr<std::string>("prefix") == "global");
		}
		else
		{
			sink->set_filter(logging::trivial::severity >= sev_level && expr::attr<std::string>("prefix") == prefix_name);
		}

		logging::add_common_attributes();
		logging::core::get()->add_global_attribute("Scopes", attrs::named_scope());
		logging::core::get()->add_global_attribute("prefix", attrs::constant< std::string >("global"));
		logging::core::get()->add_sink(sink);
		
#ifdef CONSOLE_LOG
		if (use_console)
		{
			boost::shared_ptr<sinks::text_ostream_backend> console_backend = boost::make_shared<sinks::text_ostream_backend>();
			console_backend->add_stream(boost::shared_ptr<std::ostream>(&std::clog, [](void*) {}));
			console_backend->auto_flush(true);

			boost::shared_ptr<console_sink_t> console_sink(new console_sink_t(console_backend));
			console_sink->set_formatter
			(
				expr::stream
				<< "[" << expr::format_date_time<boost::posix_time::ptime>(logging::aux::default_attribute_names::timestamp(), "%Y-%m-%d %H:%M:%S.%f") << "]"
				<< "[" << logging::trivial::severity << "]"
				<< "[" << expr::attr< logging::thread_id >(logging::aux::default_attribute_names::thread_id()) << "]"
				<< "[" << expr::smessage << "]"
				// << "[" << expr::format_named_scope("Scopes", keywords::format = "%n", keywords::iteration = expr::forward, keywords::depth = 1) << "]"
			);

			if (true == prefix_name.empty())
			{
				console_sink->set_filter(logging::trivial::severity >= sev_level && expr::attr<std::string>("prefix") == "global");
			}
			else
			{
				console_sink->set_filter(logging::trivial::severity >= sev_level && expr::attr<std::string>("prefix") == prefix_name);
			}

			logging::core::get()->add_sink(console_sink);
		}
#endif
		return true;
	}
};

} }		// logger	// nmsp

#endif
