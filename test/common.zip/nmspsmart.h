﻿////////////////////////////////////////////////////////////////////////////////
//
// 작성자 : huelee
// 설  명 : 
//

#pragma once
#ifndef __NMSPSMART_H__
#define __NMSPSMART_H__

namespace nmsp {

// 
template <typename REF>
class smartinterface
{
	using _SAME_T = smartinterface<REF>;

public:
	typedef REF _T;
	typedef REF element_type;

public:
	smartinterface(REF* pcNode)
		:m_pcRef(pcNode)
	{
		if (m_pcRef)
		{
			m_pcRef->AddRef();
		}
	}
	smartinterface()
		:m_pcRef(nullptr)
	{
	}
	smartinterface(const _SAME_T& cObj)
	{
		m_pcRef = cObj.m_pcRef;

		if (m_pcRef)
		{
			m_pcRef->AddRef();
		}
	}
	smartinterface(_SAME_T&& cObj)
	{
		m_pcRef = cObj.m_pcRef;

		cObj.m_pcRef = nullptr;
	}
	~smartinterface()
	{
		if (m_pcRef)
		{
			m_pcRef->Release();
		}
	}
	inline REF* operator->()
	{
		return m_pcRef;
	}
	inline REF* operator->() const
	{
		return m_pcRef;
	}
	inline REF& operator *()
	{
		return *m_pcRef;
	}
	inline REF& operator *() const
	{
		return *m_pcRef;
	}
	inline REF* operator=(const _SAME_T& cObj)
	{
		REF* pcOldRef = m_pcRef;

		m_pcRef = cObj.m_pcRef;

		if (m_pcRef)
		{
			m_pcRef->AddRef();
		}

		if (pcOldRef)
		{
			pcOldRef->Release();
		}

		return m_pcRef;
	}
	inline REF* operator=(_SAME_T&& cObj)
	{
		REF* pcOldRef = m_pcRef;

		m_pcRef = cObj.m_pcRef;

		cObj.m_pcRef = nullptr;

		if (pcOldRef)
		{
			pcOldRef->Release();
		}

		return m_pcRef;
	}
	inline REF* operator=(REF* pcRef)
	{
		REF* pcOldRef = m_pcRef;

		m_pcRef = pcRef;

		if (m_pcRef)
		{
			m_pcRef->AddRef();
		}

		if (pcOldRef)
		{
			pcOldRef->Release();
		}

		return m_pcRef;
	}
	inline REF* operator=(const REF& cRef)
	{
		if (nullptr == m_pcRef)
			return nullptr;

		*m_pcRef = cRef;

		return m_pcRef;
	}
	inline operator REF* ()
	{
		return m_pcRef;
	}
	inline operator const REF* () const
	{
		return m_pcRef;
	}
	inline operator REF** ()
	{
		return &m_pcRef;
	}
	inline operator const REF** () const
	{
		return &m_pcRef;
	}
	inline operator void** ()
	{
		return reinterpret_cast<void**>(&m_pcRef);
	}
	inline operator const void** () const
	{
		return reinterpret_cast<void**>(&m_pcRef);
	}
	inline REF* get() const
	{
		return m_pcRef;
	}

public:
	template <class T, class R> friend bool operator == (const T& _tVal, const smartinterface<R>& cRef);
	template <class R> friend bool operator == (const smartinterface<R>& cVal, const smartinterface<R>& cRef);
	template <class T, class R> friend bool operator != (const T& _tVal, const smartinterface<R>& cRef);
	template <class R> friend bool operator != (const smartinterface<R>& cVal, const smartinterface<R>& cRef);
	template <class T> inline bool operator == (const T& _tVal)
	{
		return reinterpret_cast<REF*>(_tVal) == m_pcRef ? true : false;
	}
	template <class T> inline bool operator == (const T& _tVal) const
	{
		return reinterpret_cast<REF*>(_tVal) == m_pcRef ? true : false;
	}
	inline bool operator == (const smartinterface<REF>& cVal)
	{
		return cVal.m_pcRef == m_pcRef ? true : false;
	}
	inline bool operator == (const smartinterface<REF>& cVal) const
	{
		return cVal.m_pcRef == m_pcRef ? true : false;
	}
	template <class T> inline bool operator != (const T& _tVal)
	{
		return reinterpret_cast<REF*>(_tVal) != m_pcRef ? true : false;
	}
	template <class T> inline bool operator != (const T& _tVal) const
	{
		return reinterpret_cast<REF*>(_tVal) != m_pcRef ? true : false;
	}
	template <class T> inline bool operator != (const smartinterface<REF>& cVal)
	{
		return cVal.m_pcRef != m_pcRef ? true : false;
	}
	template <class T> inline bool operator != (const smartinterface<REF>& cVal) const
	{
		return cVal.m_pcRef != m_pcRef ? true : false;
	}
	inline bool operator !()
	{
		return !m_pcRef;
	}
	inline bool operator !() const
	{
		return !m_pcRef;
	}

private:
	REF* m_pcRef;
};

template <class T, class R> bool operator == (const T& _tVal, const smartinterface<R>& cRef)
{
	return reinterpret_cast<R*>(_tVal) == cRef.m_pcRef ? true : false;
}

template <class R> bool operator == (const smartinterface<R>& cVal, const smartinterface<R>& cRef)
{
	return cVal.m_pcRef == cRef.m_pcRef ? true : false;
}

template <class T, class R> bool operator != (const T& _tVal, const smartinterface<R>& cRef)
{
	return reinterpret_cast<R*>(_tVal) != cRef.m_pcRef ? true : false;
}

template <class R> bool operator != (const smartinterface<R>& cVal, const smartinterface<R>& cRef)
{
	return cVal.m_pcRef != cRef.m_pcRef ? true : false;
}

} // nmsp

#endif
