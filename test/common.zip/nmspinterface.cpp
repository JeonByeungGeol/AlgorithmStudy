////////////////////////////////////////////////////////////////////////////////
//
// �ۼ��� : huelee
// ��  �� : 
//

//
#include <string>
#include "nmspinterface.h"

namespace nmsp {

// {24E13F6D-3C27-4833-86C5-6654CCD7B48B}
const UUID UUID_IComponentBase = { 0x24e13f6d, 0x3c27, 0x4833,{ 0x86, 0xc5, 0x66, 0x54, 0xcc, 0xd7, 0xb4, 0x8b } };

// {17AE6FDD-BC24-41B5-BDAF-0A5243B10F4A}
const UUID UUID_IComponent = { 0x17ae6fdd, 0xbc24, 0x41b5,{ 0xbd, 0xaf, 0xa, 0x52, 0x43, 0xb1, 0xf, 0x4a } };

// {2E135C00-17D8-4C40-9CDA-BF8EC5A143B8}
const UUID UUID_IComponentContainer = { 0x2e135c00, 0x17d8, 0x4c40,{ 0x9c, 0xda, 0xbf, 0x8e, 0xc5, 0xa1, 0x43, 0xb8 } };

}
