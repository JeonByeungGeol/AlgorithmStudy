﻿
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __NMSPDISPATCHOBJPOOL_H__
#define __NMSPDISPATCHOBJPOOL_H__

//
namespace nmsp {
	
/*

// template parameter
// int : key type
// int : queue에 push할 타입 (예제라 int임)
// tbb::strict_ppl::concurrent_queue : queue로 사용할 자료 구조 (thread safety해야 함)
// nmsp::pool::allocator_from_pool<> : memory allocator임
struct _object_ext_t : public nmsp::dispatch_obj_pool<int, int, tbb::strict_ppl::concurrent_queue, nmsp::pool::allocator_from_pool<>>::dispatch_obj
{
	using __super_t = nmsp::dispatch_obj_pool<int, int, tbb::strict_ppl::concurrent_queue, nmsp::pool::allocator_from_pool<>>::dispatch_obj;
	_object_ext_t(int key)
		: __super_t(key)
	{
	}
};

//
void main(int argc, char* argv[])
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	nmsp::smartinterface<_object_ext_t> xrray[10000];

	for (int nI = 0; nI < ARRAYSIZE(xrray); nI++)
		xrray[nI] = new _object_ext_t(nI);

	nmsp::dispatch_obj_pool<int, int, tbb::strict_ppl::concurrent_queue, nmsp::pool::allocator_from_pool<>> pool;
	pool.Init(3);

	std::chrono::steady_clock::time_point start = std::chrono::steady_clock::now();

	//
	{
		for (int nI = 0; nI < 1000000; ++nI)
		{
			auto mod = nI % ARRAYSIZE(xrray);
			pool.Push(xrray[mod], 1);
		}

		while (true)
		{
			if (pool.Empty())
				break;
			std::this_thread::yield();
		}
	}

	std::chrono::steady_clock::time_point end = std::chrono::steady_clock::now();
	std::cout << "elapsed time " << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count() << "**" << pool.WorkerWorkCount() << "::" << pool.ControllerWorkCount() << std::endl;

	pool.Uninit();
}
*/

// 
template <typename KEY, typename PARAM, template <typename X, typename Y> class QUEUE, typename ALLOC>
class dispatch_base_obj : public nmsp::new_from_pool<ALLOC>
{
	using _key_t = KEY;
	using _allocator_t = ALLOC;
	using _obj_job_queue_t = QUEUE<PARAM, nmsp::stl_default_allocator<PARAM, _allocator_t>>;
public:
	dispatch_base_obj(_key_t key)
		: m_refs(0)
		, m_key(key)
	{
	}
		
	inline void Push(PARAM&& param)
	{
		m_queue.push(std::forward<PARAM>(param));
	}
		
	virtual void Pop(PARAM& param)
	{
	}
		
	virtual void Process()
	{
		PARAM param;
		if (true == m_queue.try_pop(param))
			Pop(param);
	}
		
	inline int AddRef()
	{
		return ++m_refs;
	}
		
	inline int Release()
	{
		int refs = --m_refs;
		if (0 == refs)
		{
			delete this;
			return 0;
		}
		return refs;
	}

	inline void Clear()
	{
		m_queue.clear();
	}

	inline void SetKey(const _key_t & key)
	{
		m_key = key;
	}
	inline _key_t GetKey()
	{
		return m_key;
	}

private:
	std::atomic_int m_refs;
	_key_t m_key;
	_obj_job_queue_t m_queue;
};

template <typename KEY, typename PARAM, template <typename X, typename Y> class QUEUE, typename ALLOC, typename OBJ = dispatch_base_obj<KEY, PARAM, QUEUE, ALLOC>>
class dispatch_obj_pool
{
public:
	using _key_t = KEY;
	using _param_t = PARAM;
	using _allocator_t = ALLOC;
	using dispatch_obj = OBJ;
	using __this_t = dispatch_obj_pool<KEY, PARAM, QUEUE, ALLOC, OBJ>;

private:
	struct _internal_job_t : public nmsp::new_from_pool<_allocator_t>
	{
		_internal_job_t(dispatch_obj* o)
			: m_refs(0)
			, m_newJob(true)
			, m_obj(o)
		{
		}
		inline int AddRef()
		{
			return ++m_refs;
		}
		inline int Release()
		{
			int refs = --m_refs;
			if (0 == refs)
			{
				delete this;
				return 0;
			}
			return refs;
		}
		int m_refs;
		bool m_newJob;
		nmsp::smartinterface<dispatch_obj> m_obj;
	};

	using _dispatch_thread_with_job_t = nmsp::dispatch_thread<
		nmsp::smartinterface<_internal_job_t>,
		nmsp::stl_default_allocator<nmsp::smartinterface<_internal_job_t>, __this_t::_allocator_t>,
		QUEUE>;

	class __worker_t : public _dispatch_thread_with_job_t
	{
	public:
		__worker_t(__this_t* pool)
			: m_pool(pool)
		{
			m_workCount = 0;
		}
		virtual void Pop(typename _dispatch_thread_with_job_t::_queue_param_t&& n) override
		{
			n->m_obj->Process();

			++m_workCount;
			m_pool->m_controller.Push(std::forward<_queue_param_t>(n));
		}
		inline auto WorkCount()
		{
			return m_workCount;
		}
	private:
		__this_t* m_pool;
		int64_t m_workCount;
	};
	class __controller_t : public _dispatch_thread_with_job_t
	{
		using _container_t = std::unordered_map<_key_t, int, std::hash<_key_t>, std::equal_to<_key_t>, nmsp::stl_default_allocator<std::pair<const _key_t, int>, __this_t::_allocator_t>>;
	public:
		__controller_t(__this_t* pool)
			: m_pool(pool)
		{
			m_workCount = 0;
		}
		virtual void Pop(typename _dispatch_thread_with_job_t::_queue_param_t&& n) override
		{
			++m_workCount;

			auto itrFind = m_container.find(n->m_obj->GetKey());

			if (true == n->m_newJob)
			{
				if (itrFind == m_container.end())
				{
					auto pairRet = m_container.emplace(n->m_obj->GetKey(), 1);
					if (false == pairRet.second)
						return;
				}
				else
				{
					itrFind->second++;
					return;
				}

				n->m_newJob = false;
			}
			else
			{
				itrFind->second--;

				if (0 >= itrFind->second)
				{
					m_container.erase(itrFind);
					return;
				}
			}

			m_pool->m_workers.Push(std::forward<_queue_param_t>(n));
		}
		inline auto WorkCount()
		{
			return m_workCount;
		}

	private:
		_container_t m_container;
		__this_t* m_pool;
		int64_t m_workCount;
	};

	// 내부 함수를 호출하도록
	friend __controller_t;
	friend __worker_t;

public:
	dispatch_obj_pool()
		: m_controller(this)
		, m_workers(this)
	{
	}
	bool Init(int threadCount)
	{
		if (false == m_controller.Init(1))
			return false;
		if (false == m_workers.Init(threadCount))
			return false;
		return true;
	}
	void Uninit()
	{
		m_workers.DoEnd();
		m_controller.DoEnd();
		m_workers.Uninit();
		m_controller.Uninit();
	}
	bool Push(dispatch_obj* o)
	{
		nmsp::smartinterface<_internal_job_t> newJob = new _internal_job_t(o);
		if (nullptr == newJob)
			return false;

		m_controller.Push(std::move(newJob));
		return true;
	}
	bool Push(dispatch_obj* o, PARAM&& param)
	{
		nmsp::smartinterface<_internal_job_t> newJob = new _internal_job_t(o);
		if (nullptr == newJob)
			return false;

		o->Push(std::forward<PARAM>(param));

		m_controller.Push(std::move(newJob));
		return true;
	}
	inline bool Empty()
	{
		return m_controller.Empty() && m_workers.Empty();
	}
	inline auto WorkerWorkCount()
	{
		return m_workers.WorkCount();
	}
	inline auto ControllerWorkCount()
	{
		return m_controller.WorkCount();
	}

private:
	__controller_t m_controller;
	__worker_t m_workers;
};

} // namespace nmsp

#endif
