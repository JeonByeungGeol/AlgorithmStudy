﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __NMSPGRID_H__
#define __NMSPGRID_H__

#define __NEW_GRID_CACHING_2__

namespace nmsp {

// map 의 크기를 알지 못하기 때문에..
// 일단 위치에 해당하는 hash값으로 변환을..

template <typename ELEMENT, typename ALLOC>
class grid : public nmsp::new_from_pool<ALLOC>
{
public:
	using _element_t = ELEMENT;			// grid안에 들어가 있을 뭔가임.
	using _allocator_t = ALLOC;

public:
	grid()
	{
		m_refs = 0;
		m_layerSize = 0;
		m_bucketsSize = 0;
		m_buckets = nullptr;
		m_ranges = nullptr;
		m_elementCount = 0;
	}
	~grid()
	{
		if (nullptr != m_ranges)
		{
			_allocator_t::DestroyMemory(m_ranges);
			m_ranges = nullptr;
		}

		if (nullptr != m_buckets)
		{
			_allocator_t::DestroyMemory(m_buckets);
			m_buckets = nullptr;
		}
	}
	int AddRef()
	{
		return ++m_refs;
	}
	int Release()
	{
		int refs = --m_refs;
		if (0 == refs)
		{
			delete this;
			return 0;
		}
		return refs;
	}
	bool Init(int layerSize, int bucketSize, int defaultRange)
	{
		// 0을 허용한다!
		if (0 > defaultRange || 0 >= bucketSize || 0 >= layerSize)
			return false;

		if (nullptr != m_buckets)
			return false;

		// range를 layer마다 다르게 하고자..
		int memRangeSize = sizeof(int) * layerSize;

		int* ranges = static_cast<int*>(_allocator_t::CreateMemory(memRangeSize));
		if (nullptr == ranges)
			return false;

		// range를 설정한다!
		for (int currLayer = 0; currLayer < layerSize; ++currLayer)
			ranges[currLayer] = defaultRange;

		// bucket
		int totalBuckets = bucketSize * layerSize;
		int memSize = sizeof(_element_t*) * totalBuckets;

		void* bucket = _allocator_t::CreateMemory(memSize);
		if (nullptr == bucket)
			return false;

		memset(bucket, 0x00, memSize);

		m_layerSize = layerSize;
		m_bucketsSize = bucketSize;
		m_buckets = reinterpret_cast<decltype(m_buckets)>(bucket);
		m_ranges = ranges;
		m_elementCount = 0;

		return true;
	}
	void Uninit()
	{
		if (nullptr != m_ranges)
		{
			_allocator_t::DestroyMemory(m_ranges);
			m_ranges = nullptr;
		}

		if (nullptr != m_buckets)
		{
			_allocator_t::DestroyMemory(m_buckets);
			m_buckets = nullptr;
		}

		m_layerSize = 0;
		m_bucketsSize = 0;
		m_elementCount = 0;
	}
	/*
	// ADD (추가 entity, &버킷 저장소)
	template <typename T, typename ADD, typename ADDTRAVERSE>
	bool Add(int layer, _element_t* element, T orgX, T orgY, ADD& add, ADDTRAVERSE& addTraverse)
	{
		if (0 > layer || layer >= m_layerSize)
			return false;

		const int modOrgX = static_cast<int>(std::floor(orgX));
		const int modOrgY = static_cast<int>(std::floor(orgY));

		// grid에 추가하는 작업
		{
			const int range = m_ranges[layer];

			// range가 0이면 전체로 한다!
			if (0 == range)
			{
				if (false == add(layer, element, 0, m_buckets[layer * m_bucketsSize]))
					return false;
			}
			else
			{
				const int tmpModOrgX = modOrgX - CalcMod(modOrgX, range);
				const int tmpModOrgY = modOrgY - CalcMod(modOrgY, range);

				//
				const int bucketIndex = hashPos2(tmpModOrgX, tmpModOrgY, m_bucketsSize);

				if (false == add(layer, element, MakeLoc(tmpModOrgX, tmpModOrgY), m_buckets[layer * m_bucketsSize + bucketIndex]))
					return false;
			}

			++m_elementCount;
		}

		// 순회
		for (int currLayer = 0; currLayer < m_layerSize; ++currLayer)
		{
			const int range = m_ranges[currLayer];

			// 0이면 전체로 한다!
			if (0 == range)
			{
				addTraverse(layer, element, 0, currLayer, m_buckets[currLayer * m_bucketsSize]);
			}
			else
			{
				const int tmpModOrgX = modOrgX - CalcMod(modOrgX, range);
				const int tmpModOrgY = modOrgY - CalcMod(modOrgY, range);

				const int minOrgX = tmpModOrgX - range;
				const int minOrgY = tmpModOrgY - range;
				const int maxOrgX = tmpModOrgX + range;
				const int maxOrgY = tmpModOrgY + range;

				// 작업상태를 초기화 한다
				for (int currX = minOrgX; currX <= maxOrgX; currX += range)
				{
					for (int currY = minOrgY; currY <= maxOrgY; currY += range)
					{
						int bucketIndex = hashPos2(currX, currY, m_bucketsSize);
						addTraverse(layer, element, MakeLoc(currX, currY), currLayer, m_buckets[currLayer * m_bucketsSize + bucketIndex]);
					}
				}
			}
		}
		
		return true;
	}
	*/
	template <typename T, typename ADD, typename ADDLINK>
	bool Add(int layer, _element_t* element, T orgX, T orgY, ADD& add, ADDLINK& addLink)
	{
		if (0 > layer || layer >= m_layerSize)
			return false;

		const int range = m_ranges[layer];

		// 0이면 시야 범위없음
		if (0 == range)
		{
			if (false == add(layer, element, 0, m_buckets[layer * m_bucketsSize]))
				return false;

#ifdef __NEW_GRID_CACHING_2__
			addLink(layer, element, 0);
#endif
		}
		else
		{
			const int modOrgX = static_cast<int>(std::floor(orgX));
			const int modOrgY = static_cast<int>(std::floor(orgY));

			const int tmpModOrgX = modOrgX - CalcMod(modOrgX, range);
			const int tmpModOrgY = modOrgY - CalcMod(modOrgY, range);

			//
			int bucketIndex = hashPos2(tmpModOrgX, tmpModOrgY, m_bucketsSize);

			if (false == add(layer, element, MakeLoc(tmpModOrgX, tmpModOrgY), m_buckets[layer * m_bucketsSize + bucketIndex]))
				return false;

#ifdef __NEW_GRID_CACHING_2__
			const int minOrgX = tmpModOrgX - range;
			const int minOrgY = tmpModOrgY - range;
			const int maxOrgX = tmpModOrgX + range;
			const int maxOrgY = tmpModOrgY + range;

			for (int currX = minOrgX; currX <= maxOrgX; currX += range)
			{
				for (int currY = minOrgY; currY <= maxOrgY; currY += range)
				{
					addLink(layer, element, MakeLoc(currX, currY));
				}
			}
#endif
		}

		++m_elementCount;
		return true;
	}
	/*
	template <typename T, typename DEL, typename DELTRAVERSE>
	bool Del(int layer, _element_t* element, T orgX, T orgY, DEL& del, DELTRAVERSE& delTraverse)
	{
		if (0 > layer || layer >= m_layerSize)
			return false;

		const int modOrgX = static_cast<int>(std::floor(orgX));
		const int modOrgY = static_cast<int>(std::floor(orgY));

		// grid에서 삭제하는 작업 !
		{
			const int range = m_ranges[layer];

			// 0이면 시야 범위 없음
			if (0 == range)
			{
				if (false == del(layer, element, 0, m_buckets[layer * m_bucketsSize]))
					return false;
			}
			else
			{
				const int tmpModOrgX = modOrgX - CalcMod(modOrgX, range);
				const int tmpModOrgY = modOrgY - CalcMod(modOrgY, range);

				//
				const int bucketIndex = hashPos2(tmpModOrgX, tmpModOrgY, m_bucketsSize);

				if (false == del(layer, element, MakeLoc(tmpModOrgX, tmpModOrgY), m_buckets[layer * m_bucketsSize + bucketIndex]))
					return false;
			}

			--m_elementCount;
		}

		// 순회
		for (int currLayer = 0; currLayer < m_layerSize; ++currLayer)
		{
			const int range = m_ranges[currLayer];

			if (0 == range)
			{
				delTraverse(layer, element, 0, currLayer, m_buckets[currLayer * m_bucketsSize]);
			}
			else
			{
				const int tmpModOrgX = modOrgX - CalcMod(modOrgX, range);
				const int tmpModOrgY = modOrgY - CalcMod(modOrgY, range);

				const int minOrgX = tmpModOrgX - range;
				const int minOrgY = tmpModOrgY - range;
				const int maxOrgX = tmpModOrgX + range;
				const int maxOrgY = tmpModOrgY + range;

				for (int currX = minOrgX; currX <= maxOrgX; currX += range)
				{
					for (int currY = minOrgY; currY <= maxOrgY; currY += range)
					{
						int bucketIndex = hashPos2(currX, currY, m_bucketsSize);
						delTraverse(layer, element, MakeLoc(currX, currY), currLayer, m_buckets[currLayer * m_bucketsSize + bucketIndex]);
					}
				}
			}
		}

		return true;
	}
	*/
	template <typename T, typename DEL, typename DELLINK>
	bool Del(int layer, _element_t* element, T orgX, T orgY, DEL& del, DELLINK& delLink)
	{
		if (0 > layer || layer >= m_layerSize)
			return false;

		const int range = m_ranges[layer];

		// 0이면 시야 범위 없음
		if (0 == range)
		{
			if (false == del(layer, element, 0, m_buckets[layer * m_bucketsSize]))
				return false;

#ifdef __NEW_GRID_CACHING_2__
			delLink(layer, element, 0);
#endif
		}
		else
		{
			const int modOrgX = static_cast<int>(std::floor(orgX));
			const int modOrgY = static_cast<int>(std::floor(orgY));

			const int tmpModOrgX = modOrgX - CalcMod(modOrgX, range);
			const int tmpModOrgY = modOrgY - CalcMod(modOrgY, range);

			int bucketIndex = hashPos2(tmpModOrgX, tmpModOrgY, m_bucketsSize);

			if (false == del(layer, element, MakeLoc(tmpModOrgX, tmpModOrgY), m_buckets[layer * m_bucketsSize + bucketIndex]))
				return false;

#ifdef __NEW_GRID_CACHING_2__
			const int minOrgX = tmpModOrgX - range;
			const int minOrgY = tmpModOrgY - range;
			const int maxOrgX = tmpModOrgX + range;
			const int maxOrgY = tmpModOrgY + range;

			for (int currX = minOrgX; currX <= maxOrgX; currX += range)
			{
				for (int currY = minOrgY; currY <= maxOrgY; currY += range)
				{
					delLink(layer, element, MakeLoc(currX, currY));
				}
			}
#endif
		}

		--m_elementCount;
		return true;
	}
	template <typename T, typename MOVE, typename MOVETRAVERSE>
	bool LayerbaseMove(int baseLayer, _element_t* element, T oldX, T oldY, T newX, T newY, MOVE& move, MOVETRAVERSE& moveTraverse)
	{
		if (0 > baseLayer || baseLayer >= m_layerSize)
			return false;

		const int baseRange = m_ranges[baseLayer];

		// 범위가 0이라면.. 시야 범위가 전체이므로.. 그냥 리턴한다!
		if (0 == baseRange)
			return true;

		// 이전 
		const int modOldX = static_cast<int>(std::floor(oldX));
		const int modOldY = static_cast<int>(std::floor(oldY));

		// 이후
		const int modNewX = static_cast<int>(std::floor(newX));
		const int modNewY = static_cast<int>(std::floor(newY));

		// 이동
		{
			const int tmpModOldX = modOldX - CalcMod(modOldX, baseRange);
			const int tmpModOldY = modOldY - CalcMod(modOldY, baseRange);
			const int tmpModNewX = modNewX - CalcMod(modNewX, baseRange);
			const int tmpModNewY = modNewY - CalcMod(modNewY, baseRange);

			const auto oldLoc = MakeLoc(tmpModOldX, tmpModOldY);
			const auto newLoc = MakeLoc(tmpModNewX, tmpModNewY);

			int bucketOldIndex = hashPos2(tmpModOldX, tmpModOldY, m_bucketsSize);
			int bucketNewIndex = hashPos2(tmpModNewX, tmpModNewY, m_bucketsSize);

			if (false == move(baseLayer, element, oldLoc, bucketOldIndex, m_buckets[baseLayer * m_bucketsSize + bucketOldIndex], newLoc, bucketNewIndex, m_buckets[baseLayer * m_bucketsSize + bucketNewIndex]))
				return false;
		}

		// 순회
		for (int currLayer = 0; currLayer < m_layerSize; ++currLayer)
		{
			int currMaxRange = m_ranges[currLayer];

			// 범위가 없는 경우이므로 어떤 이동도 영향을 주지 않는다!
			if (0 == currMaxRange)
				continue;

			int currMinRange = m_ranges[currLayer];
			if (currMinRange > baseRange)
				currMinRange = baseRange;

			const int tmpModOldX = modOldX - CalcMod(modOldX, currMinRange);
			const int tmpModOldY = modOldY - CalcMod(modOldY, currMinRange);
			const int tmpModNewX = modNewX - CalcMod(modNewX, currMinRange);
			const int tmpModNewY = modNewY - CalcMod(modNewY, currMinRange);

			const auto oldLoc = MakeLoc(tmpModOldX, tmpModOldY);
			const auto newLoc = MakeLoc(tmpModNewX, tmpModNewY);

			// 그리드 경계를 이동하지 않았다면 여기서 리턴
			if (oldLoc == newLoc)
				continue;

			if (currMaxRange < baseRange)
				currMaxRange = baseRange;

			const int minOldX = tmpModOldX - currMaxRange;
			const int minOldY = tmpModOldY - currMaxRange;
			const int maxOldX = tmpModOldX + currMaxRange;
			const int maxOldY = tmpModOldY + currMaxRange;

			const int minNewX = tmpModNewX - currMaxRange;
			const int minNewY = tmpModNewY - currMaxRange;
			const int maxNewX = tmpModNewX + currMaxRange;
			const int maxNewY = tmpModNewY + currMaxRange;

			int currOriginRange = m_ranges[currLayer];

			int halfCurrOriginRange = currMinRange;
			if (currMaxRange != currMinRange)
				halfCurrOriginRange = CalcGcf(currMaxRange, currMinRange);

			int bucketBase = currLayer * m_bucketsSize;
			int bucketIndex;

			int minIX = 0;
			int minIY = 0;
			int maxIX = 0;
			int maxIY = 0;

			if (false == Intercection(
				minOldX, minOldY, maxOldX - minOldX, maxOldY - minOldY,
				minNewX, minNewY, maxNewX - minNewX, maxNewY - minNewY,
				minIX, minIY, maxIX, maxIY))
			{
				for (int currX = minOldX; currX <= maxOldX + currMaxRange - 1; currX += halfCurrOriginRange)
				{
					for (int currY = minOldY; currY <= maxOldY + currMaxRange - 1; currY += halfCurrOriginRange)
					{
						bucketIndex = hashPos2(currX, currY, currOriginRange, m_bucketsSize);
						moveTraverse(true, false, baseLayer, element, MakeLoc(currX, currY, halfCurrOriginRange), currLayer, halfCurrOriginRange, m_buckets[bucketBase + bucketIndex]);
					}
				}

				for (int currX = minNewX; currX <= maxNewX + currMaxRange - 1; currX += halfCurrOriginRange)
				{
					for (int currY = minNewY; currY <= maxNewY + currMaxRange - 1; currY += halfCurrOriginRange)
					{
						bucketIndex = hashPos2(currX, currY, currOriginRange, m_bucketsSize);
						moveTraverse(false, true, baseLayer, element, MakeLoc(currX, currY, halfCurrOriginRange), currLayer, halfCurrOriginRange, m_buckets[bucketBase + bucketIndex]);
					}
				}
			}
			else
			{
				maxIX += (minIX + currMaxRange - 1);
				maxIY += (minIY + currMaxRange - 1);

				for (int currX = minOldX; currX <= maxOldX + currMaxRange - 1; currX += halfCurrOriginRange)
				{
					for (int currY = minOldY; currY <= maxOldY + currMaxRange - 1; currY += halfCurrOriginRange)
					{
						if (minIX <= currX && currX <= maxIX && minIY <= currY && currY <= maxIY)
						{
							bucketIndex = hashPos2(currX, currY, currOriginRange, m_bucketsSize);
							moveTraverse(false, false, baseLayer, element, MakeLoc(currX, currY, halfCurrOriginRange), currLayer, halfCurrOriginRange, m_buckets[bucketBase + bucketIndex]);
						}
						else
						{
							bucketIndex = hashPos2(currX, currY, currOriginRange, m_bucketsSize);
							moveTraverse(true, false, baseLayer, element, MakeLoc(currX, currY, halfCurrOriginRange), currLayer, halfCurrOriginRange, m_buckets[bucketBase + bucketIndex]);
						}
					}
				}

				for (int currX = minNewX; currX <= maxNewX + currMaxRange - 1; currX += halfCurrOriginRange)
				{
					for (int currY = minNewY; currY <= maxNewY + currMaxRange - 1; currY += halfCurrOriginRange)
					{
						if (minIX <= currX && currX <= maxIX && minIY <= currY && currY <= maxIY)
							continue;

						bucketIndex = hashPos2(currX, currY, currOriginRange, m_bucketsSize);
						moveTraverse(false, true, baseLayer, element, MakeLoc(currX, currY, halfCurrOriginRange), currLayer, halfCurrOriginRange, m_buckets[bucketBase + bucketIndex]);
					}
				}
			}
		}

		return true;
	}
	template <typename T, typename TRAVERSE>
	void LayerbaseTraverse(int baseLayer, T orgX, T orgY, TRAVERSE& traverse)
	{
		if (0 > baseLayer || baseLayer >= m_layerSize)
			return;

		const int baseRange = m_ranges[baseLayer];

		// 범위가 0이라면.. 시야 범위가 전체이므로.. 그냥 리턴한다!
		if (0 == baseRange)
			return;

		// 기준 좌표
		const int modOrgX = static_cast<int>(std::floor(orgX));
		const int modOrgY = static_cast<int>(std::floor(orgY));

		for (int currLayer = 0; currLayer < m_layerSize; ++currLayer)
		{
			int currMaxRange = m_ranges[currLayer];

			// 범위가 없는 경우이므로 어떤 이동도 영향을 주지 않는다!
			if (0 == currMaxRange)
			{
				traverse(this, static_cast<int64_t>(0), currLayer, currMaxRange, m_buckets[currLayer * m_bucketsSize]);
			}
			else
			{
				if (currMaxRange < baseRange)
					currMaxRange = baseRange;

				int currMinRange = m_ranges[currLayer];
				if (currMinRange > baseRange)
					currMinRange = baseRange;

				const int tmpModOrgX = modOrgX - CalcMod(modOrgX, currMinRange);
				const int tmpModOrgY = modOrgY - CalcMod(modOrgY, currMinRange);

				const int minOrgX = tmpModOrgX - currMaxRange;
				const int minOrgY = tmpModOrgY - currMaxRange;
				const int maxOrgX = tmpModOrgX + currMaxRange + currMaxRange - 1;
				const int maxOrgY = tmpModOrgY + currMaxRange + currMaxRange - 1;

				int currOriginRange = m_ranges[currLayer];

				int halfCurrOriginRange = currMinRange;
				if (currMaxRange != currMinRange)
					halfCurrOriginRange = CalcGcf(currMaxRange, currMinRange);

				int bucketBase = currLayer * m_bucketsSize;
				int bucketIndex;

				for (int currX = minOrgX; currX <= maxOrgX; currX += halfCurrOriginRange)
				{
					for (int currY = minOrgY; currY <= maxOrgY; currY += halfCurrOriginRange)
					{
						bucketIndex = hashPos2(currX, currY, currOriginRange, m_bucketsSize);
						traverse(this, MakeLoc(currX, currY, halfCurrOriginRange), currLayer, halfCurrOriginRange, m_buckets[bucketBase + bucketIndex]);
					}
				}
			}
		}
	}
	template <typename T, typename TRAVERSE>
	void LayerbaseTraverse(int baseLayer, T orgX, T orgY, TRAVERSE& traverse, int currLayer)
	{
		if (0 > baseLayer || baseLayer >= m_layerSize ||
			0 > currLayer || currLayer >= m_layerSize)
			return;

		const int baseRange = m_ranges[baseLayer];

		// 범위가 0이라면.. 시야 범위가 전체이므로.. 그냥 리턴한다!
		if (0 == baseRange)
			return;

		int currMaxRange = m_ranges[currLayer];

		// 범위가 없는 경우이므로 어떤 이동도 영향을 주지 않는다!
		if (0 == currMaxRange)
		{
			traverse(this, static_cast<int64_t>(0), currLayer, currMaxRange, m_buckets[currLayer * m_bucketsSize]);
		}
		else
		{
			// 기준 좌표
			const int modOrgX = static_cast<int>(std::floor(orgX));
			const int modOrgY = static_cast<int>(std::floor(orgY));

			if (currMaxRange < baseRange)
				currMaxRange = baseRange;

			int currMinRange = m_ranges[currLayer];
			if (currMinRange > baseRange)
				currMinRange = baseRange;

			const int tmpModOrgX = modOrgX - CalcMod(modOrgX, currMinRange);
			const int tmpModOrgY = modOrgY - CalcMod(modOrgY, currMinRange);

			const int minOrgX = tmpModOrgX - currMaxRange;
			const int minOrgY = tmpModOrgY - currMaxRange;
			const int maxOrgX = tmpModOrgX + currMaxRange + currMaxRange - 1;
			const int maxOrgY = tmpModOrgY + currMaxRange + currMaxRange - 1;

			int currOriginRange = m_ranges[currLayer];

			int halfCurrOriginRange = currMinRange;
			if (currMaxRange != currMinRange)
				halfCurrOriginRange = CalcGcf(currMaxRange, currMinRange);

			int bucketBase = currLayer * m_bucketsSize;
			int bucketIndex;

			for (int currX = minOrgX; currX <= maxOrgX; currX += halfCurrOriginRange)
			{
				for (int currY = minOrgY; currY <= maxOrgY; currY += halfCurrOriginRange)
				{
					bucketIndex = hashPos2(currX, currY, currOriginRange, m_bucketsSize);
					traverse(this, MakeLoc(currX, currY, halfCurrOriginRange), currLayer, halfCurrOriginRange, m_buckets[bucketBase + bucketIndex]);
				}
			}
		}
	}
	/*
	template <typename T, typename MOVE, typename MOVETRAVERSE>
	bool Move(int layer, _element_t* element, T oldX, T oldY, T newX, T newY, MOVE& move, MOVETRAVERSE& moveTraverse)
	{
		if (0 > layer || layer >= m_layerSize)
			return false;

		const int currRange = m_ranges[layer];

		// 범위가 0이라면.. 시야 범위가 전체이므로.. 그냥 리턴한다!
		if (0 == currRange)
			return true;

		// 이전 
		const int modOldX = static_cast<int>(std::floor(oldX));
		const int modOldY = static_cast<int>(std::floor(oldY));

		// 이후
		const int modNewX = static_cast<int>(std::floor(newX));
		const int modNewY = static_cast<int>(std::floor(newY));

		// 이동
		{
			// 범위가 0이 아닐때만..
			const int tmpModOldX = modOldX - CalcMod(modOldX, currRange);
			const int tmpModOldY = modOldY - CalcMod(modOldY, currRange);
			const int tmpModNewX = modNewX - CalcMod(modNewX, currRange);
			const int tmpModNewY = modNewY - CalcMod(modNewY, currRange);

			const auto oldLoc = MakeLoc(tmpModOldX, tmpModOldY);
			const auto newLoc = MakeLoc(tmpModNewX, tmpModNewY);

			// bucketIndex를 비교해보자! 
			// 같으면.. 
			//if (oldLoc != newLoc)
			{
				int bucketOldIndex = hashPos2(tmpModOldX, tmpModOldY, m_bucketsSize);
				int bucketNewIndex = hashPos2(tmpModNewX, tmpModNewY, m_bucketsSize);

				if (false == move(layer, element, oldLoc, bucketOldIndex, m_buckets[layer * m_bucketsSize + bucketOldIndex], newLoc, bucketNewIndex, m_buckets[layer * m_bucketsSize + bucketNewIndex]))
					return false;
			}
		}

		// 순회
		for (int currLayer = 0; currLayer < m_layerSize; ++currLayer)
		{
			int range = m_ranges[currLayer];

			// 범위가 없는 경우이므로 어떤 이동도 영향을 주지 않는다!
			if (0 == range)
				continue;

			const int tmpModOldX = modOldX - CalcMod(modOldX, range);
			const int tmpModOldY = modOldY - CalcMod(modOldY, range);
			const int tmpModNewX = modNewX - CalcMod(modNewX, range);
			const int tmpModNewY = modNewY - CalcMod(modNewY, range);

			const auto oldLoc = MakeLoc(tmpModOldX, tmpModOldY);
			const auto newLoc = MakeLoc(tmpModNewX, tmpModNewY);

			// layer에 변경된게 없다면 pass한다!
			if (oldLoc == newLoc)
				continue;

			// layer에 대해 변경된게 있다면.. 
			const int minOldX = tmpModOldX - range;
			const int minOldY = tmpModOldY - range;
			const int maxOldX = tmpModOldX + range;
			const int maxOldY = tmpModOldY + range;

			const int minNewX = tmpModNewX - range;
			const int minNewY = tmpModNewY - range;
			const int maxNewX = tmpModNewX + range;
			const int maxNewY = tmpModNewY + range;

			int minIX = 0;
			int minIY = 0;
			int maxIX = 0;
			int maxIY = 0;

			if (false == Intercection(
				minOldX, minOldY, maxOldX - minOldX, maxOldY - minOldY,
				minNewX, minNewY, maxNewX - minNewX, maxNewY - minNewY,
				minIX, minIY, maxIX, maxIY))
			{
				for (int currX = minOldX; currX <= maxOldX; currX += range)
				{
					for (int currY = minOldY; currY <= maxOldY; currY += range)
					{
						int bucketIndex = hashPos2(currX, currY, m_bucketsSize);
						moveTraverse(true, false, layer, element, MakeLoc(currX, currY), currLayer, m_buckets[currLayer * m_bucketsSize + bucketIndex]);
					}
				}

				for (int currX = minNewX; currX <= maxNewX; currX += range)
				{
					for (int currY = minNewY; currY <= maxNewY; currY += range)
					{
						int bucketIndex = hashPos2(currX, currY, m_bucketsSize);
						moveTraverse(false, true, layer, element, MakeLoc(currX, currY), currLayer, m_buckets[currLayer * m_bucketsSize + bucketIndex]);
					}
				}
			}
			else
			{
				maxIX += minIX;
				maxIY += minIY;

				for (int currX = minOldX; currX <= maxOldX; currX += range)
				{
					for (int currY = minOldY; currY <= maxOldY; currY += range)
					{
						if (minIX <= currX && currX <= maxIX && minIY <= currY && currY <= maxIY)
						{
							int bucketIndex = hashPos2(currX, currY, m_bucketsSize);
							moveTraverse(false, false, layer, element, MakeLoc(currX, currY), currLayer, m_buckets[currLayer * m_bucketsSize + bucketIndex]);
						}
						else
						{
							int bucketIndex = hashPos2(currX, currY, m_bucketsSize);
							moveTraverse(true, false, layer, element, MakeLoc(currX, currY), currLayer, m_buckets[currLayer * m_bucketsSize + bucketIndex]);
						}
					}
				}

				for (int currX = minNewX; currX <= maxNewX; currX += range)
				{
					for (int currY = minNewY; currY <= maxNewY; currY += range)
					{
						if (minIX <= currX && currX <= maxIX && minIY <= currY && currY <= maxIY)
							continue;

						int bucketIndex = hashPos2(currX, currY, m_bucketsSize);
						moveTraverse(false, true, layer, element, MakeLoc(currX, currY), currLayer, m_buckets[currLayer * m_bucketsSize + bucketIndex]);
					}
				}
			}
		}

		return true;
	}
	*/
	template <typename T, typename TRAVERSE>
	void Traverse(T orgX, T orgY, TRAVERSE& traverse)
	{
		const int modOrgX = static_cast<int>(std::floor(orgX));
		const int modOrgY = static_cast<int>(std::floor(orgY));

		for (int currLayer = 0; currLayer < m_layerSize; ++currLayer)
		{
			const int range = m_ranges[currLayer];

			// 0이면 경계가 없다!
			if (0 == range)
			{
				traverse(this, 0, currLayer, m_buckets[currLayer * m_bucketsSize]);
			}
			else
			{
				const int tmpModOrgX = modOrgX - CalcMod(modOrgX, range);
				const int tmpModOrgY = modOrgY - CalcMod(modOrgY, range);

				const int minOrgX = tmpModOrgX - range;
				const int minOrgY = tmpModOrgY - range;
				const int maxOrgX = tmpModOrgX + range;
				const int maxOrgY = tmpModOrgY + range;

				for (int currX = minOrgX; currX <= maxOrgX; currX += range)
				{
					for (int currY = minOrgY; currY <= maxOrgY; currY += range)
					{
						int bucketIndex = hashPos2(currX, currY, m_bucketsSize);
						traverse(this, MakeLoc(currX, currY), currLayer, m_buckets[currLayer * m_bucketsSize + bucketIndex]);
					}
				}
			}
		}
	}
	template <typename T, typename TRAVERSE>
	void TraverseInSight(T orgX, T orgY, TRAVERSE& traverse, int sightRange)
	{
		const int modOrgX = static_cast<int>(std::floor(orgX));
		const int modOrgY = static_cast<int>(std::floor(orgY));

		for (int currLayer = 0; currLayer < m_layerSize; ++currLayer)
		{
			const int range = m_ranges[currLayer];

			// 0이면 경계가 없다!
			if (0 == range)
			{
				traverse(this, 0, currLayer, m_buckets[currLayer * m_bucketsSize]);
			}
			else
			{
				int minOrgX = modOrgX - sightRange;
				int minOrgY = modOrgY - sightRange;
				int maxOrgX = modOrgX + sightRange;
				int maxOrgY = modOrgY + sightRange;

				minOrgX -= CalcMod(minOrgX, range);
				minOrgY -= CalcMod(minOrgY, range);
				maxOrgX += (range - CalcMod(maxOrgX, range));
				maxOrgY += (range - CalcMod(maxOrgY, range));

				for (int currX = minOrgX; currX <= maxOrgX; currX += range)
				{
					for (int currY = minOrgY; currY <= maxOrgY; currY += range)
					{
						int bucketIndex = hashPos2(currX, currY, m_bucketsSize);
						traverse(this, MakeLoc(currX, currY), currLayer, m_buckets[currLayer * m_bucketsSize + bucketIndex]);
					}
				}
			}
		}
	}
	template <typename T, typename TRAVERSE>
	void Traverse(T orgX, T orgY, TRAVERSE& traverse, int layer)
	{
		if (0 > layer || layer >= m_layerSize)
			return;

		const int range = m_ranges[layer];

		// range가 0이면 경계가 없다!
		if (0 == range)
		{
			// range가 0인 대상은 모두 bucketIndex = 0에 기록
			traverse(this, 0, layer, m_buckets[layer * m_bucketsSize]);
		}
		else
		{
			const int modOrgX = static_cast<int>(std::floor(orgX));
			const int modOrgY = static_cast<int>(std::floor(orgY));

			const int tmpModOrgX = modOrgX - CalcMod(modOrgX, range);
			const int tmpModOrgY = modOrgY - CalcMod(modOrgY, range);

			const int minOrgX = tmpModOrgX - range;
			const int minOrgY = tmpModOrgY - range;
			const int maxOrgX = tmpModOrgX + range;
			const int maxOrgY = tmpModOrgY + range;

			for (int currX = minOrgX; currX <= maxOrgX; currX += range)
			{
				for (int currY = minOrgY; currY <= maxOrgY; currY += range)
				{
					int bucketIndex = hashPos2(currX, currY, m_bucketsSize);
					traverse(this, MakeLoc(currX, currY), layer, m_buckets[layer * m_bucketsSize + bucketIndex]);
				}
			}
		}
	}
	template <typename T, typename TRAVERSE>
	void TraverseInSight(T orgX, T orgY, TRAVERSE& traverse, int layer, int sightRange)
	{
		if (0 > layer || layer >= m_layerSize)
			return;

		const int range = m_ranges[layer];

		// range가 0이면 경계가 없다!
		if (0 == range)
		{
			// range가 0인 대상은 모두 bucketIndex = 0에 기록
			traverse(this, 0, layer, m_buckets[layer * m_bucketsSize]);
		}
		else
		{
			const int modOrgX = static_cast<int>(std::floor(orgX));
			const int modOrgY = static_cast<int>(std::floor(orgY));

			int minOrgX = modOrgX - sightRange;
			int minOrgY = modOrgY - sightRange;
			int maxOrgX = modOrgX + sightRange;
			int maxOrgY = modOrgY + sightRange;

			minOrgX -= CalcMod(minOrgX, range);
			minOrgY -= CalcMod(minOrgY, range);
			maxOrgX += (range - CalcMod(maxOrgX, range));
			maxOrgY += (range - CalcMod(maxOrgY, range));

			for (int currX = minOrgX; currX <= maxOrgX; currX += range)
			{
				for (int currY = minOrgY; currY <= maxOrgY; currY += range)
				{
					int bucketIndex = hashPos2(currX, currY, m_bucketsSize);
					traverse(this, MakeLoc(currX, currY), layer, m_buckets[layer * m_bucketsSize + bucketIndex]);
				}
			}
		}
	}
	template <typename TRAVERSE>
	void TraverseAll(TRAVERSE& traverse)
	{
		for (int currBucketIndex = 0; currBucketIndex < m_bucketsSize; ++currBucketIndex)
		{
			for (int currLayer = 0; currLayer < m_layerSize; ++currLayer)
			{
				auto tmpLayerIndex = currLayer * m_bucketsSize + currBucketIndex;

				if (nullptr == m_buckets[tmpLayerIndex])
					continue;

				traverse(m_buckets[tmpLayerIndex]);
			}
		}
	}
	template <typename TRAVERSE>
	void TraverseAll(TRAVERSE& traverse, int layer)
	{
		if (0 > layer || layer >= m_layerSize)
			return;

		const auto currLayerIndex = layer * m_bucketsSize;

		for (int currBucketIndex = 0; currBucketIndex < m_bucketsSize; ++currBucketIndex)
		{
			auto tmpLayerIndex = currLayerIndex + currBucketIndex;
			if (nullptr == m_buckets[tmpLayerIndex])
				continue;

			traverse(m_buckets[tmpLayerIndex]);
		}
	}
	template <typename TRAVERSE>
	void TraverseLoc(int64_t loc, TRAVERSE& traverse)
	{
		for (int currLayer = 0; currLayer < m_layerSize; ++currLayer)
		{
			int bucketIndex = hashPos2(loc, m_bucketsSize);
			traverse(m_buckets[currLayer * m_bucketsSize + bucketIndex]);
		}
	}


public:
	inline int Size() const
	{
		return m_elementCount;
	}
	// 0 이면 무제한이다.
	inline bool SetLayerSightRange(int layer, int range)
	{
		// 여기서는 0을 허용한다!
		if (0 > layer || layer >= m_layerSize || 0 > range || 0 != m_elementCount || nullptr == m_ranges)
			return false;

		m_ranges[layer] = range;
		return true;
	}
	inline bool GetLayerSightRange(int layer, int& range)
	{
		if (0 > layer || layer >= m_layerSize || nullptr == m_ranges)
			return false;

		range = m_ranges[layer];
		return true;
	}

public:
	inline int64_t MakeLoc(const float orgX, const float orgY, const int range)
	{
		const int x = static_cast<int>(std::floor(orgX));
		const int y = static_cast<int>(std::floor(orgY));
		return this->MakeLoc(x - CalcMod(x, range), y - CalcMod(y, range));
	}

private:
	// recast에 있는거 가져옮
	inline int hashPos2(int x, int y, int n)
	{
		return ((x * 73856093) ^ (y * 19349663)) & (n - 1);
	}
	inline int hashPos2(int64_t loc, int n)
	{
		return ((static_cast<int32_t>(loc >> 32) * 73856093) ^ (static_cast<int32_t>(loc) * 19349663)) & (n-1);
	}
	inline int hashPos2(int x, int y, int range, int n)
	{
		return this->hashPos2(x - CalcMod(x, range), y - CalcMod(y, range), n);
	}
	inline int64_t MakeLoc(int x, int y)
	{
		return ((static_cast<int64_t>(x) << 32) & 0xFFFFFFFF00000000) | (static_cast<int64_t>(y) & 0x00000000FFFFFFFF);
	}
	inline int64_t MakeLoc(const int x, const int y, const int range)
	{
		return this->MakeLoc(x - CalcMod(x, range), y - CalcMod(y, range));
	}
	// grid에서의 영역을 찾아서 처리할때 사용함..
	inline bool Intercection(
		const int x1, const int y1, const int w1, const int h1,
		const int x2, const int y2, const int w2, const int h2,
		int& ix, int& iy, int& iw, int& ih)
	{
		if (x1 > x2 + w2 || x1 + w1 < x2 || y1 > y2 + h2 || y1 + h1 < y2)
			return false;

		ix = std::max(x1, x2);
		iw = std::min(x1 + w1, x2 + w2) - ix;
		iy = std::max(y1, y2);
		ih = std::min(y1 + h1, y2 + h2) - iy;

		return true;
	}
	inline int CalcMod(const int modOrg, const int range) const
	{
		//return (modOrg >= 0) ? (modOrg % range) : (range + (modOrg % range));
		auto modCalc = modOrg % range;
		return (modCalc >= 0) ? modCalc : (range + modCalc);
	}
	inline int CalcGcf(int tA, int tB)
	{
		for (;;)
		{
			int tC = tA % tB;
			if (0 == tC)
				break;

			tA = tB;
			tB = tC;
		}

		return tB;
	}

private:
	int m_refs;
	int m_layerSize;
	int m_bucketsSize;
	int m_elementCount;
	_element_t** m_buckets;
	int* m_ranges;
};

}

#endif
