﻿////////////////////////////////////////////////////////////////////////////////
//
// 작성자 : sjkim
// 설  명 : 
//

#pragma once
#ifndef __NMSPRANDOM_H__
#define __NMSPRANDOM_H__

#include <random>

namespace nmsp {

	static std::mt19937& RandomInstance()
	{
		static thread_local std::random_device rd;
		static thread_local std::mt19937 generator(rd());
		return generator;
	}

	class prandom
	{
	public:
		static int32_t gen(int32_t min, int32_t max)
		{
			if (min == max)
				return min;
			
			if (min > max)
				return min;

			std::uniform_int_distribution<int> uniform_dist(min, max);
			return uniform_dist(RandomInstance());
		}

		static int32_t gen(const std::pair<int32_t, int32_t>& value)
		{
			return gen(value.first, value.second);
		}
	};
	template <typename T>
	class random
	{
	public:
		random(T MIN_VAL, T MAX_VAL)
			: m_mt(m_r())
			, m_uniformDist(MIN_VAL, MAX_VAL)
		{
		}
		inline T gen()
		{
			return m_uniformDist(m_mt);
		}
	private:
		std::random_device m_r;
		std::mt19937 m_mt;
		std::uniform_int_distribution<T> m_uniformDist;
	};
	template <>
	class random<float>
	{
	public:
		random(float MIN_VAL, float MAX_VAL)
			: m_mt(m_r())
			, m_uniformDist(MIN_VAL, MAX_VAL)
		{
		}
		inline float gen()
		{
			return m_uniformDist(m_mt);
		}
	private:
		std::random_device m_r;
		std::mt19937 m_mt;
		std::uniform_real_distribution<float> m_uniformDist;
	};
	template <>
	class random<double>
	{
	public:
		random(double MIN_VAL, double MAX_VAL)
			: m_mt(m_r())
			, m_uniformDist(MIN_VAL, MAX_VAL)
		{
		}
		inline double gen()
		{
			return m_uniformDist(m_mt);
		}
	private:
		std::random_device m_r;
		std::mt19937 m_mt;
		std::uniform_real_distribution<double> m_uniformDist;
	};
}

#endif