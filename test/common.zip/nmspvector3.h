﻿////////////////////////////////////////////////////////////////////////////////
//
// 작성자 : bkkim, sjkim
// 설  명 : 
//

#pragma once
#ifndef __NMSPVECTOR3_H__
#define __NMSPVECTOR3_H__

#ifndef _assert
#ifndef NDEBUG
#define _assert(exp) _ASSERT(exp)
#define _debug_log(Format, ...) _debug_log_impl(sizeof((Format)[0]) != 1, Format, __VA_ARGS__)
#else
#define _assert(exp)
#define _debug_log(Format, ...)
#endif
#endif

#include <string>

namespace nmsp {

	extern const float PI;

	float RadiansToDegrees(const float RadVal);
	float DegreesToRadians(const float DegVal);

	class Vector3Functor {
	public:
		inline static float* Copy(float* dest, const float* src)
		{
			_assert(dest && src);
			dest[0] = src[0];
			dest[1] = src[1];
			dest[2] = src[2];
			return dest;
		}

		inline static float* Set(float* dest, const float x, const float y, const float z)
		{
			_assert(dest);
			dest[0] = x;
			dest[1] = y;
			dest[2] = z;
			return dest;
		}

		inline static float* Add(float* dest, const float* v1, const float* v2)
		{
			_assert(dest && v1 && v2);
			dest[0] = v1[0] + v2[0];
			dest[1] = v1[1] + v2[1];
			dest[2] = v1[2] + v2[2];
			return dest;
		}

		inline static float* Sub(float* dest, const float* v1, const float* v2)
		{
			_assert(dest && v1 && v2);
			dest[0] = v1[0] - v2[0];
			dest[1] = v1[1] - v2[1];
			dest[2] = v1[2] - v2[2];
			return dest;
		}

		inline static float* Sub2D(float* dest, const float* v1, const float* v2)
		{
			_assert(dest && v1 && v2);
			dest[0] = v1[0] - v2[0];
			dest[1] = 0.f;
			dest[2] = v1[2] - v2[2];
			return dest;
		}

		inline static float* Scale(float* dest, const float* v, const float s)
		{
			_assert(dest && v);
			dest[0] = v[0] * s;
			dest[1] = v[1] * s;
			dest[2] = v[2] * s;
			return dest;
		}

		inline static float* Scale(float* dest, const float* v, const float* s)
		{
			_assert(dest && v && s);
			dest[0] = v[0] * s[0];
			dest[1] = v[1] * s[1];
			dest[2] = v[2] * s[2];
			return dest;
		}

		inline static float SquaredLength2D(const float* v)
		{
			_assert(v);
			return v[0] * v[0] + v[2] * v[2];
		}

		inline static float SquaredLength(const float* v)
		{
			_assert(v);
			return v[0] * v[0] + v[1] * v[1] + v[2] * v[2];
		}

		inline static float Length(const float* v) {
			_assert(v);
			return sqrtf(SquaredLength(v));
		}

		inline static float Distance(const float* v1, const float* v2)
		{
			_assert(v1 && v2);
			float res[3] = { 0.f, 0.f, 0.f };
			return Length(Sub(res, v1, v2));
		}

		inline static float SquareDistance(const float* v1, const float* v2)
		{
			_assert(v1 && v2);
			float res[3] = { 0.f, 0.f, 0.f };
			return SquaredLength(Sub(res, v1, v2));
		}

		inline static float Distance2D(const float* v1, const float* v2)
		{
			_assert(v1 && v2);
			float res[2];
			res[0] = v1[0] - v2[0];
			res[1] = v1[2] - v2[2];
			return sqrtf(res[0] * res[0] + res[1] * res[1]);
		}

		inline static float SquareDistance2D(const float* v1, const float* v2)
		{
			_assert(v1 && v2);
			float res[2];
			res[0] = v1[0] - v2[0];
			res[1] = v1[2] - v2[2];
			return (res[0] * res[0] + res[1] * res[1]);
		}

		inline static float* Normalize(float* dest, const float* v)
		{
			_assert(dest && v);
			float d = 1.f / Length(v);
			dest[0] = v[0] * d;
			dest[1] = v[1] * d;
			dest[2] = v[2] * d;
			return dest;
		}

		inline static float* Unreal2Recast(float* dest, const float* unreal_vec)
		{
			_assert(dest && unreal_vec);
			dest[0] = -unreal_vec[0];
			dest[1] = unreal_vec[2];
			dest[2] = -unreal_vec[1];
			return dest;
		}

		inline static float* CrossProduct(float* dest, const float* v1, const float* v2)
		{
			_assert(dest && v1 && v2);
			dest[0] = v1[1] * v2[2] - v1[2] * v2[1];
			dest[1] = v1[2] * v2[0] - v1[0] * v2[2];
			dest[2] = v1[0] * v2[1] - v1[1] * v2[0];
			return dest;
		}

		inline static float DotProduct(const float* v1, const float* v2)
		{
			_assert(v1 && v2);
			return v1[0] * v2[0] + v1[1] * v2[1] + v1[2] * v2[2];
		}

		inline static float DotProduct2D(const float* v1, const float* v2)
		{
			_assert(v1 && v2);
			return v1[0] * v2[0] + v1[2] * v2[2];
		}

		inline static void PerpByY(float* dest)
		{
			float x = dest[0];
			dest[0] = dest[2];
			dest[2] = -x;
		}

		inline static void PerpByY(float* dest, const float* src)
		{
			dest[0] = src[2];
			dest[1] = src[1];
			dest[2] = -src[0];
		}

		inline static void AntiPerpByY(float* dest)
		{
			float x = dest[0];
			dest[0] = -dest[2];
			dest[2] = x;
		}
		
		inline static void AntiPerpByY(float* dest, const float* src)
		{
			dest[0] = -src[2];
			dest[1] = src[1];
			dest[2] = src[0];
		}

		inline static float LeftSide(const float* baseV, const float* checkV)
		{
			float tmp[3] = { 0.f, 0.f, 0.f };
			tmp[0] = baseV[0];
			tmp[1] = baseV[1];
			tmp[2] = baseV[2];

			PerpByY(tmp);

			return DotProduct2D(tmp, checkV);
		}

		inline static bool Front(const float* baseV, const float* checkV)
		{
			if (baseV[0] * checkV[0] + baseV[2] * checkV[2] > 0.f)
				return true;
			return false;
		}

		inline static void Lerp(float* dest, const float* v1, const float* v2, const float t)
		{
			dest[0] = v1[0] + (v2[0] - v1[0])*t;
			dest[1] = v1[1] + (v2[1] - v1[1])*t;
			dest[2] = v1[2] + (v2[2] - v1[2])*t;
		}

		static float* RotateAngleAxis(float *dest, const float* v, const float angle_deg, const float* axis);
		static float* RotateAngle2D(float *dest, const float *v, const float angle_deg);
		static float* RotateRadian2D(float *dest, const float *v, const float angle_rad);
	};

	class Vector3 {
	public:
		Vector3();
		Vector3(const float*);
		//Vector3(const float (&other)[3]);
		Vector3(float x, float y, float z);
		Vector3(const Vector3& other);
		~Vector3() { }

	public:
		inline float X() const { return _pos[0]; }
		inline void X(float x) { _pos[0] = x; }
		inline float Y() const { return _pos[1]; }
		inline void Y(float y) { _pos[1] = y; }
		inline float Z() const { return _pos[2]; }
		inline void Z(float z) { _pos[2] = z; }
		inline float* Data() { return _pos; }
		inline const float* Data() const { return _pos; }

	public:
		bool operator== (const Vector3& other) const;
		bool operator== (const float (&other)[3]) const;
		bool operator!= (const Vector3& other) const;
		bool operator!= (const float(&other)[3]) const;
		Vector3& operator= (const Vector3& other);
		Vector3& operator+= (const Vector3& other);
		Vector3& operator-= (const Vector3& other);
		Vector3& operator*= (float scalar);
		Vector3& operator/= (float scalar);
		Vector3 operator- () const;

		inline float& operator[] (int i) {
			_assert(i >= 0 && i < 3);
			return _pos[i];
		}

		inline const float& operator[] (int i) const {
			_assert(i >= 0 && i < 3);
			return _pos[i];
		}

		inline float* operator* () {
			return _pos;
		}

		inline const float* operator* () const {
			return _pos;
		}

		inline void Zero()
		{
			_pos[0] = 0.f;
			_pos[1] = 0.f;
			_pos[2] = 0.f;
		}

		inline void Copy(float* pos) const
		{
			*pos = _pos[0]; ++pos;
			*pos = _pos[1]; ++pos;
			*pos = _pos[2];
		}

		const std::string ToString() const;

	public:
		void Set(float x, float y, float z);
		void Set(const float*);
		float SqrMagnitude() const;
		float SqrMagnitude2D() const;
		float Magnitude() const;
		float Magnitude2D() const;
		Vector3& Normalized();
		Vector3& Vector3::Normalized2D();
		bool IsNan() const;
		bool Equals(const Vector3& v) const;
		bool SameTo(const float* v) const;
		bool IsNearlyZero() const;
		bool IsZero() const;
		Vector3& Rotate(const float angle_deg, const Vector3& axis = Vector3::UpVector);
		bool IsInf() const;

	private:
		float _pos[3];

	public:
		friend Vector3 operator+ (const Vector3& v1, const Vector3& v2);
		friend Vector3 operator- (const Vector3& v1, const Vector3& v2);
		friend Vector3 operator- (const Vector3& v1, const float* v2);
		friend Vector3 operator* (const Vector3& v, const float s);
		friend Vector3 operator/ (const Vector3& v, const float s);

	public:
		static float Distance(const Vector3& v1, const Vector3& v2);
		static float Distance(const Vector3& v1, const float* v2);
		static float Distance2D(const Vector3& v1, const Vector3& v2);
		static float Distance2D(const Vector3& v1, const float* v2);
		static Vector3 Normalize(const Vector3& v);
		static Vector3 Normalize2D(const Vector3& v);
		static Vector3 Normalize2D(const Vector3& v, const Vector3& defaultV);
		static Vector3 Unreal2Recast(float x, float y, float z);
		static Vector3 Unreal2Recast(const float* v);
		static Vector3 Unreal2Recast(const Vector3& v);
		static Vector3 Recast2Unreal(float x, float y, float z);
		static Vector3 Recast2Unreal(const float* v);
		static Vector3 Recast2Unreal(const Vector3& v);
		static Vector3 CrossProduct(const Vector3& v1, const Vector3& v2);
		static float DotProduct(const Vector3& v1, const Vector3& v2);
		static Vector3 RotateAngleAxis(const Vector3& v, const float angle_deg, const Vector3& axis);
		
		// Y축을 기준으로 기준 백터로부터의 각도를 구함
		static float AngleBetweenVectors2D(const Vector3& baseV, const Vector3& v);

		// Vector3::ForwardVector 기준으로 changeForward 만큼 회전시킨 v 값 을 구한다.
		static Vector3 RotateAngleAxis(const Vector3& v, const Vector3& changeDiretion);

		static Vector3 RotateAngleAxis(const Vector3& v, const Vector3& baseDiretion, const Vector3& changeDiretion);
		
		static Vector3 FindDirection(const float* src, const float* dest, const float* defaultDir);
		static Vector3 FindDirection(const Vector3& src, const Vector3& dest, const Vector3& defaultDir);
		static Vector3 FindDirection2D(const float* src, const float* dest, const float* defaultDir);
		static Vector3 FindDirection2D(const Vector3& src, const Vector3& dest, const Vector3& defaultDir);
	public:
		static const Vector3 ZeroVector;
		static const Vector3 OneVector;
		static const Vector3 UpVector;
		static const Vector3 DownVector;
		static const Vector3 RightVector;
		static const Vector3 ForwardVector;
	};
}

#endif
