﻿#pragma once
#ifndef __NMSPOBJECTPOOL_H__
#define __NMSPOBJECTPOOL_H__

/*
**** Multi Thread 고려하지 않음
*/
namespace nmsp {

	template <class OBJECT, int32_t defaultCount = 32>
	class object_pool
	{
	private:
		static uint8_t level;
		static std::deque<OBJECT*, nmsp::stl_default_allocator<OBJECT*, nmsp::pool::allocator_from_pool<>> > ptrList;

	public:
		object_pool()	{}
		virtual ~object_pool()	{}

	public:
		static void* operator new (std::size_t size) 
		{
			if (ptrList.empty() == true)
			{
				++level;
				void* pAlloc = reinterpret_cast<void*>(::malloc(sizeof(OBJECT) * level * defaultCount));
				if (nullptr == pAlloc)
					throw std::bad_alloc();

				OBJECT* objectPtr = static_cast<OBJECT*>(pAlloc);
				for (size_t i = 0; i < level * defaultCount; ++i)
				{
					objectPtr += i;
					ptrList.push_front(objectPtr);
				}
			}

			void* objectPtr = static_cast<void*>(ptrList.front());
			ptrList.pop_front();

			return objectPtr;
		}
		static void operator delete(void* releasePtr)	{ ptrList.push_front(static_cast<OBJECT*>(releasePtr)); }
	};

	template <class OBJECT, int32_t defaultCount> 
	uint8_t object_pool<OBJECT, defaultCount>::level = 0;

	template <class OBJECT, int32_t defaultCount>
	std::deque<OBJECT*, nmsp::stl_default_allocator<OBJECT*, nmsp::pool::allocator_from_pool<>>> object_pool<OBJECT, defaultCount>::ptrList;
} // nmsp

#endif
