﻿////////////////////////////////////////////////////////////////////////////////
//
// 작성자 : huelee
// 설  명 : 플랫폼 의존적인 기능들은 이쪽에다가 구현한다..
//

#pragma once
#ifndef __NMSPSYSTEM_H__
#define __NMSPSYSTEM_H__

namespace nmsp {

// cpu 갯수
#if defined(_WIN32) || defined(_WIN64)
#include <pdh.h>
#include <pdhmsg.h>

class cpu_usage
{
public:
	cpu_usage()
		: m_hQuery(nullptr)
		, m_hCounter(nullptr)
	{
	}
	virtual ~cpu_usage()
	{
		if (nullptr != m_hQuery)
		{
			PdhCloseQuery(m_hQuery);
			m_hQuery = nullptr;
		}
	}

	bool Init()
	{
		if (m_bInit){
			return true;
		}

		PDH_STATUS status = PdhOpenQuery(0, 0, &m_hQuery);
		if (ERROR_SUCCESS != status)
			return false;

		status = PdhAddCounterA(m_hQuery, "\\Processor(_TOTAL)\\% Processor Time", 0, &m_hCounter);
		if (ERROR_SUCCESS != status)
			return false;

		status = PdhCollectQueryData(m_hQuery);
		if (ERROR_SUCCESS != status)
			return false;

		m_bInit = true;
		return true;
	}
	void Uninit()
	{
		if (m_hQuery)
		{
			PdhCloseQuery(m_hQuery);
			m_hQuery = nullptr;
		}
	}
	bool GetCpuUsage(int* val)
	{
		PDH_STATUS status = PdhCollectQueryData(m_hQuery);
		if (ERROR_SUCCESS != status)
			return false;

		PDH_FMT_COUNTERVALUE value;
		status = PdhGetFormattedCounterValue(m_hCounter, PDH_FMT_LONG, 0, &value);
		if (ERROR_SUCCESS != status)
			return false;

		*val = value.longValue;
		return true;
	}

private:
	PDH_HQUERY m_hQuery;
	PDH_HCOUNTER m_hCounter;
	bool m_bInit = false;
};

inline int GetCpuUsage()
{
	static cpu_usage cpu;
	if (false == cpu.Init())
		return 0;

	int val = 0;
	if (cpu.GetCpuUsage(&val))
		return val;

	return 0;
}

//
class directory_info
{
public:
	using _dir_vector_t = std::vector<std::string>;

public:
	directory_info() = default;
	virtual ~directory_info() = default;

	//open a directory the WIN32 way
	bool readdir(const std::string& dirname, const std::string& ext, _dir_vector_t& info)
	{
		std::string dirname_;

		if (dirname[dirname.size() - 1] == '\\' || dirname[dirname.size() - 1] == '/')
		{
			dirname_ = dirname.substr(0, dirname.size() - 1);
		}
		else
		{
			dirname_ = dirname;
			dirname_ += '/';
		}

		std::string rootdirname = dirname_;

		dirname_ += "*";

		WIN32_FIND_DATAA fdata;
		HANDLE hFind = FindFirstFileA(dirname_.c_str(), &fdata);
		if (INVALID_HANDLE_VALUE == hFind)
			return false;

		do
		{
			if (strcmp(fdata.cFileName, ".") != 0 && strcmp(fdata.cFileName, "..") != 0)
			{
				std::string fn = fdata.cFileName;
				std::string newdirname = rootdirname;
				newdirname += fn;

				if (fdata.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
				{
					if (false == readdir(newdirname, ext, info))
						return false;
				}
				else
				{
					std::string ext_ = fn.substr(fn.find_last_of(".") + 1);
					if (ext_ == ext)
						info.push_back(newdirname);
				}
			}
		} while (FindNextFileA(hFind, &fdata) != 0);

		if (GetLastError() != ERROR_NO_MORE_FILES)
		{
			FindClose(hFind);
			return false;
		}

		FindClose(hFind);
		hFind = INVALID_HANDLE_VALUE;

		return true;
	}
};

#else

#endif

// cpu 사용율

} // nmsp

#endif
