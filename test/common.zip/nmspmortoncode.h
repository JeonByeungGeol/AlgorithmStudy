////////////////////////////////////////////////////////////////////////////////
// �ۼ���: huelee
// ��  ��:
// https://en.wikipedia.org/wiki/Z-order_curve
// https://github.com/Forceflow/libmorton

// ȣȯ���� ���ؼ�..
#pragma once
#ifndef __NMSPMORTONCODE_H__
#define __NMSPMORTONCODE_H__

// 
namespace nmsp { namespace morton {

// "Insert" a 0 bit after each of the 16 low bits of x
inline uint32_t Part32By1(uint32_t x)
{
	x &= 0x0000ffff;                  // x = ---- ---- ---- ---- fedc ba98 7654 3210
	x = (x ^ (x << 8)) & 0x00ff00ff; // x = ---- ---- fedc ba98 ---- ---- 7654 3210
	x = (x ^ (x << 4)) & 0x0f0f0f0f; // x = ---- fedc ---- ba98 ---- 7654 ---- 3210
	x = (x ^ (x << 2)) & 0x33333333; // x = --fe --dc --ba --98 --76 --54 --32 --10
	x = (x ^ (x << 1)) & 0x55555555; // x = -f-e -d-c -b-a -9-8 -7-6 -5-4 -3-2 -1-0
	return x;
}

// "Insert" two 0 bits after each of the 10 low bits of x
inline uint32_t Part32By2(uint32_t x)
{
	x &= 0x000003ff;                  // x = ---- ---- ---- ---- ---- --98 7654 3210
	//x = (x ^ (x << 16)) & 0xff0000ff; // x = ---- --98 ---- ---- ---- ---- 7654 3210
	x = (x ^ (x << 16)) & 0x030000ff; // x = ---- --98 ---- ---- ---- ---- 7654 3210
	x = (x ^ (x <<  8)) & 0x0300f00f; // x = ---- --98 ---- ---- 7654 ---- ---- 3210
	x = (x ^ (x <<  4)) & 0x030c30c3; // x = ---- --98 ---- 76-- --54 ---- 32-- --10
	x = (x ^ (x <<  2)) & 0x09249249; // x = ---- 9--8 --7- -6-- 5--4 --3- -2-- 1--0
	return x;
}

inline uint64_t Part64By2(const uint64_t a)
{
	uint64_t x = ((uint_fast64_t)a) & 0x1fffff;
	x = (x | x << 32) & 0x1f00000000ffff;
	x = (x | x << 16) & 0x1f0000ff0000ff;
	x = (x | x << 8) & 0x100f00f00f00f00f;
	x = (x | x << 4) & 0x10c30c30c30c30c3;
	x = (x | x << 2) & 0x1249249249249249;
	return x;
}

// Inverse of Part1By1 - "delete" all odd-indexed bits
inline int32_t Compact32By1(uint32_t x)
{
	x &= 0x55555555;                  // x = -f-e -d-c -b-a -9-8 -7-6 -5-4 -3-2 -1-0
	x = (x ^ (x >> 1)) & 0x33333333; // x = --fe --dc --ba --98 --76 --54 --32 --10
	x = (x ^ (x >> 2)) & 0x0f0f0f0f; // x = ---- fedc ---- ba98 ---- 7654 ---- 3210
	x = (x ^ (x >> 4)) & 0x00ff00ff; // x = ---- ---- fedc ba98 ---- ---- 7654 3210
	x = (x ^ (x >> 8)) & 0x0000ffff; // x = ---- ---- ---- ---- fedc ba98 7654 3210
	return static_cast<int32_t>(x);
}

// Inverse of Part1By2 - "delete" all bits not at positions divisible by 3
inline int32_t Compact32By2(uint32_t x)
{
	x &= 0x09249249;                  // x = ---- 9--8 --7- -6-- 5--4 --3- -2-- 1--0
	x = (x ^ (x >> 2)) & 0x030c30c3; // x = ---- --98 ---- 76-- --54 ---- 32-- --10
	x = (x ^ (x >> 4)) & 0x0300f00f; // x = ---- --98 ---- ---- 7654 ---- ---- 3210
	//x = (x ^ (x >> 8)) & 0xff0000ff; // x = ---- --98 ---- ---- ---- ---- 7654 3210
	x = (x ^ (x >> 8)) & 0x030000ff; // x = ---- --98 ---- ---- ---- ---- 7654 3210
	x = (x ^ (x >> 16)) & 0x000003ff; // x = ---- ---- ---- ---- ---- --98 7654 3210
	return static_cast<int32_t>(x);
}

inline int32_t Compact64By2(const uint64_t m)
{
	uint64_t x = m & 0x1249249249249249;
	x = (x ^ (x >> 2)) & 0x10c30c30c30c30c3;
	x = (x ^ (x >> 4)) & 0x100f00f00f00f00f;
	x = (x ^ (x >> 8)) & 0x1f0000ff0000ff;
	x = (x ^ (x >> 16)) & 0x1f00000000ffff;
	x = (x ^ (x >> 32)) & 0x1fffff;
	return static_cast<int32_t>(x);
}

inline uint32_t EncodeMorton32By1(int32_t x, int32_t y)
{
	return (Part32By1(x) << 1) + Part32By1(y);
}

inline uint32_t EncodeMorton32By3(uint32_t x, uint32_t y, uint32_t z)
{
	return (Part32By2(x) << 2) + (Part32By2(y) << 1) + Part32By2(z);
}

inline uint64_t EncodeMorton64By3(uint32_t x, uint32_t y, uint32_t z)
{
	return (Part64By2(x) << 2) + (Part64By2(y) << 1) + Part64By2(z);
}

inline void DecodeMorton32By2(uint32_t code, int32_t& x, int32_t& y)
{
	y = Compact32By1(code >> 0);
	x = Compact32By1(code >> 1);
}

inline void DecodeMorton32By3(uint32_t code, int32_t& x, int32_t& y, int32_t& z)
{
	x = Compact32By2(code >> 2);
	y = Compact32By2(code >> 1);
	z = Compact32By2(code >> 0);
}

inline void DecodeMorton64By3(uint64_t code, int32_t& x, int32_t& y, int32_t& z)
{
	x = Compact64By2(code >> 2);
	y = Compact64By2(code >> 1);
	z = Compact64By2(code >> 0);
}

}	// morton
}	// nmsp

#endif	//__NMSPMORTONCODE_H__
