﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __NMSPHEXAGRID_H__
#define __NMSPHEXAGRID_H__

namespace nmsp {

// pointy orientation, hexagon
// odd row를 가정한다.
// 수학에서 사용하는 직교좌표계 기준.
// https://www.redblobgames.com/grids/hexagons/
// https://stackoverflow.com/questions/7705228/hexagonal-grids-how-do-you-find-which-hexagon-a-point-is-in
template <typename ELEMENT, typename ALLOC>
class hexagonal_grid : public nmsp::new_from_pool<ALLOC>
{
public:
	using _element_t = ELEMENT;			// grid안에 들어가 있을 뭔가임.
	using _allocator_t = ALLOC;

private:
	static const float m_sqrt3;
	struct hexa_index
	{
		hexa_index(const hexa_index& other)
		{
			m_column = other.m_column;
			m_row = other.m_row;
		}
		hexa_index(int32_t column, int32_t row)
		{
			m_column = column;
			m_row = row;
		}
		inline bool operator == (const hexa_index& other)
		{
			return m_column == other.m_column && m_row == other.m_row;
		}
		int32_t m_column;
		int32_t m_row;
	};
	using _hexa_index_vec_t = std::vector<hexa_index, nmsp::stl_default_allocator<hexa_index, _allocator_t> >;
private:
	struct range
	{
		range()
		{
			m_fullHeight = 0;
			m_rowHeight = 0.f;
			m_rowHeightInverse = 0.f;
			m_rowHalfHeight = 0.f;
			m_halfHeight = 0.f;
			m_width = 0.f;
			m_widthInverse = 0.f;
			m_halfWidth = 0.f;
			m_c = 0.f;
			m_m = 0.f;
		}
		range(int32_t height)
		{
			m_fullHeight = height;
			if (0.f == m_fullHeight)
				return;

			m_rowHeight = height * 0.75f;					// 실제 크기의 3/4
			m_rowHeightInverse = 1.f / m_rowHeight;
			m_rowHalfHeight = m_rowHeight * 0.5f;
			m_halfHeight = height * 0.5f;
			m_c = height * 0.25f;

			m_width = m_halfHeight;
			m_width *= m_sqrt3;
			m_widthInverse = 1.f / m_width;
			m_halfWidth = m_width * 0.5f;

			m_m = m_c / m_halfWidth;
		}
		inline void SetVar(int32_t height)
		{
			m_fullHeight = height;
			if (0.f == m_fullHeight)
				return;

			m_rowHeight = height * 0.75f;					// 실제 크기의 3/4
			m_rowHeightInverse = 1.f / m_rowHeight;
			m_rowHalfHeight = m_rowHeight * 0.5f;
			m_halfHeight = height * 0.5f;
			m_c = height * 0.25f;

			m_width = m_halfHeight;
			m_width *= m_sqrt3;
			m_widthInverse = 1.f / m_width;
			m_halfWidth = m_width * 0.5f;

			m_m = m_c / m_halfWidth;
		}
		inline void CnvPoint2OddR(float x, float z, int32_t& column, int32_t& row) const
		{
			row = static_cast<int32_t>(z * m_rowHeightInverse);

			bool rowIsOdd = ((row & 1) != 0);
			float relX;

			// OddR에 해당하는 경우는 m_halfWidth를 minus해서 정렬해준다.
			// 그리고 x의 정렬 후 나머지 값을 계산한다.
			if (rowIsOdd)
			{
				column = static_cast<int32_t>((x - m_halfWidth) * m_widthInverse);
				relX = (x - (column * m_width)) - m_halfWidth;
			}
			else
			{
				column = static_cast<int32_t>(x * m_widthInverse);
				relX = (x - (column * m_width));
			}

			// z정렬 후 나머지 값을 계산한다.
			float relY = z - (row * m_rowHeight);

			// edge의 바깥쪽에 있는지 확인한다.
			if (relY < (m_c - m_m * relX)) // LEFT edge
			{
				row--;
				if (!rowIsOdd)
					column--;
			}
			else if (relY < (m_m * relX - m_c)) // RIGHT edge
			{
				row--;
				if (rowIsOdd)
					column++;
			}
		}
		inline void CnvOddR2Point(const int32_t column, const int32_t row, float& x, float& z) const
		{
			x = m_width * column + (m_halfWidth * (row & 1)) + m_halfWidth;
			z = m_rowHeight * row + m_rowHalfHeight;
		}
		inline int32_t GetRange() const { return m_fullHeight; }

	private:
		int32_t m_fullHeight;
		float m_rowHeight;
		float m_rowHeightInverse;
		float m_rowHalfHeight;
		float m_halfHeight;
		float m_width;
		float m_widthInverse;
		float m_halfWidth;
		float m_c;
		float m_m;
	};

public:
	hexagonal_grid()
	{
		m_refs = 0;
		m_layerSize = 0;
		m_bucketsSize = 0;
		m_buckets = nullptr;
		m_ranges = nullptr;
		m_elementCount = 0;
		m_maxRange = 0;
		m_baseX = 0.f;
		m_baseZ = 0.f;
	}
	~hexagonal_grid()
	{
		if (nullptr != m_ranges)
		{
			_allocator_t::DestroyMemory(m_ranges);
			m_ranges = nullptr;
		}

		if (nullptr != m_buckets)
		{
			_allocator_t::DestroyMemory(m_buckets);
			m_buckets = nullptr;
		}
	}
	int32_t AddRef()
	{
		return ++m_refs;
	}
	int32_t Release()
	{
		int32_t refs = --m_refs;
		if (0 == refs)
		{
			delete this;
			return 0;
		}
		return refs;
	}
	bool Init(int32_t layerSize, int32_t bucketSize, int32_t defaultRange, float baseX, float baseZ)
	{
		// 0을 허용한다!
		if (0 > defaultRange ||		// range는 0 <= 임.
			0 >= bucketSize ||		// bucket은 0 < 임
			0 >= layerSize)			// lasyerSize 0 < 임
			return false;

		if (nullptr != m_buckets)
			return false;

		// range를 layer마다 다르게 하고자..
		int32_t memRangeSize = sizeof(range) * layerSize;

		range* ranges = static_cast<range*>(_allocator_t::CreateMemory(memRangeSize));
		if (nullptr == ranges)
			return false;

		// range를 설정한다!
		for (int32_t currLayer = 0; currLayer < layerSize; ++currLayer)
			new (&ranges[currLayer]) range(defaultRange);

		// bucket
		int32_t totalBuckets = bucketSize * layerSize;
		int32_t memSize = sizeof(_element_t*) * totalBuckets;

		void* bucket = _allocator_t::CreateMemory(memSize);
		if (nullptr == bucket)
			return false;

		memset(bucket, 0x00, memSize);

		m_layerSize = layerSize;
		m_bucketsSize = bucketSize;
		m_buckets = reinterpret_cast<decltype(m_buckets)>(bucket);
		m_ranges = ranges;
		m_elementCount = 0;
		m_maxRange = defaultRange;

		// 원점을 옮기자.!
		m_baseX = baseX;
		m_baseZ = baseZ;

		return true;
	}
	void Uninit()
	{
		if (nullptr != m_ranges)
		{
			_allocator_t::DestroyMemory(m_ranges);
			m_ranges = nullptr;
		}

		if (nullptr != m_buckets)
		{
			_allocator_t::DestroyMemory(m_buckets);
			m_buckets = nullptr;
		}

		m_layerSize = 0;
		m_bucketsSize = 0;
		m_elementCount = 0;
	}
	template <typename T, typename ADD>
	bool Add(int32_t layer, _element_t* element, T orgX, T orgZ, ADD& add)
	{
		if (0 > layer || layer >= m_layerSize)
			return false;

		// 0이면 시야 범위없음
		if (0.f == m_ranges[layer].GetRange())
		{
			if (false == add(layer, element, 0, m_buckets[layer * m_bucketsSize]))
				return false;
		}
		else
		{
			int32_t column;
			int32_t row;
			int64_t newLoc = MakeLoc(orgX, orgZ, layer, column, row);

			//
			int32_t bucketIndex = hashPos2(column, row, m_bucketsSize);

			if (false == add(layer, element, newLoc, m_buckets[layer * m_bucketsSize + bucketIndex]))
				return false;
		}

		++m_elementCount;
		return true;
	}
	template <typename T, typename DEL>
	bool Del(int32_t layer, _element_t* element, T orgX, T orgZ, DEL& del)
	{
		if (0 > layer || layer >= m_layerSize)
			return false;

		// 0이면 시야 범위없음
		if (0.f == m_ranges[layer].GetRange())
		{
			if (false == del(layer, element, 0, m_buckets[layer * m_bucketsSize]))
				return false;
		}
		else
		{
			int32_t column;
			int32_t row;
			int64_t newLoc = MakeLoc(orgX, orgZ, layer, column, row);

			//
			int32_t bucketIndex = hashPos2(column, row, m_bucketsSize);

			if (false == del(layer, element, newLoc, m_buckets[layer * m_bucketsSize + bucketIndex]))
				return false;
		}

		--m_elementCount;
		return true;
	}
	template <typename T, typename MOVE, typename MOVETRAVERSE>
	bool LayerbaseMove(int32_t baseLayer, _element_t* element, T oldX, T oldZ, T newX, T newZ, MOVE& move, MOVETRAVERSE& moveTraverse)
	{
		if (0 > baseLayer || baseLayer >= m_layerSize)
			return false;

		const range* baseRange = &m_ranges[baseLayer];

		// 범위가 0이라면.. 시야 범위가 전체이므로.. 그냥 리턴한다!
		if (0.f == baseRange->GetRange())
			return true;

		// 자신의 이동 처리
		{
			// 이전 
			int32_t oldColumn;
			int32_t oldRow;
			int64_t oldLoc = MakeLoc(oldX, oldZ, baseLayer, oldColumn, oldRow);

			// 이후
			int32_t newColumn;
			int32_t newRow;
			int64_t newLoc = MakeLoc(newX, newZ, baseLayer, newColumn, newRow);

			// 이동
			int32_t bucketOldIndex = hashPos2(oldColumn, oldRow, m_bucketsSize);
			int32_t bucketNewIndex = hashPos2(newColumn, newRow, m_bucketsSize);

			if (false == move(baseLayer, element, oldLoc, bucketOldIndex, m_buckets[baseLayer * m_bucketsSize + bucketOldIndex], newLoc, bucketNewIndex, m_buckets[baseLayer * m_bucketsSize + bucketNewIndex]))
				return false;
		}

		// 순회
		for (int32_t currLayer = 0; currLayer < m_layerSize; ++currLayer)
		{
			const range* currMaxRange = &m_ranges[currLayer];

			// 범위가 없는 경우이므로 어떤 이동도 영향을 주지 않는다!
			if (0.f == currMaxRange->GetRange())
				continue;

			const range* currMinRange = &m_ranges[currLayer];
			if (currMinRange->GetRange() > baseRange->GetRange())
				currMinRange = baseRange;

			// 이전
			int32_t oldColumn;
			int32_t oldRow;
			int64_t oldLoc = MakeLoc(oldX, oldZ, currMinRange, oldColumn, oldRow);

			// 이후
			int32_t newColumn;
			int32_t newRow;
			int64_t newLoc = MakeLoc(newX, newZ, currMinRange, newColumn, newRow);

			// 그리드 경계를 이동하지 않았다면 여기서 리턴
			if (oldLoc == newLoc)
				continue;

			const range* currRange = &m_ranges[currLayer];
			int32_t bucketBase = currLayer * m_bucketsSize;

			if (currMaxRange->GetRange() < baseRange->GetRange())
				currMaxRange = baseRange;

			// 
			if (currMaxRange->GetRange() != currMinRange->GetRange())
			{
				int32_t tmpGcf = this->CalcGcf(currMinRange->GetRange(), currMaxRange->GetRange());

				if (tmpGcf != m_temporaryRange.GetRange())
					m_temporaryRange.SetVar(tmpGcf);

				MakeLoc(oldX, oldZ, &m_temporaryRange, oldColumn, oldRow);
				MakeLoc(newX, newZ, &m_temporaryRange, newColumn, newRow);

				m_oldHexaIndices.clear();
				m_newHexaIndices.clear();
				m_intersectionHexaIndices.clear();

				Intersection(
					oldColumn, oldRow, newColumn, newRow,
					currMaxRange->GetRange() / tmpGcf,
					m_oldHexaIndices, m_newHexaIndices, m_intersectionHexaIndices);

				// 제거되는 목록
				float currX;
				float currZ;
				for (auto& curr : m_oldHexaIndices)
				{
					auto currLoc = MakeLoc(curr.m_column, curr.m_row);
					CnvOddR2Point(curr.m_column, curr.m_row, &m_temporaryRange, currX, currZ);
					int32_t currBucketIndex = hashPos2(currX, currZ, currRange, m_bucketsSize);
					moveTraverse(true, false, baseRange, element, currLoc, currRange, &m_temporaryRange, m_buckets[bucketBase + currBucketIndex]);
				}

				// 추가되는 목록
				for (auto& curr : m_newHexaIndices)
				{
					auto currLoc = MakeLoc(curr.m_column, curr.m_row);
					CnvOddR2Point(curr.m_column, curr.m_row, &m_temporaryRange, currX, currZ);
					int32_t currBucketIndex = hashPos2(currX, currZ, currRange, m_bucketsSize);
					moveTraverse(false, true, baseRange, element, currLoc, currRange, &m_temporaryRange, m_buckets[bucketBase + currBucketIndex]);
				}
			}
			else
			{
				m_oldHexaIndices.clear();
				m_newHexaIndices.clear();
				m_intersectionHexaIndices.clear();

				Intersection(
					oldColumn, oldRow, newColumn, newRow,
					1,
					m_oldHexaIndices, m_newHexaIndices, m_intersectionHexaIndices);

				// 제거되는 목록
				for (auto& curr : m_oldHexaIndices)
				{
					auto currLoc = MakeLoc(curr.m_column, curr.m_row);
					int32_t currBucketIndex = hashPos2(curr.m_column, curr.m_row, m_bucketsSize);
					moveTraverse(true, false, baseRange, element, currLoc, currRange, currMaxRange, m_buckets[bucketBase + currBucketIndex]);
				}

				// 추가되는 목록
				for (auto& curr : m_newHexaIndices)
				{
					auto currLoc = MakeLoc(curr.m_column, curr.m_row);
					int32_t currBucketIndex = hashPos2(curr.m_column, curr.m_row, m_bucketsSize);
					moveTraverse(false, true, baseRange, element, currLoc, currRange, currMaxRange, m_buckets[bucketBase + currBucketIndex]);
				}
			}
		}

		return true;
	}
	template <typename T, typename TRAVERSE>
	void LayerbaseTraverse(int baseLayer, T orgX, T orgZ, TRAVERSE& traverse)
	{
		if (0 > baseLayer || baseLayer >= m_layerSize)
			return;

		const range* baseRange = &m_ranges[baseLayer];

		// 범위가 0이라면.. 시야 범위가 전체이므로.. 그냥 리턴한다!
		if (0.f == baseRange->GetRange())
			return;

		// 순회
		for (int currLayer = 0; currLayer < m_layerSize; ++currLayer)
		{
			const range* currMaxRange = &m_ranges[currLayer];

			// 범위가 없는 경우이므로 어떤 이동도 영향을 주지 않는다!
			if (0.f == currMaxRange->GetRange())
			{
				traverse(this, static_cast<int64_t>(0), currLayer, currMaxRange->GetRange(), m_buckets[currLayer * m_bucketsSize]);
			}
			else
			{
				if (currMaxRange->GetRange() < baseRange->GetRange())
					currMaxRange = baseRange;

				const range* currMinRange = &m_ranges[currLayer];
				if (currMinRange->GetRange() > baseRange->GetRange())
					currMinRange = baseRange;

				const range* currRange = &m_ranges[currLayer];

				//
				if (currMaxRange->GetRange() != currMinRange->GetRange())
				{
					int32_t tmpGcf = this->CalcGcf(currMinRange->GetRange(), currMaxRange->GetRange());

					if (tmpGcf != m_temporaryRange.GetRange())
						m_temporaryRange.SetVar(tmpGcf);

					// 해당 영역을 검색한다.
					{
						int32_t column;
						int32_t row;
						int64_t loc = MakeLoc(orgX, orgZ, &m_temporaryRange, column, row);

						m_traverseIndices.clear();
						this->CubeRange(column, row, currMaxRange->GetRange() / tmpGcf, m_traverseIndices);
					}

					// 
					float currX;
					float currZ;
					int bucketBase = currLayer * m_bucketsSize;

					for (auto& curr : m_traverseIndices)
					{
						auto currLoc = MakeLoc(curr.m_column, curr.m_row);
						CnvOddR2Point(curr.m_column, curr.m_row, &m_temporaryRange, currX, currZ);
						int32_t currBucketIndex = hashPos2(currX, currZ, currRange, m_bucketsSize);
						traverse(this, currLoc, currRange, &m_temporaryRange, m_buckets[bucketBase + currBucketIndex]);
					}
				}
				else
				{
					// 해당 영역을 검색한다.
					{
						int32_t column;
						int32_t row;
						int64_t loc = MakeLoc(orgX, orgZ, currMaxRange, column, row);

						m_traverseIndices.clear();
						CubeRange(column, row, 1, m_traverseIndices);
					}

					int bucketBase = currLayer * m_bucketsSize;

					for (auto& curr : m_traverseIndices)
					{
						auto currLoc = MakeLoc(curr.m_column, curr.m_row);
						int32_t currBucketIndex = hashPos2(curr.m_column, curr.m_row, m_bucketsSize);
						traverse(this, currLoc, currRange, currMaxRange, m_buckets[bucketBase + currBucketIndex]);
					}
				}
			}
		}
	}
	template <typename T, typename TRAVERSE>
	void LayerbaseTraverse(int baseLayer, T orgX, T orgZ, TRAVERSE& traverse, int currLayer)
	{
		if (0 > baseLayer || baseLayer >= m_layerSize)
			return;

		const range* baseRange = &m_ranges[baseLayer];

		// 범위가 0이라면.. 시야 범위가 전체이므로.. 그냥 리턴한다!
		if (0.f == baseRange->GetRange())
			return;

		// 순회
		const range* currMaxRange = &m_ranges[currLayer];

		// 범위가 없는 경우이므로 어떤 이동도 영향을 주지 않는다!
		if (0.f == currMaxRange->GetRange())
		{
			traverse(this, static_cast<int64_t>(0), currLayer, currMaxRange->GetRange(), m_buckets[currLayer * m_bucketsSize]);
		}
		else
		{
			if (currMaxRange->GetRange() < baseRange->GetRange())
				currMaxRange = baseRange;

			const range* currMinRange = &m_ranges[currLayer];
			if (currMinRange->GetRange() > baseRange->GetRange())
				currMinRange = baseRange;

			const range* currRange = &m_ranges[currLayer];

			//
			if (currMaxRange->GetRange() != currMinRange->GetRange())
			{
				int32_t tmpGcf = this->CalcGcf(currMinRange->GetRange(), currMaxRange->GetRange());

				if (tmpGcf != m_temporaryRange.GetRange())
					m_temporaryRange.SetVar(tmpGcf);

				// 해당 영역을 검색한다.
				{
					int32_t column;
					int32_t row;
					int64_t loc = MakeLoc(orgX, orgZ, &m_temporaryRange, column, row);

					m_traverseIndices.clear();
					this->CubeRange(column, row, currMaxRange->GetRange() / tmpGcf, m_traverseIndices);
				}

				// 
				float currX;
				float currZ;
				int bucketBase = currLayer * m_bucketsSize;

				for (auto& curr : m_traverseIndices)
				{
					auto currLoc = MakeLoc(curr.m_column, curr.m_row);
					CnvOddR2Point(curr.m_column, curr.m_row, &m_temporaryRange, currX, currZ);
					int32_t currBucketIndex = hashPos2(currX, currZ, currRange, m_bucketsSize);
					traverse(this, currLoc, currRange, &m_temporaryRange, m_buckets[bucketBase + currBucketIndex]);
				}
			}
			else
			{
				// 해당 영역을 검색한다.
				{
					int32_t column;
					int32_t row;
					int64_t loc = MakeLoc(orgX, orgZ, currMaxRange, column, row);

					m_traverseIndices.clear();
					CubeRange(column, row, 1, m_traverseIndices);
				}

				int bucketBase = currLayer * m_bucketsSize;

				for (auto& curr : m_traverseIndices)
				{
					auto currLoc = MakeLoc(curr.m_column, curr.m_row);
					int32_t currBucketIndex = hashPos2(curr.m_column, curr.m_row, m_bucketsSize);
					traverse(this, currLoc, currRange, currMaxRange, m_buckets[bucketBase + currBucketIndex]);
				}
			}
		}
	}
	template <typename T, typename TRAVERSE>
	void Traverse(T orgX, T orgZ, TRAVERSE& traverse)
	{
		for (int currLayer = 0; currLayer < m_layerSize; ++currLayer)
		{
			const range* currRange = &m_ranges[currLayer];

			// 0이면 경계가 없다!
			if (0 == currRange->GetRange())
			{
				traverse(this, static_cast<int64_t>(0), currRange, m_buckets[currLayer * m_bucketsSize]);
			}
			else
			{
				// 영역을 구한다.
				{
					int32_t column;
					int32_t row;
					int64_t loc = MakeLoc(orgX, orgZ, currRange, column, row);

					m_traverseIndices.clear();
					CubeRange(column, row, 1, m_traverseIndices);
				}

				//
				int bucketBase = currLayer * m_bucketsSize;

				for (auto& curr : m_traverseIndices)
				{
					auto currLoc = MakeLoc(curr.m_column, curr.m_row);
					int32_t currBucketIndex = hashPos2(curr.m_column, curr.m_row, m_bucketsSize);
					traverse(this, currLoc, currRange, m_buckets[bucketBase + currBucketIndex]);
				}
			}
		}
	}
	template <typename T, typename TRAVERSE>
	void TraverseInSight(T orgX, T orgZ, TRAVERSE& traverse, int sightRange)
	{
		for (int currLayer = 0; currLayer < m_layerSize; ++currLayer)
		{
			const range* currRange = &m_ranges[currLayer];

			// 0이면 경계가 없다!
			if (0 == currRange->GetRange())
			{
				traverse(this, static_cast<int64_t>(0), currLayer, m_buckets[currLayer * m_bucketsSize]);
			}
			else
			{
				// 검색 영역이 기존 range보다 크다면..
				int32_t currLevel;
				if (sightRange > currRange->GetRange())
					currLevel = (sightRange + currRange->GetRange() - 1) / currRange->GetRange();
				else
					currLevel = 1;

				// 영역을 구한다.
				{
					int32_t column;
					int32_t row;
					MakeLoc(orgX, orgZ, currRange, column, row);

					m_traverseIndices.clear();
					this->CubeRange(column, row, currLevel, m_traverseIndices);
				}

				float currX;
				float currZ;
				int bucketBase = currLayer * m_bucketsSize;

				for (auto& curr : m_traverseIndices)
				{
					auto currLoc = MakeLoc(curr.m_column, curr.m_row);
					int32_t currBucketIndex = hashPos2(curr.m_column, curr.m_row, m_bucketsSize);
					traverse(this, currLoc, currLayer, m_buckets[bucketBase + currBucketIndex]);
				}
			}
		}
	}
	template <typename T, typename TRAVERSE>
	void Traverse(T orgX, T orgZ, TRAVERSE& traverse, int currLayer)
	{
		if (0 > currLayer || currLayer >= m_layerSize)
			return;

		const range* currRange = &m_ranges[currLayer];

		// range가 0이면 경계가 없다!
		if (0 == currRange->GetRange())
		{
			// range가 0인 대상은 모두 bucketIndex = 0에 기록
			traverse(this, static_cast<int64_t>(0), currRange, m_buckets[currLayer * m_bucketsSize]);
		}
		else
		{
			// 영역을 구한다.
			{
				int32_t column;
				int32_t row;
				MakeLoc(orgX, orgZ, currRange, column, row);

				m_traverseIndices.clear();
				CubeRange(column, row, 1, m_traverseIndices);
			}

			int bucketBase = currLayer * m_bucketsSize;

			for (auto& curr : m_traverseIndices)
			{
				auto currLoc = MakeLoc(curr.m_column, curr.m_row);
				int32_t currBucketIndex = hashPos2(curr.m_column, curr.m_row, m_bucketsSize);
				traverse(this, currLoc, currRange, m_buckets[bucketBase + currBucketIndex]);
			}
		}
	}
	template <typename T, typename TRAVERSE>
	void TraverseInSight(T orgX, T orgZ, TRAVERSE& traverse, int currLayer, int sightRange)
	{
		if (0 > currLayer || currLayer >= m_layerSize)
			return;

		const range* currRange = &m_ranges[currLayer];

		// 0이면 경계가 없다!
		if (0 == currRange->GetRange())
		{
			traverse(this, static_cast<int64_t>(0), currLayer, m_buckets[currLayer * m_bucketsSize]);
		}
		else
		{
			// 검색 영역이 기존 range보다 크다면..
			int32_t currLevel;
			if (sightRange > currRange->GetRange())
				currLevel = (sightRange + currRange->GetRange() - 1) / currRange->GetRange();
			else
				currLevel = 1;

			// 영역을 구한다.
			{
				int32_t column;
				int32_t row;
				this->MakeLoc(orgX, orgZ, currRange, column, row);

				m_traverseIndices.clear();
				this->CubeRange(column, row, currLevel, m_traverseIndices);
			}

			int bucketBase = currLayer * m_bucketsSize;

			for (auto& curr : m_traverseIndices)
			{
				auto currLoc = MakeLoc(curr.m_column, curr.m_row);
				int32_t currBucketIndex = hashPos2(curr.m_column, curr.m_row, m_bucketsSize);
				traverse(this, currLoc, currLayer, m_buckets[bucketBase + currBucketIndex]);
			}
		}
	}
	template <typename TRAVERSE>
	void TraverseAll(TRAVERSE& traverse)
	{
		for (int currLayer = 0; currLayer < m_layerSize; ++currLayer)
		{
			const auto currLayerIndex = currLayer * m_bucketsSize;

			for (int currBucketIndex = 0; currBucketIndex < m_bucketsSize; ++currBucketIndex)
			{
				auto tmpLayerIndex = currLayerIndex + currBucketIndex;
				if (nullptr == m_buckets[tmpLayerIndex])
					continue;

				traverse(m_buckets[tmpLayerIndex]);
			}
		}
	}
	template <typename TRAVERSE>
	void TraverseAll(TRAVERSE& traverse, int currLayer)
	{
		if (0 > currLayer || currLayer >= m_layerSize)
			return;

		const auto currLayerIndex = currLayer * m_bucketsSize;

		for (int currBucketIndex = 0; currBucketIndex < m_bucketsSize; ++currBucketIndex)
		{
			auto tmpLayerIndex = currLayerIndex + currBucketIndex;
			if (nullptr == m_buckets[tmpLayerIndex])
				continue;

			traverse(m_buckets[tmpLayerIndex]);
		}
	}

public:
	inline int32_t Size() const
	{
		return m_elementCount;
	}
	// 0 이면 무제한이다.
	inline bool SetLayerSightRange(int32_t layer, int32_t range)
	{
		// 여기서는 0을 허용한다!
		if (0 > layer || layer >= m_layerSize || 0 > range || 0 != m_elementCount || nullptr == m_ranges)
			return false;

		m_ranges[layer].SetVar(range);
		return true;
	}
	inline bool GetLayerSightRange(int32_t layer, int32_t& range)
	{
		if (0 > layer || layer >= m_layerSize || nullptr == m_ranges)
			return false;

		range = m_ranges[layer].GetRange();
		return true;
	}

public:
	inline void CnvPoint2OddR(const float orgX, const float orgZ, const int32_t layer, int32_t& column, int32_t& row)
	{
		m_ranges[layer].CnvPoint2OddR(orgX - m_baseX, orgZ - m_baseZ, column, row);
	}
	inline void CnvOddR2Point(const int32_t column, const int32_t row, const int32_t layer, float& orgX, float& orgZ)
	{
		m_ranges[layer].CnvOddR2Point(column, row, orgX, orgZ);
		orgX += m_baseX;
		orgZ += m_baseZ;
	}
	inline void CnvOddR2Point(const int32_t column, const int32_t row, const range* currRange, float& orgX, float& orgZ)
	{
		currRange->CnvOddR2Point(column, row, orgX, orgZ);
		orgX += m_baseX;
		orgZ += m_baseZ;
	}
	inline int64_t MakeLoc(const float orgX, const float orgZ, const int32_t layer)
	{
		int32_t column;
		int32_t row;
		m_ranges[layer].CnvPoint2OddR(orgX - m_baseX, orgZ - m_baseZ, column, row);

		return this->MakeLoc(column, row);
	}
	inline int64_t MakeLoc(const float orgX, const float orgZ, const range* currRange)
	{
		int32_t column;
		int32_t row;
		currRange->CnvPoint2OddR(orgX - m_baseX, orgZ - m_baseZ, column, row);

		return this->MakeLoc(column, row);
	}
	inline int64_t MakeLoc(const float orgX, const float orgZ, const int32_t layer, int32_t& column, int32_t& row)
	{
		m_ranges[layer].CnvPoint2OddR(orgX - m_baseX, orgZ - m_baseZ, column, row);
		return this->MakeLoc(column, row);
	}
	inline int64_t MakeLoc(const float orgX, const float orgZ, const range* currRange, int32_t& column, int32_t& row)
	{
		currRange->CnvPoint2OddR(orgX - m_baseX, orgZ - m_baseZ, column, row);
		return this->MakeLoc(column, row);
	}
	inline bool Intersection(
		const int32_t oldColumn, const int32_t oldRow,
		const int32_t newColumn, const int32_t newRow,
		const int32_t n,
		_hexa_index_vec_t& oldHexaIndces,
		_hexa_index_vec_t& newHexaIndces,
		_hexa_index_vec_t& intersectionHexaIndces)
	{
		int32_t oldCubeX, oldCubeY, oldCubeZ;
		CnvOddr2Cube(oldColumn, oldRow, oldCubeX, oldCubeY, oldCubeZ);
		int32_t newCubeX, newCubeY, newCubeZ;
		CnvOddr2Cube(newColumn, newRow, newCubeX, newCubeY, newCubeZ);

		CubeIntersection(oldCubeX, oldCubeY, oldCubeZ, newCubeX, newCubeY, newCubeZ, n, [this, &intersectionHexaIndces](auto cubeX, auto cubeY, auto cubeZ)
		{
			int32_t column, row;
			this->CnvCube2Oddr(cubeX, cubeY, cubeZ, column, row);
			intersectionHexaIndces.emplace_back(column, row);
		});

		// 고차되는게 없다.
		if (intersectionHexaIndces.empty())
		{
			CubeRange(oldCubeX, oldCubeY, oldCubeZ, n, [&oldHexaIndces, this](auto cubeX, auto cubeY, auto cubeZ)
			{
				int32_t column, row;
				this->CnvCube2Oddr(cubeX, cubeY, cubeZ, column, row);
				oldHexaIndces.emplace_back(column, row);
			});
			CubeRange(newCubeX, newCubeY, newCubeZ, n, [&newHexaIndces, this](auto cubeX, auto cubeY, auto cubeZ)
			{
				int32_t column, row;
				this->CnvCube2Oddr(cubeX, cubeY, cubeZ, column, row);
				newHexaIndces.emplace_back(column, row);
			});

			return false;
		}

		// 교차한다.
		CubeRange(oldCubeX, oldCubeY, oldCubeZ, n, [&oldHexaIndces, &intersectionHexaIndces, this](auto cubeX, auto cubeY, auto cubeZ)
		{
			int32_t column, row;
			this->CnvCube2Oddr(cubeX, cubeY, cubeZ, column, row);

			if (intersectionHexaIndces.end() == std::find_if(intersectionHexaIndces.begin(), intersectionHexaIndces.end(), [column, row](const auto& val) { return column == val.m_column && row == val.m_row; }))
				oldHexaIndces.emplace_back(column, row);
		});
		CubeRange(newCubeX, newCubeY, newCubeZ, n, [&newHexaIndces, &intersectionHexaIndces, this](auto cubeX, auto cubeY, auto cubeZ)
		{
			int32_t column, row;
			this->CnvCube2Oddr(cubeX, cubeY, cubeZ, column, row);

			if (intersectionHexaIndces.end() == std::find_if(intersectionHexaIndces.begin(), intersectionHexaIndces.end(), [column, row](const auto& val) { return column == val.m_column && row == val.m_row; }))
				newHexaIndces.emplace_back(column, row);
		});

		return true;
	}

public:
//private:
	// recast에 있는거 가져옮
	inline int32_t hashPos2(int32_t column, int32_t row, int32_t n)
	{
		return ((column * 73856093) ^ (row * 19349663)) & (n - 1);
	}
	inline int32_t hashPos2(float orgX, float orgZ, int32_t layer, int32_t n)
	{
		int32_t column;
		int32_t row;
		m_ranges[layer].CnvPoint2OddR(orgX - m_baseX, orgZ - m_baseZ, column, row);

		return this->hashPos2(column, row, n);
	}
	inline int32_t hashPos2(float orgX, float orgZ, const range* currRange, int32_t n)
	{
		int32_t column;
		int32_t row;
		currRange->CnvPoint2OddR(orgX - m_baseX, orgZ - m_baseZ, column, row);

		return this->hashPos2(column, row, n);
	}
	inline int64_t MakeLoc(int32_t column, int32_t row)
	{
		return ((static_cast<int64_t>(column) << 32) & 0xFFFFFFFF00000000) | (static_cast<int64_t>(row) & 0x00000000FFFFFFFF);
	}
	inline void CnvCube2Evenr(int32_t cubeX, int32_t cubeY, int32_t cubeZ, int32_t& column, int32_t& row) 
	{
		column = cubeX + ((cubeZ + (cubeZ & 1)) >> 1);
		row = cubeZ;
	}
	inline void CnvEvenr2Cube(int32_t column, int32_t row, int32_t& cubeX, int32_t& cubeY, int32_t& cubeZ)
	{
		cubeX = column - ((row + (row & 1)) >> 1);
		cubeZ = row;
		cubeY = -cubeX - cubeZ;
	}
	inline void CnvCube2Oddr(int32_t cubeX, int32_t cubeY, int32_t cubeZ, int32_t& column, int32_t& row)
	{
		column = cubeX + ((cubeZ - (cubeZ & 1)) >> 1);
		row = cubeZ;
	}
	inline void CnvOddr2Cube(int32_t column, int32_t row, int32_t& cubeX, int32_t& cubeY, int32_t& cubeZ)
	{
		cubeX = column - ((row - (row & 1)) >> 1);
		cubeZ = row;
		cubeY = -cubeX - cubeZ;
	}
	inline int32_t CalcCubeDistance(int32_t aCubeX, int32_t aCubeY, int32_t aCubeZ, int32_t bCubeX, int32_t bCubeY, int32_t bCubeZ)
	{
		return (std::abs(aCubeX - bCubeX) + std::abs(aCubeY - bCubeY) + std::abs(aCubeZ - bCubeZ)) >> 1;
	}
	inline int32_t CalcOffsetDistance(int32_t aColumn, int32_t aRow, int32_t bColumn, int32_t bRow)
	{
		int32_t aCubeX, aCubeY, aCubeZ;
		CnvOddr2Cube(aColumn, aRow, aCubeX, aCubeY, aCubeZ);

		int32_t bCubeX, bCubeY, bCubeZ;
		CnvOddr2Cube(bColumn, bRow, bCubeX, bCubeY, bCubeZ);

		return CalcCubeDistance(aCubeX, aCubeY, aCubeZ, bCubeX, bCubeY, bCubeZ);
	}
	inline void CubeAdd(int32_t& cubeX, int32_t& cubeY, int32_t& cubeZ, int32_t dirX, int32_t dirY, int32_t dirZ)
	{
		cubeX += dirX;
		cubeY += dirY;
		cubeZ += dirZ;
	}
	template <typename EMPLACE> inline void CubeRange(int32_t cubeX, int32_t cubeY, int32_t cubeZ, int32_t n, EMPLACE& emplace)
	{
		for (int32_t x = -n; x <= n; ++x)
		{
			for (int32_t y = std::max(-n, -x - n); y <= std::min(n, -x + n); ++y)
			{
				int32_t z = -x - y;
				emplace(cubeX + x, cubeY + y, cubeZ + z);
			}
		}
	}
	inline void CubeRange(int32_t column, int32_t row, int32_t n, _hexa_index_vec_t& traverseIndices)
	{
		int32_t cubeX, cubeY, cubeZ;
		CnvOddr2Cube(column, row, cubeX, cubeY, cubeZ);

		CubeRange(cubeX, cubeY, cubeZ, n, [&traverseIndices, this](auto cubeX, auto cubeY, auto cubeZ)
		{
			int32_t column, row;
			this->CnvCube2Oddr(cubeX, cubeY, cubeZ, column, row);

			traverseIndices.emplace_back(column, row);
		});
	}
	inline void CalcCubeMinMax(
		int32_t cubeX, int32_t cubeY, int32_t cubeZ, int32_t n,
		int32_t& minX, int32_t& maxX, int32_t& minY, int32_t& maxY, int32_t& minZ, int32_t& maxZ)
	{
		minX = cubeX - n; maxX = cubeX + n;
		minY = cubeY - n; maxY = cubeY + n;
		minZ = cubeZ - n; maxZ = cubeZ + n;
	}
	template <typename EMPLACE> inline void CubeIntersection(
		int32_t aCubeX, int32_t aCubeY, int32_t aCubeZ, 
		int32_t bCubeX, int32_t bCubeY, int32_t bCubeZ,
		int32_t n, EMPLACE& emplace)
	{
		int32_t aMinX, aMaxX, aMinY, aMaxY, aMinZ, aMaxZ;
		CalcCubeMinMax(aCubeX, aCubeY, aCubeZ, n, aMinX, aMaxX, aMinY, aMaxY, aMinZ, aMaxZ);
		int32_t bMinX, bMaxX, bMinY, bMaxY, bMinZ, bMaxZ;
		CalcCubeMinMax(bCubeX, bCubeY, bCubeZ, n, bMinX, bMaxX, bMinY, bMaxY, bMinZ, bMaxZ);

		int32_t tMinX = std::max(aMinX, bMinX);
		int32_t tMaxX = std::min(aMaxX, bMaxX);
		int32_t tMinY = std::max(aMinY, bMinY);
		int32_t tMaxY = std::min(aMaxY, bMaxY);
		int32_t tMinZ = std::max(aMinZ, bMinZ);
		int32_t tMaxZ = std::min(aMaxZ, bMaxZ);

		for (int32_t x = tMinX; x <= tMaxX; ++x)
		{
			for (int32_t y = std::max(tMinY, -x - tMaxZ); y <= std::min(tMaxY, -x - tMinZ); ++y)
			{
				int32_t z = -x - y;
				emplace(x, y, z);
			}
		}
	}
	inline int CalcGcf(int tA, int tB)
	{
		for (;;)
		{
			int tC = tA % tB;
			if (0 == tC)
				break;

			tA = tB;
			tB = tC;
		}

		return tB;
	}

private:
	int32_t m_refs;
	int32_t m_layerSize;
	int32_t m_bucketsSize;
	int32_t m_elementCount;
	_element_t** m_buckets;
	range* m_ranges;
	int32_t m_maxRange;
	float m_baseX;
	float m_baseZ;
	range m_temporaryRange;
	_hexa_index_vec_t m_oldHexaIndices;
	_hexa_index_vec_t m_newHexaIndices;
	_hexa_index_vec_t m_intersectionHexaIndices;
	_hexa_index_vec_t m_traverseIndices;
};

//
template <typename ELEMENT, typename ALLOC>
const float hexagonal_grid<ELEMENT, ALLOC>::m_sqrt3 = std::sqrtf(3.f);

}

#endif
