﻿/*
* 작성자 : 
* 설명 : 시간 측정을 돕기 위해 만든 유틸 클래스
* 사용 법 :
*	void func()
*	{
*		for (int32_t i = 0; i < 100; ++i) {}	
*	}
*
*	void exec()
*	{
*		nmsp::benchmark bench;
*
*		func1();
*		bench.Mark(BM_STEP1);
*
*		func2();
*		bench.Mark(BM_STEP2);
*
*		std::cout << bench.ToString() << std::endl;
*	}
*/

#pragma once
#ifndef __NMSPBENCHMARK_H__
#define __NMSPBENCHMARK_H__

#include "nmspstopwatch.h"

#define BM_STEP1
#define BM_STEP2
#define BM_STEP3
#define BM_STEP4
#define BM_STEP5
#define BM_STEP6
#define BM_STEP7
#define BM_STEP8
#define BM_STEP9
#define BM_STEP10
#define BM_STEP11
#define BM_STEP12
#define BM_STEP13
#define BM_STEP14
#define BM_STEP15
#define BM_STEP16
#define BM_STEP17
#define BM_STEP18
#define BM_STEP19
#define BM_STEP20

namespace nmsp 
{
class benchmark : private boost::noncopyable
{
public:
	enum class mark_option
	{

	};

	benchmark()
		: m_index(0)
	{
		m_timer.Start();
	}
	
	~benchmark() = default;
	
	inline const int32_t GetIndex() { return m_index; }

	void Mark()
	{
		if (m_index >= m_steps.max_size())
			return;
	
		m_steps[m_index++] = m_timer.LapAndRestart();
	}
	
	/*
	* 특정 인덱스에 측정 결과를 더합니다. 
	* ex) auto index = bench.GetIndex(); // result : 10
	* for (int32_t i = 0; i < 10; ++i) {
	*	bench.MarkOrSum(index + 1);	// index : 11
	*	// ... 생략 
	*	bench.MarkOrSum(index + 2);	// index : 12
	* }
	*/
	void MarkOrSum(const int32_t index)
	{
		if (0 > index || index > (m_index + 1))
			return;

		if (index == (m_index + 1)) // 다음 스텝일 경우 마크
		{
			Mark();
			return;
		}

		m_steps[index] += m_timer.LapAndRestart();
	}

	std::string ToString()
	{
		fmt::memory_buffer out;
		
		for (int32_t i = 0; i < m_index; ++i)
		{
			if (0 == i)
			{
				fmt::format_to(out, "step{}={}", i + 1, m_steps[i]);
			}
			else 
			{
				fmt::format_to(out, ",step{}={}", i + 1, m_steps[i]);
			}
		}
		
		return std::string(out.data(), out.size());
	}

private:
	int32_t m_index;
	nmsp::_stop_watch_mic_t m_timer;
	std::array<time_t, 100> m_steps;
};
} // end namespace nmsp

#endif // end __NMSPBENCHMARK_H__