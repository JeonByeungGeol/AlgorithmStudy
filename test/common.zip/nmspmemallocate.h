////////////////////////////////////////////////////////////////////////////////
// �ۼ���: huelee
// ��  ��:
//
//

// ȣȯ���� ���ؼ�..
#pragma once
#ifndef __NMSPMEMALLOCATE_H__
#define __NMSPMEMALLOCATE_H__

//
namespace nmsp {

// nmsp���� ��������� �� �⺻ �޸� ��������
// ��� �޸� �Ҵ翡 ������ ���� bad_alloc�� throw�Ѵ�.
class default_allocator
{
public:
	default_allocator() {};

	//
	template <class T, class ..._ARGS_T>
	static inline T* Create(_ARGS_T&&... _ARGX)
	{
		//return new (std::nothrow) T(_ARGX...);
		return new T(std::forward<_ARGS_T>(_ARGX) ...);
	}
	//
	template <class T, class ..._ARGS_T>
	static inline T* Create(const std::nothrow_t&, _ARGS_T&&... _ARGX) noexcept
	{
		//return new (std::nothrow) T(_ARGX...);
		return new (std::nothrow) T(std::forward<_ARGS_T>(_ARGX) ...);
	}
	//
	template <class T>
	static inline void Destroy(T* pT) noexcept
	{
		delete pT;
	}
	//
	template <class T>
	static inline T* CreateArray(int nSize)
	{
		return new T[nSize];
	}
	//
	template <class T>
	static inline T* CreateArray(const std::nothrow_t&, int nSize)
	{
		return new (std::nothrow) T[nSize];
	}
	//
	template <class T>
	static inline void DestroyArray(int nSize, T* pT) noexcept
	{
		delete[] pT;
	}
	//
	static inline void* CreateMemory(int nSize) noexcept
	{ 
		return reinterpret_cast<void*>(::malloc(nSize));
	}
	//
	template <class T>
	static inline void* CreateMemory(int nSize, T _t) noexcept
	{
		return reinterpret_cast<void*>(::malloc(nSize));
	}
	//
	static inline void* RecreateMemory(void* pT, int /*nSizeForCopy*/, int nSize) noexcept
	{ 
		return reinterpret_cast<void*>(::realloc(pT, nSize));
	}
	//
	static inline void DestroyMemory(void* pT) noexcept
	{ 
		if (nullptr == pT)
			return;

		::free(pT);
	}

protected:
	virtual ~default_allocator() {};
};
//

////////////////////////////////////////////////////////////////////////////////
//
// STL�� �ʿ��� �Ҵ���~~~
//
template<typename T, typename CAllocator>
class stl_default_allocator
{
public:
	typedef T value_type;
	typedef size_t size_type;
	typedef ptrdiff_t difference_type;
	typedef value_type* pointer;
	typedef value_type& reference;
	typedef const value_type* const_pointer;
	typedef const value_type& const_reference;

	//
	template<class Other> struct rebind { typedef stl_default_allocator<Other, CAllocator> other; };

	//
	inline pointer address(reference _Val) const { return (&_Val); }
	inline const_pointer address(const_reference _Val) const { return (&_Val); }

	//
	stl_default_allocator() throw() {}
	stl_default_allocator(const stl_default_allocator<T, CAllocator>&) throw() {}
	template<class Other> stl_default_allocator(const stl_default_allocator<Other, CAllocator>&) throw() {}

	//
	template<class Other> stl_default_allocator<T, CAllocator>& operator=(const stl_default_allocator<Other, CAllocator>&) { return (*this); }

	//
	inline pointer allocate(size_type count) { return reinterpret_cast<pointer>(CAllocator::CreateMemory(static_cast<int>(count * sizeof(T)))); }
	inline pointer allocate(size_type count, const void*) { return (allocate(count)); }
	inline void deallocate(pointer p, size_type /*count*/) { CAllocator::DestroyMemory(reinterpret_cast<void*>(p)); }

	//
	inline void construct(pointer p, const T& val) { new (p) T(val); }
	inline void construct(pointer p, T&& val) { new (p) T(std::move(val)); }
	inline void destroy(pointer p) { (p)->~T(); }

	//
	inline size_type max_size() const { size_type sCount = static_cast<size_type>(-1)/sizeof(T); return (0<sCount?sCount:1); }
};

template<class T, class Other, class CAllocator> 
inline bool operator==(const stl_default_allocator<T, CAllocator>&, const stl_default_allocator<Other, CAllocator>&)
{	
	return true;
}

template<class T, class Other, class CAllocator> 
inline bool operator!=(const stl_default_allocator<T, CAllocator>&, const stl_default_allocator<Other, CAllocator>&)
{	
	return false;
}

} // namespace nmsp

#endif
