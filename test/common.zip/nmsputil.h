﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __NMSPUTIL_H__
#define __NMSPUTIL_H__

// 
namespace nmsp {

// 2의 배수
inline unsigned int NextPow(unsigned int v)
{
	v--;
	v |= v >> 1;
	v |= v >> 2;
	v |= v >> 4;
	v |= v >> 8;
	v |= v >> 16;
	v++;
	return v;
}
	
// 배열의 크기와 타입을.. 알아내는 템플릿 
template<class T>
class array_traits
{
public:
	typedef T _T;
	enum { _VALUE = FALSE, _SIZE = 0, };
};

template<class T, int I>
class array_traits<T[I]>
{
public:
	typedef T _T;
	enum { _VALUE = TRUE, _SIZE = I, };
};

//
template <typename T>
constexpr T calc_hash(const char* str, const short sht)
{
	return *str ? (*str + (calc_hash<T>(str + 1, sht) << sht)) : 0;
}

// 
template< class TYPE, int SIZE>
constexpr int count_of(TYPE(&)[SIZE]) { return SIZE; }

// 간단하게 spinlock을 만들어보자
// 재귀 호출이 안되므로.. 주의하자!
class lite_lock
{
private:
	enum
	{
		SPIN_DEFAULT_COUNT	= 4000,					// spin count
	};

public:
	//You can improve performance significantly by choosing a small spin count for a critical section of short duration. 
	//The heap manager uses a spin count of roughly 4000 for its per-heap critical sections. 
	//This gives great performance and scalability in almost all worst-case scenarios.
	lite_lock(int nSpinCounter = SPIN_DEFAULT_COUNT)
		: m_nLock(0)
		, m_nSpinCounter(nSpinCounter)
		, m_sleeptime(0)
	{
	}
	//
	virtual ~lite_lock()
	{
	}
	inline void lock(void)
	{
		int nSpinCounter = 0;
		int nTmp = 0;

		while (m_nLock.compare_exchange_weak(nTmp, 1) == false)
		{
			this->SpinWait(nSpinCounter, m_nSpinCounter);
			nTmp = 0;
		}
	}
	inline void unlock(void)
	{
		m_nLock.exchange(0);
	}

private:
	inline void SpinWait(int& nCounter, int nCount)
	{
		if ((++nCounter % nCount) == 0)
			std::this_thread::sleep_for(m_sleeptime);
	}

private:
	std::atomic_int m_nLock;

private:
	int m_nSpinCounter;
	const std::chrono::duration<int, std::ratio<1>> m_sleeptime;
};

//
// 간단하게 read-write-spinlock을 만들어보자
// 재귀 호출이 안되므로.. 주의하자!
class lite_rwlock
{
private:
	enum
	{
		WRITER_COUNT_FLAG = 0x1,
		READER_COUNT_INC = 0x2,
		SPIN_DEFAULT_COUNT = 4000,					// spin count
	};

public:
	//You can improve performance significantly by choosing a small spin count for a critical section of short duration. 
	//The heap manager uses a spin count of roughly 4000 for its per-heap critical sections. 
	//This gives great performance and scalability in almost all worst-case scenarios.
	lite_rwlock(int nSpinCounter = SPIN_DEFAULT_COUNT)
		: m_nLock(0)
		, m_nSpinCounter(nSpinCounter)
		, m_sleeptime(0)
	{
	}
	//
	virtual ~lite_rwlock()
	{
	}
	inline void lock(void)
	{
		int nSpinCounter = 0;
		int nTmp = 0;
		
		++m_nWLockCnt;

		while (m_nLock.compare_exchange_weak(nTmp, WRITER_COUNT_FLAG) == false)
		{
			this->SpinWait(nSpinCounter, m_nSpinCounter);
			nTmp = 0;
		}
	}
	inline void unlock(void)
	{
		m_nLock -= WRITER_COUNT_FLAG;
		--m_nWLockCnt;
	}
	inline void lock_shared(void)
	{
		int nSpinCounter = 0;

		m_nLock += READER_COUNT_INC;

		while ((m_nLock & WRITER_COUNT_FLAG) != 0)
			SpinWait(nSpinCounter, m_nSpinCounter);
	}
	inline void unlock_shared(void)
	{
		m_nLock -= READER_COUNT_INC;

		// WriteLock이 기다리는 경우
		if (m_nWLockCnt)
			std::this_thread::sleep_for(m_sleeptime);
	}

private:
	inline void SpinWait(int& nCounter, int nCount)
	{
		if ((++nCounter % nCount) == 0)
			std::this_thread::sleep_for(m_sleeptime);
	}

private:
	std::atomic_int m_nLock;
	std::atomic_int m_nWLockCnt;

private:
	int m_nSpinCounter;
	const std::chrono::duration<int, std::ratio<1>> m_sleeptime;
};

// 멤버함수에서 클래스나 리턴타입
template <typename> struct member_function_traits;
template <typename R, typename T, typename... ARGS>
struct member_function_traits<R(T::*)(ARGS...)>
{
	typedef R return_type;
	typedef T type;
};

template <typename R, typename... ARGS>
struct member_function_traits<R(*)(ARGS...)>
{
	typedef R return_type;
	using type = R(*)(ARGS...);
};

// 멤버 함수를 찾아주는...
#define HAS_MEMBER_FUNC(func)	namespace nmsp {																											\
								template <typename R, typename T, typename ...ARGS>																			\
								struct has_memfunc_##func																									\
								{																															\
									using _TYPE1_T = R (T::*)(ARGS...) const;																				\
									using _TYPE2_T = R (T::*)(ARGS...);																						\
									private: template <typename F, _TYPE1_T X = &T::func> constexpr static bool has_memberfunc_helper() { return true; }	\
									private: template <typename F, _TYPE2_T X = &T::func> constexpr static bool has_memberfunc_helper() { return true; }	\
									private: template <typename F> constexpr static bool has_memberfunc_helper(...) { return false; }						\
									public: enum { value = std::is_class<T>::value == true ? has_memberfunc_helper<T>() : false, };							\
								}; }

// 아래는 사용예 !!!
/*
HAS_MEMBER_FUNC(size)
HAS_MEMBER_FUNC(data)
HAS_MEMBER_FUNC(begin)

struct XXXX
{
	int size(int cx, int xx) { return 0; }
};

struct YYYY
{
};

//
int main()
{
	using x = nmsp::has_memfunc_data<int*, std::vector<int>>;

	std::cout << x::value << std::endl;
	std::cout << typeid(x::_TYPE1_T).name() << std::endl;
	std::cout << typeid(x::_TYPE2_T).name() << std::endl;

	std::cout << nmsp::has_memfunc_begin<std::vector<int>::iterator, std::vector<int>>::value << std::endl;
	std::cout << nmsp::has_memfunc_size<int, XXXX, int, int>::value << std::endl;
	std::cout << nmsp::has_memfunc_size<int, YYYY, int>::value << std::endl;
}
*/


template<class T>
inline const T& Clamp(const T& value, const T& min, const T& max)
{
	if (value < min)
		return min;
	else if (value > max)
		return max;
	else
		return value;
}

class util
{
public:
	// 0 보다 큰 값을 10의 제곱수로 나누어 0 보다 작게 만드는 함수 (ex. 12345 -> 0.12345)
	// 아레나 랭킹에서 동점자 처리에 사용
	static double ToLowerThanZero(const double& val)
	{
		static const std::vector<double> DIV_VALUES({ 10.0, 100.0, 1000.0, 10000.0, 100000.0, 1000000.0, 10000000.0, 100000000.0, 1000000000.0, 10000000000.0 });

		if (val < 0.0)
			return val;

		auto it = std::upper_bound(DIV_VALUES.begin(), DIV_VALUES.end(), val);
		if (it == DIV_VALUES.end())
			return 0;

		return (val / *it);
	}

	// 부동소수점 값을 문자열로 변환
	// std::to_string 사용 시 소수점 이하 6자리까지 표현되므로 스트림의 precision 을 최대로 설정해서 변환에 사용
	static std::string ToStringFromDouble(const double& val)
	{
		std::stringstream ss;
		ss.precision(std::numeric_limits<double>::max_digits10);
		ss << val;

		return ss.str();
	}
};

} // nmsp

#endif
