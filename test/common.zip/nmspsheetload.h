﻿////////////////////////////////////////////////////////////////////////////////
//
// 작성자 : huelee
// 설  명 : 
//

#pragma once
#ifndef __NMSPSHEETLOAD_H__
#define __NMSPSHEETLOAD_H__

namespace nmsp {

//
template <
	typename TYPER,
	class trim_policy,					//  = csv::trim_chars<' ', '\t'>,
	class quote_policy,					//  = csv::double_quote_escape<',', '\"'>,
	class overflow_policy,				//  = csv::throw_on_overflow,
	class comment_policy,				//  = csv::no_comment
	class nullstring_check_policy		//  = csv::no_nullstring_check
>
class sheet_load
{
public:
	typedef typename TYPER::_T _key_t;
	using _value_t = TYPER;
	using _shared_value_t = std::shared_ptr<_value_t>;
	using _shared_const_value_t = std::shared_ptr<const _value_t>;

private:
	using _container_t = std::unordered_map<_key_t, _shared_value_t>;

public:
	using const_iterator = typename _container_t::const_iterator;

public:
	sheet_load()
		: m_refs(0)
	{
	}
	~sheet_load() = default;
	inline int AddRef()
	{
		return ++m_refs;
	}
	inline int Release()
	{
		int refs = --m_refs;
		if (0 == refs)
		{
			delete this;
			return 0;
		}
		return refs;
	}
	bool Load(const char* path, nmsp::csv::ignore_case ignore_case_policy = nmsp::csv::ignore_case_yes)
	{
		nmsp::csv::csv_reader<_value_t, trim_policy, quote_policy, overflow_policy, comment_policy, nullstring_check_policy> csv_reader(path);
		csv_reader.read_header(nmsp::csv::ignore_extra_column, ignore_case_policy);

		// 
		while (true)
		{
			auto value = std::make_shared<_value_t>();

			bool ret = csv_reader.read_row(*value);
			if (false == ret)
				break;

			auto pairRet = m_container.emplace(value->m_t, value);
			if (false == pairRet.second)
				return false;
		}

		return true;
	}
	template <typename X>
	bool Load(const char* path, X func, nmsp::csv::ignore_case ignore_case_policy = nmsp::csv::ignore_case_yes)
	{
		nmsp::csv::csv_reader<_value_t, trim_policy, quote_policy, overflow_policy, comment_policy, nullstring_check_policy> csv_reader(path);
		csv_reader.read_header(nmsp::csv::ignore_extra_column, ignore_case_policy);

		// 
		while (true)
		{
			auto value = std::make_shared<_value_t>();

			bool ret = csv_reader.read_row(*value);
			if (false == ret)
				break;

			auto pairRet = m_container.emplace(value->m_t, value);
			if (false == pairRet.second)
				return false;

			if (false == func(value))
				return false;
		}

		return true;
	}
	void Unload()
	{
		m_container.clear();
	}
	inline bool get(const _key_t& key, _shared_value_t& val) {
		auto value = m_container.find(key);
		if (value != m_container.end())
		{
			val = value->second;
			return true;
		}
		return false;
	}
	inline bool get(const _key_t& key, _shared_const_value_t& val) {
		auto value = m_container.find(key);
		if (value != m_container.end())
		{
			val = value->second;
			return true;
		}
		return false;
	}
	inline bool is(const _key_t& key) {
		auto value = m_container.find(key);
		if (value != m_container.end())
			return true;
		return false;
	}
	inline auto begin() const
	{
		return m_container.cbegin();
	}
	inline auto end() const
	{
		return m_container.cend();
	}
	inline auto find(const _key_t& key) const
	{
		return m_container.find(key);
	}
	inline auto size() const
	{
		return m_container.size();
	}
	inline auto empty() const
	{
		return m_container.empty();
	}
	inline void emplace(const _key_t& key, _shared_value_t& val)
	{
		m_container.emplace(key, val);
	}
	inline const _container_t& operator * ()
	{
		return m_container;
	}
	inline const _container_t* operator -> ()
	{
		return &m_container;
	}

private:
	std::atomic_int m_refs;
	_container_t m_container;
};

// 정통 csv파일
template <
	class TYPER,
	class trim_policy = csv::trim_chars<' ', '\t'>,
	class quote_policy = csv::double_quote_escape<',', '\"'>,
	class overflow_policy = csv::throw_on_overflow,
	class comment_policy = csv::no_comment,
	class nullstring_check_policy = csv::no_nullstring_check		//  = csv::no_nullstring_check
>
class csv_sheet_load : public sheet_load<TYPER, trim_policy, quote_policy, overflow_policy, comment_policy, nullstring_check_policy>
{
};

// tab으로 구분된 파일에 대한...
template <
	class TYPER,
	class trim_policy = csv::trim_chars<' '>,
	class quote_policy = csv::no_quote_escape<'\t'>,
	class overflow_policy = csv::throw_on_overflow,
	class comment_policy = csv::no_comment,
	class nullstring_check_policy = csv::default_nullstring_check		//  = csv::no_nullstring_check
>
class tab_sheet_load : public sheet_load<TYPER, trim_policy, quote_policy, overflow_policy, comment_policy, nullstring_check_policy>
{
};

}

#endif
