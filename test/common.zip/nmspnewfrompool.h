﻿////////////////////////////////////////////////////////////////////////////////
//
// 작성자 : huelee
// 설  명 : 
//

#pragma once
#ifndef __NMSPNEWFROMPOOL_H__
#define __NMSPNEWFROMPOOL_H__

namespace nmsp {

template <class ALLOC>
class new_from_pool
{
protected:
	using _allocator_t = ALLOC;

public:
	new_from_pool()
	{
	}
	virtual ~new_from_pool()
	{
	}

public:
	static inline void* operator new (std::size_t tSize)
	{
		void* pAlloc = _allocator_t::CreateMemory(static_cast<int>(tSize));
		if (nullptr == pAlloc)
			throw std::bad_alloc();

		return pAlloc;
	}
	static inline void* operator new (std::size_t tSize, const std::nothrow_t& nothrow_constant) noexcept
	{
		return _allocator_t::CreateMemory(static_cast<int>(tSize));
	}
	static inline void* operator new (std::size_t tSize, void* ptr) noexcept
	{
		return ptr;
	}
	static inline void* operator new[] (std::size_t tSize)
	{
		void* pAlloc = _allocator_t::CreateMemory(static_cast<int>(tSize));
		if (nullptr == pAlloc)
			throw std::bad_alloc();

		return pAlloc;
	}
	static inline void* operator new[] (std::size_t tSize, const std::nothrow_t& nothrow_constant)
	{
		return _allocator_t::CreateMemory(static_cast<int>(tSize));
	}
	static inline void operator delete(void* pBack) noexcept
	{
		_allocator_t::DestroyMemory(reinterpret_cast<unsigned char*>(pBack));
	}
	static inline void operator delete (void* pBack, const std::nothrow_t& nothrow_constant) noexcept
	{
		_allocator_t::DestroyMemory(reinterpret_cast<unsigned char*>(pBack));
	}
	static inline void operator delete[](void* pBack) noexcept
	{
		_allocator_t::DestroyMemory(reinterpret_cast<unsigned char*>(pBack));
	}
	static inline void operator delete[](void* pBack, const std::nothrow_t& nothrow_constant) noexcept
	{
		_allocator_t::DestroyMemory(reinterpret_cast<unsigned char*>(pBack));
	}
};

} // nmsp

#endif
