////////////////////////////////////////////////////////////////////////////////
// �ۼ���: huelee
// ��  ��:
//
//

// ȣȯ���� ���ؼ�..
#pragma once
#ifndef __NMSPCONDITION_H__
#define __NMSPCONDITION_H__

//
namespace nmsp {

class thread_for_condition : protected std::condition_variable
{
	typedef std::condition_variable __parent;
public:
	thread_for_condition()
	{
	}
	virtual ~thread_for_condition()
	{
	}
	void SetNotification()
	{
		std::unique_lock<std::mutex> lk(m_cLk);
		__parent::notify_one();
	}
	void SetNotificationAll()
	{
		std::unique_lock<std::mutex> lk(m_cLk);
		__parent::notify_all();
	}
	std::cv_status Wait(int nTimeWait)
	{
		std::unique_lock<std::mutex> lk(m_cLk);
		return __parent::wait_for(lk, std::chrono::duration<int, std::milli>(nTimeWait));
	}
	template <class T>
	void SetNotification(T& func)
	{
		std::unique_lock<std::mutex> lk(m_cLk);
		if (true == func())
			__parent::notify_one();
	}
	template <class T>
	void SetNotificationAll(T& func)
	{
		std::unique_lock<std::mutex> lk(m_cLk);
		if (true == func())
			__parent::notify_all();
	}
	template <class T>
	std::cv_status Wait(int nTimeWait, T& func)
	{
		std::unique_lock<std::mutex> lk(m_cLk);
		if (false == func())
			return __parent::wait_for(lk, std::chrono::duration<int, std::milli>(nTimeWait));
		return std::cv_status::no_timeout;
	}

private:
	std::mutex m_cLk;
};

} // nmsp

#endif
