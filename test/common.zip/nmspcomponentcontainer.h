﻿////////////////////////////////////////////////////////////////////////////////
//
// 작성자 : huelee
// 설  명 : 
//

#pragma once
#ifndef __NMSPCOMPONENTCONTAINER_H__
#define __NMSPCOMPONENTCONTAINER_H__

//
namespace nmsp {

// container정의
class componentcontainer
{
private:
#if defined(_WIN32) || defined(_WIN64)
	typedef HMODULE _handlex_t;
#else
	typedef void* _handlex_t;
#endif
	// 컴포넌트 정보
	struct COMPONENTINF
	{
		COMPONENTINF()
		{
			m_hDl = nullptr;
		}
		virtual ~COMPONENTINF()
		{
			std::cout << "componentinf destructor call. config=" << m_cstrConfig << " ";

			m_cRefComponent = nullptr;
#if defined(_WIN32) || defined(_WIN64)
			if (nullptr != m_hDl)
			{
				::FreeLibrary(m_hDl);
				m_hDl = nullptr;
			}
#else
#endif
			std::cout << "componentinf destructor success."<< std::endl;
		}
		_handlex_t m_hDl;
		std::string m_cstrConfig;
		int m_logLevel;
		bool m_outConsole = false;
		std::string m_timeZoneName;
		smartinterface<IComponent> m_cRefComponent;
	};
	typedef std::map<unsigned short, std::unique_ptr<COMPONENTINF> > _component_map_t;
	// 컨테이너 인터페이스의 구현
	class containersinkimpl: public IComponentContainer
	{
	public:
		containersinkimpl()
		{
			m_nRefs = 0;
		}
		
		~containersinkimpl()
		{
			std::cout << "componentimpl destructor call." << std::endl;

			int nLenServiceTypes = 0;
			unsigned short* puiServiceTypes = nullptr;

			int nRet = m_pcContainer->GetServiceTypes(&nLenServiceTypes, &puiServiceTypes);
			if (nmsp::_NMSP_NOERROR != nRet)
			{
				std::cout << "componentimpl destructor call error. refs=" << m_nRefs << std::endl;
			}
			else
			{
				std::stringstream ss;
				ss << "componentimpl destructor call. servicetype=";
				
				bool bFirst = true;
				for (int nI = 0; nI < nLenServiceTypes; ++nI)
				{
					if (bFirst)
					{						
						bFirst = false;
					}
					else
					{
						ss << ", ";
					}
					ss << puiServiceTypes[nI];					
				}
					
				std::cout << ss.str() << std::endl;
			}
		}

		int QueryInterface(const UUID* iid, void** pInterface)
		{
			if (UUID_IComponentBase == *iid)
			{
				*pInterface = static_cast<IComponentBase*>(this);
				reinterpret_cast<IComponentBase*>(*pInterface)->AddRef();
				return _NMSP_NOERROR;
			}
			else
			if (UUID_IComponentContainer == *iid)
			{
				*pInterface = static_cast<IComponentContainer*>(this);
				reinterpret_cast<IComponentContainer*>(*pInterface)->AddRef();
				return _NMSP_NOERROR;
			}

			return make_nmsp_error(_NMSP_RESERVED_SERVICETYPE_CONTAINER, _CONTAINER_ERROR_NO_INTERFACE);
		}
		int AddRef(void)
		{
			return ++m_nRefs;
		}
		int Release(void)
		{
			return --m_nRefs;
		}
		int QueryComponent(unsigned short uiServiceType, const UUID* uuid, void** ppIOther)
		{
			return m_pcContainer->QueryComponent(uiServiceType, uuid, ppIOther);
		}
		int GetServiceTypes(int* pnLen, unsigned short** ppuiTypes)
		{
			return m_pcContainer->GetServiceTypes(pnLen, ppuiTypes);
		}
		int ResetServiceTypes(unsigned short* puiTypes)
		{
			return m_pcContainer->ResetServiceTypes(puiTypes);
		}
		int GetRefCount()
		{
			return m_nRefs;
		}
		void SetContainer(componentcontainer* pcContainer)
		{
			m_pcContainer = pcContainer;
		}
	private:
		std::atomic_int m_nRefs;
		componentcontainer* m_pcContainer;
	};

public:
	componentcontainer(const std::string& cstrConfig)
	{
		// 컨테이너의 포인터를 설정해준다..
		m_cContainersinkImpl.SetContainer(this);

		//
		boost::property_tree::ptree props;
		boost::property_tree::read_json(cstrConfig, props);

		auto name = props.get<std::string>("instancename");
		auto debuglevel = props.get<int>("debuglevel");
		auto timeZoneName = props.get<std::string>("time zone name");

		// std::cout << "instancename : " << name << ", debug level : " << debuglevel << std::endl;
		
		auto components = props.get_child("components");
		for (const auto& component : components)
		{
			auto use = component.second.get<bool>("use");
			auto servicetype = component.second.get<unsigned short>("servicetype");
			auto executable = component.second.get<std::string>("executable");
			auto config = component.second.get<std::string>("config");

			int loglevel = 1;			// 기본값 : debug
			bool outConsole = false;	// 기본값 : false

			auto logProps = component.second.get_child_optional("log");
			if (logProps)
			{
				loglevel = logProps.get().get<int>("loglevel", 1);
				outConsole = logProps.get().get<bool>("console", false);
			}

			std::cout << "servicetype :" << servicetype 
				<< ", executable :" << executable 
				<< ", config :" << config 
				<< ", loglevel :" << loglevel
				<< ", console :" << outConsole
				<< std::endl;

			// 사용중이 아니라면..
			if (false == use)
				continue;

			//
			auto pairRet = m_cComponentMap.insert(_component_map_t::value_type(servicetype, std::make_unique<COMPONENTINF>()));
			if (false == pairRet.second)
				throw nmsp_error("duplication service type", make_nmsp_error(_NMSP_RESERVED_SERVICETYPE_CONTAINER, _CONTAINER_ERROR_DUP_SERVICETYPE));

			// Load
#if defined(_WIN32) || defined(_WIN64)
			_handlex_t handle = LoadLibrary(executable.c_str());
			if (nullptr == handle)
				throw nmsp_error("component load error", make_nmsp_error(_NMSP_RESERVED_SERVICETYPE_CONTAINER, _CONTAINER_ERROR_LOAD_ERROR));

			// 컴포넌트의 extern된 기본 함수의 형
			typedef int(*_GETCLASSOBJECT_T)(const UUID* uuid, void** ppv);
			_GETCLASSOBJECT_T fp = (_GETCLASSOBJECT_T)::GetProcAddress(handle, "ComGetClassObject");
			if (nullptr == fp)
			{
				::FreeLibrary(handle);
				throw nmsp_error("ComGetClassObject not found", make_nmsp_error(_NMSP_RESERVED_SERVICETYPE_CONTAINER, _CONTAINER_ERROR_EXTERN_FUNCTION_ERRPR));
			}

			// 인터페이스를 얻어온다
			int nRet = (*fp)(&UUID_IComponent, static_cast<void**>(pairRet.first->second->m_cRefComponent));
			if (_NMSP_NOERROR != nRet)
			{
				::FreeLibrary(handle);
				throw nmsp_error("ComGetClassObject error", nRet);
			}

			//
			pairRet.first->second->m_hDl = handle;
			pairRet.first->second->m_cstrConfig = config;
			pairRet.first->second->m_logLevel = loglevel;
			pairRet.first->second->m_outConsole = outConsole;
			pairRet.first->second->m_timeZoneName = timeZoneName;
#else
#endif
		}
	}
	virtual ~componentcontainer()
	{
		std::cout << "componentcontainer destructor call" << std::endl;
	}
	int PreInit()
	{
		for (const auto& component : m_cComponentMap)
		{
			std::cout << "component config load : " << component.second->m_cstrConfig.c_str() << std::endl;

			int nRet = component.second->m_cRefComponent->SetBaseInfo(
															component.first,
															&m_cContainersinkImpl,
															static_cast<int>(component.second->m_cstrConfig.length()), component.second->m_cstrConfig.c_str(),
															component.second->m_logLevel, component.second->m_outConsole,
															component.second->m_timeZoneName.c_str());
			if (_NMSP_NOERROR != nRet)
				return nRet;

			nRet = component.second->m_cRefComponent->PreInit();
			if (_NMSP_NOERROR != nRet)
				return nRet;
		}

		return _NMSP_NOERROR;
	}
	int Init()
	{
		for (const auto& component : m_cComponentMap)
		{
			std::cout << "component init call. config=" << component.second->m_cstrConfig << " ";
			int nRet = component.second->m_cRefComponent->Init();
			if (_NMSP_NOERROR != nRet)
			{
				std::cout << "init fail." << nRet << ", config=" << component.second->m_cstrConfig << std::endl;
				return nRet;
			}			
			std::cout << "component init success." << std::endl;
		}

		return _NMSP_NOERROR;
	}
	void Uninit()
	{
		for (auto itr = m_cComponentMap.crbegin(); itr != m_cComponentMap.crend(); ++itr)
		{
			std::cout << "component uninit call. config=" << itr->second->m_cstrConfig.c_str() << " ";
			itr->second->m_cRefComponent->Uninit();
			std::cout << "component uninit success." << std::endl;
		}			
	}
	void PostUninit()
	{
		for (auto itr = m_cComponentMap.crbegin(); itr != m_cComponentMap.crend(); ++itr)
		{
			std::cout << "component postuninit call. config=" << itr->second->m_cstrConfig.c_str() << " ";
			itr->second->m_cRefComponent->PostUninit();
			std::cout << "component postuninit success." << std::endl;
		}

		m_cComponentMap.clear();

		std::cout << "componentmap clear." << std::endl;
	}
	int QueryComponent(unsigned short uiServiceType, const UUID* uuid, void** ppIOther)
	{
		const auto itr = m_cComponentMap.find(uiServiceType);
		if (itr == m_cComponentMap.end())
			return make_nmsp_error(_NMSP_RESERVED_SERVICETYPE_CONTAINER, _CONTAINER_ERROR_INTERFACE_NOT_FOUND);

		return itr->second->m_cRefComponent->QueryInterface(uuid, ppIOther);
	}
	int GetServiceTypes(int* pnLen, unsigned short** ppuiTypes)
	{
		*pnLen = 0;

		if (true == m_cComponentMap.empty())
		{
			*ppuiTypes = nullptr;
			return nmsp::_NMSP_NOERROR;
		}

		_component_map_t::size_type sCount = m_cComponentMap.size();

		*ppuiTypes = new (std::nothrow) unsigned short[sCount];
		if (nullptr == *ppuiTypes)
			return nmsp::make_nmsp_error(nmsp::_NMSP_RESERVED_SERVICETYPE_CONTAINER, nmsp::_CONTAINER_ERROR_MEMORY);

		for (const auto& itr : m_cComponentMap)
			(*ppuiTypes)[(*pnLen)++] = itr.first;

		return nmsp::_NMSP_NOERROR;
	}
	int ResetServiceTypes(unsigned short* puiTypes)
	{
		delete[] puiTypes;
		return nmsp::_NMSP_NOERROR;
	}
	template <typename T>void Execute(T& _t)
	{
		for (auto itr = m_cComponentMap.crbegin(); itr != m_cComponentMap.crend(); ++itr)
			_t(itr->first, itr->second->m_cstrConfig, itr->second->m_cRefComponent);
	}

private:
	containersinkimpl m_cContainersinkImpl;
	_component_map_t m_cComponentMap;
};

} // nmsp

#endif //
