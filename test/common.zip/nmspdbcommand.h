#pragma once
#ifndef __NMSPDBCOMMAND_H__
#define __NMSPDBCOMMAND_H__

#include <sql.h>
#include <sqlext.h>


// https://www.ibm.com/support/knowledgecenter/ko/ssw_i5_54/cli/rzadpfnbndpm.htm#rzadpfnbndpm
// SQLBindParameter : https://docs.microsoft.com/ko-kr/sql/odbc/reference/syntax/sqlbindparameter-function?view=sql-server-2017
// ValueType : https://docs.microsoft.com/ko-kr/sql/odbc/reference/appendixes/c-data-types?view=sql-server-2017
// ParameterType : https://docs.microsoft.com/ko-kr/sql/odbc/reference/appendixes/sql-data-types?view=sql-server-2017
/*
SQLRETURN SQLBindParameter(
SQLHSTMT          StatementHandle,		// StatementHandle (SQL ���ɹ� �ڵ�)
SQLSMALLINT       ParameterNumber,		// ParameterNumber (�Ű������� ���� (1���� ����))
SQLSMALLINT       InputOutputType,		// InputOutputType (�Ű������� �뵵 (�Է�/���/�����))
SQLSMALLINT       ValueType,			// ValueType (�Ű������� �������� (C Data Type))
SQLSMALLINT       ParameterType,		// ParameterType (�Ű������� �������� (SQL data type ))
SQLINTEGER        ColumnSize,			// ColumnSize (�Ű������� ũ��)
SQLSMALLINT       DecimalDigits,		// DecimalDigits (�Ű������� �ڸ� �� (�������� ���))
SQLPOINTER        ParameterValuePtr,	// ParameterValuePtr (�Ű������� ���ε��� ����)
SQLINTEGER        BufferLength,			// BufferLength (�Ű������� ���ε��� ������ ũ�� (���ڿ�,���������� ũ��))
SQLINTEGER       *StrLen_or_IndPtr		// StrLen_or_IndPtr (�Ű������� ����/���°��� ��ȯ ���� ����)
);


Native Value			SQL Type				C Type
bigint unsigned			SQL_BIGINT				SQL_C_UBIGINT
bigint					SQL_BIGINT				SQL_C_SBIGINT
bit						SQL_BIT					SQL_C_BIT
bit						SQL_CHAR				SQL_C_CHAR
blob					SQL_LONGVARBINARY		SQL_C_BINARY
bool					SQL_CHAR				SQL_C_CHAR
char					SQL_CHAR				SQL_C_CHAR
date					SQL_DATE				SQL_C_DATE
datetime				SQL_TIMESTAMP			SQL_C_TIMESTAMP
decimal					SQL_DECIMAL				SQL_C_CHAR
double precision		SQL_DOUBLE				SQL_C_DOUBLE
double					SQL_FLOAT				SQL_C_DOUBLE
enum					SQL_VARCHAR				SQL_C_CHAR
float					SQL_REAL				SQL_C_FLOAT
int unsigned			SQL_INTEGER				SQL_C_ULONG
int						SQL_INTEGER				SQL_C_SLONG
integer unsigned		SQL_INTEGER				SQL_C_ULONG
integer					SQL_INTEGER				SQL_C_SLONG
long varbinary			SQL_LONGVARBINARY		SQL_C_BINARY
long varchar			SQL_LONGVARCHAR			SQL_C_CHAR
longblob				SQL_LONGVARBINARY		SQL_C_BINARY
longtext				SQL_LONGVARCHAR			SQL_C_CHAR
mediumblob				SQL_LONGVARBINARY		SQL_C_BINARY
mediumint unsigned		SQL_INTEGER				SQL_C_ULONG
mediumint				SQL_INTEGER				SQL_C_SLONG
mediumtext				SQL_LONGVARCHAR			SQL_C_CHAR
numeric					SQL_NUMERIC				SQL_C_CHAR
real					SQL_FLOAT				SQL_C_DOUBLE
set						SQL_VARCHAR				SQL_C_CHAR
smallint unsigned		SQL_SMALLINT			SQL_C_USHORT
smallint				SQL_SMALLINT			SQL_C_SSHORT
text					SQL_LONGVARCHAR			SQL_C_CHAR
time					SQL_TIME				SQL_C_TIME
timestamp				SQL_TIMESTAMP			SQL_C_TIMESTAMP
tinyblob				SQL_LONGVARBINARY		SQL_C_BINARY
tinyint unsigned		SQL_TINYINT				SQL_C_UTINYINT
tinyint					SQL_TINYINT				SQL_C_STINYINT
tinytext				SQL_LONGVARCHAR			SQL_C_CHAR
varchar					SQL_VARCHAR				SQL_C_CHAR
year					SQL_SMALLINT			SQL_C_SHORT

*/

template<class FLATBUFFER, class NOTIFY>
class dbcommand : public nmsp::dbproxy::ICommand
{
protected:
	using int32_t = __int32;
	using uint32_t = unsigned __int32;
	using CHAR = char;
	using UCHAR = unsigned char;
	using WCHAR = wchar_t;
	using BYTE = CHAR;

	using _notify_t = NOTIFY;
	using _flatbuffer_t = FLATBUFFER;

public:
	command_base(nmsp::connector::_serverid_t fromServerId, unsigned short fromServiceType, int32_t flatbuffer_initial_size, _flatbuffer_t * flatbuffer_allocator, _notify_t * notify)
		: m_serverId(fromServerId)
		, m_serviceType(fromServiceType)
		, m_builder(flatbuffer_initial_size, flatbuffer_allocator)
		, m_notify(notify)
		, m_refs(0)
		, m_hStmt(nullptr)
		, m_index(1)
		, m_result(0)
	{
		m_query.empty();
	}
	~command_base() {}

	virtual int AddRef(void)
	{
		return ++m_refs;
	}

	virtual int Release(void)
	{
		int nRefs = --m_refs;
		if (0 == nRefs)
		{
			delete this;
			return 0;
		}

		return nRefs;
	}

	virtual void InitHandle(SQL_H_STMT hStmt)
	{
		m_hStmt = hStmt;
	}

	virtual void Clear()
	{
		m_index = 0;

		// commit or rollback
		SQLEndTran(SQL_HANDLE_STMT, m_hStmt, SQL_COMMIT); // SQL_COMMIT or SQL_ROLLBACK

														  // execute result close. (SQL_CLOSE, SQL_DROP, SQL_UNBIND, SQL_RESET_PARAMS)
		SQLFreeStmt(m_hStmt, SQL_CLOSE);
	}

	bool isNext()
	{
		SQLRETURN retcode = SQLFetch(m_hStmt);
		if (retcode == SQL_SUCCESS || retcode == SQL_SUCCESS_WITH_INFO)
			return true;

		return false;
	}

	const std::string & GetQueryString()
	{
		return m_query;
	}

protected:
	bool AddParam(char value) { return SQLBindParameter(m_hStmt, m_index++, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_CHAR, sizeof(char), 0, &value, 0, nullptr) == SQL_SUCCESS ? true : false; }
	bool AddParam(wchar_t value) { return SQLBindParameter(m_hStmt, m_index++, SQL_PARAM_INPUT, SQL_C_WCHAR, SQL_CHAR, sizeof(wchar_t), 0, &value, 0, nullptr) == SQL_SUCCESS ? true : false; }
	bool AddParam(char * value, __int32 len) { return SQLBindParameter(m_hStmt, m_index++, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, len, 0, &value, 0, nullptr) == SQL_SUCCESS ? true : false; }
	bool AddParam(wchar_t * value, __int32 len) { return SQLBindParameter(m_hStmt, m_index++, SQL_PARAM_INPUT, SQL_C_WCHAR, SQL_VARCHAR, len, 0, &value, 0, nullptr) == SQL_SUCCESS ? true : false; }

	bool AddParam(short value) { return SQLBindParameter(m_hStmt, m_index++, SQL_PARAM_INPUT, SQL_C_SSHORT, SQL_SMALLINT, 0, 0, &value, 0, nullptr) == SQL_SUCCESS ? true : false; }
	bool AddParam(unsigned short value) { return SQLBindParameter(m_hStmt, m_index++, SQL_PARAM_INPUT, SQL_C_USHORT, SQL_SMALLINT, 0, 0, &value, 0, nullptr) == SQL_SUCCESS ? true : false; }

	bool AddParam(__int32 value) { return SQLBindParameter(m_hStmt, m_index++, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &value, 0, nullptr) == SQL_SUCCESS ? true : false; }
	bool AddParam(unsigned __int32 value) { return SQLBindParameter(m_hStmt, m_index++, SQL_PARAM_INPUT, SQL_C_ULONG, SQL_INTEGER, 0, 0, &value, 0, nullptr) == SQL_SUCCESS ? true : false; }

	bool AddParam(__int64 value) { return SQLBindParameter(m_hStmt, m_index++, SQL_PARAM_INPUT, SQL_C_SBIGINT, SQL_BIGINT, 0, 0, &value, 0, nullptr) == SQL_SUCCESS ? true : false; }
	bool AddParam(unsigned __int64 value) { return SQLBindParameter(m_hStmt, m_index++, SQL_PARAM_INPUT, SQL_C_UBIGINT, SQL_BIGINT, 0, 0, &value, 0, nullptr) == SQL_SUCCESS ? true : false; }

	bool AddParam(long value) { return SQLBindParameter(m_hStmt, m_index++, SQL_PARAM_INPUT, SQL_C_ULONG, SQL_INTEGER, 0, 0, &value, 0, nullptr) == SQL_SUCCESS ? true : false; }
	bool AddParam(unsigned long value) { return SQLBindParameter(m_hStmt, m_index++, SQL_PARAM_INPUT, SQL_C_ULONG, SQL_INTEGER, 0, 0, &value, 0, nullptr) == SQL_SUCCESS ? true : false; }

	bool AddParam(double value) { return SQLBindParameter(m_hStmt, m_index++, SQL_PARAM_INPUT, SQL_C_DOUBLE, SQL_DOUBLE, 0, 0, &value, 0, nullptr) == SQL_SUCCESS ? true : false; }
	bool AddParam(float value) { return SQLBindParameter(m_hStmt, m_index++, SQL_PARAM_INPUT, SQL_C_FLOAT, SQL_REAL, 0, 0, &value, 0, nullptr) == SQL_SUCCESS ? true : false; }

	bool AddParam(std::string & value) { return SQLBindParameter(m_hStmt, m_index++, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, sizeof(char) * value.length(), 0, const_cast<char *>(value.c_str()), 0, nullptr) == SQL_SUCCESS ? true : false; }
	bool AddParam(std::wstring & value) { return SQLBindParameter(m_hStmt, m_index++, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, sizeof(wchar_t) * value.length(), 0, const_cast<wchar_t *>(value.c_str()), 0, nullptr) == SQL_SUCCESS ? true : false; }

	bool AddParam(void * value, __int32 len) { return SQLBindParameter(m_hStmt, m_index++, SQL_PARAM_INPUT, SQL_C_BINARY, SQL_LONGVARBINARY, len, 0, value, 0, nullptr) == SQL_SUCCESS ? true : false; }

protected:
	int m_refs;

	SQL_H_STMT m_hStmt;
	int m_index;
	std::string m_query;
	int m_result;

	nmsp::connector::_serverid_t m_serverId;
	unsigned short m_serviceType;
	flatbuffers::FlatBufferBuilder m_builder;
	_notify_t * m_notify;

};

#endif