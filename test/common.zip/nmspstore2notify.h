﻿////////////////////////////////////////////////////////////////////////////////
//
// 작성자: huelee
// 설  명:
//

#pragma once
#ifndef __STORE2NOTIFY_H__
#define __STORE2NOTIFY_H__

namespace nmsp {

template <class ALLOC>
class store2notify
{
	using _allocator_t = ALLOC;
	using _serverid_t = nmsp::connector::_serverid_t;
	using _key_t = std::tuple<_serverid_t, unsigned short, int>;
	class _hash_t
	{
	public:
		_hash_t() = default;
		virtual ~_hash_t() = default;
		inline std::size_t operator ()(const _key_t& key) const
		{
			return std::get<0>(key);
		}
	};

public:
	using _value_t = nmsp::smartinterface<nmsp::connector::IConnectorMessage>;
	class _servermap_t : public nmsp::new_from_pool<_allocator_t>, public std::unordered_map<_key_t, _value_t, _hash_t, std::equal_to<_key_t>, nmsp::stl_default_allocator<std::pair<const _key_t, _value_t>, _allocator_t>>
	{
	public:
		_servermap_t()
		{
			m_refs = 0;
		}
		int AddRef()
		{
			return ++m_refs;
		}
		int Release()
		{
			int refs = --m_refs;
			if (0 == refs)
			{
				delete this;
				return 0;
			}
			return refs;
		}
	private:
		std::atomic_int m_refs;
	};

public:
	store2notify()
	{
		m_toServers = nullptr;
		m_connector = nullptr;
		m_fromServiceType = 0;
	}
	store2notify(nmsp::connector::IConnector* connector, const unsigned short& serviceType)
		: m_connector(connector)
		, m_fromServiceType(serviceType) { }
	virtual ~store2notify() = default;

	void Init(nmsp::connector::IConnector* connector, const unsigned short& fromServiceType){
		m_connector = connector;
		m_fromServiceType = fromServiceType;
	}

	bool Store(nmsp::connector::_serverid_t toId, unsigned short toServiceType, int option, int len, const char* data)
	{
		return Store(toId, toServiceType, option, len, reinterpret_cast<const unsigned char*>(data));
	}

	bool Store(nmsp::connector::_serverid_t toId, unsigned short toServiceType, int option, int len, const unsigned char* data)
	{
		if (nullptr == m_toServers)
		{
			m_toServers = new (std::nothrow) _servermap_t;
			if (nullptr == m_toServers)
				return false;
		}

		auto key = std::make_tuple(toId, toServiceType, option);

		std::lock_guard<std::mutex> lock(m_lock);

		auto itrfind = m_toServers->find(key);
		if (itrfind == m_toServers->end())
		{
			_value_t val;
			if (nmsp::_NMSP_NOERROR != m_connector->GetConnectorMessage(val))
				return false;

			auto pair = m_toServers->emplace(key, std::move(val));
			if (false == pair.second)
				return false;

			itrfind = pair.first;
		}
		else
		{
			if (nullptr == itrfind->second)
			{
				_value_t val;
				if (nmsp::_NMSP_NOERROR != m_connector->GetConnectorMessage(val))
					return false;

				itrfind->second = val;
			}
		}

		if (nmsp::_NMSP_NOERROR != itrfind->second->Put(len, data))
			return false;

		return true;
	}
	bool Notify()
	{
		if (nullptr == m_toServers)
			return true;

		bool ret = true;

		std::lock_guard<std::mutex> lock(m_lock);

		for (auto itr = m_toServers->begin(); itr != m_toServers->end();)
		{
			if (nmsp::_NMSP_NOERROR != m_connector->NotifyMessage(std::get<0>(itr->first), std::get<1>(itr->first), m_fromServiceType, std::get<2>(itr->first), itr->second))
				ret = false;

			itr->second = nullptr;
			if (m_toServers->size() > 0)
				itr = m_toServers->erase(itr);
			else
			{
				std::cout << "==================================================================================================================================" << std::endl;
				std::cout << "========================================== store2notify=m_toServers is zero ======================================================" << std::endl;
				std::cout << "==================================================================================================================================" << std::endl;
				break;
			}
		}

		return ret;
	}
	bool Merge(_servermap_t* toServers)
	{	
		if (nullptr == m_toServers)
		{
			m_toServers = new (std::nothrow) _servermap_t;
			if (nullptr == m_toServers)
				return false;
		}

		std::lock_guard<std::mutex> lock(m_lock);

		for (auto itr = toServers->begin(); itr != toServers->end(); )
		{
			auto itrFind = m_toServers->find(itr->first);
			if (itrFind != m_toServers->end())
			{
				itrFind->second->Merge(itr->second);
			}
			else
			{
				m_toServers->emplace(itr->first, itr->second);
			}

			itr = toServers->erase(itr);
		}

		return true;
	}
	template <typename F> inline void Notify(F& f)
	{
		std::lock_guard<std::mutex> lock(m_lock);

		if (nullptr != m_toServers)
		{
			f(m_toServers);
			m_toServers = nullptr;
		}
	}
	inline void SetConnectorInterface(nmsp::connector::IConnector* connector)
	{
		m_connector = connector;
	}
	inline void SetFromServiceType(const unsigned short& serviceType)
	{
		m_fromServiceType = serviceType;
	}
	inline void ResetConnectorInterface()
	{
		m_toServers = nullptr;
		m_connector = nullptr;
		m_fromServiceType = 0;
	}
	inline bool IsConnector() { return m_connector == nullptr ? false : true; }

private:
	nmsp::smartinterface<_servermap_t> m_toServers;
	nmsp::smartinterface<nmsp::connector::IConnector> m_connector;
	unsigned short m_fromServiceType;

	std::mutex m_lock;
};

} // end of namespace nmsp
#endif
