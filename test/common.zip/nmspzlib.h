////////////////////////////////////////////////////////////////////////////////
//
// �ۼ��� : 
// ��  �� : 
//

#pragma once
#ifndef __NMZIP_H__
#define __NMZIP_H__

#include <boost/iostreams/filtering_stream.hpp>
#include <boost/iostreams/filter/zlib.hpp>
#include <boost/iostreams/filter/counter.hpp>
#include <boost/iostreams/stream.hpp>
#include <boost/iostreams/device/array.hpp>

namespace nmsp {
class zlib
{
public:
	template <class Container>
	static void Compress(const uint8_t* src, int32_t srcLen, Container& dest)
	{
		if (src == nullptr)
			return;

		if (srcLen <= 0)
			return;

		// �⺻ ũ��� ���� ������ ũ�⸦ ��������.
		dest.reserve(srcLen);

		boost::iostreams::filtering_ostream os;
		os.push(boost::iostreams::zlib_compressor());
		os.push(std::back_inserter(dest));

		boost::iostreams::write(os, (const char*)src, srcLen);
		boost::iostreams::close(os);
	}

	static int32_t Compress(const uint8_t* src, int32_t srcLen, uint8_t* dest, int32_t destLen)
	{
		boost::iostreams::array_sink sink{ (char*)dest, static_cast<size_t>(destLen) };

		boost::iostreams::filtering_ostream os;
		os.push(boost::iostreams::zlib_compressor());
		os.push(boost::iostreams::counter{});
		os.push(sink);

		boost::iostreams::write(os, (const char*)src, srcLen);
		boost::iostreams::close(os);

		return os.component<boost::iostreams::counter>(1)->characters();
	}

	template <class Alloc>
	static void Decompress(const uint8_t* src, int32_t srcLen, std::vector<uint8_t, Alloc>& dest)
	{
		if (src == nullptr)
			return;

		if (srcLen <= 0)
			return;

		// ũ�⸦ �˼� ������ srcLen �� �ι��� ũ�⸦ �Ҵ�
		dest.reserve(srcLen * 2);

		boost::iostreams::filtering_ostream os;
		os.push(boost::iostreams::zlib_decompressor());
		os.push(std::back_inserter(dest));

		boost::iostreams::write(os, (const char*)src, srcLen);
		boost::iostreams::close(os);
	}
};
}

#endif
