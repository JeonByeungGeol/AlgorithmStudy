////////////////////////////////////////////////////////////////////////////////
//
// �ۼ��� : huelee
// ��  �� : 
//

// ȣȯ���� ���ؼ�..
#pragma once
#ifndef __NMSPPOLYGON_H__
#define __NMSPPOLYGON_H__

//
namespace nmsp {

class polygon
{
public:
	template <typename V>
	static bool IsPointInPoly2D(const V& verts, const nmsp::Vector3& point)
	{
		if (verts.empty())
			return false;

		auto minX = verts[0][0];
		auto maxX = verts[0][0];
		auto minY = verts[0][2];
		auto maxY = verts[0][2];

		int nvert = static_cast<int>(verts.size());

		for (int i = 1; i < nvert; i++)
		{
			const auto& q = verts[i];

			minX = std::min(q[0], minX);
			maxX = std::max(q[0], maxX);
			minY = std::min(q[2], minY);
			maxY = std::max(q[2], maxY);
		}

		if (point[0] < minX || point[0] > maxX || point[2] < minY || point[2] > maxY)
			return false;

		//
		bool in = false;

		for (int i = 0, j = nvert - 1; i < nvert; j = i++)
		{
			const auto& q1 = verts[i];
			const auto& q2 = verts[j];

			if (((q1[2] > point[2]) != (q2[2] > point[2])) && (point[0] < (q2[0] - q1[0]) * (point[2] - q1[2]) / (q2[2] - q1[2]) + q1[0]))
				in = !in;
		}

		return in;
	}
	template <typename V, std::size_t SIZE>
	static bool IsPointInPoly2D(const V (&verts)[SIZE], const nmsp::Vector3& point)
	{
		auto minX = verts[0][0];
		auto maxX = verts[0][0];
		auto minY = verts[0][2];
		auto maxY = verts[0][2];

		int nvert = SIZE;

		for (int i = 1; i < nvert; i++)
		{
			const auto& q = verts[i];

			minX = std::min(q[0], minX);
			maxX = std::max(q[0], maxX);
			minY = std::min(q[2], minY);
			maxY = std::max(q[2], maxY);
		}

		if (point[0] < minX || point[0] > maxX || point[2] < minY || point[2] > maxY)
			return false;

		//
		bool in = false;

		for (int i = 0, j = nvert - 1; i < nvert; j = i++)
		{
			const auto& q1 = verts[i];
			const auto& q2 = verts[j];

			if (((q1[2] > point[2]) != (q2[2] > point[2])) && (point[0] < (q2[0] - q1[0]) * (point[2] - q1[2]) / (q2[2] - q1[2]) + q1[0]))
				in = !in;
		}

		return in;
	}
	static bool RayLineIntersect2D(const nmsp::Vector3& ro, const nmsp::Vector3& rd, const nmsp::Vector3& l1, const nmsp::Vector3& l2, float& t, float& s)
	{
		nmsp::Vector3 seg = l2 - l1;
		nmsp::Vector3 segPerp(seg[2], 0.f, -seg[0]);

		float perpDotd = nmsp::Vector3Functor::DotProduct2D(rd.Data(), segPerp.Data());

		if (std::abs(perpDotd) <= std::numeric_limits<float>::epsilon())
		{
			t = std::numeric_limits<float>::max();
			return false;
		}

		nmsp::Vector3 d = l1 - ro;
		nmsp::Vector3 rdPerp(rd[2], 0.f, -rd[0]);

		t = nmsp::Vector3Functor::DotProduct2D(segPerp.Data(), d.Data()) / perpDotd;
		s = nmsp::Vector3Functor::DotProduct2D(rdPerp.Data(), d.Data()) / perpDotd;

		return t >= 0.0f && s >= 0.0f && s <= 1.0f;
	}

	// ro		- in	: ray�� ����
	// rd		- in	: ray�� ���� (normalized�ʿ�)
	// polygon	- in	: polygon point�� ��� �ִ� container. ������ point�� ù point�� ���� ���� �ʿ�� ����
	// length	- out	: ray�� �������� ���������� �Ÿ�
	// point	- out	: ����
	// normal	- out	: ������ 2���� ���� ����
	template <typename V>
	static bool RayPolygonIntersect2D(const nmsp::Vector3& ro, const nmsp::Vector3& rd, const V& polygon, float* length, nmsp::Vector3* point, nmsp::Vector3* normal)
	{
		float t = std::numeric_limits<float>::max();
		float s = std::numeric_limits<float>::max();

		if (nullptr != point)
			*point = ro;

		if (nullptr != normal)
			*normal = rd;

		// Comparison variables.
		float distance;				// ray������ �Ÿ�
		float distance2;			// ��� ���� ���׸�Ʈ������ �Ÿ�
		int crossings = 0;
		int nPolygon = static_cast<int>(polygon.size());

		for (int j = nPolygon - 1, i = 0; i < nPolygon; j = i, i++)
		{
			if (RayLineIntersect2D(ro, rd, polygon[j], polygon[i], distance, distance2))
			{
				++crossings;

				if (distance < t)
				{
					t = distance;

					if (nullptr != point)
					{
						*point = ro + (rd * t);
						(*point)[1] = polygon[j][1] + (polygon[i][1] - polygon[j][1]) * distance2;
					}

					if (nullptr != normal)
					{
						nmsp::Vector3 edge = polygon[j] - polygon[i];
						nmsp::Vector3 edgePerp(-edge[2], 0.f, edge[0]);
						*normal = edgePerp.Normalized2D();
					}
				}
			}
		}

		if (nullptr != length)
			*length = t;

		//return crossings > 0 && (crossings % 2) == 0;
		return crossings > 0;
	}
	// ro		- in	: ray�� ����
	// rd		- in	: ray�� ���� (normalized�ʿ�)
	// polygon	- in	: polygon point�� ��� �ִ� container. ������ point�� ù point�� ���� ���� �ʿ�� ����
	// length	- out	: ray�� �������� ���������� �Ÿ�
	// point	- out	: ����
	// normal	- out	: ������ 2���� ���� ����
	template <typename V, std::size_t SIZE>
	static bool RayPolygonIntersect2D(const nmsp::Vector3& ro, const nmsp::Vector3& rd, const V (&polygon)[SIZE], float* length, nmsp::Vector3* point, nmsp::Vector3* normal)
	{
		float t = std::numeric_limits<float>::max();
		float s = std::numeric_limits<float>::max();

		if (nullptr != point)
			*point = ro;

		if (nullptr != normal)
			*normal = rd;

		// Comparison variables.
		float distance;				// ray������ �Ÿ�
		float distance2;			// ��� ���� ���׸�Ʈ������ �Ÿ�
		int crossings = 0;
		int nPolygon = SIZE;

		for (int j = nPolygon - 1, i = 0; i < nPolygon; j = i, i++)
		{
			if (RayLineIntersect2D(ro, rd, polygon[j], polygon[i], distance, distance2))
			{
				++crossings;

				if (distance < t)
				{
					t = distance;

					if (nullptr != point)
					{
						*point = ro + (rd * t);
						(*point)[1] = polygon[j][1] + (polygon[i][1] - polygon[j][1]) * distance2;
					}

					if (nullptr != normal)
					{
						nmsp::Vector3 edge = polygon[j] - polygon[i];
						nmsp::Vector3 edgePerp(-edge[2], 0.f, edge[0]);
						*normal = edgePerp.Normalized2D();
					}
				}
			}
		}

		if (nullptr != length)
			*length = t;

		//return crossings > 0 && (crossings % 2) == 0;
		return crossings > 0;
	}
	//l1 = A, the origin of the line segement
	//l2 = B, simply the line from A to B
	//normal = normal of the plane
	//point = a point on the plane
	//contact = the contact point on the plane, this is what i want calculated
	static bool LinePlaneIntersection3D(const float* l1, const float* l2, const float* normal, const float* point, float* contact)
	{
		float ray[3];
		nmsp::Vector3Functor::Sub(ray, l2, l1);

		// get d value
		float d = nmsp::Vector3Functor::DotProduct(normal, point);
		float r = nmsp::Vector3Functor::DotProduct(normal, ray);

		if (std::abs(r) <= std::numeric_limits<float>::epsilon())
			return false; // No intersection, the line is parallel to the plane

						  // Compute the X value for the directed line ray intersecting the plane
		float t = (d - nmsp::Vector3Functor::DotProduct(normal, l1)) / r;

		// scale the ray by t
		nmsp::Vector3 newRay = ray;
		newRay *= t;

		// calc contact point
		contact[0] = l1[0] + newRay[0];
		contact[1] = l1[1] + newRay[1];
		contact[2] = l1[2] + newRay[2];

		if (0.0f <= t && 1.0f >= t)
			return true; // line intersects plane

		return false;
	}
	static bool LinePlaneIntersection2D(const float* l1, const float* l2, const float* normal, const float* point, float* contact)
	{
		float ray[3];
		nmsp::Vector3Functor::Sub2D(ray, l2, l1);

		// get d value
		float d = nmsp::Vector3Functor::DotProduct2D(normal, point);
		float r = nmsp::Vector3Functor::DotProduct2D(normal, ray);

		if (std::abs(r) <= std::numeric_limits<float>::epsilon())
			return false; // No intersection, the line is parallel to the plane

						  // Compute the X value for the directed line ray intersecting the plane
		float t = (d - nmsp::Vector3Functor::DotProduct2D(normal, l1)) / r;

		// scale the ray by t
		nmsp::Vector3 newRay = ray;
		newRay *= t;

		// calc contact point
		contact[0] = l1[0] + newRay[0];
		contact[1] = 0.f;
		contact[2] = l1[2] + newRay[2];

		if (0.0f <= t && 1.0f >= t)
			return true; // line intersects plane

		return false;
	}
};

}

#endif 