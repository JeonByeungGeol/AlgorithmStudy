////////////////////////////////////////////////////////////////////////////////
//
// �ۼ���: huelee
// ��  ��:
//
//
// ����
/* 

#include "nmsptyper.h"
#include "nmsptypermacro.h"

// ����
TYPEDEF_TYPER_8(_XXXXX_T,
	OSTYPE1, int8_t,
	OSTYPE2, int16_t,
	OSTYPE3, int32_t,
	OSTYPE4, int64_t
)

// ����
TYPEDEF_TYPER_6(_XXXXX_EXT_T,
	VERSION2, int,
	OSTYPE_EXT, _XXXXX_T,
	VERSION3, int
)

class get_data_caster: public std::stringbuf
{
	using __super_t = std::stringbuf;
	template <typename T, typename D, bool CON> struct _call_t
	{
		static inline void call(T& t, D& d)
		{
			t.m_t.Traverse(d);
		}
	};
	template <typename T, typename D> struct _call_t<T,D,false>
	{
		static inline void call(T& t, D& d)
		{
		}
	};
public:
	template <typename X> inline void operator ()(X& x)
	{
		short loc = static_cast<short>(X::INDEX);
		__super_t::sputn(reinterpret_cast<char*>(&loc), sizeof(loc));
		if (true == std::is_base_of<nmsp::type_container_base, X::_T>::value)
		{
			_call_t<X, get_data_caster, std::is_base_of<nmsp::type_container_base, X::_T>::value>::call(x, *this);
			return;
		}

		__super_t::sputn(reinterpret_cast<char*>(&x.m_t), sizeof(x.m_t));
	}
};

class set_data_caster : public std::stringbuf
{
	using __super_t = std::stringbuf;
	template <typename T, typename D, bool CON> struct _call_t
	{
		static inline void call(T& t, D& d)
		{
			t.m_t.Traverse(d);
		}
	};
	template <typename T, typename D> struct _call_t<T, D, false>
	{
		static inline void call(T& t, D& d)
		{
		}
	};
public:
	set_data_caster()
	{
		m_readId = false;
		m_loc = -1;
	}
	template <typename X> inline void operator ()(X& x)
	{
		if (false == m_readId)
		{
			__super_t::sgetn(reinterpret_cast<char*>(&m_loc), sizeof(m_loc));
			m_readId = true;
		}

		if (m_loc != X::INDEX)
			return;

		m_readId = false;

		if (true == std::is_base_of<nmsp::type_container_base, X::_T>::value)
		{
			_call_t<X, set_data_caster, std::is_base_of<nmsp::type_container_base, X::_T>::value>::call(x, *this);
			return;
		}

		__super_t::sgetn(reinterpret_cast<char*>(&x.m_t), sizeof(x.m_t));
	}

private:
	bool m_readId;
	short m_loc;
};

void main(int argc, char* argv[])
{
	get_data_caster dx;
	_XXXXX_EXT_T x;

	x.set_VERSION2(5);
	x.set_VERSION3(10);
	x.OSTYPE_EXT.OSTYPE1 = 1;
	x.OSTYPE_EXT.OSTYPE2 = 2;
	x.OSTYPE_EXT.OSTYPE3 = 3;
	x.OSTYPE_EXT.OSTYPE4 = 4;

	x.OSTYPE_EXT.set_OSTYPE1(20);

	x.Traverse(dx);

	//
	set_data_caster dr;
	dr.str(dx.str());

	_XXXXX_EXT_T y;
	y.Traverse(dr);
}

*/

// ȣȯ���� ���ؼ�..
#pragma once
#ifndef __NMSPTYPER_H__
#define __NMSPTYPER_H__

#ifndef __NMSPUTIL_H__
#error nmsptyper require include "nmsputil.h"
#endif

//
namespace nmsp {

// �⺻ �ڷ� Ÿ���� ã�´�
template <typename X>
struct find_type_of
{
	using type = typename std::remove_pointer<typename std::remove_reference<typename std::remove_cv<typename std::remove_all_extents<X>::type>::type>::type>::type;
};

//
template <std::size_t V>
struct value2type
{
	enum 
	{ 
		VALUE = V, 
	};
};

//
template <typename ...Arguments>
class type_container
{
	static_assert(0 != sizeof ...(Arguments), "type_container need to have argument more than 0!.");
};

template<typename... Types>
struct is_type_container
{
	enum { value = false, };
};

template<typename... Types>
struct is_type_container<type_container<Types...>>
{
	enum { value = true, };
};

struct type_container_end_args
{
};

struct type_container_base
{
};

template <typename T>
class type_container<T>: public type_container_base
{
	static_assert(!std::is_pointer<T>::value, "type_container can't have pointer types!.");
	using __this_t = type_container<T>;

public:
	using _T = T;
	enum
	{
		INDEX = 0,
		SIZE = sizeof(T),
	};
protected:
	template <typename T, bool TYPER> struct _assign_t
	{
		static inline void assign(T& d, const T& s)
		{
			d = s;
		}
	};
	template <typename T> struct _assign_t<T, true>
	{
		static inline void assign(T& d, const T& s)
		{
			d.Assign(s);
		}
	};
	template <typename T, std::size_t SIZE> struct _assign_t<T[SIZE], false>
	{
		static inline void assign(T(&d)[SIZE], const T(&s)[SIZE])
		{
			for (std::size_t l = 0; l < SIZE; ++l)
				d[l] = s[l];
		}
	};
	template <typename T, std::size_t SIZE> struct _assign_t<T[SIZE], true>
	{
		static inline void assign(T(&d)[SIZE], const T(&s)[SIZE])
		{
			for (std::size_t l = 0; l < SIZE; ++l)
				d[l].Assign(s[l]);
		}
	};
public:
	type_container()
		: m_t{}
		, m_f(false)
	{
	}
	template <typename TAG, typename FIRST_ARG, std::enable_if_t<std::is_same<TAG, type_container_end_args>::value, int> = 0> type_container(TAG, FIRST_ARG&& firstArg)
		: m_t(std::forward<FIRST_ARG>(firstArg))
		, m_f(false)
	{
	}
	type_container(const __this_t& other)
	{
		_assign_t<_T, std::is_base_of<type_container_base, _T>::value>::assign(m_t, other.m_t);
		m_f = other.m_f;
	}
	inline void operator = (const __this_t& other)
	{
		_assign_t<_T, std::is_base_of<type_container_base, _T>::value>::assign(m_t, other.m_t);
		m_f = other.m_f;
	}
	inline void Assign(const __this_t& other)
	{
		_assign_t<_T, std::is_base_of<type_container_base, _T>::value>::assign(m_t, other.m_t);
		m_f = other.m_f;
	}
	inline void AssignMod(const __this_t& other)
	{
		if (other.m_f)
			_assign_t<_T, std::is_base_of<type_container_base, _T>::value>::assign(m_t, other.m_t);
		m_f = other.m_f;
	}
	template <typename F> inline void Traverse(F& _f)
	{
		_f(*this);
	}
	template <typename F> inline void Traverse(F& _f, int& count)
	{
		_f(*this, count);
	}
	_T m_t;
	bool m_f;
};

template <typename T, typename ...Arguments>
class type_container<T, Arguments...> : public type_container<Arguments...>
{
	using __super_t = type_container<Arguments...>;
	using __this_t = type_container<T, Arguments...>;
public:
	using _T = T;
	enum
	{
		INDEX = __super_t::INDEX + 1,
		SIZE = sizeof(_T) + __super_t::SIZE,
	};
public:
	type_container()
		: m_t{}
		, m_f(false)
	{
	}
	template <typename TAG, typename FIRST_ARG, typename ...ARGS, std::enable_if_t<std::is_same<TAG, type_container_end_args>::value, int> = 0> type_container(TAG, FIRST_ARG&& firstArg, ARGS&&... args)
		: __super_t(type_container_end_args{}, std::forward<ARGS>(args)...)
		, m_t(std::forward<FIRST_ARG>(firstArg))
		, m_f(false)
	{
	}
	template <typename FIRST, typename ...ARGS, std::enable_if_t<std::is_same<FIRST, __this_t>::value, int> = 0> type_container(FIRST&& first, ARGS&&... args)
		: __super_t(type_container_end_args{}, std::forward<ARGS>(args)...)
		, m_t(std::forward<FIRST>(first))
		, m_f(false)
	{
	}
	type_container(const __this_t& other)
		: __super_t(other)
	{
		_assign_t<_T, std::is_base_of<type_container_base, _T>::value>::assign(m_t, other.m_t);
		m_f = other.m_f;
	}
	inline void operator = (const __this_t& other)
	{
		__super_t::Assign(other);
		_assign_t<_T, std::is_base_of<type_container_base, _T>::value>::assign(m_t, other.m_t);
		m_f = other.m_f;
	}
	inline void Assign(const __this_t& other)
	{
		__super_t::Assign(other);
		_assign_t<_T, std::is_base_of<type_container_base, _T>::value>::assign(m_t, other.m_t);
		m_f = other.m_f;
	}
	inline void AssignMod(const __this_t& other)
	{
		__super_t::AssignMod(other);
		if (other.m_f)
			_assign_t<_T, std::is_base_of<type_container_base, _T>::value>::assign(m_t, other.m_t);
		m_f = other.m_f;
	}
	template <typename F> inline void Traverse(F& _f)
	{
		_f(*this);
		__super_t::Traverse(_f);
	}
	template <typename F> inline void Traverse(F& _f, int& count)
	{
		_f(*this, count);
		__super_t::Traverse(_f, count);
	}

public:
	_T m_t;
	bool m_f;
};

template <int INDEX, typename Arguments>
class type_container_indexer;

template <int INDEX>
class type_container_indexer<INDEX, type_container<>>
{
	static_assert(std::_Always_false<std::integral_constant<int, INDEX>>::value, "type_container index out of bounds");
};

template <typename T, typename ...Arguments>
class type_container_indexer<0, type_container<T, Arguments...>>
{
public:
	using _This = T;
	using _Target = type_container<T, Arguments...>;
};

template <int INDEX, typename T, typename ...Arguments>
class type_container_indexer<INDEX, type_container<T, Arguments...>> : public type_container_indexer<INDEX - 1, type_container<Arguments...>>
{
};

//
template <int INDEX, typename ...Types>
auto& GET(type_container<Types...>& a)
{
	using _Target = typename type_container_indexer<INDEX, type_container<Types...> >::_Target;
	return static_cast<_Target&>(a).m_t;
}

template <int INDEX, typename ...Types>
const auto& GET(const type_container<Types...>& a) 
{
	using _Target = typename type_container_indexer<INDEX, type_container<Types...> >::_Target;
	return static_cast<_Target&>(a).m_t;
}

template <int INDEX, typename ...Types>
auto& GET_OBJECT(type_container<Types...>& a)
{
	using _Target = typename type_container_indexer<INDEX, type_container<Types...> >::_Target;
	return static_cast<_Target&>(a);
}

template <int INDEX, typename ...Types>
const auto& GET_OBJECT(const type_container<Types...>& a) 
{
	using _Target = typename type_container_indexer<INDEX, type_container<Types...> >::_Target;
	return static_cast<_Target&>(a);
}

namespace type_container_multi_caller
{
	template <bool>
	struct X;
	template <> struct X<true>
	{
		template <int FIRSTINDEX, int ...INDEX, typename ...Types>
		static inline auto& call(type_container<Types...>& a)
		{
			using _Target = typename type_container_indexer<FIRSTINDEX, type_container<Types...> >::_Target;
			return GETX<INDEX...>(static_cast<_Target&>(a).m_t);
		}
	};
	template <> struct X<false>
	{
		template <int I, typename ...Types>
		static inline auto& call(type_container<Types...>& a)
		{
			using _Target = typename type_container_indexer<I, type_container<Types...> >::_Target;
			static_assert(!std::is_base_of<type_container_base, _Target::_T>::value, "index_container is invalid column!");
			return static_cast<_Target&>(a).m_t;
		}
	};
	template <bool>
	struct Y;
	template <> struct Y<true>
	{
		template <typename FIRSTINDEX, typename ...INDEX, typename ...Types>
		static inline auto& call(type_container<Types...>& a)
		{
			using _Target = typename type_container_indexer<FIRSTINDEX::VALUE, type_container<Types...> >::_Target;
			return GETX<INDEX...>(static_cast<_Target&>(a).m_t);
		}
	};
	template <> struct Y<false>
	{
		template <typename FIRSTINDEX, typename ...Types>
		static inline auto& call(type_container<Types...>& a)
		{
			using _Target = typename type_container_indexer<FIRSTINDEX::VALUE, type_container<Types...> >::_Target;
			static_assert(!std::is_base_of<type_container_base, _Target::_T>::value, "index_container is invalid column!");
			return static_cast<_Target&>(a).m_t;
		}
	};
}

template <int ...INDEX, typename ...Types>
auto& GETX(type_container<Types...>& a)
{
	return type_container_multi_caller::X<(sizeof...(INDEX) > 1)>::call<INDEX...>(a);
}

template <int ...INDEX, typename ...Types>
const auto& GETX(const type_container<Types...>& a) 
{
	return type_container_multi_caller::X<(sizeof...(INDEX) > 1)>::call<INDEX...>(a);
}

template <typename ...INDEX, typename ...Types>
auto& GETX(type_container<Types...>& a)
{
	return type_container_multi_caller::Y<(sizeof...(INDEX) > 1)>::call<INDEX...>(a);
}

template <typename ...INDEX, typename ...Types>
const auto& GETX(const type_container<Types...>& a)
{
	return type_container_multi_caller::Y<(sizeof...(INDEX) > 1)>::call<INDEX...>(a);
}

template <typename ...Values>
class index_container
{
	static_assert(0 != sizeof ...(Values), "index_container need to have argument more than 0!.");
};

struct index_container_base
{
};

template <std::size_t LAST>
class index_container<value2type<LAST>> : public index_container_base
{
public:
	enum
	{
		VALUE = LAST,
		MAXVALUE = LAST,
	};
	template <typename T, typename F> inline void Traverse(T& t, F& f)
	{
		f(GETX<value2type<LAST>>(t));
	}
};

template <typename ...LAST>
class index_container<index_container<LAST...>> : public index_container_base
{
public:
	enum
	{
		VALUE = index_container<LAST...>::MAXVALUE,
		MAXVALUE = (VALUE > index_container<LAST...>::VALUE) ? VALUE : index_container<LAST...>::VALUE,
	};
	template <typename T, typename F> inline void Traverse(T& t, F& f)
	{
		f(GETX<LAST...>(t));
	}
};

template <typename FIRST, typename ...Values>
class index_container<FIRST, Values...> : public index_container<Values...>
{
	using __super_t = index_container<Values...>;
	template <typename X, bool> struct value_of;
	template <typename X> struct value_of<X, false>
	{
		enum { VALUE = X::VALUE, };
	};
	template <typename X> struct value_of<X, true>
	{
		enum { VALUE = index_container<X>::MAXVALUE, };
	};
	template <typename P, typename T, typename F> struct _call_t;
	template <std::size_t P, typename T, typename F> struct _call_t<value2type<P>, T, F>
	{
		static inline void call(T& _t, F&_f)
		{
			_f(GETX<P>(_t));
		}
	};
	template <typename P, typename T, typename F> struct _call_t<index_container<P>, T, F>
	{
		static inline void call(T& _t, F& _f)
		{
			_f(GETX<P>(_t));
		}
	};

public:
	enum
	{
		VALUE = value_of<FIRST, std::is_base_of<index_container_base, FIRST>::value>::VALUE,
		MAXVALUE = (VALUE > index_container<Values...>::MAXVALUE) ? VALUE : index_container<Values...>::MAXVALUE,
	};
	template <typename T, typename F> inline void Traverse(T& t, F& f)
	{
		static_assert(std::is_base_of<type_container_base, T>::value, "invalid type_container !");
		_call_t<FIRST, T, F>::call(t, f);
		__super_t::Traverse<T,F>(t, f);
	}
};

//
template <int INDEX, typename Arguments>
class index_container_indexer;

template <int INDEX>
class index_container_indexer<INDEX, index_container<>>
{
	static_assert(std::_Always_false<std::integral_constant<int, INDEX>>::value, "index_container index out of bounds");
};

template <typename T, typename ...Arguments>
class index_container_indexer<0, index_container<T, Arguments...>>
{
public:
	using _Target = T;
};

template <int INDEX, typename T, typename ...Arguments>
class index_container_indexer<INDEX, index_container<T, Arguments...>> : public index_container_indexer<INDEX - 1, index_container<Arguments...>>
{
};

template <int INDEX, typename Values>
constexpr inline std::size_t GET()
{
	static_assert(std::is_base_of<index_container_base, Values>::value, "this parameter is not index_container class");
	return typename index_container_indexer<INDEX, Values>::_Target::VALUE;
}

} // namespace nmsp

#endif
