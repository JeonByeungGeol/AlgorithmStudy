﻿#pragma once

/*
외부 메모리 할당자를 사용하여 stl 기본 자료구조를 재정의 합니다.

* 요구 사항

  - _stl_allocator_t<T> 정의가 되어 있어야함.
	ex) 
	template <typename T>
	using _stl_allocator_t<T> = nmsp::stl_default_allocator<T, USER_ALLOCATOR>;
	
	#include "nmsptypes.h"
	
	// TODO: 사용

  - 또는 stl 컨테이너에서 요구하는 할당자
*/

namespace nmsp
{
namespace types
{
template <typename _Kty, typename _Ty, typename _Hasher = std::hash<_Kty> >
using unordered_map = std::unordered_map< _Kty, _Ty, _Hasher, std::equal_to<_Kty>, _stl_allocator_t<std::pair<const _Kty, _Ty>>>;

template <typename _Kty, typename _Ty, typename _Pr = std::less<_Kty> >
using multimap = std::multimap<_Kty, _Ty, _Pr, _stl_allocator_t<std::pair<const _Kty, _Ty>>>;

template <typename _Kty, typename _Ty, typename _Pr= std::less<_Kty> >
using map = std::map<_Kty, _Ty, _Pr, _stl_allocator_t<std::pair<const _Kty, _Ty>>>;

template <typename _Kty>
using set = std::set<_Kty, std::less<_Kty>, _stl_allocator_t<_Kty>>;

template <typename _Kty>
using unordered_set = std::unordered_set<_Kty, std::hash<_Kty>, std::equal_to<_Kty>, _stl_allocator_t<_Kty>>;

template <typename _Ty>
using vector = std::vector<_Ty, _stl_allocator_t<_Ty>>;

template <typename _Ty>
using list = std::list<_Ty, _stl_allocator_t<_Ty>>;

template <typename _Ty>
using queue = std::queue<_Ty, std::deque<_Ty, _stl_allocator_t<_Ty>>>;

template <template<class, class, class...> class C, typename K, typename V, typename... Args>
V GetWithDef(const C<K, V, Args...>& m, K const& key, const V & defval)
{
	typename C<K, V, Args...>::const_iterator it = m.find(key);
	if (it == m.end())
		return defval;
	return it->second;
}

}
}