﻿#pragma once
#ifndef __NMSPSTRING_H__
#define __NMSPSTRING_H__

#pragma warning( push )

#include <string>
#include <codecvt>
#include <locale>

namespace nmsp {

#pragma warning( disable : 4333 )
	using namespace std::string_literals;

	//using Converter = std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>>;
	//using Converter = std::wstring_convert<std::codecvt_utf16<wchar_t>>;//todojksstd deprecated in c++17(std::codecvt_utf16<wchar_t,1114111,(std::codecvt_mode)0>': warning STL4017: std::wbuffer_convert, std::wstring_convert, and the <codecvt> header (containing std::codecvt_mode, std::codecvt_utf8, std::codecvt_utf16, and std::codecvt_utf8_utf16) )
	//using Converter = std::wstring_convert<std::codecvt_utf8<wchar_t>>;

	class StringConvert
	{
	public:
		static bool UTF8ToUnicode(const std::string & src, std::wstring & dest)
		{
			dest.clear();
			/*
			std::wstring_convert<std::codecvt_utf8<wchar_t>> wconv;
			dest = wconv.from_bytes(src.data(), src.data() + src.size());
			/*/
			wchar_t wc;
			for (int i = 0;i < src.length(); )
			{
				char c = src[i];
				//if (c == 0x00)
				//	break;
				
				if ((c & 0x80) == 0)
				{
					wc = c;
					++i;
				}
				else if ((c & 0xE0) == 0xC0)
				{
					wc = (src[i] & 0x1F) << 6;
					wc |= (src[i + 1] & 0x3F);
					i += 2;
				}
				else if ((c & 0xF0) == 0xE0)
				{
					wc = (src[i] & 0xF) << 12;
					wc |= (src[i + 1] & 0x3F) << 6;
					wc |= (src[i + 2] & 0x3F);
					i += 3;
				}
				else if ((c & 0xF8) == 0xF0)
				{
					wc = (src[i] & 0x7) << 18;
					wc |= (src[i + 1] & 0x3F) << 12;
					wc |= (src[i + 2] & 0x3F) << 6;
					wc |= (src[i + 3] & 0x3F);
					i += 4;
				}
				else if ((c & 0xFC) == 0xF8)
				{
					wc = (src[i] & 0x3) << 24;
					wc |= (src[i] & 0x3F) << 18;
					wc |= (src[i] & 0x3F) << 12;
					wc |= (src[i] & 0x3F) << 6;
					wc |= (src[i] & 0x3F);
					i += 5;
				}
				else if ((c & 0xFE) == 0xFC)
				{
					wc = (src[i] & 0x1) << 30;
					wc |= (src[i] & 0x3F) << 24;
					wc |= (src[i] & 0x3F) << 18;
					wc |= (src[i] & 0x3F) << 12;
					wc |= (src[i] & 0x3F) << 6;
					wc |= (src[i] & 0x3F);
					i += 6;
				}
				else
				{
					return false;
				}
				dest += wc;
			}
			//*/
			return true;
		}

		static void UnicodeToUTF8(const std::wstring & src, std::string & dest, const std::locale& loc = std::locale{})
		{
			dest.clear();
			/*
			std::vector<char> buf(src.size());
			std::use_facet<std::ctype<wchar_t>>(loc).narrow(src.data(), src.data() + src.size(), '?', buf.data());
			dest.append(buf.data(), buf.size());
			/*/
			for (int i = 0;i < src.size(); ++i)
			{
				wchar_t wc = src[i];
				//if (wc == 0x00)
				//	break;

				if (0 <= wc && wc <= 0x7f)
				{
					dest += (char)wc;
				}
				else if (0x80 <= wc && wc <= 0x7ff)
				{
					dest += (0xc0 | (wc >> 6));
					dest += (0x80 | (wc & 0x3f));
				}
				else if (0x800 <= wc && wc <= 0xffff)
				{
					dest += (0xe0 | (wc >> 12));
					dest += (0x80 | ((wc >> 6) & 0x3f));
					dest += (0x80 | (wc & 0x3f));
				}
				else if (0x10000 <= wc && wc <= 0x1fffff)
				{
					dest += (0xf0 | (wc >> 18));
					dest += (0x80 | ((wc >> 12) & 0x3f));
					dest += (0x80 | ((wc >> 6) & 0x3f));
					dest += (0x80 | (wc & 0x3f));
				}
				else if (0x200000 <= wc && wc <= 0x3ffffff)
				{
					dest += (0xf8 | (wc >> 24));
					dest += (0x80 | ((wc >> 18) & 0x3f));
					dest += (0x80 | ((wc >> 12) & 0x3f));
					dest += (0x80 | ((wc >> 6) & 0x3f));
					dest += (0x80 | (wc & 0x3f));
				}
				else if (0x4000000 <= wc && wc <= 0x7fffffff)
				{
					dest += (0xfc | (wc >> 30));
					dest += (0x80 | ((wc >> 24) & 0x3f));
					dest += (0x80 | ((wc >> 18) & 0x3f));
					dest += (0x80 | ((wc >> 12) & 0x3f));
					dest += (0x80 | ((wc >> 6) & 0x3f));
					dest += (0x80 | (wc & 0x3f));
				}
			}
			//*/
		}

		static bool IsCompleteWords(const std::wstring& textStr)
		{
			if (textStr.empty())
				return false;

			for (auto textChar : textStr)
			{
				if (textChar >= 0x1100 && textChar <= 0x11FF) // Hangul Jamo
					return false;

				if (textChar >= 0x3130 && textChar <= 0x318F) // Hangul Compatibility Jamo
					return false;

				if (textChar >= 0xA960 && textChar <= 0xA97F) // Hangul Jamo Extended-A
					return false;

				if (textChar >= 0xD7B0 && textChar <= 0xD7FF) // Hangul Jamo Extended-B
					return false;

				if (textChar >= 0xFFA1 && textChar <= 0xFFDC) // Halfwidth and Fullwidth Forms
					return false;
			}

			return true;
		}

		static bool UnicodeToAnsi(const wchar_t* unicode, const std::size_t unicode_size, std::string& ansi)
		{
			DWORD error = 0;
			do {
				if ((nullptr == unicode) || (0 == unicode_size)) {
					error = ERROR_INVALID_PARAMETER;
					break;
				}
				ansi.clear();
				//
				// getting required cch.
				//
				int required_cch = ::WideCharToMultiByte(
					CP_ACP,
					0,
					unicode, static_cast<int>(unicode_size),
					nullptr, 0,
					nullptr, nullptr
				);
				if (0 == required_cch) {
					error = ::GetLastError();
					break;
				}
				//
				// allocate.
				//
				ansi.resize(required_cch);
				//
				// convert.
				//
				if (0 == ::WideCharToMultiByte(
					CP_ACP,
					0,
					unicode, static_cast<int>(unicode_size),
					const_cast<char*>(ansi.c_str()), static_cast<int>(ansi.size()),
					nullptr, nullptr
				)) {
					error = ::GetLastError();
					break;
				}
			} while (false);
	
			ansi.shrink_to_fit();
			return (error == 0);
		}
	};
}

#pragma warning( pop )
#endif