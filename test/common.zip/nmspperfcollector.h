﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: 누군가
// 설  명: 공유 메모리를 이용해 perfmon과 연동하기 위해 제작됨. (지원 플랫폼 : Windows)
// 
// 1) 수집을 위한 리파지토리 구성(여러개 구성 가능)
// 2) 생성한 리파지토리 파싱 및 마샬링을 위해 perf_parser 상속 구현
// 3) 수집기를 선언 후 시작
// 4) 필요한 위치에 수집 후 수집기로 내용 전달
//
// ** 공유 메모리에 적재되기 때문에 perfmon 또는 기타 도구를 이용해 주기적으로 모니터링 필요.

/*
Example 1) Typer를 이용해 수집할 데이터 구조 정의

// 패킷 카운트
TYPEDEF_TYPER_2(_PERF_PACKET_COUNT_T
, added_count, int32_t
)

Example 2) nmsp::perf_collector에서 사용하기 위해 nmsp::perf_parser 상속하여 내용 구현

class sample_parser : public nmsp::perf_parser
{
public:
	enum class type : int32_t
	{
		send_packet_count = 1,
		recv_packet_count = 2,
	};

	sample_parser()
	{
		Reset();
	}

	virtual ~sample_parser() = default;

	// 메시지 분석 
	virtual bool Parse(const int32_t& id, const std::string& msg) override
	{
		type ty = static_cast<type>(id);

		nmsp::set_data_caster sd;
		sd.str(msg);

		if (type::send_packet_count == ty)
		{
			_PERF_PACKET_COUNT_T obj;
			obj.Traverse(sd);

			m_send_pkt_count += obj.added_count;
		}
		else if (type::recv_packet_count == ty)
		{
			_PERF_PACKET_COUNT_T obj;
			obj.Traverse(sd);

			m_recv_pkt_count += obj.added_count;
		}
		else
		{
			// unknown
			return false;
		}

		return true;
	}

	// 수집 내용 공유를 위한 데이터 마샬링
	virtual bool Marshel(nmsp::perf_result& result) override
	{
		result.sputn(reinterpret_cast<const char*>(&m_send_pkt_count), sizeof(m_send_pkt_count));
		result.sputn(reinterpret_cast<const char*>(&m_recv_pkt_count), sizeof(m_recv_pkt_count));

		return true;
	}

	// 수집 내용 초기화
	virtual void Reset() override
	{
		m_zone_count = 0;
		m_send_pkt_count = 0;
	}

private:
	int32_t m_send_pkt_count;
	int32_t m_recv_pkt_count;
};

Example 3) perf_collector 사용

#include "nmspperfcollector.h"

// 객체 선언
nmsp::perf_collector g_collector;

void main(void)
{
	// 수집기 시작!
	g_collector.Start("sample_mmf", std::static_pointer_cast<nmsp::perf_parser>(std::make_shared<sample_parser>()), 1000);

	// 주기적 데이터 입력을 위한 쓰레드 생성
	auto producer = std::thread([&g_collector]() {

		nmsp::_stop_watch_t endTimer;

		while ((3600 * 1000) > endTimer.Lap())
		{
			// 리파지토리 생성 
			_PERF_PACKET_COUNT_T repo;
			repo.add_ed_count = 1;

			// 직렬화
			nmsp::get_data_caster gdc;
			repo.Traverse(gdc);

			// 수집기에 등록
			g_collector.Put(std::make_tuple(static_cast<int32_t>(sample_parser::send_packet_count), gdc.str()));

			std::this_thread::sleep(std::chrono::milliseconds(10);
		}
	});

	nmsp::_stop_watch_t endTimer;
	
	nmsp::_stop_watch_t collectTimer;
	
	while ((3600 * 1000) >= endTimer.Lap())
	{
		if (1000 <= collecteTimer.Lap())
		{
			// 1초 주기로 수집된 데이터 처리
			g_collector.Collect(nmsp::time::now());

			collecteTimer.Start();
		}
	}

}
*/

// 호환성을 위해서..
#pragma once
#ifndef __NMSPPERFCOLLECTOR_H__
#define __NMSPPERFCOLLECTOR_H__

#include <boost/asio/streambuf.hpp>

namespace nmsp 
{
// binary 구성을 위한 streambuf
// 사용법은 boost::asio::streambuf 문서 참고
class perf_result : public boost::asio::streambuf
{
public:
	using __super_t = boost::asio::streambuf;

	const void* get_pointer()
	{
		return boost::asio::buffer_cast<const void*>(__super_t::data());
	}
};

// 사용자가 정의한 데이터를 분석 및 마샬링 하기 위한 기본 클래스
class perf_parser
{
public:
	// 메시지를 파싱하여 데이터 적재
	virtual bool Parse(const int32_t& id, const std::string& msg) = 0;

	// 적재된 데이터를 perf_result에 직렬화
	virtual bool Marshel(perf_result& result) = 0;

	// 적재된 데이터 초기화
	virtual void Reset() = 0;
};

// 가공된 데이터를 공유 메모리에 적재합니다.
// 윈도우 전용 코드
class perf_publisher
{
public:
	perf_publisher()
		:m_handle(nullptr)
		, m_pointer(nullptr)
	{
	}
	~perf_publisher() = default;

	int32_t OpenMMF(const std::string& name)
	{
#if defined(_WIN32) || defined(_WIN64)
		auto status = Create(name);
		if (NO_ERROR != status)
		{
			return status;
		}

		return Open();
#else
		return ERROR_INVALID_HANDLE;
#endif
	}

	void Publish(perf_result& result)
	{
#if defined(_WIN32) || defined(_WIN64)
		if (nullptr == m_pointer)
			return;

		memcpy(m_pointer, result.get_pointer(), result.size());
		result.consume(result.size());
		result.prepare(result.size());
#endif
	}

	void Close()
	{
#if defined(_WIN32) || defined(_WIN64)
		if (nullptr != m_pointer)
		{
			UnmapViewOfFile(m_pointer);
			m_pointer = nullptr;
		}

		if (nullptr != m_handle)
		{
			CloseHandle(m_handle);
			m_handle = nullptr;
		}
#endif
	}

private:
	int32_t Open()
	{
#if defined(_WIN32) || defined(_WIN64)
		m_pointer = MapViewOfFile(m_handle, FILE_MAP_ALL_ACCESS, 0, 0, 0);
		if (nullptr == m_pointer)
		{
			Close();
			return ERROR_INVALID_DATA;
		}

		return NO_ERROR;
#else
		return ERROR_INVALID_HANDLE;
#endif
	}

	int32_t Create(const std::string& name)
	{
#if defined(_WIN32) || defined(_WIN64)
		m_handle = CreateFileMappingA(INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE, 0, 1024, name.c_str());

		auto status = GetLastError();
		if (NO_ERROR != status && ERROR_ALREADY_EXISTS != status)
		{
			Close();
			return status;
		}

		if (nullptr == m_handle)
			return ERROR_INVALID_HANDLE;

		return NO_ERROR;
#else
		return ERROR_INVALID_HANDLE;
#endif
	}

	void* m_handle;
	void* m_pointer;
};

// 데이터 수집 후 일정 주기로 분석 및 공유 메모리에 적재
class perf_collector
{
public:
	using _value_t = std::tuple<int32_t, std::string>; // first : 구분 ID, second : 데이터(Repository 또는 원하는 포멧)
	using _channel_t = tbb::concurrent_bounded_queue<_value_t>;
	using _parser_t = std::shared_ptr<perf_parser>;
	using _publisher_t = perf_publisher;						

	static const int32_t PUBLISH_DEFAULT_INTERVAL_MS = 1000;

	perf_collector()
		: m_isRun(false)
		, m_nextTime(0)
		, m_publishInterval(0)
	{
	}

	bool Start(
		const std::string& mmf_name,	// 공유 메모리에 사용할 이름(perfmon 및 기타 툴에서 조회를 위한 이름)
		_parser_t& parser,				// 사용자가 정의한 parser
		int32_t publishIntervalMs,		// 공유 메모리에 적재할 주기(밀리세컨드)
		bool useWorkerThread = false		// Collect용 쓰레드를 생성할지 여부. false일 경우 사용자가 주기적으로 Collect 메소드를 호출해줘야함.
	)	
	{
		if (NO_ERROR != m_publisher.OpenMMF(mmf_name))
			return false;

		m_parser = std::move(parser);

		m_publishInterval = publishIntervalMs;
		if (0 >= m_publishInterval)
			m_publishInterval = PUBLISH_DEFAULT_INTERVAL_MS;

		m_isRun = true;

		if (true == useWorkerThread)
		{
			m_workerTh = std::thread([this]() {
				
				using namespace std::chrono;

				while (true == m_isRun)
				{
					Collect(duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count());

					std::this_thread::sleep_for(milliseconds(m_publishInterval));
				}
			});
		}

		return true;
	}

	void Stop()
	{
		m_isRun = false;

		if (true == m_workerTh.joinable())
			m_workerTh.join();

		m_publisher.Close();
	}

	// immediate를 이용할 경우 데이터 손실이 있을 수 있음.
	void Put(const _value_t& value, bool immediate = false)
	{
		if (false == m_isRun)
			return;

		if (immediate == false)
		{
			m_channel.push(std::move(value));
		}
		else
		{
			m_parser->Parse(std::get<0>(value), std::get<1>(value));
		}
	}

	void Collect(const uint64_t now)
	{
		if (false == m_isRun)
			return;

		while (true == m_isRun)
		{
			_value_t value;
			if (false == m_channel.try_pop(value))
				break;

			m_parser->Parse(std::get<0>(value), std::get<1>(value));
		}

		if (0 == m_nextTime)
		{
			m_nextTime = now + m_publishInterval;
			return;
		}

		// 일정 시간이 흘렀다면?
		if (now >= m_nextTime)
		{
			m_parser->Marshel(m_result);
			m_parser->Reset();

			m_publisher.Publish(m_result);

			m_nextTime = now + m_publishInterval;
		}
	}

private:
	volatile bool m_isRun;

	uint64_t m_nextTime;

	uint64_t m_publishInterval;

	// 데이터 수집 채널
	_channel_t m_channel;

	// 일정 시간동안 쌓인 데이터를 분석&정리 합니다.
	_parser_t m_parser;

	// 분석한 결과를 공유 메모리에 적재합니다.
	_publisher_t m_publisher;

	perf_result m_result;

	std::thread m_workerTh;
};
} // nmsp

#endif
