﻿////////////////////////////////////////////////////////////////////////////////
//
// 작성자 : huelee
// 설  명 : 
//

#pragma once
#ifndef __NMSPINTERFACE_H__
#define __NMSPINTERFACE_H__

namespace nmsp {

//
typedef struct _UUID
{
	unsigned int   Data1;
	unsigned short Data2;
	unsigned short Data3;
	unsigned char  Data4[8];
} UUID;

// UUID비교
__inline bool operator==(const UUID& uuid1, const UUID& uuid2)
{
	return !memcmp(&uuid1, &uuid2, sizeof(UUID));
}

// Service Type정의
enum _NMSP_RESERVED_SERVICETYPE_T
{
	_NMSP_RESERVED_SERVICETYPE_CONTAINER	= 0xFFFE,			// 내부에서 사용하려는 의도
	_NMSP_RESERVED_SERVICETYPE_NULL			= 0xFFFF,			// 내부에서 사용하려는 의도
};

// base interface정의
struct IComponentBase
{
	virtual int QueryInterface(const UUID* iid, void** pInterface) = 0;
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
};

// Container
struct IComponentContainer: public IComponentBase
{
	virtual int QueryComponent(unsigned short uiServiceType, const UUID* uuid, void** ppIOther) = 0;
	virtual int GetServiceTypes(int* pnLen, unsigned short** ppuiTypes) = 0;
	virtual int ResetServiceTypes(unsigned short* puiTypes) = 0;
};

// component의 기본 구현 interface정의
struct IComponent: public IComponentBase
{
	virtual int SetBaseInfo(unsigned short uiServiceType, IComponentContainer* piContainer, int nLen, const char* pszCfgPath, int logLevel, bool outConsole, const char* timeZoneName) = 0;
	virtual int PreInit() = 0;
	virtual int Init() = 0;
	virtual void Uninit() = 0;
	virtual void PostUninit() = 0;
};

// 
extern "C" const UUID UUID_IComponentBase;
extern "C" const UUID UUID_IComponentContainer;
extern "C" const UUID UUID_IComponent;

}	// nmsp

#endif
