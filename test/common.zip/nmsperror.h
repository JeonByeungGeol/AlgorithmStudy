﻿////////////////////////////////////////////////////////////////////////////////
//
// 작성자 : huelee
// 설  명 : 
//

#pragma once
#ifndef __NMSPERROR_H__
#define __NMSPERROR_H__

namespace nmsp {

// error code의 구성
// int 형중 상위 16비트는 servicetype을 하위 16비트는 에러코드를 표현한다.
enum
{
	_NMSP_NOERROR							= 0x00000000,
};

// CONTAINER의 오류 정리
enum _CONTAINER_ERROR_T
{
	_CONTAINER_ERROR_NO_INTERFACE			= 0x0001,
	_CONTAINER_ERROR_DUP_SERVICETYPE		= 0x0002,
	_CONTAINER_ERROR_LOAD_ERROR				= 0x0003,
	_CONTAINER_ERROR_EXTERN_FUNCTION_ERRPR	= 0x0004,
	_CONTAINER_ERROR_INTERFACE_NOT_FOUND	= 0x0005,
	_CONTAINER_ERROR_CREATION_COMPONENT		= 0x0006,
	_CONTAINER_ERROR_MEMORY					= 0x0007,
	_CONTAINER_ERROR_NO_MESSAGE				= 0x0008,
};

//
class nmsp_error: public std::exception 
{
public:
	nmsp_error()
		: std::exception()
	{
		m_nError = 0;
	}
	nmsp_error(const char* const pszError)
		: std::exception(pszError)
	{
		m_nError = 0;
	}
	nmsp_error(const char* const pszError, int nError)
		: std::exception(pszError)
	{
		m_nError = nError;
	}
	nmsp_error(const nmsp_error& e)
		: std::exception(e)
	{
		m_nError = e.m_nError;
	}
	nmsp_error(const std::exception& e)
		: std::exception(e)
	{
		m_nError = 0;
	}
	nmsp_error& operator=(const nmsp_error& e)
	{
		std::exception::operator=(e);
		m_nError = e.m_nError;
	}
	nmsp_error& operator=(const std::exception& e)
	{
		std::exception::operator=(e);
		m_nError = 0;
	}
	int error() const
	{
		return m_nError;
	}
private:
	int m_nError;
};

// 에러를 만들어준다
inline int make_nmsp_error(unsigned short uiServiceType, unsigned short uiErrorCode)
{
	return (uiServiceType << 16) | uiErrorCode;
}

// 에러를 찾자
inline void from_nmsp_error(int error, unsigned short& uiServiceType, unsigned short& uiErrorCode)
{
	uiServiceType = (error >> 16);
	uiErrorCode = error - (uiServiceType << 16);
}

}

#endif
