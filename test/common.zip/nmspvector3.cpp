﻿////////////////////////////////////////////////////////////////////////////////
//
// 작성자 : bkkim, sjkim
// 설  명 : 
//

#include <crtdbg.h>
#include <cmath>
#include <float.h>
#include <stdint.h>
#include <sstream>
#include "nmspvector3.h"

namespace nmsp {

	const Vector3 Vector3::ZeroVector(0, 0, 0);
	const Vector3 Vector3::OneVector(1, 1, 1);

	/** Unreal World up vector (0,0,1) */
	/** Recast up vector (0,1,0) */
	const Vector3 Vector3::UpVector(0, 1, 0);
	const Vector3 Vector3::DownVector(0, -1, 0);

	/** Unreal forward vector (1,0,0) */
	/** Recast forward vector (-1,0,0) */
	const Vector3 Vector3::ForwardVector(-1, 0, 0);

	/** Unreal right vector (0,1,0) */
	/** Recast right vector (0,0,-1) */
	const Vector3 Vector3::RightVector(0, 0, -1);

	const float PI = (3.1415926535897932f);
	static const float INV_PI = (0.31830988618f);
	static const float HALF_PI = (1.57079632679f);

	float RadiansToDegrees(const float RadVal)
	{
		return RadVal * (180.f / PI);
	}

	float DegreesToRadians(const float DegVal)
	{
		return DegVal * (PI / 180.f);
	}

	// Unreal 에서 가져온 함수
	inline void SinCos(float& scalar_sin, float& scalar_cos, const float value)
	{
		float quotient = (INV_PI * 0.5f) * value;
		if (value >= 0)
			quotient = (float)((int)(quotient + 0.5f));
		else
			quotient = (float)((int)(quotient - 0.5f));

		float y = value - (2.f * PI) * quotient;

		float sign;
		if (y > HALF_PI) {
			y = PI - y;
			sign = -1.f;
		}
		else if (y < -HALF_PI) {
			y = -PI - y;
			sign = -1.f;
		}
		else {
			sign = 1.f;
		}

		float y2 = y * y;

		scalar_sin = (((((-2.3889859e-08f * y2 + 2.7525562e-06f) * y2 - 0.00019840874f) * y2 + 0.0083333310f) * y2 - 0.16666667f) * y2 + 1.0f) * y;

		float p = ((((-2.6051615e-07f * y2 + 2.4760495e-05f) * y2 - 0.0013888378f) * y2 + 0.041666638f) * y2 - 0.5f) * y2 + 1.0f;
		scalar_cos = sign * p;
	}

	float* Vector3Functor::RotateAngleAxis(float *dest, const float* v, const float angle_deg, const float* axis)
	{
		_assert(dest && v && axis);

		float S, C;
		float rad = DegreesToRadians(angle_deg);

		SinCos(S, C, rad);

		const float XX = axis[0] * axis[0];
		const float YY = axis[1] * axis[1];
		const float ZZ = axis[2] * axis[2];

		const float XY = axis[0] * axis[1];
		const float YZ = axis[1] * axis[2];
		const float ZX = axis[2] * axis[0];

		const float XS = axis[0] * S;
		const float YS = axis[1] * S;
		const float ZS = axis[2] * S;

		const float OMC = 1.f - C;

		dest[0] = (OMC * XX + C) * v[0] + (OMC * XY - ZS) * v[1] + (OMC * ZX + YS) * v[2];
		dest[1] = (OMC * XY + ZS) * v[0] + (OMC * YY + C) * v[1] + (OMC * YZ - XS) * v[2];
		dest[2] = (OMC * ZX - YS) * v[0] + (OMC * YZ + XS) * v[1] + (OMC * ZZ + C) * v[2];

		return dest;
	}

	float* Vector3Functor::RotateAngle2D(float *dest, const float *v, const float angle_deg)
	{
		float rad = DegreesToRadians(angle_deg);

		dest[0] = (v[0] * cosf(rad)) - (v[2] * sinf(rad));
		dest[1] = 0.f;
		dest[2] = (v[2] * cosf(rad)) + (v[0] * sinf(rad));

		return dest;
	}

	float* Vector3Functor::RotateRadian2D(float *dest, const float *v, const float angle_rad)
	{
		dest[0] = (v[0] * cosf(angle_rad)) - (v[2] * sinf(angle_rad));
		dest[1] = 0.f;
		dest[2] = (v[2] * cosf(angle_rad)) + (v[0] * sinf(angle_rad));

		return dest;
	}

	Vector3::Vector3()
	{
		Vector3Functor::Set(_pos, 0, 0, 0);
	}

	Vector3::Vector3(float x, float y, float z)
	{
		Vector3Functor::Set(_pos, x, y, z);
	}

	Vector3::Vector3(const float* other)
	{
		Vector3Functor::Set(_pos, other[0], other[1], other[2]);
	}

	Vector3::Vector3(const Vector3& other)
	{
		Vector3Functor::Copy(_pos, other._pos);
	}

	bool Vector3::operator== (const Vector3& other) const
	{
		return _pos[0] == other._pos[0] &&
			_pos[1] == other._pos[1] &&
			_pos[2] == other._pos[2];
	}

	bool Vector3::operator== (const float(&other)[3]) const
	{
		return _pos[0] == other[0] &&
			_pos[1] == other[1] &&
			_pos[2] == other[2];
	}

	bool Vector3::operator!= (const Vector3& other) const
	{
		return _pos[0] != other._pos[0] ||
			_pos[1] != other._pos[1] ||
			_pos[2] != other._pos[2];
	}

	bool Vector3::operator!= (const float(&other)[3]) const
	{
		return _pos[0] != other[0] ||
			_pos[1] != other[1] ||
			_pos[2] != other[2];
	}

	Vector3& Vector3::operator= (const Vector3& other)
	{
		Vector3Functor::Copy(_pos, other._pos);
		return *this;
	}

	Vector3& Vector3::operator+= (const Vector3& other)
	{
		Vector3Functor::Add(_pos, _pos, other._pos);
		return *this;
	}

	Vector3& Vector3::operator-= (const Vector3& other)
	{
		Vector3Functor::Sub(_pos, _pos, other._pos);
		return *this;
	}

	Vector3& Vector3::operator*= (float scalar)
	{
		Vector3Functor::Scale(_pos, _pos, scalar);
		return *this;
	}

	Vector3& Vector3::operator/= (float scalar)
	{
		if (scalar != 0)
			Vector3Functor::Scale(_pos, _pos, 1.f / scalar);
		return *this;
	}

	Vector3 Vector3::operator- () const
	{
		Vector3 res(-_pos[0], -_pos[1], -_pos[2]);
		return res;
	}

	const std::string Vector3::ToString() const
	{
		std::stringstream ss;

		ss << _pos[0] << "," << _pos[1] << "," << _pos[2];

		return ss.str();
	}

	void Vector3::Set(float x, float y, float z)
	{
		Vector3Functor::Set(_pos, x, y, z);
	}

	void Vector3::Set(const float* other)
	{
		Vector3Functor::Set(_pos, other[0], other[1], other[2]);
	}

	float Vector3::SqrMagnitude() const
	{
		return Vector3Functor::SquaredLength(_pos);
	}
	float Vector3::SqrMagnitude2D() const
	{
		return Vector3Functor::SquaredLength2D(_pos);
	}

	float Vector3::Magnitude() const
	{
		return sqrtf(Vector3Functor::SquaredLength(_pos));
	}
	float Vector3::Magnitude2D() const
	{
		return sqrtf(Vector3Functor::SquaredLength2D(_pos));
	}

	Vector3& Vector3::Normalized()
	{
		Vector3Functor::Normalize(_pos, _pos);
		return *this;
	}

	Vector3& Vector3::Normalized2D()
	{
		_pos[1] = 0;
		Vector3Functor::Normalize(_pos, _pos);
		return *this;
	}

	bool Vector3::IsNan() const
	{
		return isnan(_pos[0]) || isnan(_pos[1]) || isnan(_pos[2]);
	}

	bool Vector3::IsInf() const
	{
		return isinf(_pos[0]) || isinf(_pos[1]) || isinf(_pos[2]);
	}

	bool Vector3::Equals(const Vector3& v) const
	{
		return (abs(_pos[0] - v._pos[0]) <= FLT_EPSILON) &&
			(abs(_pos[1] - v._pos[1]) <= FLT_EPSILON) &&
			(abs(_pos[2] - v._pos[2]) <= FLT_EPSILON);
	}

	bool Vector3::SameTo(const float* v) const
	{
		return (abs(_pos[0] - v[0]) <= FLT_EPSILON) &&
			(abs(_pos[1] - v[1]) <= FLT_EPSILON) &&
			(abs(_pos[2] - v[2]) <= FLT_EPSILON);
	}

	bool Vector3::IsNearlyZero() const
	{
		return abs(_pos[0]) <= FLT_EPSILON &&
			abs(_pos[1]) <= FLT_EPSILON &&
			abs(_pos[2]) <= FLT_EPSILON;
	}

	bool Vector3::IsZero() const
	{
		return _pos[0] == 0.f && _pos[1] == 0.f && _pos[2] == 0.f;
	}

	Vector3& Vector3::Rotate(const float angle_deg, const Vector3& axis)
	{
		Vector3 temp = *this;
		Vector3Functor::RotateAngleAxis(_pos, temp._pos, angle_deg, axis._pos);
		return *this;
	}

	Vector3 operator+ (const Vector3& v1, const Vector3& v2)
	{
		Vector3 res;
		Vector3Functor::Add(res._pos, v1._pos, v2._pos);
		return res;
	}

	Vector3 operator- (const Vector3& v1, const Vector3& v2)
	{
		Vector3 res;
		Vector3Functor::Sub(res._pos, v1._pos, v2._pos);
		return res;
	}

	Vector3 operator- (const Vector3& v1, const float* v2)
	{
		Vector3 res;
		Vector3Functor::Sub(res._pos, v1._pos, v2);
		return res;
	}

	Vector3 operator* (const Vector3& v, const float s)
	{
		Vector3 res;
		Vector3Functor::Scale(res._pos, v._pos, s);
		return res;
	}

	Vector3 operator/ (const Vector3& v, const float s)
	{
		Vector3 res;
		if (s != 0)
			Vector3Functor::Scale(res._pos, v._pos, 1.f / s);
		return res;
	}


	float Vector3::Distance(const Vector3& v1, const Vector3& v2)
	{
		return Vector3Functor::Distance(v1._pos, v2._pos);
	}

	float Vector3::Distance2D(const Vector3& v1, const Vector3& v2)
	{
		return Vector3Functor::Distance2D(v1._pos, v2._pos);
	}

	float Vector3::Distance(const Vector3& v1, const float* v2)
	{
		return Vector3Functor::Distance(v1._pos, v2);
	}

	float Vector3::Distance2D(const Vector3& v1, const float* v2)
	{
		return Vector3Functor::Distance2D(v1._pos, v2);
	}

	Vector3 Vector3::Normalize(const Vector3& v)
	{
		Vector3 res = v;
		return res.Normalized();
	}

	Vector3 Vector3::Normalize2D(const Vector3& v)
	{
		Vector3 res = v;
		return res.Normalized2D();
	}

	Vector3 Vector3::Normalize2D(const Vector3& v, const Vector3& defaultV)
	{
		Vector3 res = v;
		res.Normalized2D();
		if (res.IsNan() || res.IsNearlyZero())
			return defaultV;

		return res;
	}

	Vector3 Vector3::Unreal2Recast(float x, float y, float z)
	{
		Vector3 res(-x, z, -y);
		return res;
	}

	Vector3 Vector3::Unreal2Recast(const float* v)
	{
		if (v == nullptr) return ZeroVector;
		return Unreal2Recast(v[0], v[1], v[2]);
	}

	Vector3 Vector3::Unreal2Recast(const Vector3& v)
	{
		return Unreal2Recast(v._pos[0], v._pos[1], v._pos[2]);
	}

	Vector3 Vector3::Recast2Unreal(float x, float y, float z)
	{
		Vector3 res(-x, -z, y);
		return res;
	}

	Vector3 Vector3::Recast2Unreal(const float* v)
	{
		if (v == nullptr) return ZeroVector;
		return Recast2Unreal(v[0], v[1], v[2]);
	}

	Vector3 Vector3::Recast2Unreal(const Vector3& v)
	{
		return Recast2Unreal(v._pos[0], v._pos[1], v._pos[2]);
	}

	Vector3 Vector3::CrossProduct(const Vector3& v1, const Vector3& v2)
	{
		Vector3 res;
		Vector3Functor::CrossProduct(res._pos, v1._pos, v2._pos);
		return res;
	}

	float Vector3::DotProduct(const Vector3& v1, const Vector3& v2)
	{
		return Vector3Functor::DotProduct(v1._pos, v2._pos);
	}

	float Vector3::AngleBetweenVectors2D(const Vector3& baseV, const Vector3& v)
	{
		// 외적의 Y 값
		float crossProductY = (baseV.Z()*v.X()) - (baseV.X()*v.Z());
		
		float rv = nmsp::RadiansToDegrees(acosf(nmsp::Vector3Functor::DotProduct2D(Vector3::Normalize2D(baseV).Data(), Vector3::Normalize2D(v).Data())));
		rv = isnan(rv) ? 0.f : rv;
		return crossProductY>0 ? -rv : rv;
	}

	Vector3 Vector3::RotateAngleAxis(const Vector3& v, const float angle_deg, const Vector3& axis)
	{
		Vector3 res;
		Vector3Functor::RotateAngleAxis(res._pos, v._pos, angle_deg, axis._pos);
		return res;
	}

	Vector3 Vector3::RotateAngleAxis(const Vector3& v, const Vector3& changeDiretion)
	{
		if (changeDiretion.IsNan() || changeDiretion.IsZero())
			return v;
		nmsp::Vector3 axis = nmsp::Vector3::CrossProduct(nmsp::Vector3::ForwardVector, changeDiretion);
		if (!axis.IsZero())
		{
			axis.Normalized();
			float angle = nmsp::RadiansToDegrees(acosf(fminf(nmsp::Vector3::DotProduct(nmsp::Vector3::ForwardVector, changeDiretion), 1.f)));
			return nmsp::Vector3::RotateAngleAxis(v.Data(), angle, axis.Data());
		}
		
		return v;
	}

	Vector3 Vector3::RotateAngleAxis(const Vector3& v, const Vector3& baseDiretion, const Vector3& changeDiretion)
	{
		if (changeDiretion.IsNan() || changeDiretion.IsZero() || baseDiretion.IsNan() || baseDiretion.IsZero() )
			return v;
		nmsp::Vector3 axis = nmsp::Vector3::CrossProduct(baseDiretion, changeDiretion);
		if (!axis.IsZero())
		{
			axis.Normalized();
			float angle = nmsp::RadiansToDegrees(acosf(fminf(nmsp::Vector3::DotProduct(baseDiretion, changeDiretion), 1.f)));
			return nmsp::Vector3::RotateAngleAxis(v.Data(), angle, axis.Data());
		}

		return v;
	}

	Vector3 Vector3::FindDirection(const float* src, const float* dest, const float* defaultDir)
	{
		if (defaultDir == nullptr)
			return nmsp::Vector3::ForwardVector;

		if (src == nullptr || dest == nullptr)
			return defaultDir;

		Vector3 vel;
		Vector3Functor::Sub(vel.Data(), dest, src);
		vel.Normalized();

		if (vel.IsNan() || vel.IsNearlyZero())
			return defaultDir;

		return vel;
			
	}
	Vector3 Vector3::FindDirection(const Vector3& src, const Vector3& dest, const Vector3& defaultDir)
	{
		nmsp::Vector3 vel = nmsp::Vector3::Normalize(dest - src);
		if (vel.IsNan() || vel.IsNearlyZero())
			return defaultDir;

		return vel;
	}
	Vector3 Vector3::FindDirection2D(const float* src, const float* dest, const float* defaultDir)
	{
		if (defaultDir == nullptr)
			return nmsp::Vector3::ForwardVector;

		if (src == nullptr || dest == nullptr)
			return defaultDir;

		Vector3 vel;
		Vector3Functor::Sub(vel.Data(), dest, src);
		vel.Normalized2D();
		
		if (vel.IsNan() || vel.IsNearlyZero())
			return defaultDir;

		return vel;
	}
	Vector3 Vector3::FindDirection2D(const Vector3& src, const Vector3& dest, const Vector3& defaultDir)
	{
		nmsp::Vector3 vel = nmsp::Vector3::Normalize2D(dest - src);
		if (vel.IsNan() || vel.IsNearlyZero())
			return defaultDir;

		return vel;
	}
}