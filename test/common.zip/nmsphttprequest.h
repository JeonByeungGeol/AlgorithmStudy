﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: 
// 설  명:
//

// 호환성을 위해서..
#pragma once
#ifndef __NMSPHTTPREQUEST_H__
#define __NMSPHTTPREQUEST_H__

#include <string>
#include <atomic>

//
#include "nmspinterface.h"
#include "httpinterface.h"
#include "nmspnewfrompool.h"

//
namespace nmsp { namespace http {

template <typename ALLOC>
class http_request : public nmsp::http::IRequest, public nmsp::new_from_pool<ALLOC>
{
public:
	http_request()
		: m_refs(0)
	{
		m_port = 80;
		m_schema = "http";
		m_method = "POST";
	}
	virtual ~http_request() = default;

	virtual int QueryInterface(const nmsp::UUID* iid, void** pInterface) override
	{
		return nmsp::_NMSP_NOERROR;
	}

	virtual int AddRef() override
	{
		return ++m_refs;
	}

	virtual int Release() override
	{
		int lastRef = --m_refs;
		if (0 == lastRef)
		{
			delete this;
			return 0;
		}

		return lastRef;
	}

	virtual const char* Schema() override { return m_schema.data(); }
	virtual void Schema(const char* schema) override { m_schema = schema; }

	virtual const char* Method() override { return m_method.data(); }
	virtual void Method(const char* method) override { m_method = method; }

	virtual const char* Host() override { return m_host.data(); }
	virtual void Host(const char* host) override { m_host = host; }

	virtual unsigned short Port() override { return m_port; }
	virtual void Port(unsigned short port) override { m_port = port; }

	virtual const char* Path() override { return m_path.data(); }
	virtual void Path(const char* path) override { m_path = path; }

	virtual const wchar_t* Body() override { return m_body.data(); }
	virtual int GetBodyLenth() override { return static_cast<int>(m_body.length()); }
	virtual void Body(const wchar_t* body, int) override { m_body = body; }

	virtual const std::unordered_map<std::string, std::string> Reserved() { return m_reserved; }
	virtual void Reserved(const std::unordered_map<std::string, std::string> reserved) { m_reserved = reserved; }
	virtual std::string FindReservedValue(const std::string& key) {
		auto itr = m_reserved.find(key);
		if (itr == m_reserved.end())
			return "";
		return itr->second;
	}

private:
	std::string m_schema;
	std::string m_method;
	std::string m_host;
	uint16_t m_port;
	std::string m_path;
	std::wstring m_body;

	std::unordered_map<std::string, std::string> m_reserved;

	std::atomic_int m_refs;
};

} }		// http	// nmsp

#endif
