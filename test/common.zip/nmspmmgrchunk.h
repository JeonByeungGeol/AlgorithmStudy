﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __NMSPMMGRCHUNK_H__
#define __NMSPMMGRCHUNK_H__

//
namespace nmsp {

// 상수 정의
enum
{
	MMGR_POOLINDEX_NULL			= (-1),
	ALIGNMENT_DEFAULT_SIZE		= (sizeof(void*)),
	CHUNK_DEFAULT_SIZE			= 32768,
	CHUNK_MAX_SIZE				= 100000000,
#if defined(_DEBUG) || defined(_NMSP_MEMORY_POOL_CHECK_)
	CHUNK_CHECK_DATA			= 0xDBDBDBDB,
	BLOCK_CHECK_DATA			= 0xDBDBDBDB,
#endif
};

// define을 옮길려다 보니..
inline int GET_OFFSETCOUNT(int c, int b)
{
	return (((c)+(b)-1) / (b));
}

inline int GET_ALIGNMENT_BY_SIZE(int c, int a)
{
	return (((c)+(a)-1) - (((c)+(a)-1) % (a)));
}

inline int CHECK_POWOFTWO(int c)
{
	return (!((c)&((c)-1)));
}

////////////////////////////////////////////////////////////////////////////////
//
template <class ALLOC, int t_nAlignment = ALIGNMENT_DEFAULT_SIZE>
class mmgr_chunk
{
	typedef unsigned char CHUNK_TYPE;
	typedef CHUNK_TYPE CHUNK_HEAD_TYPE;

#if defined(_DEBUG) || defined(_NMSP_MEMORY_POOL_CHECK_)
	typedef int CHUNK_TAIL_TYPE;
	typedef int BLOCK_TAIL_TYPE;
#endif

	enum 
	{
		MNGR_CHUNK_ALIGNMENT = t_nAlignment,
		MNGR_CHUNK_TYPE_SIZE = sizeof(CHUNK_TYPE*),
		MNGR_CHUNK_HEAD_TYPE_SIZE = sizeof(CHUNK_HEAD_TYPE*),
#if defined(_DEBUG) || defined(_NMSP_MEMORY_POOL_CHECK_)
		MNGR_CHUNK_TAIL_TYPE_SIZE = sizeof(CHUNK_TAIL_TYPE),
		MNGR_BLOCK_TAIL_TYPE_SIZE = sizeof(BLOCK_TAIL_TYPE),
#endif
	};

public:
	enum CHKMEMORY
	{
		CHKMEMORY_OK,
		CHKMEMORY_NOFOUNDED,
		CHKMEMORY_INVALIDPOINTER,
	};

public:
	mmgr_chunk();
	virtual ~mmgr_chunk();

	bool Init(int nBlockSize, int nChunkSize);
	void Uninit();
	void* Allocate();
	void Deallocate(void* pBack);
#if defined(_DEBUG) || defined(_NMSP_MEMORY_POOL_CHECK_)
	bool CheckMemory();
#endif
	CHKMEMORY CheckMemory(void* pBack);

public:
	inline bool IsInitialize() { return (0 != m_nChunkSize || 0 != m_nBlockSize); }
	inline int GetAllocationCount() { return m_nAllocCount; }
	inline int GetFreeCount() { return m_nFreeCount; }
	inline int GetBlockSize() { return m_nBlockSize; }

private:
	bool AddChunk();

private:
	CHUNK_TYPE* m_pAvailableFirstBlock;
	CHUNK_HEAD_TYPE* m_pAvailableLaskChunk;
	int m_nGrIdx;
	int m_nGrIdxExt;
	int m_nBlockSize;
#if defined(_DEBUG) || defined(_NMSP_MEMORY_POOL_CHECK_)
	int m_nRawBlockSize;
#endif
	int m_nChunkSize;
	int m_nChunkHeadSize;
	int m_nAllocCount;
	int m_nFreeCount;
};

template <class ALLOC, int t_nAlignment>
mmgr_chunk<ALLOC, t_nAlignment>::mmgr_chunk()
{
	m_pAvailableFirstBlock = nullptr;
	m_pAvailableLaskChunk = nullptr;
	m_nGrIdx = 0;
	m_nGrIdxExt = 0;
	m_nChunkSize = 0;
	m_nBlockSize = 0;
	m_nChunkHeadSize = 0;
	m_nAllocCount = 0;
	m_nFreeCount = 0;
}

template <class ALLOC, int t_nAlignment>
mmgr_chunk<ALLOC, t_nAlignment>::~mmgr_chunk()
{
	CHUNK_TYPE** ppFreeChunk = reinterpret_cast<CHUNK_TYPE**>(m_pAvailableLaskChunk);
	CHUNK_TYPE* pNextChunk;

	while (ppFreeChunk)
	{
		pNextChunk = *ppFreeChunk;
		
		ALLOC::DestroyMemory(reinterpret_cast<CHUNK_TYPE*>(ppFreeChunk));

		ppFreeChunk = reinterpret_cast<CHUNK_TYPE**>(pNextChunk);
	}
}

template <class ALLOC, int t_nAlignment>
bool
mmgr_chunk<ALLOC, t_nAlignment>::Init(int nRawBlockSize, int nChunkSize)
{
	if (0 >= nRawBlockSize)
	{
		return false;
	}

	//
#if defined(_DEBUG) || defined(_NMSP_MEMORY_POOL_CHECK_)
	int nBlockSize = GET_ALIGNMENT_BY_SIZE(nRawBlockSize + MNGR_BLOCK_TAIL_TYPE_SIZE, MNGR_CHUNK_ALIGNMENT);
#else
	int nBlockSize = GET_ALIGNMENT_BY_SIZE(nRawBlockSize, MNGR_CHUNK_ALIGNMENT);
#endif
	//

	// 기본 사이즈보다 작다면.. 확보하자..
	if (nBlockSize < ALIGNMENT_DEFAULT_SIZE)
		nBlockSize = ALIGNMENT_DEFAULT_SIZE;

	int nBlockCount = GET_OFFSETCOUNT(nChunkSize, nBlockSize);
	if (0 >= nBlockCount)
	{
		return false;
	}

	m_nChunkSize = nBlockCount * nBlockSize;
	m_nBlockSize = nBlockSize;
#if defined(_DEBUG) || defined(_NMSP_MEMORY_POOL_CHECK_)
	m_nRawBlockSize = nRawBlockSize;
#endif
	m_nChunkHeadSize = GET_ALIGNMENT_BY_SIZE(MNGR_CHUNK_HEAD_TYPE_SIZE, MNGR_CHUNK_ALIGNMENT);

	return true;
}

template <class ALLOC, int t_nAlignment>
void
mmgr_chunk<ALLOC, t_nAlignment>::Uninit()
{
}

template <class ALLOC, int t_nAlignment>
bool 
mmgr_chunk<ALLOC, t_nAlignment>::AddChunk()
{
	//
#if defined(_DEBUG) || defined(_NMSP_MEMORY_POOL_CHECK_)
	int nNewAllocSize = m_nChunkHeadSize + (m_nChunkSize << m_nGrIdx) + GET_ALIGNMENT_BY_SIZE(MNGR_CHUNK_TAIL_TYPE_SIZE, MNGR_CHUNK_ALIGNMENT);
#else
	int nNewAllocSize = m_nChunkHeadSize + (m_nChunkSize << m_nGrIdx);
#endif

	//
	CHUNK_HEAD_TYPE** ppNewChunk = reinterpret_cast<CHUNK_HEAD_TYPE**>(ALLOC::CreateMemory(nNewAllocSize));
	if (nullptr == ppNewChunk)
	{
		return false;
	}

	if (nullptr != m_pAvailableLaskChunk)
	{
		*ppNewChunk = m_pAvailableLaskChunk;
	}
	else
	{
		*ppNewChunk = nullptr;
	}

	m_pAvailableLaskChunk = reinterpret_cast<CHUNK_HEAD_TYPE*>(ppNewChunk);
	m_pAvailableFirstBlock = reinterpret_cast<CHUNK_TYPE*>(reinterpret_cast<unsigned char*>(m_pAvailableLaskChunk) + m_nChunkHeadSize); 
#if defined(_DEBUG) || defined(_NMSP_MEMORY_POOL_CHECK_)
	CHUNK_TYPE* pAvailableLastBlock = reinterpret_cast<CHUNK_TYPE*>(reinterpret_cast<unsigned char*>(m_pAvailableLaskChunk) + nNewAllocSize - m_nBlockSize - GET_ALIGNMENT_BY_SIZE(MNGR_CHUNK_TAIL_TYPE_SIZE, MNGR_CHUNK_ALIGNMENT));
#else
	CHUNK_TYPE* pAvailableLastBlock = reinterpret_cast<CHUNK_TYPE*>(reinterpret_cast<unsigned char*>(m_pAvailableLaskChunk) + nNewAllocSize - m_nBlockSize);
#endif

	//
	CHUNK_TYPE* pNextBlock = m_pAvailableFirstBlock;
	CHUNK_TYPE** ppCurBlock = reinterpret_cast<CHUNK_TYPE**>(m_pAvailableFirstBlock);
	//

	for (;pNextBlock < pAvailableLastBlock;)
	{
#if defined(_DEBUG) || defined(_NMSP_MEMORY_POOL_CHECK_)
		*reinterpret_cast<BLOCK_TAIL_TYPE*>(reinterpret_cast<unsigned char*>(pNextBlock) + m_nRawBlockSize) = static_cast<BLOCK_TAIL_TYPE>(BLOCK_CHECK_DATA);
#endif
		pNextBlock = reinterpret_cast<CHUNK_TYPE*>(reinterpret_cast<unsigned char*>(pNextBlock) + m_nBlockSize);
		*ppCurBlock = pNextBlock;
		ppCurBlock = reinterpret_cast<CHUNK_TYPE**>(pNextBlock);
	}

	m_nFreeCount += (nNewAllocSize - m_nChunkHeadSize) / m_nBlockSize;

#if defined(_DEBUG) || defined(_NMSP_MEMORY_POOL_CHECK_)
	if (pNextBlock != pAvailableLastBlock)
	{
		return false;
	}

	// 마지막 블럭에도 넣어줘야 한다.
	*reinterpret_cast<BLOCK_TAIL_TYPE*>(reinterpret_cast<unsigned char*>(pNextBlock) + m_nRawBlockSize) = static_cast<BLOCK_TAIL_TYPE>(BLOCK_CHECK_DATA);

	CHUNK_TAIL_TYPE* pTail = reinterpret_cast<CHUNK_TAIL_TYPE*>(reinterpret_cast<unsigned char*>(pAvailableLastBlock) + m_nBlockSize);
	*pTail = CHUNK_CHECK_DATA;
#endif

	*ppCurBlock = nullptr;
	//

#if defined(_DEBUG) || defined(_NMSP_MEMORY_POOL_CHECK_)
	int nNextNewAllocSize = m_nChunkHeadSize + (m_nChunkSize << (m_nGrIdx + 1)) + GET_ALIGNMENT_BY_SIZE(MNGR_CHUNK_TAIL_TYPE_SIZE, MNGR_CHUNK_ALIGNMENT);
	if (CHUNK_MAX_SIZE < nNextNewAllocSize || 0 > nNextNewAllocSize)
	{
		m_nGrIdxExt++;
		return true;
	}
#else
	int nNextNewAllocSize = m_nChunkHeadSize + (m_nChunkSize << (m_nGrIdx + 1));
	if (CHUNK_MAX_SIZE < nNextNewAllocSize || 0 > nNextNewAllocSize)
	{
		m_nGrIdxExt++;
		return true;
	}
#endif

	m_nGrIdx++;

	return true;
}

template <class ALLOC, int t_nAlignment>
void*
mmgr_chunk<ALLOC, t_nAlignment>::Allocate()
{
	if (nullptr == m_pAvailableFirstBlock)
	{
		if (false == AddChunk())
		{
			return nullptr;
		}
	}

	//
	m_nAllocCount++;
	m_nFreeCount--;

	CHUNK_TYPE** ppNextBlock = reinterpret_cast<CHUNK_TYPE**>(m_pAvailableFirstBlock);
	m_pAvailableFirstBlock = *ppNextBlock;

	return reinterpret_cast<void*>(ppNextBlock);
}

template <class ALLOC, int t_nAlignment>
void
mmgr_chunk<ALLOC, t_nAlignment>::Deallocate(void* pBack)
{
	if (nullptr == pBack)
	{
		return;
	}

#if defined(_DEBUG) || defined(_NMSP_MEMORY_POOL_CHECK_)
	if (*reinterpret_cast<BLOCK_TAIL_TYPE*>(reinterpret_cast<unsigned char*>(pBack) + m_nRawBlockSize) != static_cast<BLOCK_TAIL_TYPE>(BLOCK_CHECK_DATA))
		*reinterpret_cast<BLOCK_TAIL_TYPE*>(nullptr) = static_cast<BLOCK_TAIL_TYPE>(BLOCK_CHECK_DATA);
#endif

	*(reinterpret_cast<CHUNK_TYPE**>(pBack)) = m_pAvailableFirstBlock;
	m_pAvailableFirstBlock = reinterpret_cast<CHUNK_TYPE*>(pBack);

	//
	m_nAllocCount--;
	m_nFreeCount++;
}

#if defined(_DEBUG) || defined(_NMSP_MEMORY_POOL_CHECK_)
template <class ALLOC, int t_nAlignment>
bool
mmgr_chunk<ALLOC, t_nAlignment>::CheckMemory()
{
	int nGrIdx = m_nGrIdx;
	int nGridxExt = m_nGrIdxExt;

	CHUNK_TYPE** ppFreeChunk = reinterpret_cast<CHUNK_TYPE**>(m_pAvailableLaskChunk);
	CHUNK_TYPE* pNextChunk;
	CHUNK_TAIL_TYPE* pTail;

	while (ppFreeChunk)
	{
		// nGridxExt는 CHUNK_MAX_SIZE이상으로 할당하고자 하는 메모리 블럭이 커지는 것을 막았기 떄문에...
		// m_nGrIdx이것으로는 사이즈를 표현할 수 없게 되었다.. nGridxExt를 사용하여 nGrIdx의 사이즈를 표현함과 동시에 동일 사이즈의 갯수를 파악하도록 했다
		if (0 < nGridxExt)
			nGridxExt--;
		else
			nGrIdx--;
		//

		pNextChunk = *ppFreeChunk;

		//
		pTail = reinterpret_cast<CHUNK_TAIL_TYPE*>(reinterpret_cast<unsigned char*>(ppFreeChunk) + m_nChunkHeadSize + (m_nChunkSize << nGrIdx));
		if (CHUNK_CHECK_DATA != *pTail)
		{
			return false;
		}
		//

		ppFreeChunk = reinterpret_cast<CHUNK_TYPE**>(pNextChunk);
	}

	if (0 != nGrIdx)
	{
		return false;
	}

	return true;
}
#endif

template <class ALLOC, int t_nAlignment>
typename mmgr_chunk<ALLOC, t_nAlignment>::CHKMEMORY
mmgr_chunk<ALLOC, t_nAlignment>::CheckMemory(void* pBack)
{
	int nGrIdx = m_nGrIdx;
	int nGridxExt = m_nGrIdxExt;

	CHUNK_TYPE** ppFreeChunk = reinterpret_cast<CHUNK_TYPE**>(m_pAvailableLaskChunk);
	CHUNK_TYPE* pNextChunk;
	CHUNK_TYPE* pHead;
	CHUNK_TYPE* pTail;

	while (ppFreeChunk)
	{
		// nGridxExt는 CHUNK_MAX_SIZE이상으로 할당하고자 하는 메모리 블럭이 커지는 것을 막았기 떄문에...
		// m_nGrIdx이것으로는 사이즈를 표현할 수 없게 되었다.. nGridxExt를 사용하여 nGrIdx의 사이즈를 표현함과 동시에 동일 사이즈의 갯수를 파악하도록 했다
		if (0 < nGridxExt)
			nGridxExt--;
		else
			nGrIdx--;
		//

		pNextChunk = *ppFreeChunk;

		//
		pHead = reinterpret_cast<CHUNK_TYPE*>(ppFreeChunk) + m_nChunkHeadSize;
		pTail = reinterpret_cast<CHUNK_TYPE*>(reinterpret_cast<CHUNK_TYPE*>(ppFreeChunk) + m_nChunkHeadSize + (m_nChunkSize << nGrIdx));
		//

		if (reinterpret_cast<CHUNK_TYPE*>(pHead) <= reinterpret_cast<CHUNK_TYPE*>(pBack) && reinterpret_cast<CHUNK_TYPE*>(pTail) > reinterpret_cast<CHUNK_TYPE*>(pBack))
		{
			if (0 != ((reinterpret_cast<CHUNK_TYPE*>(pBack) - reinterpret_cast<CHUNK_TYPE*>(pHead)) % m_nBlockSize))
			{
				return CHKMEMORY_INVALIDPOINTER;
			}

			return CHKMEMORY_OK;
		}
		//

		ppFreeChunk = reinterpret_cast<CHUNK_TYPE**>(pNextChunk);
	}

	return CHKMEMORY_NOFOUNDED;
}

////////////////////////////////////////////////////////////////////////////////
//
template <class ALLOC, int t_nAlignment = ALIGNMENT_DEFAULT_SIZE>
class mmgr
{
	typedef int MNGR_HEAD_TYPE;

	enum 
	{
		MNGR_ALIGNMENT = t_nAlignment,
		MNGR_HEAD_TYPE_SIZE = sizeof(MNGR_HEAD_TYPE)
	};

public:
	typedef mmgr_chunk<ALLOC, t_nAlignment> _MEM_CHUNK_T;
	typedef typename _MEM_CHUNK_T::CHKMEMORY _CHKMEMORY_T;

public:
	mmgr();
	virtual ~mmgr();

	bool Init(int nMinObjAlignmentSize, int nMaxObjAlignmentSize);
	void Uninit();
	void* Allocate(int nSize);
	void Deallocate(void* pBack);
	bool CheckMemory();
	typename _CHKMEMORY_T CheckMemory(void* pBack);
	int GetAllocationCount();
	int GetFreeCount();

public:
	inline bool IsInitialize() { return (0 != m_nMinObjAlignmentSize || 0 != m_nChunkObjectCount); }
	inline int GetCorruptCount() { return m_nCorruptCount; }

private:
	int m_nMinObjAlignmentSize;
	int m_nChunkObjectCount;
	int m_nMngrHeadSize;
	int m_nCorruptCount;
	_MEM_CHUNK_T* m_pChunk;
};

template <class ALLOC, int t_nAlignment>
mmgr<ALLOC, t_nAlignment>::mmgr()
{
	m_nMinObjAlignmentSize = 0;
	m_nChunkObjectCount = 0;
	m_nMngrHeadSize = 0;
	m_nCorruptCount = 0;
	m_pChunk = nullptr;
}

template <class ALLOC, int t_nAlignment>
mmgr<ALLOC, t_nAlignment>::~mmgr()
{
	if (m_pChunk)
	{
		ALLOC::template DestroyArray<mmgr_chunk<ALLOC, t_nAlignment>>(m_nChunkObjectCount, m_pChunk);
	}
}

template <class ALLOC, int t_nAlignment>
bool
mmgr<ALLOC, t_nAlignment>::Init(int nRawMinObjAlignmentSize, int nRawMaxObjAlignmentSize)
{
	if (0 != m_nChunkObjectCount)
	{
		return false;
	}

	// 움.. 아무래도 헤더 사이즈를 넣어서 만드는게 이치에 맞는듯 해서..
	int nMinObjAlignmentSize = GET_ALIGNMENT_BY_SIZE(nRawMinObjAlignmentSize + MNGR_HEAD_TYPE_SIZE, MNGR_ALIGNMENT);
	//nMinObjAlignmentSize += GET_ALIGNMENT_BY_SIZE(MNGR_HEAD_TYPE_SIZE, MNGR_ALIGNMENT);
	int nMaxObjAlignmentSize = GET_ALIGNMENT_BY_SIZE(nRawMaxObjAlignmentSize + MNGR_HEAD_TYPE_SIZE, MNGR_ALIGNMENT);
	//nMaxObjAlignmentSize += GET_ALIGNMENT_BY_SIZE(MNGR_HEAD_TYPE_SIZE, MNGR_ALIGNMENT);

	//
	int nCount = GET_OFFSETCOUNT(nMaxObjAlignmentSize, nMinObjAlignmentSize);
	if (0 >= nCount)
	{
		return false;
	}

	m_pChunk = ALLOC::template CreateArray<mmgr_chunk<ALLOC, t_nAlignment>>(nCount);
	if (nullptr == m_pChunk)
	{
		return false;
	}

	//
	int nNewMaxObjAlignmentSize = nCount * nMinObjAlignmentSize;

	for (int nStep = 0; nStep < nCount; nStep++)
	{
		if (false == m_pChunk[nStep].Init((nStep + 1) * nMinObjAlignmentSize, nNewMaxObjAlignmentSize << 1))
		{
			return false;
		}
	}
	//

	m_nChunkObjectCount = nCount;
	m_nMinObjAlignmentSize = nMinObjAlignmentSize;
	m_nMngrHeadSize = GET_ALIGNMENT_BY_SIZE(MNGR_HEAD_TYPE_SIZE, MNGR_ALIGNMENT);

	return true;
}

template <class ALLOC, int t_nAlignment>
void
mmgr<ALLOC, t_nAlignment>::Uninit()
{
	for (int nStep = 0; nStep < m_nChunkObjectCount; nStep++)
	{
		m_pChunk[nStep].Uninit();
	}
}

template <class ALLOC, int t_nAlignment>
void*
mmgr<ALLOC, t_nAlignment>::Allocate(int nSize)
{
	if (0 == m_nChunkObjectCount)
	{
		return nullptr;
	}

	if (0 > nSize)
	{
		return nullptr;
	}

	if (0 == nSize)
	{
		nSize = 1;
	}

	//
	int nRealSize = m_nMngrHeadSize + nSize;
	int nRealIndex = GET_OFFSETCOUNT(nRealSize, m_nMinObjAlignmentSize) - 1;

	//
	void* pReturn;
	//

	if (nRealIndex >= m_nChunkObjectCount)
	{
		pReturn = ALLOC::CreateMemory(nRealSize);
		if (nullptr == pReturn)
		{
			return nullptr;
		}

		*(reinterpret_cast<MNGR_HEAD_TYPE*>(pReturn)) = static_cast<MNGR_HEAD_TYPE>(MMGR_POOLINDEX_NULL);
	}
	else
	{
		// 디버깅 코드... (메모리 관리자의 중요성을 고려해서..)
#if defined(_DEBUG) || defined(_NMSP_MEMORY_POOL_CHECK_)
		if  (!(0 <= nRealIndex && nRealIndex < m_nChunkObjectCount)) (m_nCorruptCount)++; 
		assert(0 <= nRealIndex && nRealIndex < m_nChunkObjectCount);

		if  (!(nRealSize <= m_pChunk[nRealIndex].GetBlockSize())) (m_nCorruptCount)++;
		assert(nRealSize <= m_pChunk[nRealIndex].GetBlockSize());
#else
		if  (!(0 <= nRealIndex && nRealIndex < m_nChunkObjectCount)) (m_nCorruptCount)++;
		if  (!(nRealSize <= m_pChunk[nRealIndex].GetBlockSize())) (m_nCorruptCount)++;
#endif
		//

		pReturn = m_pChunk[nRealIndex].Allocate();
		if (nullptr == pReturn)
		{
			return nullptr;
		}

		*(reinterpret_cast<MNGR_HEAD_TYPE*>(pReturn)) = nRealIndex;
	}

	return (reinterpret_cast<unsigned char*>(pReturn) + m_nMngrHeadSize);
}

template <class ALLOC, int t_nAlignment>
void
mmgr<ALLOC, t_nAlignment>::Deallocate(void* pBack)
{
	if (0 == m_nChunkObjectCount)
	{
		return;
	}

	if (nullptr == pBack)
	{
		return;
	}

	void* pOrignLoc = reinterpret_cast<unsigned char*>(pBack) - m_nMngrHeadSize;
	int nRealIndex = *(reinterpret_cast<MNGR_HEAD_TYPE*>(pOrignLoc));

	if (static_cast<MNGR_HEAD_TYPE>(MMGR_POOLINDEX_NULL) == nRealIndex)
	{
		ALLOC::DestroyMemory(reinterpret_cast<unsigned char*>(pOrignLoc));
		return;
	}

	// 디버깅 코드... (메모리 관리자의 중요성을 고려해서..)
#if defined(_DEBUG) || defined(_NMSP_MEMORY_POOL_CHECK_)
	if (!(0 <= nRealIndex && nRealIndex < m_nChunkObjectCount)) (m_nCorruptCount)++;
	assert((0 <= nRealIndex && nRealIndex < m_nChunkObjectCount));
#else
	if (!(0 <= nRealIndex && nRealIndex < m_nChunkObjectCount)) (m_nCorruptCount)++;
#endif
	//

	m_pChunk[nRealIndex].Deallocate(pOrignLoc);
}

template <class ALLOC, int t_nAlignment>
bool
mmgr<ALLOC, t_nAlignment>::CheckMemory()
{
#if defined(_DEBUG) || defined(_NMSP_MEMORY_POOL_CHECK_)
	for (int nStep = 0; nStep < m_nChunkObjectCount; nStep++)
	{
		if (false == m_pChunk[nStep].CheckMemory())
		{
			return false;
		}
	}
#endif

	return true;
}

template <class ALLOC, int t_nAlignment>
typename mmgr<ALLOC, t_nAlignment>::_CHKMEMORY_T
mmgr<ALLOC, t_nAlignment>::CheckMemory(void* pBack)
{
	void* pOrignLoc = reinterpret_cast<unsigned char*>(pBack) - m_nMngrHeadSize;
	int nRealIndex = *(reinterpret_cast<MNGR_HEAD_TYPE*>(pOrignLoc));

	if (0 <= nRealIndex && nRealIndex < m_nChunkObjectCount)
	{
		return m_pChunk[nRealIndex].CheckMemory(pOrignLoc);
	}
	else
	if (MMGR_POOLINDEX_NULL == nRealIndex)
	{
		return _MEM_CHUNK_T::CHKMEMORY_OK;
	}

	return _MEM_CHUNK_T::CHKMEMORY_NOFOUNDED;
}

template <class ALLOC, int t_nAlignment>
int
mmgr<ALLOC, t_nAlignment>::GetAllocationCount()
{
	int nTotal = 0;

	for (int nStep = 0; nStep < m_nChunkObjectCount; nStep++)
	{
		nTotal += m_pChunk[nStep].GetAllocationCount();
	}

	return nTotal;
}

template <class ALLOC, int t_nAlignment>
int
mmgr<ALLOC, t_nAlignment>::GetFreeCount()
{
	int nTotal = 0;

	for (int nStep = 0; nStep < m_nChunkObjectCount; nStep++)
	{
		nTotal += m_pChunk[nStep].GetFreeCount();
	}

	return nTotal;
}

////////////////////////////////////////////////////////////////////////////////
//
template <class T, class ALLOC = default_allocator, int t_lChunkSize = CHUNK_DEFAULT_SIZE, int t_nAlignment = ALIGNMENT_DEFAULT_SIZE>
class mmgr_obj
{
public:
	mmgr_obj()
	{
	}
	virtual ~mmgr_obj()
	{
	}

	static inline void * operator new (size_t tSize)
	{
		if (false == m_cPoolT.IsInitialize())
		{
			GetAllocator().Init(sizeof(T), t_lChunkSize);
		}
#ifdef __MMGR_ARRAY_OBJECT_
		return GetAllocator().Allocate(static_cast<int>(tSize));
#else
		return GetAllocator().Allocate();
#endif
	}

	static inline void	operator delete(void* pBack)
	{
		GetAllocator().Deallocate(pBack);
	}

#ifdef __MMGR_ARRAY_OBJECT_
	static inline void * operator new [] (size_t tSize)
	{
		if (false == GetAllocator().IsInitialize())
		{
			GetAllocator().Init(sizeof(T), t_lChunkSize);
		}

		return GetAllocator().Allocate(static_cast<int>(tSize));
	}

	static inline void	operator delete[] (void* pBack)
	{
		GetAllocator().Deallocate(pBack);
	}
#endif

	static inline bool CheckMemory()
	{
#if defined(_DEBUG) || defined(_NMSP_MEMORY_POOL_CHECK_)
		return GetAllocator().CheckMemory();
#else
		return true;
#endif
	}

private:
#ifdef __MMGR_ARRAY_OBJECT_
	static inline mmgr<ALLOC, t_nAlignment>& GetAllocator()
	{
		static mmgr<ALLOC, t_nAlignment> m_cPoolT;
		return m_cPoolT;
	}
#else
	static inline mmgr_chunk<ALLOC, t_nAlignment>& GetAllocator()
	{
		static mmgr_chunk<ALLOC, t_nAlignment> m_cPoolT;
	}
#endif
};

}		// namespace nmsp

#endif
