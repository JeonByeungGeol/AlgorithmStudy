////////////////////////////////////////////////////////////////////////////////
// �ۼ���: huelee
// ��  ��:
//
//

// ȣȯ���� ���ؼ�..
#pragma once
#ifndef __NMSPNODES_H__
#define __NMSPNODES_H__

//
namespace nmsp {

//
class node 
{
public:
	node()
	{
		m_pcPrev = nullptr; 
		m_pcNext = nullptr; 
	}
	virtual ~node() {}

public:
	virtual int AddRef() = 0;
	virtual int Release() = 0;
	virtual int CompareTo(const node *pcNode) = 0;

public:
	inline node* GetPrev() { return m_pcPrev; }
	inline node* GetNext() { return m_pcNext; }
	inline void SetPrev(node *pcPrev) { m_pcPrev = pcPrev; }
	inline void SetNext(node *pcNext) { m_pcNext = pcNext; }
	inline void Reset() 
	{ 
		m_pcPrev = nullptr; 
		m_pcNext = nullptr; 
	}

private:
	node *m_pcPrev;
	node *m_pcNext;
};

////////////////////////////////////////////////////////////////////////////////
//
class both_list
{
public:
	both_list::both_list()
		:m_pcBegin(nullptr)
		, m_pcEnd(nullptr)
	{
		m_nCount = 0;
	}
	virtual ~both_list()
	{
		node *pcTmp;
		node* pcCurrent = GetBegin();

		while (pcCurrent)
		{
			pcTmp = pcCurrent->GetNext();
			pcCurrent->Release();

			pcCurrent = pcTmp;
		}
	}

public:
	void AddAtFirst(node* pcNode)
	{
		pcNode->Reset();

		if (nullptr == m_pcBegin &&
			nullptr == m_pcEnd)
		{
			m_pcBegin = pcNode;
			m_pcEnd = pcNode;
		}
		else
		{
			pcNode->SetNext(m_pcBegin);
			m_pcBegin->SetPrev(pcNode);
			m_pcBegin = pcNode;
		}

		m_nCount++;
	}
	void Add(node* pcNode)
	{
		pcNode->Reset();

		if (nullptr == m_pcBegin &&
			nullptr == m_pcEnd)
		{
			m_pcBegin = pcNode;
			m_pcEnd = pcNode;
		}
		else
		{
			m_pcEnd->SetNext(pcNode);
			pcNode->SetPrev(m_pcEnd);
			m_pcEnd = pcNode;
		}

		m_nCount++;
	}
	void Delete(const node* pcNode)
	{
		node* pcDelNode = DelWithLive(pcNode);
		if (pcDelNode)
		{
			pcDelNode->Release();
		}
	}
	void DeletePtr(node* pcNode)
	{
		node* pcDelNode = DelWithLiveInPtr(pcNode);
		if (pcDelNode)
		{
			pcDelNode->Release();
		}
	}
	node* DelWithLive(const node* pcNode)
	{
		node* pcDelNode;

		if (nullptr == pcNode ||
			nullptr == (pcDelNode = Find(pcNode)))
		{
			return (nullptr);
		}

		node* pcPrev = pcDelNode->GetPrev();
		node* pcNext = pcDelNode->GetNext();

		if (nullptr != pcPrev &&
			nullptr != pcNext)
		{
			pcNext->SetPrev(pcPrev);
			pcPrev->SetNext(pcNext);
		}
		else
			if (nullptr != pcPrev &&
				nullptr == pcNext)
			{
				m_pcEnd = pcPrev;
				pcPrev->SetNext(nullptr);
			}
			else
				if (nullptr == pcPrev &&
					nullptr != pcNext)
				{
					m_pcBegin = pcNext;
					pcNext->SetPrev(nullptr);
				}
				else
				{
					m_pcBegin = nullptr;
					m_pcEnd = nullptr;
				}

		m_nCount--;

		return (pcDelNode);
	}
	node* DelWithLiveInPtr(node* pcDelNodePtr)
	{
		if (nullptr == pcDelNodePtr)
		{
			return (nullptr);
		}

		node* pcPrev = pcDelNodePtr->GetPrev();
		node* pcNext = pcDelNodePtr->GetNext();

		if (nullptr != pcPrev &&
			nullptr != pcNext)
		{
			pcNext->SetPrev(pcPrev);
			pcPrev->SetNext(pcNext);
		}
		else
			if (nullptr != pcPrev &&
				nullptr == pcNext)
			{
				m_pcEnd = pcPrev;
				pcPrev->SetNext(nullptr);
			}
			else
				if (nullptr == pcPrev &&
					nullptr != pcNext)
				{
					m_pcBegin = pcNext;
					pcNext->SetPrev(nullptr);
				}
				else
				{
					m_pcBegin = nullptr;
					m_pcEnd = nullptr;
				}

		m_nCount--;

		return (pcDelNodePtr);
	}
	void Reset()
	{
		node *pcTmp;
		node* pcCurrent = GetBegin();

		while (pcCurrent)
		{
			pcTmp = pcCurrent->GetNext();
			pcCurrent->Release();

			pcCurrent = pcTmp;
		}

		m_pcBegin = nullptr;
		m_pcEnd = nullptr;

		m_nCount = 0;
	}
	node* Find(const node* pcNode)
	{
		node* pcCurr = GetBegin();

		while (pcCurr)
		{
			if (!pcCurr->CompareTo(pcNode))
			{
				return pcCurr;
			}

			pcCurr = pcCurr->GetNext();
		}

		return (nullptr);
	}
	node* DelBeginWithLive()
	{
		node* pcDelNode = m_pcBegin;
		if (nullptr == pcDelNode)
		{
			return nullptr;
		}

		node* pcNext = pcDelNode->GetNext();

		if (nullptr != pcNext)
		{
			m_pcBegin = pcNext;
			pcNext->SetPrev(nullptr);
		}
		else
		{
			m_pcBegin = nullptr;
			m_pcEnd = nullptr;
		}

		m_nCount--;

		return (pcDelNode);
	}
	node* DelEndWithLive()
	{
		node* pcDelNode = m_pcEnd;
		if (nullptr == pcDelNode)
		{
			return nullptr;
		}

		node* pcPrev = pcDelNode->GetPrev();

		if (nullptr != pcPrev)
		{
			m_pcEnd = pcPrev;
			pcPrev->SetNext(nullptr);
		}
		else
		{
			m_pcBegin = nullptr;
			m_pcEnd = nullptr;
		}

		m_nCount--;

		return (pcDelNode);
	}

public:
	// ������ �Լ����� �Ҹ��ڿ��� ȣ���ϱ� ������.. �����Լ��� ������ �Ǹ� �ȵ˴ϴ�..
	inline node* GetBegin() { return m_pcBegin; }
	inline node* GetEnd() { return m_pcEnd; }
	inline bool IsEmpty() { return ((nullptr == m_pcBegin)?true:false); }
	inline int GetCount() { return m_nCount; }

private:
	node* m_pcBegin;
	node* m_pcEnd;

private:
	int m_nCount;
};

////////////////////////////////////////////////////////////////////////////////
//
template<class T, class ALLOC>
class queue
{
public:
	queue();
	virtual ~queue();

public:
	bool Init();
	void Uninit();
	bool Push(T tData);
	bool Pop(T* ptData);
	bool Find(T tData);

public:
	inline void Clear() { m_nHead = m_nTail = 0; }
	inline bool Empty() { return ((m_nHead == m_nTail) ? true : false); }
	inline void SetSize(int nSize) { m_nMaxSize = nSize + 1; }
	inline int GetSize() { return m_nMaxSize; }
	inline int GetCount() { return m_nCount; }

private:
	int m_nMaxSize;
	int m_nHead;
	int m_nTail;
	int m_nCount;

private:
	T* m_pQueueData;
};

// 
template<class T, class ALLOC>
queue<T, ALLOC>::queue()
{
	m_nMaxSize = 0;
	m_nHead = 0;
	m_nTail = 0;
	m_nCount = 0;
	m_pQueueData = nullptr;
}

template<class T, class ALLOC>
queue<T, ALLOC>::~queue()
{
	if (m_pQueueData)
	{
		ALLOC::DestroyMemory(m_pQueueData);
		m_pQueueData = nullptr;
	}
}

template<class T, class ALLOC>
bool
queue<T, ALLOC>::Init()
{
	if (0 >= m_nMaxSize)
	{
		return false;
	}

	m_pQueueData = reinterpret_cast<T*>(ALLOC::CreateMemory(sizeof(T) * m_nMaxSize));
	if (nullptr == m_pQueueData)
	{
		return false;
	}

	m_nHead = 0;
	m_nTail = 0;
	m_nCount = 0;

	return true;
}

template<class T, class ALLOC>
void
queue<T, ALLOC>::Uninit()
{
	if (m_pQueueData)
	{
		ALLOC::DestroyMemory(m_pQueueData);
		m_pQueueData = nullptr;
	}

	m_nHead = 0;
	m_nTail = 0;
	m_nCount = 0;
}

template<class T, class ALLOC>
bool
queue<T, ALLOC>::Push(T tData)
{
	int nTmpHead = (m_nHead + 1) % m_nMaxSize;

	if (nTmpHead == m_nTail)
	{
		return false;
	}

	m_pQueueData[m_nHead] = tData;
	m_nHead = nTmpHead;
	m_nCount++;

	return true;
}

template<class T, class ALLOC>
bool
queue<T, ALLOC>::Pop(T* ptData)
{
	if (m_nHead == m_nTail)
	{
		return false;
	}

	*ptData = m_pQueueData[m_nTail];
	m_nTail = (m_nTail + 1) % m_nMaxSize;
	m_nCount--;

	return true;
}

template<class T, class ALLOC>
bool
queue<T, ALLOC>::Find(T tData)
{
	int nHead = m_nHead;
	int nTail = m_nTail;

	while (nHead != nTail)
	{
		if (tData == m_pQueueData[nTail])
		{
			return true;
		}

		nTail = (nTail + 1) % m_nMaxSize;
	}

	return false;
}

} // nmsp

#endif
