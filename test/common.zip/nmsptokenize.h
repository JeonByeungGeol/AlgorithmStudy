﻿////////////////////////////////////////////////////////////////////////////////
//
// 작성자 : huelee
// 설  명 : 
//

#pragma once
#ifndef __NMSPTOKENIZE_H__
#define __NMSPTOKENIZE_H__

namespace nmsp {

// 기본형
template <typename ALLOC, typename T = char>
class tokenize;

// ansi형
template <typename ALLOC>
class tokenize<ALLOC, char>
{
public:
	using  _allocator_t = ALLOC;
	struct tokeninfo
	{
		const char* m_token;
		int m_len;
	};
	using _tokens_t = std::vector<tokeninfo, stl_default_allocator<tokeninfo,_allocator_t>>;

public:
	static void Tokenize(_tokens_t& vecToken, int len, const char* tokenStr, char symbol)
	{
		int leftLen = len;
		const char* ptrToken = tokenStr;

		while (leftLen > 0)
		{
			tokeninfo token;

			token.m_token = ptrToken;
			token.m_len = GetTokenString(ptrToken, leftLen, symbol);
			
			ptrToken += (token.m_len + 1);
			leftLen -= (token.m_len + 1);

			vecToken.push_back(token);
		}
	}

private:
	static int GetTokenString(const char* src, int len, char symbol)
	{
		int cnt = 0;

		for(int nI = 0; nI < len; nI++)
		{
			if (src[nI] == symbol) 
				break;

			cnt++;
		}

		return (cnt);
	}
};

// unicode형
template <typename ALLOC>
class tokenize<ALLOC, wchar_t>
{
public:
	using _allocator_t = ALLOC;
	struct tokeninfo
	{
		const wchar_t* m_pwchToken;
		int m_len;
	};
	using _tokens_t = std::vector<tokeninfo, stl_default_allocator<tokeninfo,_allocator_t>>;

public:
	static void Tokenize(_tokens_t& vecToken, int len, const wchar_t* tokenStr, wchar_t symbol)
	{
		int leftLen = len;
		const wchar_t* ptrToken = tokenStr;

		while (leftLen > 0)
		{
			tokeninfo token;

			token.m_token = ptrToken;
			token.m_len = GetTokenString(ptrToken, leftLen, symbol);
			
			ptrToken += (token.m_len + 1);
			leftLen -= (token.m_len + 1);

			vecToken.push_back(token);
		}
	}

private:
	static int GetTokenString(const wchar_t* src, int len, wchar_t symbol)
	{
		int cnt = 0;

		for(int nI = 0; nI < len; nI++)
		{
			if (src[nI] == symbol) 
				break;

			cnt++;
		}

		return (cnt);
	}
};

} // namespace __NMSPTOKENIZE_H__

#endif
