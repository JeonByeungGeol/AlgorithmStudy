﻿#pragma once
#ifndef __NMSPSTOPWATCH_H__
#define __NMSPSTOPWATCH_H__

namespace nmsp
{
template <typename ReturnType, typename TimeType, typename Clock>
class stop_watch
{
public:
	using _timepoint_t = typename Clock::time_point;

	stop_watch();

	void Start();

	ReturnType Stop();
	ReturnType Lap();
	ReturnType LapAndRestart();
	void Reset();

private:
	bool is_start_;
	_timepoint_t start_;
};

template <typename ReturnType, typename TimeType, typename Clock>
stop_watch<ReturnType, TimeType, Clock>::stop_watch()
{
	Start();
}

template <typename ReturnType, typename TimeType, typename Clock>
void stop_watch<ReturnType, TimeType, Clock>::Start()
{
	start_ = Clock::now();

	is_start_ = true;
}

template <typename ReturnType, typename TimeType, typename Clock>
ReturnType stop_watch<ReturnType, TimeType, Clock>::Lap()
{
	if (is_start_ == false)
		return ReturnType();

	using namespace std::chrono;
	auto fp = duration_cast<TimeType>(Clock::now() - start_);
	return fp.count();// / TimeType::den;
}

template <typename ReturnType, typename TimeType, typename Clock>
ReturnType stop_watch<ReturnType, TimeType, Clock>::LapAndRestart()
{
	using namespace std::chrono;

	ReturnType elapsedTime = 0;
	if (is_start_ == true)
	{
		auto fp = duration_cast<TimeType>(Clock::now() - start_);
		elapsedTime = fp.count();// / TimeType::den;
	}

	Start();

	return elapsedTime;
}

template <typename ReturnType, typename TimeType, typename Clock>
ReturnType stop_watch<ReturnType, TimeType, Clock>::Stop()
{
	if (is_start_ == false)
		return ReturnType();

	ReturnType v = Lap();

	is_start_ = false;

	return v;
}

template <typename ReturnType, typename TimeType, typename Clock>
void stop_watch<ReturnType, TimeType, Clock>::Reset()
{
	Start();
}

//using stop_watchS = stop_watch<uint64_t, std::ratio<1>, std::chrono::system_clock>;

using _stop_watch_t = stop_watch<uint64_t, std::chrono::milliseconds, std::chrono::high_resolution_clock>;
using _stop_watch_mic_t = stop_watch<uint64_t, std::chrono::microseconds, std::chrono::high_resolution_clock>;
} // end namespace nmsp

#endif // end __STOPWATCH_H__