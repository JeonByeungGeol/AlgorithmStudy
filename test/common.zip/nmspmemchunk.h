////////////////////////////////////////////////////////////////////////////////
// �ۼ���: huelee
// ��  ��:
//
//

// ȣȯ���� ���ؼ�..
#pragma once
#ifndef __NMSPMEMCHUNK_H__
#define __NMSPMEMCHUNK_H__

//
namespace nmsp {

////////////////////////////////////////////////////////////////////////////////
//
template <class ALLOC>
class memory_chunk
{
	enum
	{
		MEMCHUNK_DEFAULT_SIZE = 1024,
		MEMCHUNK_DEFAULT_EXTSIZE = 1024,
	};

public:
	typedef ALLOC _ALLOC_T;

private:
	typedef memory_chunk<_ALLOC_T> _THIS_T;

public:
	memory_chunk();
	memory_chunk(const _THIS_T& _x);
	virtual ~memory_chunk();

	bool Init(int nSize = MEMCHUNK_DEFAULT_SIZE, int nExtSize = MEMCHUNK_DEFAULT_EXTSIZE);
	void Uninit();
	bool Ext(int nSize);

public:
	void operator = (const _THIS_T& _x);

public:
	inline void* GetMemChunk() { return m_pMem; }
	inline int GetMemChunkSize() { return m_nMemSize; } 
	inline int GetMemExtSize() { return m_nExtSize; }
	inline void SetMemExtSize(int nExtSize) { m_nExtSize = nExtSize; }

private:
	int m_nMemSize;
	int m_nExtSize;
	void* m_pMem;
};

template <class ALLOC>
memory_chunk<ALLOC>::memory_chunk()
{
	m_nMemSize = 0;
	m_nExtSize = MEMCHUNK_DEFAULT_EXTSIZE;
	m_pMem = nullptr;
}

template <class ALLOC>
memory_chunk<ALLOC>::memory_chunk(const _THIS_T& _x)
{
	m_pMem = reinterpret_cast<void*>(ALLOC::CreateMemory(_x.m_nMemSize));
	if (nullptr == m_pMem)
	{
		m_nMemSize = 0;
		m_nExtSize = _x.m_nExtSize;
		return;
	}
	else
	{
		m_nMemSize = _x.m_nMemSize;
		m_nExtSize = _x.m_nExtSize;

		memcpy(m_pMem, _x.m_pMem, _x.m_nMemSize);
	}
}

template <class ALLOC>
memory_chunk<ALLOC>::~memory_chunk()
{
	if (m_pMem)
	{
		ALLOC::DestroyMemory(reinterpret_cast<void*>(m_pMem));
		m_pMem = nullptr;
	}
}

template <class ALLOC>
bool
memory_chunk<ALLOC>::Init(int nSize, int nExtSize)
{
	m_pMem = reinterpret_cast<void*>(ALLOC::CreateMemory(nSize));
	if (nullptr == m_pMem)
	{
		return false;
	}

	m_nMemSize = nSize;
	m_nExtSize = nExtSize;

	return true;
}

template <class ALLOC>
void
memory_chunk<ALLOC>::Uninit()
{
	m_nMemSize = 0;

	if (m_pMem)
	{
		ALLOC::DestroyMemory(reinterpret_cast<void*>(m_pMem));
		m_pMem = nullptr;
	}
}

//
// �̰��� �޸� ����� Ȯ���Ѵ�. ������.. ������ �޸𸮿� �����ϴ� �����͸� ���ο� �������� �޸𸮷�
// ������ ���� �ʴ� ���̴�. ���� �����ؾ� �Ѵ�.
//
template <class ALLOC>
bool
memory_chunk<ALLOC>::Ext(int nSize)
{
	if (m_nMemSize < nSize)
	{
		void* pResizeMem = ALLOC::RecreateMemory(reinterpret_cast<void*>(m_pMem), 0, m_nExtSize + nSize);
		if (nullptr == pResizeMem)
		{
			return false;
		}

		m_nMemSize = m_nExtSize + nSize;
		m_pMem = pResizeMem;
	}

	return true;
}

template <class ALLOC>
void 
memory_chunk<ALLOC>::operator = (const _THIS_T& _x)
{
	if (m_pMem)
	{
		ALLOC::DestroyMemory(reinterpret_cast<void*>(m_pMem));
	}

	m_pMem = reinterpret_cast<void*>(ALLOC::CreateMemory(_x.m_nMemSize));
	if (nullptr == m_pMem)
	{
		m_nMemSize = 0;
		m_nExtSize = _x.m_nExtSize;
		return;
	}
	else
	{
		m_nMemSize = _x.m_nMemSize;
		m_nExtSize = _x.m_nExtSize;

		memcpy(m_pMem, _x.m_pMem, _x.m_nMemSize);
	}
}

}		// namespace nmsp

#endif
