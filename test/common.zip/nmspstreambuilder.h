﻿#pragma once
#ifndef __NMSPSTREAMBUILDER_H__
#define __NMSPSTREAMBUILDER_H__

#include <iostream>
#include <string>
#include <tchar.h>
#include <codecvt>

#include <map>
#include <unordered_map>
#include <vector>
#include <list>
#include <tuple>
#include <utility>

#include <atomic>
#include <chrono>
#include <type_traits>

namespace nmsp {
	namespace streambuilder {

#define __OPTIMIZE__ 0
#ifdef __OPTIMIZE__
#pragma optimize("", off)
#endif

#define LOG_TYPENAME(type) << ", type_name:" << typeid(type).name()

#define LOG_WRITE_FIRST std::cout << "Write error line:" << __LINE__ << ", time:" << now() << ", func:[" << __FUNCTION__ << "]"
#define LOG_WRITE_EXCEPTION(ex) << ", msg=[" << ex.what() << "]"
#define LOG_WRITE_LAST << ", m_BufferLen:" << m_BufferLen << ", m_WritePos:" << m_WritePos << ", nCount:" << nCount << std::endl
#define LOG_WRITE_FORMAT_EXCEPTION(ex, type) LOG_WRITE_FIRST LOG_WRITE_EXCEPTION(ex) LOG_TYPENAME(type) LOG_WRITE_LAST
#define LOG_WRITE_FORMAT(type) LOG_WRITE_FIRST LOG_TYPENAME(type) LOG_WRITE_LAST


#define LOG_READ_FIRST std::cout << "Read error line:" << __LINE__ << ", time:" << now() << ", func:[" << __FUNCTION__ << "]"
#define LOG_READ_EXCEPTION(ex) << ", msg=[" << ex.what() << "]"
#define LOG_READ_LAST << ", m_BufferLen:" << m_BufferLen << ", m_ReadPos:" << m_ReadPos << ", nCount:" << nCount << std::endl
#define LOG_READ_FORMAT_EXCEPTION(ex, type) LOG_READ_FIRST LOG_READ_EXCEPTION(ex) LOG_TYPENAME(type) LOG_READ_LAST
#define LOG_READ_FORMAT(type) LOG_READ_FIRST LOG_TYPENAME(type) LOG_READ_LAST

		enum
		{
			DEFAULT_BLOCK_SIZE = 2048,
		};

		template<class _ALLOC, uint64_t _alloc_block_size_t = DEFAULT_BLOCK_SIZE>
		class stream_builder_base
		{
		public:
			using _allocator_t = _ALLOC;

		public:
			stream_builder_base()
				: m_bMyCreate(false), m_BufferLen(0), m_pszData(nullptr), m_WritePos(0), m_ReadPos(0)
			{
			}
			stream_builder_base(const stream_builder_base & ref)
				: m_bMyCreate(false), m_BufferLen(0), m_pszData(nullptr), m_WritePos(0), m_ReadPos(0)
			{
				FromStream(ref.m_pszData, ref.m_BufferLen, ref.m_bMyCreate);
				m_WritePos = ref.m_WritePos;
				m_ReadPos = ref.m_ReadPos;
			}

			virtual ~stream_builder_base()
			{
				Clear();
			}

			static time_t now()
			{
				using namespace std::chrono;

				return duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
			}

			stream_builder_base& operator=(const stream_builder_base & ref)
			{
				if (this == &ref)
					return *this;
				FromStream(ref.m_pszData, ref.m_BufferLen, ref.m_bMyCreate);
				return *this;
			}

			unsigned char * AllocMemory(uint64_t tSize)
			{
				unsigned char * ret = reinterpret_cast<unsigned char*>(_allocator_t::CreateMemory(static_cast<int32_t>(tSize)));
				if (ret == nullptr)
					throw std::bad_alloc();

				//memset(ret, 0x00, tSize);
				return ret;
			}
			void ReAllocMemory(uint64_t size)
			{
				if (m_pszData == nullptr)
				{
					if (m_BufferLen == 0)
						m_BufferLen = size > _alloc_block_size_t ? ((size / _alloc_block_size_t) + 1) * _alloc_block_size_t : _alloc_block_size_t;
					m_pszData = AllocMemory(m_BufferLen);
					m_bMyCreate = true;
					m_WritePos = 0;
					m_ReadPos = 0;
				}
				else
				{
					uint64_t add_size = size > _alloc_block_size_t ? ((size / _alloc_block_size_t) + 1) * _alloc_block_size_t : _alloc_block_size_t;
					unsigned char * temp = AllocMemory(m_BufferLen + add_size);
					memcpy(temp, m_pszData, m_BufferLen);
					if (m_bMyCreate == true)
					{
						_allocator_t::DestroyMemory(reinterpret_cast<void *>(m_pszData));
					}
					m_BufferLen += add_size;
					m_pszData = temp;
					m_bMyCreate = true;
				}
			}

			void Clear()
			{
				if (m_bMyCreate == true)
				{
					if (m_pszData != nullptr)
					{
						_allocator_t::DestroyMemory(reinterpret_cast<void *>(m_pszData));
					}
				}
				m_bMyCreate = false;
				m_pszData = nullptr;
				m_BufferLen = 0;

				m_WritePos = 0;
				m_ReadPos = 0;
			}

			bool FromStream(unsigned char * pszData, uint64_t nBufferLen, bool is_copy)
			{
				Clear();

				if (pszData == nullptr || nBufferLen <= 0)
					return false;

				m_BufferLen = nBufferLen;
				if (is_copy == true)
				{
					ReAllocMemory(nBufferLen);
					memcpy(m_pszData, pszData, m_BufferLen);
				}
				else
				{
					m_pszData = pszData;
				}

				return true;
			}

			unsigned char * GetStream()
			{
				return m_pszData;
			}

			uint64_t GetStramSize()
			{
				return m_WritePos;
			}

		protected:
			bool					m_bMyCreate;

			uint64_t				m_BufferLen;		//!< 버퍼 크기.
			unsigned char			* m_pszData;		//!< 버퍼.

			uint64_t				m_WritePos;			//!< write 한 offset.
			uint64_t				m_ReadPos;			//!< read 한 offset.
		};

		template<class _ALLOC> class stream_builder;

		template<class _ALLOC>
		struct IStreambuilderObject
		{
			virtual bool ReadWriteStream(stream_builder<_ALLOC> & builder, bool bRead) = 0;
		};

		template<class _ALLOC>
		class stream_builder : public stream_builder_base<_ALLOC>
		{
		public:
			stream_builder() : stream_builder_base()
			{
			}
			virtual ~stream_builder()
			{
			}

			void MoveFirst(bool bRead) { bRead == false ? m_WritePos = 0 : m_ReadPos = 0; }

			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

			template<typename Func, typename Tuple, std::size_t ...Is>
			Tuple Tuple_Impl(bool & ret, Func& func, Tuple& tuple, std::index_sequence<Is...>)
			{
				return std::make_tuple(func(ret, std::get<Is>(tuple))...);
			}
			template<typename Func, typename... Args>
			std::tuple<Args...> ReadWriteTuple(bool & ret, Func& func, std::tuple<Args...>& tuple)
			{
				return Tuple_Impl(ret, func, tuple, std::index_sequence_for<Args...>{});
				//return Tuple_Impl(ret, func, tuple, std::make_index_sequence<std::tuple_size<std::tuple<Args...>>::value>{});
			}

			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

			//template<typename T> bool Write(T & val)
			template<typename T, typename std::enable_if<std::is_standard_layout<T>::value>::type* = nullptr> bool Write(T & val)
			{
				uint64_t nOldWritePos = m_WritePos;
				int32_t nCount = static_cast<int32_t>(sizeof(T));
				try
				{
					if (m_pszData == nullptr || m_BufferLen < m_WritePos + nCount + sizeof(int32_t))
						ReAllocMemory(m_WritePos + nCount + sizeof(int32_t));

					memcpy(&m_pszData[m_WritePos], &val, nCount);
					m_WritePos += nCount;
				}
				catch (std::exception & ex)
				{
					LOG_WRITE_FORMAT_EXCEPTION(ex, val);
					m_WritePos = nOldWritePos;
					return false;
				}
				catch (...)
				{
					LOG_WRITE_FORMAT(val);
					m_WritePos = nOldWritePos;
					return false;
				}

				return true;
			}

			/*template<typename T, typename std::enable_if<std::is_object<T>::value>::type* = nullptr> bool Write(T & val)
			{
				uint64_t nOldWritePos = m_WritePos;
				int32_t nCount = static_cast<int32_t>(sizeof(T));
				try
				{
					if (m_pszData == nullptr || m_BufferLen < m_WritePos + nCount + sizeof(int32_t))
						ReAllocMemory(m_WritePos + nCount + sizeof(int32_t));

					memcpy(&m_pszData[m_WritePos], &val, nCount);
					m_WritePos += nCount;
				}
				catch (std::exception & ex)
				{
					LOG_WRITE_FORMAT_EXCEPTION(ex, val);
					m_WritePos = nOldWritePos;
					return false;
				}
				catch (...)
				{
					LOG_WRITE_FORMAT(val);
					m_WritePos = nOldWritePos;
					return false;
				}

				return true;
			}*/

			template<typename T, typename std::enable_if<std::is_base_of<nmsp::streambuilder::IStreambuilderObject<_ALLOC>, T>::value>::type* = nullptr> bool Write(T & val)
			{
				return val.ReadWriteStream(*this, false);
			}

			template<typename T> bool Write(std::shared_ptr<T> & val)
			{
				return Write(*(val.get()));
			}

			//*
			template<> bool Write(std::string& val) { return WriteString(val); }
			template<> bool Write(const std::string& val) { return WriteString(val); }
			bool WriteString(const std::string& val)
			/*/
			template<> bool Write(std::string& val)
			//template<typename T, typename std::enable_if<std::is_base_of<std::string, T>::value>::type* = nullptr> bool Write(T & val)
			//*/
			{
				uint64_t nOldWritePos = m_WritePos;
				int32_t nCount = static_cast<int32_t>(val.length() * sizeof(char));
				try
				{
					if (m_pszData == nullptr || m_BufferLen < m_WritePos + nCount + sizeof(int32_t))
						ReAllocMemory(m_WritePos + nCount + sizeof(int32_t));

					memcpy(&m_pszData[m_WritePos], &nCount, sizeof(int32_t));
					m_WritePos += sizeof(int32_t);
					if (nCount > 0)
					{
						memcpy(&m_pszData[m_WritePos], val.c_str(), nCount);
						m_WritePos += nCount;
					}
				}
				catch (std::exception & ex)
				{
					LOG_WRITE_FORMAT_EXCEPTION(ex, val);
					m_WritePos = nOldWritePos;
					return false;
				}
				catch (...)
				{
					LOG_WRITE_FORMAT(val);
					m_WritePos = nOldWritePos;
					return false;
				}

				return true;
			}

			//*
			template<> bool Write(std::wstring& val) { return WriteString(val); }
			template<> bool Write(const std::wstring& val) { return WriteString(val); }
			bool WriteString(const std::wstring& val)
			/*/
			template<> bool Write(std::wstring& val)
			//template<typename T, typename std::enable_if<std::is_base_of<std::wstring, T>::value>::type* = nullptr> bool Write(T & val)
			//*/
			{
				uint64_t nOldWritePos = m_WritePos;
				int32_t nCount = static_cast<int32_t>(val.length() * sizeof(wchar_t));
				try
				{
					if (m_pszData == nullptr || m_BufferLen < m_WritePos + nCount + sizeof(int32_t))
						ReAllocMemory(m_WritePos + nCount + sizeof(int32_t));

					memcpy(&m_pszData[m_WritePos], &nCount, sizeof(int32_t));
					m_WritePos += sizeof(int32_t);
					if (nCount > 0)
					{
						memcpy(&m_pszData[m_WritePos], val.c_str(), nCount);
						m_WritePos += nCount;
					}
				}
				catch (std::exception & ex)
				{
					LOG_WRITE_FORMAT_EXCEPTION(ex, val);
					m_WritePos = nOldWritePos;
					return false;
				}
				catch (...)
				{
					LOG_WRITE_FORMAT(val);
					m_WritePos = nOldWritePos;
					return false;
				}

				return true;
			}

			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

			//!< tuple 형태의 데이터 저장.
			template<typename... Args> bool Write(const std::tuple<Args...> & val)
			{
				uint64_t nOldWritePos = m_WritePos;
				int32_t nCount = 0;
				try
				{
					if (m_pszData == nullptr || m_BufferLen < m_WritePos + sizeof(int32_t))
						ReAllocMemory(sizeof(int32_t));

					//!< tuple의 개수 저장.
					nCount = static_cast<int32_t>(std::tuple_size<std::tuple<Args...>>::value);
					memcpy(&m_pszData[m_WritePos], &nCount, sizeof(int32_t));
					m_WritePos += sizeof(int32_t);

					//!< tuple 데이터 읽기
					auto do_write = [this](bool & ret, auto& elem)-> auto {
						if (ret == false)
							return elem;
						ret = Write(elem);
						return elem;
					};
					bool ret = true;
					std::tuple<Args...> temp = ReadWriteTuple(ret, do_write, const_cast<std::tuple<Args...>&>(val));
					if (ret == false)
					{
						m_WritePos = nOldWritePos;
						LOG_WRITE_FORMAT(val);
						return false;
					}
				}
				catch (std::exception & ex)
				{
					LOG_WRITE_FORMAT_EXCEPTION(ex, val);
					m_WritePos = nOldWritePos;
					return false;
				}
				catch (...)
				{
					LOG_WRITE_FORMAT(val);
					m_WritePos = nOldWritePos;
					return false;
				}

				return true;
			}

			//!< list 형태의 데이터 저장.
			template<typename T1, typename T2> bool Write(std::list<T1, T2> & val)
			{
				uint64_t nOldWritePos = m_WritePos;
				int32_t nCount = 0;
				try
				{
					nCount = static_cast<int32_t>(val.size());

					if (m_pszData == nullptr || m_BufferLen < m_WritePos + sizeof(int32_t) + (nCount * sizeof(T1)))
						ReAllocMemory(sizeof(int32_t) + (nCount * sizeof(T1)));

					//!< list의 개수 저장.
					memcpy(&m_pszData[m_WritePos], &nCount, sizeof(int32_t));
					m_WritePos += sizeof(int32_t);

					//!< list 데이터 저장
					for (auto it = val.begin(); it != val.end(); ++it)
					{
						if (Write((*it)) == false)
						{
							m_WritePos = nOldWritePos;
							LOG_WRITE_FORMAT(val);
							return false;
						}
					}
				}
				catch (std::exception & ex)
				{
					LOG_WRITE_FORMAT_EXCEPTION(ex, val);
					m_WritePos = nOldWritePos;
					return false;
				}
				catch (...)
				{
					LOG_WRITE_FORMAT(val);
					m_WritePos = nOldWritePos;
					return false;
				}

				return true;
			}

			//!< set 형태의 데이터 저장.
			template<typename T1, typename T2, typename T3> bool Write(std::set<T1, T2, T3> & val)
			{
				uint64_t nOldWritePos = m_WritePos;
				int32_t nCount = 0;
				try
				{
					nCount = static_cast<int32_t>(val.size());

					if (m_pszData == nullptr || m_BufferLen < m_WritePos + sizeof(int32_t) + (nCount * sizeof(T1)))
						ReAllocMemory(sizeof(int32_t) + (nCount * sizeof(T1)));

					//!< set의 개수 저장.
					memcpy(&m_pszData[m_WritePos], &nCount, sizeof(int32_t));
					m_WritePos += sizeof(int32_t);

					//!< set 데이터 저장
					for (auto it = val.begin(); it != val.end(); ++it)
					{
						if (Write((*it)) == false)
						{
							m_WritePos = nOldWritePos;
							LOG_WRITE_FORMAT(val);
							return false;
						}
					}
				}
				catch (std::exception & ex)
				{
					LOG_WRITE_FORMAT_EXCEPTION(ex, val);
					m_WritePos = nOldWritePos;
					return false;
				}
				catch (...)
				{
					LOG_WRITE_FORMAT(val);
					m_WritePos = nOldWritePos;
					return false;
				}

				return true;
			}

			//!< vector 형태의 데이터 저장.
			template<typename T1, typename T2> bool Write(std::vector<T1, T2> & val)
			{
				uint64_t nOldWritePos = m_WritePos;
				int32_t nCount = 0;
				try
				{
					nCount = static_cast<int32_t>(val.size());

					if (m_pszData == nullptr || m_BufferLen < m_WritePos + sizeof(int32_t) + (nCount * sizeof(T1)))
						ReAllocMemory(sizeof(int32_t) + (nCount * sizeof(T1)));

					//!< vector의 개수 저장.
					memcpy(&m_pszData[m_WritePos], &nCount, sizeof(int32_t));
					m_WritePos += sizeof(int32_t);

					//!< vector 데이터 저장
					for (auto it = val.begin(); it != val.end(); ++it)
					{
						if (Write((*it)) == false)
						{
							m_WritePos = nOldWritePos;
							LOG_WRITE_FORMAT(val);
							return false;
						}
					}
				}
				catch (std::exception & ex)
				{
					LOG_WRITE_FORMAT_EXCEPTION(ex, val);
					m_WritePos = nOldWritePos;
					return false;
				}
				catch (...)
				{
					LOG_WRITE_FORMAT(val);
					m_WritePos = nOldWritePos;
					return false;
				}

				return true;
			}

			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

			//!< 배열 형태의 데이터 저장.
			template<typename T> bool Write(T val[], int32_t nCount)
			{
				uint64_t nOldWritePos = m_WritePos;
				try
				{
					if (m_pszData == nullptr || m_BufferLen < m_WritePos + sizeof(int32_t) + (nCount * sizeof(T)))
						ReAllocMemory(sizeof(int32_t) + (nCount * sizeof(T)));

					//!< 배열의 개수 저장.
					memcpy(&m_pszData[m_WritePos], &nCount, sizeof(int32_t));
					m_WritePos += sizeof(int32_t);

					//!< 배열 데이터 저장
					for (int32_t i = 0; i < nCount; ++i)
					{
						if (Write(val[i]) == false)
						{
							m_WritePos = nOldWritePos;
							LOG_WRITE_FORMAT(val);
							return false;
						}
					}
				}
				catch (std::exception & ex)
				{
					LOG_WRITE_FORMAT_EXCEPTION(ex, val);
					m_WritePos = nOldWritePos;
					return false;
				}
				catch (...)
				{
					LOG_WRITE_FORMAT(val);
					m_WritePos = nOldWritePos;
					return false;
				}

				return true;
			}

			//!< ansi char 문자열 배열 템플릿 특수화.
			template<> bool Write<std::string>(std::string val[], int32_t nCount)
			{
				uint64_t nOldWritePos = m_WritePos;
				try
				{
					if (m_pszData == nullptr || m_BufferLen < m_WritePos + sizeof(int32_t))
						ReAllocMemory(sizeof(int32_t));

					//!< 배열의 개수 저장.
					memcpy(&m_pszData[m_WritePos], &nCount, sizeof(int32_t));
					m_WritePos += sizeof(int32_t);

					//!< 배열 데이터 저장
					for (int32_t i = 0; i < nCount; ++i)
					{
						if (Write(val[i]) == false)
						{
							m_WritePos = nOldWritePos;
							LOG_WRITE_FORMAT(val);
							return false;
						}
					}
				}
				catch (std::exception & ex)
				{
					LOG_WRITE_FORMAT_EXCEPTION(ex, val);
					m_WritePos = nOldWritePos;
					return false;
				}
				catch (...)
				{
					LOG_WRITE_FORMAT(val);
					m_WritePos = nOldWritePos;
					return false;
				}

				return true;
			}

			//!< wide char 문자열 배열 템플릿 특수화.
			template<> bool Write<std::wstring>(std::wstring val[], int32_t nCount)
			{
				uint64_t nOldWritePos = m_WritePos;
				try
				{
					if (m_pszData == nullptr || m_BufferLen < m_WritePos + sizeof(int32_t))
						ReAllocMemory(sizeof(int32_t));

					//!< 배열의 개수 저장.
					memcpy(&m_pszData[m_WritePos], &nCount, sizeof(int32_t));
					m_WritePos += sizeof(int32_t);

					//!< 배열 데이터 저장
					for (int32_t i = 0; i < nCount; ++i)
					{
						if (Write((*it)) == false)
						{
							m_WritePos = nOldWritePos;
							LOG_WRITE_FORMAT(val);
							return false;
						}
					}
				}
				catch (std::exception & ex)
				{
					LOG_WRITE_FORMAT_EXCEPTION(ex, val);
					m_WritePos = nOldWritePos;
					return false;
				}
				catch (...)
				{
					LOG_WRITE_FORMAT(val);
					m_WritePos = nOldWritePos;
					return false;
				}

				return true;
			}

			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

			//!< map 형태의 데이터 저장.
			template<typename T1, typename T2, typename T3, typename T4> bool Write(std::map<T1, T2, T3, T4> & val)
			{
				uint64_t nOldWritePos = m_WritePos;
				int32_t nCount = 0;
				try
				{
					nCount = static_cast<int32_t>(val.size());

					if (m_pszData == nullptr || m_BufferLen < m_WritePos + sizeof(int32_t))
						ReAllocMemory(sizeof(int32_t));

					//!< map의 개수 저장.
					memcpy(&m_pszData[m_WritePos], &nCount, sizeof(int32_t));
					m_WritePos += sizeof(int32_t);

					//!< map 데이터 저장
					for (auto it = val.begin(); it != val.end(); ++it)
					{
						if (Write(it->first) == false)
						{
							m_WritePos = nOldWritePos;
							LOG_WRITE_FORMAT(val);
							return false;
						}

						if (Write(it->second) == false)
						{
							m_WritePos = nOldWritePos;
							LOG_WRITE_FORMAT(val);
							return false;
						}
					}
				}
				catch (std::exception & ex)
				{
					LOG_WRITE_FORMAT_EXCEPTION(ex, val);
					m_WritePos = nOldWritePos;
					return false;
				}
				catch (...)
				{
					LOG_WRITE_FORMAT(val);
					m_WritePos = nOldWritePos;
					return false;
				}

				return true;
			}

			template<typename T1, typename T2, typename T3, typename T4, typename T5> bool Write(std::unordered_map<T1, T2, T3, T4, T5> & val)
			{
				uint64_t nOldWritePos = m_WritePos;
				int32_t nCount = 0;
				try
				{
					nCount = static_cast<int32_t>(val.size());

					if (m_pszData == nullptr || m_BufferLen < m_WritePos + sizeof(int32_t))
						ReAllocMemory(sizeof(int32_t));

					//!< map의 개수 저장.
					memcpy(&m_pszData[m_WritePos], &nCount, sizeof(int32_t));
					m_WritePos += sizeof(int32_t);

					//!< map 데이터 저장
					for (auto it = val.begin(); it != val.end(); ++it)
					{
						if (Write(it->first) == false)
						{
							m_WritePos = nOldWritePos;
							LOG_WRITE_FORMAT(val);
							return false;
						}

						if (Write(it->second) == false)
						{
							m_WritePos = nOldWritePos;
							LOG_WRITE_FORMAT(val);
							return false;
						}
					}
				}
				catch (std::exception & ex)
				{
					LOG_WRITE_FORMAT_EXCEPTION(ex, val);
					m_WritePos = nOldWritePos;
					return false;
				}
				catch (...)
				{
					LOG_WRITE_FORMAT(val);
					m_WritePos = nOldWritePos;
					return false;
				}

				return true;
			}
			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

			//template<typename T> bool Read(T & val)
			template<typename T, typename std::enable_if<std::is_standard_layout<T>::value>::type* = nullptr> bool Read(T & val)
			{
				if (m_pszData == nullptr)
					return false;

				if (m_BufferLen < m_ReadPos + sizeof(T))
					return false;

				uint64_t nOldReadPos = m_ReadPos;
				int32_t nCount = static_cast<int32_t>(sizeof(T));
				try
				{
					memcpy(&val, &m_pszData[m_ReadPos], nCount);
					m_ReadPos += nCount;
				}
				catch (std::exception & ex)
				{
					LOG_READ_FORMAT_EXCEPTION(ex, val) << std::endl;
					m_ReadPos = nOldReadPos;
					return false;
				}
				catch (...)
				{
					LOG_READ_FORMAT(val) << std::endl;
					m_ReadPos = nOldReadPos;
					return false;
				}

				return true;
			}

			/*template<typename T, typename std::enable_if<std::is_object<T>::value>::type* = nullptr> bool Read(T & val)
			{
				if (m_pszData == nullptr)
					return false;

				if (m_BufferLen < m_ReadPos + sizeof(T))
					return false;

				uint64_t nOldReadPos = m_ReadPos;
				int32_t nCount = static_cast<int32_t>(sizeof(T));
				try
				{
					memcpy(&val, &m_pszData[m_ReadPos], nCount);
					m_ReadPos += sizeof(T);
				}
				catch (std::exception & ex)
				{
					LOG_READ_FORMAT_EXCEPTION(ex, val) << std::endl;
					m_ReadPos = nOldReadPos;
					return false;
				}
				catch (...)
				{
					LOG_READ_FORMAT(val) << std::endl;
					m_ReadPos = nOldReadPos;
					return false;
				}

				return true;
			}*/

			template<typename T, typename std::enable_if<std::is_base_of<nmsp::streambuilder::IStreambuilderObject<_ALLOC>, T>::value>::type* = nullptr> bool Read(T & val)
			{
				return val.ReadWriteStream(*this, true);
			}

			template<typename T> bool Read(std::shared_ptr<T> & val)
			{
				if (val == nullptr)
					val.swap(std::make_shared<T>());
				return Read(*(val.get()));
			}

			template<> bool Read<std::string>(std::string & val)
			//template<typename T, typename std::enable_if<std::is_base_of<std::string, T>::value>::type* = nullptr> bool Read(T & val)
			{
				if (m_pszData == nullptr)
					return false;

				uint64_t nOldReadPos = m_ReadPos;
				int32_t nCount = 0;
				try
				{
					memcpy(&nCount, &m_pszData[m_ReadPos], sizeof(int32_t));
					if (m_BufferLen < m_ReadPos + sizeof(int32_t) + nCount)
						return false;
					m_ReadPos += sizeof(int32_t);

					if (nCount > 0)
					{
						char * data = reinterpret_cast<char*>(_allocator_t::CreateMemory(static_cast<int32_t>(nCount + sizeof(char))));
						data[nCount] = 0;
						memcpy(data, &m_pszData[m_ReadPos], nCount);
						val = std::string(data);
						_allocator_t::DestroyMemory(reinterpret_cast<void *>(data));

						m_ReadPos += nCount;
					}
				}
				catch (std::exception & ex)
				{
					LOG_READ_FORMAT_EXCEPTION(ex, val);
					m_ReadPos = nOldReadPos;
					return false;
				}
				catch (...)
				{
					LOG_READ_FORMAT(val);
					m_ReadPos = nOldReadPos;
					return false;
				}
				return true;
			}

			template<> bool Read<std::wstring>(std::wstring & val)
			//template<typename T, typename std::enable_if<std::is_base_of<std::wstring, T>::value>::type* = nullptr> bool Read(T & val)
			{
				if (m_pszData == nullptr)
					return false;

				uint64_t nOldReadPos = m_ReadPos;
				int32_t nCount = 0;
				try
				{
					memcpy(&nCount, &m_pszData[m_ReadPos], sizeof(int32_t));
					if (m_BufferLen < m_ReadPos + sizeof(int32_t) + nCount)
						return false;
					m_ReadPos += sizeof(int32_t);

					if (nCount > 0)
					{
						char * data = reinterpret_cast<char*>(_allocator_t::CreateMemory(static_cast<int32_t>(nCount + sizeof(wchar_t))));
						data[nCount] = 0;
						memcpy(data, &m_pszData[m_ReadPos], nCount);
						val = std::wstring(reinterpret_cast<wchar_t>(data));
						_allocator_t::DestroyMemory(reinterpret_cast<void *>(data));

						m_ReadPos += nCount;
					}
				}
				catch (std::exception & ex)
				{
					LOG_READ_FORMAT_EXCEPTION(ex, val);
					m_ReadPos = nOldReadPos;
					return false;
				}
				catch (...)
				{
					LOG_READ_FORMAT(val);
					m_ReadPos = nOldReadPos;
					return false;
				}
				return true;
			}

			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			//!< tuple 형태의 데이터 읽기.
			template<typename... Args> bool Read(std::tuple<Args...> & val)
			{
				if (m_pszData == nullptr)
					return false;

				uint64_t nOldReadPos = m_ReadPos;
				int32_t nCount = 0;
				try
				{
					memcpy(&nCount, &m_pszData[m_ReadPos], sizeof(int32_t));
					m_ReadPos += sizeof(int32_t);
					if (nCount == 0)
						return true;

					//!< tuple 데이터 저장
					auto do_read = [this](bool & ret, auto& elem)-> auto {
						if (ret == false)
							return elem;
						decltype(elem) ret_elem = elem;
						ret = Read(ret_elem);
						return ret_elem;
					};
					bool ret = true;
					std::tuple<Args...> temp = ReadWriteTuple(ret, do_read, val);
					if (ret == false)
					{
						m_ReadPos = nOldReadPos;
						LOG_READ_FORMAT(val);
						return false;
					}
					val.swap(temp);
				}
				catch (std::exception & ex)
				{
					LOG_READ_FORMAT_EXCEPTION(ex, val);
					m_ReadPos = nOldReadPos;
					return false;
				}
				catch (...)
				{
					LOG_READ_FORMAT(val);
					m_ReadPos = nOldReadPos;
					return false;
				}
				return true;
			}

			//!< list 형태의 데이터 읽기.
			template<typename T1, typename T2> bool Read(std::list<T1, T2> & val)
			{
				if (m_pszData == nullptr)
					return false;

				uint64_t nOldReadPos = m_ReadPos;
				int32_t nCount = 0;
				try
				{
					memcpy(&nCount, &m_pszData[m_ReadPos], sizeof(int32_t));
					m_ReadPos += sizeof(int32_t);
					if (nCount == 0)
						return true;

					val.clear();
					for (int32_t i = 0; i < nCount; ++i)
					{
						T1 element;
						if (Read(element) == false)
						{
							m_ReadPos = nOldReadPos;
							LOG_READ_FORMAT(val);
							return false;
						}

						val.push_back(std::move(element));
					}
				}
				catch (std::exception & ex)
				{
					LOG_READ_FORMAT_EXCEPTION(ex, val);
					m_ReadPos = nOldReadPos;
					return false;
				}
				catch (...)
				{
					LOG_READ_FORMAT(val);
					m_ReadPos = nOldReadPos;
					return false;
				}
				return true;
			}

			//!< set 형태의 데이터 읽기.
			template<typename T1, typename T2, typename T3> bool Read(std::set<T1, T2, T3> & val)
			{
				if (m_pszData == nullptr)
					return false;

				uint64_t nOldReadPos = m_ReadPos;
				int32_t nCount = 0;
				try
				{
					memcpy(&nCount, &m_pszData[m_ReadPos], sizeof(int32_t));
					m_ReadPos += sizeof(int32_t);
					if (nCount == 0)
						return true;

					val.clear();
					for (int32_t i = 0; i < nCount; ++i)
					{
						T1 element;
						if (Read(element) == false)
						{
							m_ReadPos = nOldReadPos;
							LOG_READ_FORMAT(val);
							return false;
						}

						val.emplace(std::move(element));
					}
				}
				catch (std::exception & ex)
				{
					LOG_READ_FORMAT_EXCEPTION(ex, val);
					m_ReadPos = nOldReadPos;
					return false;
				}
				catch (...)
				{
					LOG_READ_FORMAT(val);
					m_ReadPos = nOldReadPos;
					return false;
				}
				return true;
			}

			//!< vector 형태의 데이터 읽기.
			template<typename T1, typename T2> bool Read(std::vector<T1, T2> & val)
			{
				if (m_pszData == nullptr)
					return false;

				uint64_t nOldReadPos = m_ReadPos;
				int32_t nCount = 0;
				try
				{
					memcpy(&nCount, &m_pszData[m_ReadPos], sizeof(int32_t));
					m_ReadPos += sizeof(int32_t);
					if (nCount == 0)
						return true;

					val.clear();
					for (int32_t i = 0; i < nCount; ++i)
					{
						T1 element;
						if (Read(element) == false)
						{
							m_ReadPos = nOldReadPos;
							LOG_READ_FORMAT(val);
							return false;
						}

						val.emplace_back(std::move(element));
					}
				}
				catch (std::exception & ex)
				{
					LOG_READ_FORMAT_EXCEPTION(ex, val);
					m_ReadPos = nOldReadPos;
					return false;
				}
				catch (...)
				{
					LOG_READ_FORMAT(val);
					m_ReadPos = nOldReadPos;
					return false;
				}
				return true;
			}

			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

			//!< 배열 형태의 데이터 읽기.
			template<typename T> bool Read(T val[], int32_t nArraySize)
			{
				if (m_pszData == nullptr)
					return false;

				uint64_t nOldReadPos = m_ReadPos;
				int32_t nCount = 0;
				try
				{
					memcpy(&nCount, &m_pszData[m_ReadPos], sizeof(int32_t));
					m_ReadPos += sizeof(int32_t);

					if (nArraySize != nCount)
					{
						m_ReadPos = nOldReadPos;
						LOG_READ_FORMAT(val);
						return false;
					}

					for (int32_t i = 0; i < nCount; ++i)
					{
						if (Read(val[i]) == false)
						{
							m_ReadPos = nOldReadPos;
							LOG_READ_FORMAT(val);
							return false;
						}
					}
				}
				catch (std::exception & ex)
				{
					LOG_READ_FORMAT_EXCEPTION(ex, val);
					m_ReadPos = nOldReadPos;
					return false;
				}
				catch (...)
				{
					LOG_READ_FORMAT(val);
					m_ReadPos = nOldReadPos;
					return false;
				}
				return true;
			}

			//!< ansi char 문자열 배열 템플릿 특수화.
			template<> bool Read<std::string>(std::string val[], int32_t nArraySize)
			{
				if (m_pszData == nullptr)
					return false;

				uint64_t nOldReadPos = m_ReadPos;
				int32_t nCount = 0;
				try
				{
					memcpy(&nCount, &m_pszData[m_ReadPos], sizeof(int32_t));
					m_ReadPos += sizeof(int32_t);
					if (nCount == 0)
						return true;
					if (nArraySize < nCount)
						return false;
					m_ReadPos += sizeof(int32_t);

					//!< 배열 데이터 저장
					for (int32_t i = 0; i < nCount; ++i)
					{
						if (Read(val[i]) == false)
						{
							m_ReadPos = nOldReadPos;
							LOG_READ_FORMAT(val);
							return false;
						}
					}
				}
				catch (std::exception & ex)
				{
					LOG_READ_FORMAT_EXCEPTION(ex, val);
					m_ReadPos = nOldReadPos;
					return false;
				}
				catch (...)
				{
					LOG_READ_FORMAT(val);
					m_ReadPos = nOldReadPos;
					return false;
				}

				return true;
			}

			//!< wide char 문자열 배열 템플릿 특수화.
			template<> bool Read<std::wstring>(std::wstring val[], int32_t nArraySize)
			{
				if (m_pszData == nullptr)
					return false;

				uint64_t nOldReadPos = m_ReadPos;
				int32_t nCount = 0;
				try
				{
					memcpy(&nCount, &m_pszData[m_ReadPos], sizeof(int32_t));
					m_ReadPos += sizeof(int32_t);
					if (nCount == 0)
						return true;

					if (nArraySize < nCount)
						return false;
					m_ReadPos += sizeof(int32_t);

					//!< 배열 데이터 저장
					for (int32_t i = 0; i < nCount; ++i)
					{
						if (Read(val[i]) == false)
						{
							m_ReadPos = nOldReadPos;
							LOG_READ_FORMAT(val);
							return false;
						}
					}
				}
				catch (std::exception & ex)
				{
					LOG_READ_FORMAT_EXCEPTION(ex, val);
					m_ReadPos = nOldReadPos;
					return false;
				}
				catch (...)
				{
					LOG_READ_FORMAT(val);
					m_ReadPos = nOldReadPos;
					return false;
				}

				return true;
			}

			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

			//!< map 형태의 데이터 읽기.
			template<typename T1, typename T2, typename T3, typename T4> bool Read(std::map<T1, T2, T3, T4> & val)
			{
				if (m_pszData == nullptr)
					return false;

				uint64_t nOldReadPos = m_ReadPos;
				int32_t nCount = 0;
				try
				{
					memcpy(&nCount, &m_pszData[m_ReadPos], sizeof(int32_t));
					m_ReadPos += sizeof(int32_t);
					if (nCount == 0)
						return true;

					val.clear();
					for (int32_t i = 0; i < nCount; ++i)
					{
						T1 tKey;
						if (Read(tKey) == false)
						{
							m_ReadPos = nOldReadPos;
							LOG_READ_FORMAT(val);
							return false;
						}

						T2 element;
						if (Read(element) == false)
						{
							m_ReadPos = nOldReadPos;
							LOG_READ_FORMAT(val);
							return false;
						}

						val.emplace(tKey, std::move(element));
					}
				}
				catch (std::exception & ex)
				{
					LOG_READ_FORMAT_EXCEPTION(ex, val);
					m_ReadPos = nOldReadPos;
					return false;
				}
				catch (...)
				{
					LOG_READ_FORMAT(val);
					m_ReadPos = nOldReadPos;
					return false;
				}
				return true;
			}

			template<typename T1, typename T2, typename T3, typename T4, typename T5> bool Read(std::unordered_map<T1, T2, T3, T4, T5> & val)
			{
				if (m_pszData == nullptr)
					return false;

				uint64_t nOldReadPos = m_ReadPos;
				int32_t nCount = 0;
				try
				{
					memcpy(&nCount, &m_pszData[m_ReadPos], sizeof(int32_t));
					m_ReadPos += sizeof(int32_t);
					if (nCount == 0)
						return true;

					val.clear();
					for (int32_t i = 0; i < nCount; ++i)
					{
						T1 tKey;
						if (Read(tKey) == false)
						{
							m_ReadPos = nOldReadPos;
							LOG_READ_FORMAT(val);
							return false;
						}

						T2 element;
						if (Read(element) == false)
						{
							m_ReadPos = nOldReadPos;
							LOG_READ_FORMAT(val);
							return false;
						}

						val.emplace(tKey, std::move(element));
					}
				}
				catch (std::exception & ex)
				{
					LOG_READ_FORMAT_EXCEPTION(ex, val);
					m_ReadPos = nOldReadPos;
					return false;
				}
				catch (...)
				{
					LOG_READ_FORMAT(val);
					m_ReadPos = nOldReadPos;
					return false;
				}
				return true;
			}

		};

#ifdef __OPTIMIZE__
#pragma optimize("", on)
#endif
	}
}

#endif