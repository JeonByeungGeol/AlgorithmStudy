﻿////////////////////////////////////////////////////////////////////////////////
//
// 작성자 : sjkim
// 설  명 : 
//

#pragma once
#ifndef __NMTIME_H__
#define __NMTIME_H__

#include <boost/serialization/singleton.hpp>
#include <boost/date_time/local_time/local_time.hpp>
#include <boost/date_time/adjust_functors.hpp>
#include <boost/date_time/gregorian/gregorian.hpp>
#include <boost/date_time/gregorian/greg_calendar.hpp>
#include <chrono>
#include <regex>
#include <thread>

namespace nmsp
{

// 요일 값
using weekdays = boost::date_time::weekdays;

// 시간 비교를 위한 ratio 재정의
namespace ratio
{
using seconds = std::ratio<1000>;
using minuts = std::ratio<60000>;
using hours = std::ratio<3600000>;
using days = std::ratio<86400000>;
using weeks = std::ratio<604800000>;
}

// 시간 연산을 위한 단위 재정의
namespace duration
{


using seconds = std::chrono::duration<long long, std::ratio<1>>;
using minuts = std::chrono::duration<long long, std::ratio<60>>;
using hours = std::chrono::duration<long long, std::ratio<3600>>;
using days = std::chrono::duration<long long, std::ratio<86400>>;
using weeks = std::chrono::duration<long long, std::ratio<604800>>;
//using month = std::chrono::duration<long long, std::ratio<2419200>>;

// 날짜 문자열에서 소숫점 3자리까지 출력을 위한 길이
static const std::size_t TIME_LENGTH = 8;
// 문자 필터 정규식
static const std::regex HHMMSS_REGEX("^([1-9]|[01][0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])*$");

/************************************************************************/
// 설명 : 10:00:00.000 포멧의 문자열을 받아 timestamp로 변환하여 반환합니다.
// 파라메터 :
//	- time : 10:00:00.000 형식의 DATETIME 문자열
// 반환 값 : 입력받은 문자열에 대한 duration. (단위: ms)
/************************************************************************/
static time_t from_string_HHMMSS(const std::string& time)
{
	using namespace boost::posix_time;

	typedef typename ptime::time_duration_type time_duration;

	std::string temp = time;
	if (TIME_LENGTH < temp.length())
	{
		temp = temp.substr(0, TIME_LENGTH);
	}

	if (false == std::regex_match(temp, HHMMSS_REGEX))
	{
		return 0;
	}

	time_duration td = boost::date_time::parse_delimited_time_duration<time_duration>(temp);

	return td.total_milliseconds();
}

}

// Second 시간을 얻기 위해 사용됩니다.
namespace expire
{
using days = std::ratio<86400>;
using weeks = std::ratio<604800>;
using two_weeks = std::ratio<1209600>;
using month = std::ratio<2419200>;
}

class tz_database : public boost::serialization::singleton<tz_database>
{
public:
	using _database_t = boost::local_time::tz_database;
	using _row_t = boost::local_time::time_zone_ptr;

	void load(const std::string& path)
	{
		// "tz_database.csv"
		//m_db.load_from_file(path);

		const char* str = "Asia/Seoul,KST,KST,,,+09:00:00,+00:00:00,,,,+00:00:00\n" \
			"America/Dawson,PST,PST,PDT,PDT,-08:00:00,+01:00:00,2;0;3,+02:00:00,1;0;11,+02:00:00";
		std::istringstream iss(str);

		auto tid = std::this_thread::get_id();

		std::stringstream ss1;
		ss1 << &*this << std::endl;

		auto addr = ss1.str();
		m_db.load_from_stream(iss);
	}

	void SetTimeZoneName(const std::string& timeZoneName)
	{
		m_timeZoneName = timeZoneName;
	}

	_row_t get(const char* id)
	{
		if (nullptr == id)
			return m_db.time_zone_from_region(m_timeZoneName);

		return m_db.time_zone_from_region(id);
	}

	const std::string& GetTimeZoneName() { return m_timeZoneName; }

protected:
	tz_database()
	{
		load("tz_database.csv");
	}

	~tz_database() = default;

private:
	std::string m_timeZoneName;

	boost::local_time::tz_database m_db;
};

// 문자 필터 정규식
static const std::regex TIME_NUMBER_REGEX("^(19|20|21|22)\\d{2}-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[0-1])\\s([1-9]|[01][0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])(.[0-9][0-9][0-9])*$");

class time
{
	// 날짜 문자열에서 소숫점 3자리까지 출력을 위한 길이
	static const std::size_t DATETIME_LENGTH = 23;

public:
	/************************************************************************/
	// 설명 : l과 r의 차이를 지정된 단위로 반환합니다.                                 
	// 템플릿 : stl::ratio 를 사용하며 nmsp::ratio에 단위를 미리 정의해놓았습니다.
	// 파라메터 : 
	//	- l : 시간, 단위는 밀리초
	//	- r : 시간, 단위는 밀리초
	//
	// ex1) 비교된 시간을 초로 반환
	// auto sec_diff = diff<nmsp::ratio::seconds>(now, start);
	// 
	// ex2) 비교된 시간을 일로 반환
	// auto days_diff = diff<nmsp::ratio::days>(now, start);
	/************************************************************************/
	template <typename Ratio>
	static time_t diff(const time_t& l_ms_utc, const time_t& r_ms_utc)
	{
		return (l_ms_utc - r_ms_utc) / typename Ratio::num;
	}

	/************************************************************************/
	// 설명 : 현재 시간을 타임스템프로 반환합니다.(단위, ms, 타임 존 : UTC)
	/************************************************************************/
	static time_t now()
	{
		using namespace std::chrono;

		return duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
	}

	static time_t perfnow()
	{
		using namespace std::chrono;

		return duration_cast<microseconds>(system_clock::now().time_since_epoch()).count();
	}

	static time_t to_milliseconds(std::chrono::time_point<std::chrono::steady_clock> & tm_point)
	{
		using namespace std::chrono;

		return duration_cast<milliseconds>(tm_point.time_since_epoch()).count();
	}

	static time_t to_milliseconds(std::chrono::time_point<std::chrono::system_clock> & tm_point)
	{
		using namespace std::chrono;
	
		return duration_cast<milliseconds>(tm_point.time_since_epoch()).count();
	}

	/************************************************************************/
	// 설명 : ms_utc를 time_zone 에 맞게 계산, 계산된 시간을 이용해 0am을 구하고 
	//		해당 값을 utc로 변환하여 반환
	// 파라메터 :
	//	- ms : 시간, 단위는 밀리초
	//
	// 반환 값 : timestamp
	/************************************************************************/
	static time_t to_0am(const time_t& ms_utc, const char* time_zone = nullptr)
	{
		using namespace boost::posix_time;

		auto& db_row = tz_database::get_mutable_instance().get(time_zone);

		boost::local_time::local_date_time ldt(to_ptime(ms_utc), db_row);

		time_t offset = ms_utc - nmsp::time::to_time_t(ldt.local_time());

		time_duration dur = ptime(ldt.local_time().date()) - ptime(boost::gregorian::date(1970, 1, 1));

		// utc로 변환하여 반환
		return std::time_t(dur.total_milliseconds() + offset);
	}

	/************************************************************************/
	// 설명 : timestamp를 boost::posix_time::ptime으로 변환합니다.
	// 파라메터 :
	//	- ms : 시간, 단위는 밀리초
	//
	// 반환 값 : boost::posix_time::ptime
	/************************************************************************/
	static boost::posix_time::ptime to_ptime(const time_t& ms)
	{
		using namespace boost::posix_time;
		ptime start(boost::gregorian::date(1970, 1, 1));
		return (start + milliseconds(ms));
	}

	/************************************************************************/
	// 설명 : boost::posix_time::ptime으로 timestamp로 변환합니다.
	// 파라메터 :
	//	- pt : boost::posix_time::ptime 값
	//
	// 반환 값 : timestamp
	/************************************************************************/
	static time_t to_time_t(boost::posix_time::ptime& pt)
	{
		using namespace boost::posix_time;
		time_duration dur = pt - ptime(boost::gregorian::date(1970, 1, 1));
		return std::time_t(dur.total_milliseconds());
	}

	/************************************************************************/
	// 설명 : 2019-09-20 10:00:00(UTC) 포멧의 문자열을 받아 지정된 타임존의 해당 시간
	//       으로 변환하여 timestamp를 반환합니다.(localtime을 utc로 변환)
	//       ex) KST로 2019-09-20 10:00:00는 UTC로 2019-09-20 01:00:00됨.
	// 파라메터 :
	//	- datetime : 2019-09-20 10:00:00 형식의 DATETIME 문자열
	//  - time_zone : datetime의 time_zone을 지정하여 알맞는 UTC로 계산되도록 합니다.
	// 반환 값 : 입력받은 문자열에 대한 timestamp. (단위: ms, 타임 존: UTC)
	/************************************************************************/
	static time_t from_string(const std::string& datetime, const char* time_zone = nullptr)
	{
		using namespace boost::posix_time;

		typedef typename ptime::time_duration_type time_duration;
		typedef typename ptime::date_type date_type;

		std::string temp = datetime;
		if (DATETIME_LENGTH < temp.length())
		{
			temp = temp.substr(0, DATETIME_LENGTH);
		}

		if (false == std::regex_match(temp, TIME_NUMBER_REGEX))
		{
			return 0;
		}

		char sep = ' ';

		//split date/time on a unique delimiter char such as ' ' or 'T'
		std::string date_string, tod_string;
		boost::date_time::split(temp, sep, date_string, tod_string);
		//call parse_date with first string

		date_type d = boost::date_time::parse_date<date_type>(date_string);
		//call parse_time_duration with remaining string

		time_duration td = boost::date_time::parse_delimited_time_duration<time_duration>(tod_string);

		// 지정된 timezone 계산을 위한 offset
		auto db_row = tz_database::get_mutable_instance().get(time_zone);

		if (db_row != tz_database::_row_t() && true == db_row->has_dst())
		{
			/////////////////////////////////////////////////////////////////////////////////////////////////////
			typedef typename boost::date_time::dst_calculator<date_type, time_duration> dst_calculator;

			// 부스트 내부에서 가져옴
			int64_t start_minutes = db_row->dst_local_start_time(d.year()).time_of_day().hours() * 60 + db_row->dst_local_start_time(d.year()).time_of_day().minutes();
			int64_t end_minutes = db_row->dst_local_end_time(d.year()).time_of_day().hours() * 60 + db_row->dst_local_end_time(d.year()).time_of_day().minutes();
			int64_t length_minutes = db_row->dst_offset().hours() * 60 + db_row->dst_offset().minutes();

			// DST 시작 시간과 겹칠 경우
			if (d == db_row->dst_local_start_time(d.year()).date()) {
				auto result = dst_calculator::process_local_dst_start_day(td, static_cast<uint32_t>(start_minutes), static_cast<long>(length_minutes));
				if (boost::date_time::time_is_dst_result::invalid_time_label == result)
				{
					// transition to DST
					td += db_row->dst_offset();
				}
			}

			// DST 종료 시간과 겹칠 경우
			if (d == db_row->dst_local_end_time(d.year()).date()) {
				auto result = dst_calculator::process_local_dst_end_day(td, static_cast<uint32_t>(end_minutes), static_cast<long>(length_minutes));
				if (boost::date_time::time_is_dst_result::ambiguous == result)
				{
					// transition to STD
					td -= db_row->dst_offset();
				}
			}
			/////////////////////////////////////////////////////////////////////////////////////////////////////
		}

		boost::local_time::local_date_time ldt(d, td, db_row, boost::local_time::local_date_time::DST_CALC_OPTIONS::EXCEPTION_ON_ERROR);

		return nmsp::time::to_time_t(ldt.utc_time());
	}

	/************************************************************************/
	// 설명 : timestamp(UTC)를 입력 받아 지정된 타임존의 로컬시간으로 변환하여 반환합니다.
	//       ex) utf_offset 및 dst_offset 반영하여 시간 계산.
	//       (2019-09-20 10:00:00.000 포멧의 문자열로 반환합니다.)
	// 파라메터 :
	//	- ms : 시간, 단위 밀리초
	//
	// 반환 값 : 입력받은 시간을 2019-09-20 10:00:00.000 형식의 DATETIME 문자열로 반환
	/************************************************************************/
	static std::string to_string(const time_t& ms_utc, const char* time_zone = nullptr)
	{
		using namespace boost::posix_time;

		auto facet = new boost::posix_time::time_facet();
		facet->format("%Y-%m-%d %H:%M:%S%F");

		// 지정된 timezone 계산을 위한 offset
		auto db_row = tz_database::get_mutable_instance().get(time_zone);

		boost::local_time::local_date_time ldt(to_ptime(ms_utc), db_row);

		std::stringstream ss;
		ss.imbue(std::locale(std::locale::classic(), facet));

		// offset을 반영하여 문자열 출력
		ss << ldt.local_time();

		return ss.str().substr(0, DATETIME_LENGTH);
	}

	/************************************************************************/
	// 설명 : timestamp를 입력 받아 20190920 포멧의 문자열로 반환합니다.
	// 파라메터 :
	//	- ms : 시간, 단위 밀리초
	//
	// 반환 값 : 입력받은 시간을 20190920 형식의 DATETIME 문자열로 반환
	/************************************************************************/
	static std::string to_string_flag(const time_t& ms_utc, const char* time_zone = nullptr)
	{
		using namespace boost::posix_time;

		auto facet = new boost::posix_time::time_facet();
		facet->format("%Y%m%d");

		// 지정된 timezone 계산을 위한 offset
		auto db_row = tz_database::get_mutable_instance().get(time_zone);

		boost::local_time::local_date_time ldt(to_ptime(ms_utc), db_row);

		std::stringstream ss;
		ss.imbue(std::locale(std::locale::classic(), facet));

		// offset을 반영하여 문자열 출력
		ss << ldt.local_time();

		return ss.str().substr(0, DATETIME_LENGTH);
	}

	/************************************************************************/
	// 설명 : ms에 지정된 Duration을 더하여 반환합니다.
	// 파라메터 :
	//	- ms : 시간, 단위 밀리초
	//  - dur : 값
	// 반환 값 : ms + Duration
	// 
	// ex1) 초 단위 합
	// auto sec_ret = plus(now, nmsp::duration::seconds(30));
	// or 
	// auto sec_ret = plus(now, std::chrono::seconds(30));
	/************************************************************************/
	template <class Duration>
	static time_t after(const time_t ms_utc, Duration& dur)
	{
		using namespace std::chrono;
		return ms_utc + duration_cast<milliseconds>(system_clock::time_point(dur).time_since_epoch()).count();
	}

	/************************************************************************/
	// 설명 : ms에 지정된 Duration을 뺀 후 반환합니다.
	// 파라메터 :
	//	- ms : 시간, 단위 밀리초
	//  - dur : 값
	// 반환 값 : ms - Duration
	// 
	// ex1) 초 단위 합
	// auto sec_ret = nmsp::time::minus(now, nmsp::duration::seconds(30));
	// or 
	// auto sec_ret = nmsp::time::plus(now, std::chrono::seconds(30));
	/************************************************************************/
	template <class Duration>
	static time_t before(const time_t ms_utc, Duration& dur)
	{
		using namespace std::chrono;
		return ms_utc - duration_cast<milliseconds>(system_clock::time_point(dur).time_since_epoch()).count();
	}

	/************************************************************************/
	// 설명 : 주어진 utc_ms 값으로 day of week 값을 반환
	// 파라메터 :
	//	- ms : 시간, 단위는 밀리초
	//	- time_zone : 타임 존 문자열
	//
	// 반환 값 : day of week (boost::date_time::weekdays 참고)
	/************************************************************************/
	static int32_t to_weekday(const time_t& ms_utc, const char* time_zone = nullptr)
	{
		using namespace boost::posix_time;

		auto& db_row = tz_database::get_mutable_instance().get(time_zone);

		// utc 시간을 로컬 시간으로 변환
		boost::local_time::local_date_time ldt(to_ptime(ms_utc), db_row);

		return ldt.local_time().date().day_of_week().as_number();
	}

	/************************************************************************/
	// 설명 : 주어진 utc_ms 값으로 yyyyww 값을 반환 (년도 4자리 + 년 주차 2자리. ex:201915)
	// 파라메터 :
	//	- ms : 시간, 단위는 밀리초
	//	- time_zone : 타임 존 문자열
	//
	// 반환 값 : yyyyww
	/************************************************************************/
	static int32_t to_year_weeknum(const time_t& ms_utc, const char* time_zone = nullptr)
	{
		using namespace boost::posix_time;

		auto& db_row = tz_database::get_mutable_instance().get(time_zone);

		// utc 시간을 로컬 시간으로 변환
		boost::local_time::local_date_time ldt(to_ptime(ms_utc), db_row);

		int32_t year = ldt.local_time().date().year();
		int32_t week = ldt.local_time().date().week_number();

		return year * 100 + week;
	}

	/************************************************************************/
	// 설명 : 주어진 utc_ms 값 이전 요일의 0am 반환
	// 파라메터 :
	//	- ms : 시간, 단위는 밀리초
	//	- find_weekday : 찾을 요일 값(0:일요일 ~ 6:토요일), (boost::date_time::Sunday ~ boost::date_time::Saturday)
	//	- time_zone : 타임 존 문자열
	//
	// 반환 값 : timestamp
	/************************************************************************/
	static time_t to_last_weekday_0am(const time_t& ms_utc, const int32_t& find_weekday, const char* time_zone = nullptr)
	{
		using namespace boost::posix_time;
		using namespace boost::gregorian;

		auto& db_row = tz_database::get_mutable_instance().get(time_zone);

		// utc 시간을 로컬 시간으로 변환
		boost::local_time::local_date_time ldt(to_ptime(ms_utc), db_row);

		// utc 와 로컬 시간의 차이
		time_t offset = ms_utc - nmsp::time::to_time_t(ldt.local_time());

		// 세팅된 시간보다 이전에 있는 요일(find_weekday) 의 date 값 얻기
		auto last_weekday_date = previous_weekday(ldt.local_time().date(), boost::gregorian::greg_weekday(find_weekday));
		time_duration dur = ptime(last_weekday_date) - ptime(boost::gregorian::date(1970, 1, 1));

		// utc로 변환하여 반환
		return std::time_t(dur.total_milliseconds() + offset);
	}

	// 주어진 시간(milliseconds) 을 time_zone 의 시간으로 변환.
	inline static boost::local_time::local_date_time change_timezone(const time_t& milliseconds, const char* time_zone = nullptr)
	{
		using namespace boost::posix_time;

		auto db_row = tz_database::get_mutable_instance().get(time_zone);
		return boost::local_time::local_date_time(to_ptime(milliseconds), db_row);
	}

	/************************************************************************/
	// 설명 : 해당 달의 마지막 요일을 조회
	// 파라메터 :
	//	- ms : 시간, 단위는 밀리초
	//	- time_zone : 타임 존 문자열
	//
	// 반환 값 : day
	/************************************************************************/
	static int32_t end_of_month_day(const time_t& ms_utc, const char* time_zone = nullptr)
	{
		const auto& db_row = tz_database::get_mutable_instance().get(time_zone);

		boost::local_time::local_date_time ldt(to_ptime(ms_utc), db_row);

		return boost::gregorian::gregorian_calendar::end_of_month_day(ldt.local_time().date().year(), ldt.local_time().date().month());
	}

	/************************************************************************/
	// 설명 : 이전 주 시간 데이터를 조회
	// 파라메터 :
	//	- ms : 시간, 단위는 밀리초
	//	- time_zone : 타임 존 문자열
	//	- weekDay : boost에 정의된 enum형 요일 값
	//
	// 반환 값 : day
	/************************************************************************/
	static time_t previous_weekday_0am(const time_t& ms_utc, const boost::date_time::weekdays& weekDay, const char* time_zone = nullptr)
	{
		using namespace boost::posix_time;

		const auto& db_row = tz_database::get_mutable_instance().get(time_zone);

		boost::local_time::local_date_time ldt(to_ptime(ms_utc), db_row);
		const time_t offset = ms_utc - nmsp::time::to_time_t(ldt.local_time());
		
		auto weekdayDate = ldt.local_time().date();
		auto dt = days_before_weekday(weekdayDate, boost::gregorian::greg_weekday(weekDay));
		if (dt.days() == 0)
			weekdayDate -= ptime::date_duration_type(7);
		else
			weekdayDate -= dt;

		time_duration dur = ptime(weekdayDate) - ptime(boost::gregorian::date(1970, 1, 1));

		return std::time_t(dur.total_milliseconds() + offset);
	}

	/************************************************************************/
	// 설명 : 다음 주 시간 데이터를 조회
	// 파라메터 :
	//	- ms : 시간, 단위는 밀리초
	//	- time_zone : 타임 존 문자열
	//	- weekDay : boost에 정의된 enum형 요일 값
	//
	// 반환 값 : day
	/************************************************************************/
	static time_t next_weekday_0am(const time_t& ms_utc, const boost::date_time::weekdays& weekDay, const char* time_zone = nullptr)
	{
		using namespace boost::posix_time;

		const auto& db_row = tz_database::get_mutable_instance().get(time_zone);

		boost::local_time::local_date_time ldt(to_ptime(ms_utc), db_row);
		const time_t offset = ms_utc - nmsp::time::to_time_t(ldt.local_time());

		auto weekdayDate = ldt.local_time().date();
		auto dt = days_before_weekday(weekdayDate, boost::gregorian::greg_weekday(weekDay));
		if (dt.days() == 0)
			weekdayDate += ptime::date_duration_type(7);
		else
			weekdayDate += dt;

		time_duration dur = ptime(weekdayDate) - ptime(boost::gregorian::date(1970, 1, 1));

		return std::time_t(dur.total_milliseconds() + offset);
	}
};

class time_functor
{
public:
	inline static time_t to_today0am(const char* time_zone = nullptr)
	{
		return time::to_0am(time::now(), time_zone);
	}

	// 기준 시간 기준으로 합한 초 값
	inline static time_t GetNextSec(const time_t& ms, const int32_t& addSec)
	{
		return nmsp::time::after(ms, nmsp::duration::seconds(addSec));
	}

	// 기준 시간 기준으로 합한 분 값
	inline static time_t GetNextMin(const time_t& ms, const int32_t& addMin)
	{
		return nmsp::time::after(ms, nmsp::duration::minuts(addMin));
	}

	// 기준 시간 기준으로 합한 시간 값
	inline static time_t GetNextHour(const time_t& ms, const int32_t& addHour)
	{
		return nmsp::time::after(ms, nmsp::duration::hours(addHour));
	}

	// 기준 시간 기준으로 합한 시간 값
	inline static time_t GetNextDay(const time_t& ms, const int32_t& addDay)
	{
		return nmsp::time::after(ms, nmsp::duration::days(addDay));
	}

	// 기준 시간 기준으로 합한 주간 값
	inline static time_t GetNextWeek(const time_t& ms, const int32_t& addWeek)
	{
		return nmsp::time::after(ms, nmsp::duration::weeks(addWeek));
	}

	// 기준 시간 기준으로 합한 월단위 값
	inline static time_t GetNextMonth(const time_t& ms, const int32_t& addMon)
	{
		using namespace boost::posix_time;

		const auto& db_row = tz_database::get_mutable_instance().get(nullptr);
		boost::local_time::local_date_time ldt(nmsp::time::to_ptime(ms), db_row);

		ptime correct_ms(
			ldt.date() + boost::gregorian::months(addMon),
			boost::posix_time::milliseconds(ldt.time_of_day().total_milliseconds())
		);

		time_duration dur = correct_ms - ptime(boost::gregorian::date(1970, 1, 1));
		return dur.total_milliseconds();
	}

	// 기준 시간 기준으로 뺀 초 값
	inline static time_t GetBeforeSec(const time_t& ms, const int32_t& subSec)
	{
		return nmsp::time::before(ms, nmsp::duration::seconds(subSec));
	}

	// 기준 시간 기준으로 뺀 분 값
	inline static time_t GetBeforeMin(const time_t& ms, const int32_t& subMin)
	{
		return nmsp::time::before(ms, nmsp::duration::minuts(subMin));
	}

	// 기준 시간 기준으로 뺀 시간 값
	inline static time_t GetBeforeHour(const time_t& ms, const int32_t& subHour)
	{
		return nmsp::time::before(ms, nmsp::duration::hours(subHour));
	}

	// 기준 시간 기준으로 뺀 시간 값
	inline static time_t GetBeforeDay(const time_t& ms, const int32_t& subDay)
	{
		return nmsp::time::before(ms, nmsp::duration::days(subDay));
	}

	// 기준 시간 기준으로 뺀 주간 값
	inline static time_t GetBeforeWeek(const time_t& ms, const int32_t& subWeek)
	{
		return nmsp::time::before(ms, nmsp::duration::weeks(subWeek));
	}

	// 기준 시간 기준으로 뺀 월단위 값
	inline static time_t GetBeforeMonth(const time_t& ms, const int32_t& subMon)
	{
		using namespace boost::posix_time;

		const auto& db_row = tz_database::get_mutable_instance().get(nullptr);
		boost::local_time::local_date_time ldt(nmsp::time::to_ptime(ms), db_row);

		ptime correct_ms(
			ldt.date() - boost::gregorian::months(subMon),
			boost::posix_time::milliseconds(ldt.time_of_day().total_milliseconds())
		);

		time_duration dur = correct_ms - ptime(boost::gregorian::date(1970, 1, 1));
		return dur.total_milliseconds();
	}

	// 각각 시간의 차 (초)
	inline static time_t GetDiffSec(const time_t& endMs, const time_t& startMs)
	{
		return nmsp::time::diff<nmsp::ratio::seconds>(endMs, startMs);
	}

	// 각각 시간의 차 (분)
	inline static int32_t GetDiffMin(const time_t& endMs, const time_t& startMs)
	{
		return static_cast<int32_t>(nmsp::time::diff<nmsp::ratio::minuts>(endMs, startMs));
	}

	// 각각 시간의 차 (시간)
	inline static int32_t GetDiffHour(const time_t& endMs, const time_t& startMs)
	{
		return static_cast<int32_t>(nmsp::time::diff<nmsp::ratio::hours>(endMs, startMs));
	}

	// 각각 시간의 차 (일)
	inline static int32_t GetDiffDay(const time_t& endMs, const time_t& startMs)
	{
		return static_cast<int32_t>(nmsp::time::diff<nmsp::ratio::days>(endMs, startMs));
	}

	// 마지막 일일 초기화 시간을 체크하기 위한 함수
	inline static time_t GetLastResetTime(const time_t& ms_utc, const time_t& configTimeMs)
	{
		time_t resetTime = to_today0am(nullptr) + configTimeMs;

		// 현재 시간이 오늘 초기화 시간 이전이라면 어제의 초기화 시간으로 체크
		if (ms_utc < resetTime)
			resetTime = nmsp::time::before(resetTime, nmsp::duration::days(1));

		return resetTime;
	}

	// 일일 초기화 시간을 체크하기 위한 함수
	inline static time_t GetResetTime(const time_t& ms_utc, const time_t& configTimeMs)
	{
		time_t resetTime = time::to_0am(ms_utc, nullptr) + configTimeMs;

		// 현재 시간이 오늘 초기화 시간 이전이라면 어제의 초기화 시간으로 체크
		if (ms_utc < resetTime)
			resetTime = nmsp::time::before(resetTime, nmsp::duration::days(1));

		return resetTime;
	}

	// 주간 초기화 시간을 체크하기 위한 함수
	inline static time_t GetResetWeekdayTime(const time_t& ms_utc, const int32_t& find_weekday, const time_t& configTimeMs)
	{
		time_t resetTime = time::to_last_weekday_0am(ms_utc, find_weekday, nullptr) + configTimeMs;

		// 현재 시간이 오늘 초기화 시간 이전이라면 지난주의 초기화 시간으로 체크
		if (ms_utc < resetTime)
			resetTime = nmsp::time::before(resetTime, nmsp::duration::weeks(1));

		return resetTime;
	}

	// 당월의 지정된 날짜의 시간을 반환한다.
	inline static time_t GetChangeDay(const time_t& ms_utc, const int32_t& day, const char* time_zone = nullptr)
	{
		const auto& db_row = tz_database::get_mutable_instance().get(time_zone);
		boost::local_time::local_date_time ldt(nmsp::time::to_ptime(ms_utc), db_row);
		int32_t monthDay = ldt.local_time().date().day().as_number();
		int32_t endMonthDay = nmsp::time::end_of_month_day(ms_utc, time_zone);

		// 해당 월 보다 day가 초과 할 경우 해당 월 최대 일로 보정 한다.
		int32_t correctDay = day;
		if (endMonthDay < day)
			correctDay = endMonthDay;

		return GetBeforeDay(ms_utc, monthDay - correctDay);
	}

	// 오늘의 요일을 반환한다. (0:일요일, 1:월요일 ...)
	inline static int32_t GetWeekDayToday(const char* time_zone = nullptr)
	{
		return time::to_weekday(time::now(), time_zone);
	}

	// 내일의 요일을 반환한다. (0:일요일, 1:월요일 ...)
	inline static int32_t GetWeekDayTomorrow(const char* time_zone = nullptr)
	{
		time_t tomorrow = time::after(time::now(), nmsp::duration::days(1));
		return time::to_weekday(tomorrow, time_zone);
	}

	// 지정된 시간 부터 미래의 요일을 반환한다. (0:일요일, 1:월요일 ...)
	inline static int32_t GetWeekDay(const time_t& ms_utc, const int32_t& addDay, const char* time_zone = nullptr)
	{
		time_t tomorrow = time::after(ms_utc, nmsp::duration::days(addDay));
		return time::to_weekday(tomorrow, time_zone);
	}

	// int32_t의 19831113형 숫자를 time_t로 변환한다.
	inline static time_t GetFlagToMsTime(const int32_t& flagTime, const char* time_zone = nullptr)
	{
		int32_t year = flagTime / 10000;
		int32_t month = (flagTime - (year * 10000)) / 100;
		int32_t day = (flagTime - (year * 10000) - (month * 100));

		std::string dateTime = boost::str(boost::format("%04d-%02d-%02d 00:00:00") % year % month % day);
		return time::from_string(dateTime, time_zone);
	}

	// time_t형 숫자를 int32_t의 19831113형 숫자로 변환한다.
	inline static int32_t GetMsToFlagTime(const time_t& ms_utc, const time_t& configTimeMs, const char* time_zone = nullptr)
	{
		std::string strFlagTime = time::to_string_flag(ms_utc - configTimeMs, time_zone);
		return std::atoi(strFlagTime.c_str());
	}

	inline static int64_t GetSec(const time_t& ms_utc, const char* time_zone = nullptr)
	{
		return time::change_timezone(ms_utc, time_zone).time_of_day().seconds();
	}

	inline static int64_t GetMinute(const time_t& ms_utc, const char* time_zone = nullptr)
	{
		return time::change_timezone(ms_utc, time_zone).time_of_day().minutes();
	}

	inline static int64_t GetHour(const time_t& ms_utc, const char* time_zone = nullptr)
	{
		return time::change_timezone(ms_utc, time_zone).time_of_day().hours();
	}

	inline static int64_t GetDay(const time_t& ms_utc, const char* time_zone = nullptr)
	{
		return time::change_timezone(ms_utc, time_zone).date().day_number();
	}

	inline static int64_t GetMonth(const time_t& ms_utc, const char* time_zone = nullptr)
	{
		return time::change_timezone(ms_utc, time_zone).date().month();
	}

	inline static int64_t GetYear(const time_t& ms_utc, const char* time_zone = nullptr)
	{
		return time::change_timezone(ms_utc, time_zone).date().year();
	}

	inline static int64_t GetWeek(const time_t& ms_utc, const char* time_zone = nullptr)
	{
		return time::change_timezone(ms_utc, time_zone).date().week_number();
	}

};
}

#endif



/*
const int32_t size = 12;
boost::gregorian::date date[size];

auto now = nmsp::time::now() - nmsp::ratio::days().num;
date[0] = nmsp::time::GetZoneTime(now).date();
date[1] = date[0] + boost::gregorian::months(1);
date[2] = date[1] + boost::gregorian::months(1);
date[3] = date[2] + boost::gregorian::months(1);
date[4] = date[3] + boost::gregorian::months(1);
date[5] = date[4] + boost::gregorian::months(1);

date[6] = date[0] - boost::gregorian::months(1);
date[7] = date[6] - boost::gregorian::months(1);
date[8] = date[7] - boost::gregorian::months(1);

date[9] = date[0] - boost::gregorian::months(2);
date[10] = date[9] - boost::gregorian::months(2);
date[11] = date[10] - boost::gregorian::months(2);

for (int i = 0; i < size; ++i)
LOG_ERROR(this) << i << " ==> year:" << date[i].year() << ", month:" << date[i].month().as_number() << ", day:" << date[i].day();
*/
