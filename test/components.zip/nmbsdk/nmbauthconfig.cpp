﻿#include "nmbsdkbase.h"

nmbauth_config::nmbauth_config(nmbsdk_component_impl* component)
	: m_component(component)
{
}


bool nmbauth_config::Load(const char* path)
{
	try
	{
		boost::property_tree::ptree props;
		boost::property_tree::read_json(path, props);

		m_enableLocalVerify = true; /* 항상 local로 사용한다. (props.get<int>("enable local verify", 1) == 1) ? true : false; */
		m_ip = props.get<std::string>("ip", "127.0.0.1");
		m_port = props.get<int>("port", 0);
		m_gameCode = props.get<std::string>("game code", "");
		m_apiKey = props.get<std::string>("api key", "");
		m_timeoutMs = props.get<uint32_t>("timeout", 10000); // verify read timeout (단위: milisecond)
	}
	catch (const std::exception& e)
	{
		LOG_ERROR_SYS(m_component) << "exception :: " << e.what() << std::endl;
		return false;
	}

	return true;
}
