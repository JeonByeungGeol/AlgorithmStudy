#pragma once

class nmbauth_config
{
public:
	explicit nmbauth_config(nmbsdk_component_impl* component);

	bool IsEnableLocalVerify() { return m_enableLocalVerify; }
	const std::string& GetIP() const { return m_ip; }
	int32_t GetPort() { return m_port; }
	const std::string& GetGameCode() const { return m_gameCode; }
	const std::string& GetAPIKey() const { return m_apiKey; }
	int32_t GetTimeoutMS() { return m_timeoutMs; }

	bool Load(const char* path);

private:
	bool m_enableLocalVerify;
	std::string m_ip;
	int32_t m_port;
	std::string m_gameCode;
	std::string m_apiKey;
	int32_t m_timeoutMs;

	nmbsdk_component_impl* m_component;
};