﻿#include "nmbsdkbase.h"

nmbauth_impl::nmbauth_impl(nmbsdk_component_impl* component)
	: m_component(component)
	, m_isConnected(false)
	, m_verifyType(verify_type::local)
	, m_ioThread(nullptr)
{
}

nmbauth_impl::~nmbauth_impl()
{
}

int nmbauth_impl::QueryInterface(const nmsp::UUID* iid, void** pInterface)
{
	*pInterface = static_cast<nmsp::nmbsdk::INMBAuth*>(this);
	reinterpret_cast<nmsp::nmbsdk::INMBAuth*>(*pInterface)->AddRef();
	return nmsp::_NMSP_NOERROR;
}

int nmbauth_impl::AddRef(void)
{
	return m_component->AddRef();
}

int nmbauth_impl::Release(void)
{
	return m_component->Release();
}

bool nmbauth_impl::Init(const std::string& ip, int32_t port, const std::string& gameCode, const std::string& apiKey, int32_t timeoutMs, verify_type verifyType){
	GOOGLE_PROTOBUF_VERIFY_VERSION;

	// 기본 정보 세팅
	m_ip = ip;
	m_port = port;
	m_gameCode = gameCode;
	m_apiKey = apiKey;
	m_timeoutMs = timeoutMs;
	m_verifyType = verifyType;

	marble::net::share::session_config sessionConfig;

	// connector 객체 생성
	m_connector = 
		marble::authentication::create_mobileauth_connector(
			m_ioService, 
			sessionConfig, 
			m_gameCode,
			m_apiKey
		);

	// 이벤트 콜백 등록
	m_connector->set_log_handler(std::bind(&nmbauth_impl::LoggingHandler, this, std::placeholders::_1, std::placeholders::_2));
	m_connector->set_connected_handler(std::bind(&nmbauth_impl::ConnectedHandler, this, std::placeholders::_1));
	m_connector->set_closed_handler(std::bind(&nmbauth_impl::ClosedHandler, this, std::placeholders::_1));

	// connector 객체 초기화
	boost::system::error_code ec;
	if (false == m_connector->init(ec))
	{
		// 에러 발생!!! 에러 로그 출력
		return false;
	}

	return true;
}

void nmbauth_impl::UnInit()
{
	if (m_isConnected)
	{
		DisConnect();
	}
	
	m_connector.reset();

	m_ioService.stop();

	if (nullptr != m_ioThread && true == m_ioThread->joinable()) {
		m_ioThread->join();
	}

	m_ioService.reset();

	m_verifyCallback = nullptr;
	m_verifySink = nullptr;

	google::protobuf::ShutdownProtobufLibrary();
}

void nmbauth_impl::RegisterVerifyCallback(nmsp::nmbsdk::INMBVerifyObject* obj)
{
	// 참조 카운트를 올려서 들고 있어야겠다!!
	m_verifySink = obj;

	m_verifyCallback = [this](const marble::authentication::mobileauth_connector::verify_gametoken_in_type& in, const marble::authentication::mobileauth_connector::verify_gametoken_out_type& out, const boost::system::error_code& ec) {
		if (marble::authentication::error::SUCCESS == ec.value())
		{
			// 성공
			if (nullptr != m_verifySink)
				m_verifySink->Exec(in.player_id_.c_str());
		}
		else
		{
			// 실패
			if (nullptr != m_verifySink)
				m_verifySink->OnError(in.player_id_.c_str(), ec.value(), ec.message().c_str());
		}
	};
}

void nmbauth_impl::Connect()
{
	m_connector->connect(m_ip, m_port);

	LOG_INFO_SYS(m_component) << "connecting. ip=" << m_ip << ", port=" << m_port << ", game_code=" << m_gameCode << ", api_key=" << m_apiKey;

	m_ioService.reset();

	// Thread로 올린다!!!
	m_ioThread = std::make_unique<std::thread>([this]()
	{
		m_ioService.run();
	});
}

bool nmbauth_impl::Verify(const char* pid, const char* gameToken)
{
	marble::authentication::mobileauth_connector::verify_gametoken_in_type in;
	in.game_code_ = m_gameCode;
	in.player_id_ = pid;
	in.game_token_ = gameToken;

	LOG_DEBUG_SYS(m_component) << "try gametoken verify. game_code=" << m_gameCode << ", pid=" << pid << ", gameToken=" << gameToken;
	boost::system::error_code ec;

	if (verify_type::local == m_verifyType)
	{
		marble::authentication::mobileauth_connector::verify_gametoken_out_type out;
		
		auto ret = m_connector->local_verify_game_token(
			in,
			out,
			ec
		);
		
		m_verifyCallback(in, out, ec);

		return ret;
	}

	return m_connector->remote_verify_game_token(
		in,
		m_timeoutMs,
		std::forward<_verify_callback_t>(m_verifyCallback),
		ec
	);
}

void nmbauth_impl::DisConnect()
{
	if (nullptr != m_connector)
	{
		m_connector->fini();
		m_connector->close();
	}

	m_isConnected = false;
}

void nmbauth_impl::LoggingHandler(boost::log::trivial::severity_level log_level, const std::string& log_msg)
{
	switch (log_level)
	{
	case boost::log::trivial::severity_level::error:
		LOG_ERROR_SYS(m_component) << log_msg;
		break;

	case boost::log::trivial::severity_level::warning:
		LOG_WARNING_SYS(m_component) << log_msg;
		break;

	case boost::log::trivial::severity_level::info:
		LOG_INFO_SYS(m_component) << log_msg;
		break;

	case boost::log::trivial::severity_level::debug:
		LOG_DEBUG_SYS(m_component) << log_msg;
		break;

	case boost::log::trivial::severity_level::trace:
		LOG_TRACE_SYS(m_component) << log_msg;
		break;

	default:
		LOG_FATAL_SYS(m_component) << log_msg;
		break;
	}
}

void nmbauth_impl::ConnectedHandler(const boost::system::error_code& ec)
{
	if (boost::system::errc::success != ec.value())
	{
		m_isConnected = false;

		LOG_ERROR_SYS(m_component) << "connection fail. error_code=" << ec.value() << ". message=" << ec.message();
	}
	else
	{
		m_isConnected = true;

		LOG_INFO_SYS(m_component) << "connection success.";

		// 아래 주석 해제하면 연결하자마자 연결을 끊는다.
		// 일단 연결을 끊어도 local verify는 통과한다;;
		//DisConnect();
	}
}

void nmbauth_impl::ClosedHandler(const boost::system::error_code& ec)
{
	LOG_INFO_SYS(m_component) << "disconnected.";
}