﻿#pragma once

class nmbauth_impl : public nmsp::nmbsdk::INMBAuth
{
public:
	using _this_t = nmbauth_impl;
	using _connector_ptr_t = boost::shared_ptr<marble::authentication::mobileauth_connector>;
	using _verify_callback_t = marble::authentication::mobileauth_connector::on_verify_game_token_handler_type;

	enum class verify_type : int32_t
	{
		local = 1,
		remote = 2,
	};

	explicit nmbauth_impl(nmbsdk_component_impl* component);
	virtual ~nmbauth_impl();

	virtual int QueryInterface(const nmsp::UUID* iid, void** pInterface) override;
	virtual int AddRef(void) override;
	virtual int Release(void) override;

	bool Init(const std::string& ip, int32_t port, const std::string& gameCode, const std::string& apiKey, int32_t timeoutMs, verify_type verifyType = nmbauth_impl::verify_type::local);
	void UnInit();

	virtual void RegisterVerifyCallback(nmsp::nmbsdk::INMBVerifyObject* obj) override;
	virtual void Connect() override;
	virtual bool Verify(const char* pid, const char* gameToken) override;

private:
	void DisConnect();

	// 내부 로그 출력용 메서드
	void LoggingHandler(boost::log::trivial::severity_level log_level, const std::string& log_msg);

	// 연결 성공 이벤트
	void ConnectedHandler(const boost::system::error_code& ec);

	// 연결 종료 이벤트
	void ClosedHandler(const boost::system::error_code& ec);

	bool m_isConnected;

	verify_type m_verifyType;

	std::string m_ip;
	int32_t m_port;
	int32_t m_timeoutMs;

	std::string m_gameCode;
	std::string m_apiKey;

	nmsp::smartinterface<nmsp::nmbsdk::INMBVerifyObject> m_verifySink;

	_verify_callback_t m_verifyCallback;

	_connector_ptr_t m_connector;

	std::unique_ptr<std::thread> m_ioThread;

	boost::asio::io_service m_ioService;
	
	nmbsdk_component_impl* m_component;
};