#include "nmbsdkbase.h"

timer_sink_impl::timer_sink_impl(nmbsdk_component_impl* componentImpl)
	: m_componentImpl(componentImpl)
{
	m_tvFixedCurrTime = 0;
	m_tvLastServerInfoSync = 0;
}

timer_sink_impl::~timer_sink_impl()
{
}

int timer_sink_impl::QueryInterface(const nmsp::UUID* iid, void** pInterface)
{
	if (*iid == nmsp::timer::UUID_ITimerSink)
	{
		*pInterface = static_cast<nmsp::timer::ITimerSink*>(this);
		reinterpret_cast<nmsp::timer::ITimerSink*>(*pInterface)->AddRef();
		return nmsp::_NMSP_NOERROR;
	}

	return nmsp::make_nmsp_error(m_componentImpl->GetServiceType(), _ERROR_INVALID_INTERFACE_REQ);
}

int timer_sink_impl::AddRef(void)
{
	return m_componentImpl->AddRef();
}

int timer_sink_impl::Release(void)
{
	return m_componentImpl->Release();
}

int timer_sink_impl::OnTimer(
	const nmsp::timer::_TIMER_KEY_T& tkTimerKey,
	const nmsp::timer::_TIMER_REL_KEY_T& rkVal,
	const nmsp::timer::_TIMER_VALUE_T& _tvCurrTime,
	const nmsp::timer::_TIMER_VALUE_T& _tvFixedCurrTime,
	const nmsp::timer::_TIMER_VALUE_T& _tvElapsedTime,
	const nmsp::timer::_TIMER_VALUE_T& _tvScaleCurrTime)
{
	m_tvFixedCurrTime = _tvFixedCurrTime;

	return nmsp::_NMSP_NOERROR;
}