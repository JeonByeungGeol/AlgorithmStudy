﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __NMBSDKBASE_H__
#define __NMBSDKBASE_H__

#ifndef WINVER // Allow use of features specific to Windows 95 and Windows NT 4 or later.
#define WINVER 0x0601 // Change this to the appropriate value to target Windows 98 and Windows 2000 or later.
#endif

#ifndef _WIN32_WINNT // Allow use of features specific to Windows NT 4 or later.
#define _WIN32_WINNT 0x0601 // Change this to the appropriate value to target Windows 98 and Windows 2000 or later.
#endif

#ifndef _WIN32_WINDOWS // Allow use of features specific to Windows 98 or later.
#define _WIN32_WINDOWS 0x0601 // Change this to the appropriate value to target Windows Me or later.
#endif

#if defined(_WIN32) || defined(_WIN64)
#pragma warning(disable : 4819 4244 4267)
#endif

///
#ifdef _DEBUG
#define DEBUG_NEW   new( _NORMAL_BLOCK, __FILE__, __LINE__)
#else
#define DEBUG_NEW
#endif 

#define _CRTDBG_MAP_ALLOC 
#include <stdlib.h> 
#include <crtdbg.h>

////////////////////////////////////////////////////////////////////////////////
//
#include <atomic>
#include <string>
#include <map>
#include <list>
#include <vector>
#include <unordered_map>
#include <thread>
#include <shared_mutex>
#include <assert.h>
#include <iostream>
#include <set>
#include <functional>
#include <algorithm>
#include <unordered_set>
#include <unordered_map>

//#include <filesystem>
#define _SILENCE_EXPERIMENTAL_FILESYSTEM_DEPRECATION_WARNING 1
#include <experimental/filesystem>

#include <sstream>

#include <boost/shared_ptr.hpp>
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/json_parser.hpp>

#include <marble/authentication/error.h>
#include <marble/authentication/mobileauth-connector.h>

#if defined(_WIN32) || defined(_WIN64)
#include <windows.h>
#ifdef min
#undef min
#endif

#ifdef max
#undef max
#endif
#else
#endif

////////////////////////////////////////////////////////////////////////////////
// ours include
#include "nmsputil.h"
#include "nmspInterface.h"
#include "nmspsmart.h"
#include "nmsperror.h"
#include "nmspmemallocate.h"
#include "nmspmemchunk.h"
#include "nmspmmgrchunk.h"
#include "nmspcomponentmain.h"
#include "nmspnewfrompool.h"
#include "nmsplogger.h"
#include "nmspmemorypool.h"
#include "nmspnodes.h"
#include "nmspcondition.h"
#include "nmspdispatchprioritypool.h"
#include "nmspdispatchthread.h"
#include "nmspsystem.h"
#include "nmspcsv.h"
#include "nmspvector3.h"
#include "nmsptime.h"
#include "nmsprandom.h"
#include "nmsptyper.h"
#include "nmsptypermacro.h"
#include "nmspdatacaster.h"
#include "nmspsheetload.h"
#include "nmsptokenize.h"
#include "nmspgrid.h"
#include "nmspstopwatch.h"

////////////////////////////////////////////////////////////////////////////////
// 인터페이스.
#include "timerinterface.h"
#include "servicetypedef.h"
#include "uniqueidinterface.h"
#include "nmbsdkinterface.h"
#include "httpinterface.h"

////////////////////////////////////////////////////////////////////////////////
// 내부에서 전역적으로 사용할 것들을 정의한다

// component implementation class
class nmbsdk_component_impl;

// 컴포넌트 내부에서 사용할 오류 정의
enum _ERROR_T
{
	_ERROR_INVALID_INTERFACE_REQ = 1,
	_ERROR_CONFIG = 2,
	_ERROR_INIT_LOG = 3,
	_ERROR_INIT_CONTAINER = 4,
	_ERROR_NOINTERFACE = 5,
	_ERROR_INIT_QUEUE = 6,
	_ERROR_MOBILECONNECTOR_FAIL = 7,
};

//  항상 component instance를 필요로 한다..
#define LV_TRACE					nmsp::logger::lv::trace
#define LV_DEBUG					nmsp::logger::lv::debug
#define LV_INFO						nmsp::logger::lv::info
#define LV_WARNING					nmsp::logger::lv::warning
#define LV_ERROR					nmsp::logger::lv::error
#define LV_FATAL					nmsp::logger::lv::fatal

#define LOG_TRACE(component, entityID) BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_TRACE) << __FUNCTION__ << "(" << __LINE__ << ")][" << entityID << "]["
#define LOG_DEBUG(component, entityID) BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_DEBUG) << __FUNCTION__ << "(" << __LINE__ << ")][" << entityID << "]["
#define LOG_INFO(component, entityID) BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_INFO) << __FUNCTION__ << "(" << __LINE__ << ")][" << entityID << "]["
#define LOG_WARNING(component, entityID) BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_WARNING) << __FUNCTION__ << "(" << __LINE__ << ")][" << entityID << "]["
#define LOG_ERROR(component, entityID) BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_ERROR) << __FUNCTION__ << "(" << __LINE__ << ")][" << entityID << "]["
#define LOG_FATAL(component, entityID) BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_FATAL) << __FUNCTION__ << "(" << __LINE__ << ")][" << entityID << "]["

#define LOG_TRACE_SYS(component) BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_TRACE) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_DEBUG_SYS(component) BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_DEBUG) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_INFO_SYS(component) BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_INFO) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_WARNING_SYS(component) BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_WARNING) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_ERROR_SYS(component) BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_ERROR) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_FATAL_SYS(component) BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_FATAL) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["

#ifdef _DEBUG
using _nmbauth_allocator_t = nmsp::default_allocator;
#else
using _nmbauth_allocator_t = nmsp::pool::allocator_from_pool<>;
#endif

// tabledata.h 호환용
template< class T >
using TArray = std::vector< T, nmsp::stl_default_allocator<T, _nmbauth_allocator_t> >;

template< class T >
using TMap = std::map<int, T>;

template< class T >
using TList = std::list< T, nmsp::stl_default_allocator<T, _nmbauth_allocator_t> >;

// 
#ifndef ENUM_INT
#define ENUM_INT(value) (static_cast<int32_t>(value))
#endif // ENUM_INT

////////////////////////////////////////////////////////////////////////////////
// 구현 의존적인 것임
#include "nmbauthconfig.h"
#include "timersinkimpl.h"
#include "nmbauthimpl.h"
#include "nmbsdk.h"

#endif
