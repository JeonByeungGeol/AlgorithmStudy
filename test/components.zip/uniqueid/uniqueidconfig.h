////////////////////////////////////////////////////////////////////////////////
// �ۼ���: huelee
// ��  ��:
//
//

// ȣȯ���� ���ؼ�..
#pragma once
#ifndef __UNIQUEIDCONFIG_H__
#define __UNIQUEIDCONFIG_H__

// ���������� �д´�.
class uniqueid_config
{
public:
	uniqueid_config(uniqueid_component_impl* pcComponentImpl);
	virtual ~uniqueid_config();

	bool Load(const char* pszConfig);

public:
	const std::string& GetUuidRepPath() const
	{
		return m_cstrUuidRepPath;
	}
	uint16_t GetBuldSize() const
	{
		return m_bulkSize;
	}

private:
	std::string m_cstrUuidRepPath;
	uint16_t m_bulkSize;


private:
	uniqueid_component_impl* m_pcComponentImpl;
};

#endif
