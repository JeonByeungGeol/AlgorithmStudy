////////////////////////////////////////////////////////////////////////////////
// �ۼ���: huelee
// ��  ��:
//
//

// ȣȯ���� ���ؼ�..
#pragma once
#ifndef __UNIQUEIDIMPL_H__
#define __UNIQUEIDIMPL_H__

//
class uniqueid_impl: public nmsp::uniqueid::IUniqueID
{
	const uint64_t FILEGUID_MAX_GUIDSEQ = 0x00007FFFFFFFFFFFL;

public:
	uniqueid_impl(uniqueid_component_impl* componentImpl);
	virtual ~uniqueid_impl() = default;
	
	int Init(uint16_t bulkSize, const char* repPath);
	void Uninit();

	virtual int QueryInterface(const nmsp::UUID* iid, void **ppvObject);
	virtual int AddRef();
	virtual int Release();
	virtual int GenerateUuid(bool signbit, uint16_t id, nmsp::uniqueid::_uuid_t* val);

private:
	bool SaveFileGuid(uint64_t ui64Seq);

private:
	std::mutex m_lock;
	std::ofstream m_repository;
	uint16_t m_bulkSize;
	uint64_t m_currSeq;
	uint64_t m_seq;
	uniqueid_component_impl* m_componentImpl;
};
//

#endif
