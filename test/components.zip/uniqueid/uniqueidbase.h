﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __UNIQUEIDBASE_H__
#define __UNIQUEIDBASE_H__

#if defined(_WIN32) || defined(_WIN64)
#pragma warning(disable : 4819)
#pragma warning(error : 4715)
#include <windows.h>
#ifdef min
	#undef min									// macro 충돌
#endif
#ifdef max
	#undef max									// macro 충돌
#endif

#ifdef _DEBUG
#define DEBUG_NEW   new( _NORMAL_BLOCK, __FILE__, __LINE__)
#else
#define DEBUG_NEW
#endif 

#define _CRTDBG_UNIQUEID_ALLOC 
#include <stdlib.h> 
#include <crtdbg.h>

#else
#endif

////////////////////////////////////////////////////////////////////////////////
//
#include <atomic>
#include <string>
#include <map>
#include <unordered_map>
#include <list>
#include <vector>
#include <thread>
#include <shared_mutex>
#include <assert.h>
#include <boost/property_tree/json_parser.hpp>
#include <iostream>
#include <set>
#include <functional>
#include <algorithm>
#include <unordered_set>

////////////////////////////////////////////////////////////////////////////////
// ours include
#include "nmsputil.h"
#include "nmspInterface.h"
#include "nmspsmart.h"
#include "nmsperror.h"
#include "nmspmemallocate.h"
#include "nmspmemchunk.h"
#include "nmspmmgrchunk.h"
#include "nmspcomponentmain.h"
#include "nmspnewfrompool.h"
#include "nmspmemorypool.h"
#include "nmsplogger.h"
#include "nmspnodes.h"
#include "nmspsystem.h"

////////////////////////////////////////////////////////////////////////////////
// 인터페이스..
#include "loginterface.h"
#include "uniqueidinterface.h"
#include "servicetypedef.h"

////////////////////////////////////////////////////////////////////////////////
// 내부에서 전역적으로 사용할 것들을 정의한다

// component implementation class
class uniqueid_component_impl;
class uniqueid_config;

// 컴포넌트 내부에서 사용할 오류 정의
enum _UNIQUEID_ERROR_T
{
	_UNIQUEID_ERROR_INVALID_INTERFACE_REQ	= 1,
	_UNIQUEID_ERROR_CONFIG					= 2,
	_UNIQUEID_ERROR_INIT_LOG				= 3,
	_UNIQUEID_ERROR_MEMORY					= 4,
	_UNIQUEID_ERROR_INVALID_ID				= 5,
	_UNIQUEID_ERROR_SAVEERROR				= 6,
	_UNIQUEID_ERROR_FULLID					= 7,
	_UNIQUEID_ERROR_OPEN					= 8,
	_UNIQUEID_ERROR_INIT_UNIQUEID			= 9,
};

// 항상 component instance를 필요로 한다..
#define LV_TRACE	nmsp::logger::lv::trace
#define LV_DEBUG	nmsp::logger::lv::debug
#define LV_INFO		nmsp::logger::lv::info
#define LV_WARNING	nmsp::logger::lv::warning
#define LV_ERROR	nmsp::logger::lv::error
#define LV_FATAL	nmsp::logger::lv::fatal

#define LOG_TRACE_SYS(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_TRACE) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_DEBUG_SYS(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_DEBUG) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_INFO_SYS(component)				BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_INFO) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_WARNING_SYS(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_WARNING) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_ERROR_SYS(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_ERROR) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_FATAL_SYS(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_FATAL) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["

#ifdef _DEBUG
using _uniqueid_allocator_t = nmsp::default_allocator;
#else
using _uniqueid_allocator_t = nmsp::pool::allocator_from_pool<>;
#endif

////////////////////////////////////////////////////////////////////////////////
// 구현 의존적인 것임
#include "uniqueidconfig.h"
#include "uniqueidimpl.h"
#include "uniqueid.h"

#endif
