﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 가능하면 이것 하나로..
#include "uniqueidbase.h"

//
uniqueid_config::uniqueid_config(uniqueid_component_impl* pcComponentImpl)
	: m_pcComponentImpl(pcComponentImpl)
{
}

uniqueid_config::~uniqueid_config()
{
}

bool uniqueid_config::Load(const char* pszConfig)
{
	try
	{
		boost::property_tree::ptree props;
		boost::property_tree::read_json(pszConfig, props);

		m_cstrUuidRepPath = props.get<std::string>("uuid repository path");
		m_bulkSize = props.get<uint16_t>("bulk size");

		if (0 >= m_bulkSize)
		{
			LOG_ERROR_SYS(m_pcComponentImpl) << "invalid bulk size " << m_bulkSize << std::endl;
			return false;
		}
	}
	catch (const std::exception& e)
	{
		LOG_ERROR_SYS(m_pcComponentImpl) << "exception :: " << e.what() << std::endl;
		return false;
	}

	return true;
}
