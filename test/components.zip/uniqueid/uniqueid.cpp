﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 가능하면 이것 하나로..
#include "uniqueidbase.h"

// 이 정의가 꼭 필요하다..
IMPLEMENT_NMSPMODULE(uniqueid_component_impl)

////////////////////////////////////////////////////////////////////////////////
// 
uniqueid_component_impl::uniqueid_component_impl()
	: m_nRefs(1)
	, m_uiSelf(nmsp::_NMSP_RESERVED_SERVICETYPE_NULL)
	, m_cConfig(this)
	, m_uniqueidImpl(this)
	, m_outConsole(false)
{
}

uniqueid_component_impl::~uniqueid_component_impl()
{
	// 서버간 연결 정리하자
	if (nullptr != m_cRefLog)
		m_cRefLog = nullptr;
}

int uniqueid_component_impl::QueryInterface(const nmsp::UUID* iid, void** pInterface)
{
	// 모든 정의된 인터페이스에서는 어떤 다른 인터페이스라도 QueryInterface가 성공해야 한다
	// 이 Component에서 지원하는 인터페이스를 다 모아놓았음.
	if (*iid == nmsp::UUID_IComponentBase)
	{
		*pInterface = static_cast<nmsp::IComponentBase*>(this);
		reinterpret_cast<nmsp::IComponentBase*>(*pInterface)->AddRef();
		return nmsp::_NMSP_NOERROR;
	}
	else
	if (*iid == nmsp::UUID_IComponent)
	{
		*pInterface = static_cast<nmsp::IComponent*>(this);
		reinterpret_cast<nmsp::IComponent*>(*pInterface)->AddRef();
		return nmsp::_NMSP_NOERROR;
	}
	else
	if (*iid == nmsp::uniqueid::UUID_IUniqueID)
	{
		*pInterface = static_cast<nmsp::uniqueid::IUniqueID*>(&m_uniqueidImpl);
		reinterpret_cast<nmsp::uniqueid::IUniqueID*>(*pInterface)->AddRef();
		return nmsp::_NMSP_NOERROR;
	}

	return nmsp::make_nmsp_error(m_uiSelf, _UNIQUEID_ERROR_INVALID_INTERFACE_REQ);
}

int uniqueid_component_impl::AddRef(void)
{
	return ++m_nRefs;
}

int uniqueid_component_impl::Release(void)
{
	int nLastRef = --m_nRefs;
	if (0 == nLastRef)
	{
		delete this;
		return 0;
	}

	return nLastRef;
}

int uniqueid_component_impl::SetBaseInfo(unsigned short uiServiceType, nmsp::IComponentContainer* pISink, int nLenPath, const char* pszCfgPath, int logLevel, bool outConsole, const char* timeZoneName)
{
	m_uiSelf = uiServiceType;

	int nRet = pISink->QueryInterface(&nmsp::UUID_IComponentContainer, static_cast<void**>(m_cRefContainer));
	if (nmsp::_NMSP_NOERROR != nRet)
		return nRet;

	// 설정
	m_cstrCfgPath.assign(pszCfgPath, nLenPath);

	m_logLevel = static_cast<nmsp::logger::lv::severity_level>(logLevel);
	m_outConsole = outConsole;

	// 
	return nmsp::_NMSP_NOERROR;
}

int uniqueid_component_impl::PreInit()
{
	// 다른 컴포넌트들을 참조해 봅시다
	m_cRefContainer->QueryComponent(nmsp::_SERVICETYPE_LOG, &nmsp::log::UUID_ILog, static_cast<void**>(m_cRefLog));

	// 로그를 초기화 한다
	if (false == m_logger.init(m_uiSelf, m_cRefLog, m_logLevel, "", m_outConsole))
		return nmsp::make_nmsp_error(m_uiSelf, _UNIQUEID_ERROR_INIT_LOG);

	// 
	if (false == m_cConfig.Load(m_cstrCfgPath.c_str()))
		return nmsp::make_nmsp_error(m_uiSelf, _UNIQUEID_ERROR_CONFIG);

	// 
	auto ret = m_uniqueidImpl.Init(m_cConfig.GetBuldSize(), m_cConfig.GetUuidRepPath().c_str());
	if (nmsp::_NMSP_NOERROR != ret)
		return ret;

	return nmsp::_NMSP_NOERROR;
}

int uniqueid_component_impl::Init()
{
#ifdef _DEBUG
	LOG_INFO_SYS(this) << "uniqueid start!";
#endif

	return nmsp::_NMSP_NOERROR;
}

void uniqueid_component_impl::Uninit()
{
}

void uniqueid_component_impl::PostUninit()
{
}
