﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 가능하면 이것 하나로..
#include "logbase.h"

// 이 정의가 꼭 필요하다..
IMPLEMENT_NMSPMODULE(log_component_impl)

//
#if defined(_WIN32) || defined(_WIN64)

#pragma warning (disable : 4091)

#include <dbghelp.h>
#include <Psapi.h>
#include <process.h>

#pragma warning (default : 4091)

std::string s_dumpPath;

// 
typedef struct _DUMP_PARAMETER
{
	DWORD  m_dwThreadId;
	PEXCEPTION_POINTERS m_pstExPtrs;
} _DUMP_PARAMETER_T, *_PDUMP_PARAMETER_T;

//
unsigned int __stdcall
CreateMiniDump(LPVOID lpParam)
{
	_PDUMP_PARAMETER_T pstParam = reinterpret_cast<_PDUMP_PARAMETER_T>(lpParam);

	char achDumpFullPath[_MAX_PATH + 1];

	// Create the dump file name
	time_t tCurtime;
	time(&tCurtime);

	struct tm stCurtimeex;
	localtime_s(&stCurtimeex, &tCurtime);

	int nBuffLen = _snprintf_s(
		achDumpFullPath,
		_countof(achDumpFullPath),
		_TRUNCATE,
		"%sminidump_%04d%02d%02d_%02d%02d.dmp",
		s_dumpPath.c_str(),
		static_cast<int>(stCurtimeex.tm_year + 1900),
		static_cast<int>(stCurtimeex.tm_mon + 1),
		static_cast<int>(stCurtimeex.tm_mday),
		static_cast<int>(stCurtimeex.tm_hour),
		static_cast<int>(stCurtimeex.tm_min));
	if (0 >= nBuffLen)
	{
		return -1;
	}

	// Create the file
	HANDLE hFile = CreateFileA(
		achDumpFullPath,
		GENERIC_WRITE,
		0,
		NULL,
		CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL,
		NULL);

	//
	// Write the minidump to the file
	//
	if (INVALID_HANDLE_VALUE == hFile)
	{
		return -2;
	}

	//
	MINIDUMP_EXCEPTION_INFORMATION eInfo;
	eInfo.ThreadId = pstParam->m_dwThreadId;
	eInfo.ExceptionPointers = pstParam->m_pstExPtrs;
	eInfo.ClientPointers = FALSE;

	// 추후 타입 변경을 위해서.. 
	MINIDUMP_TYPE minidumpType = MiniDumpWithFullMemory;

	//
	MiniDumpWriteDump(
		GetCurrentProcess(),
		GetCurrentProcessId(),
		hFile,
		minidumpType, //MiniDumpNormal,
		pstParam->m_pstExPtrs ? &eInfo : NULL,
		NULL,
		NULL);

	// Close file
	CloseHandle(hFile);

	return 0;
}

// 
LONG CALLBACK UnhandledExceptionHandler(PEXCEPTION_POINTERS pExInfo)
{
	_DUMP_PARAMETER_T stInfo;

	stInfo.m_dwThreadId = ::GetCurrentThreadId();
	stInfo.m_pstExPtrs = pExInfo;

	//
	if (NULL != pExInfo && EXCEPTION_STACK_OVERFLOW == pExInfo->ExceptionRecord->ExceptionCode)
	{
		HANDLE hThread = reinterpret_cast<HANDLE>(_beginthreadex(0, 0, CreateMiniDump, &stInfo, 0, nullptr));
		if (NULL != hThread)
		{
			WaitForSingleObject(hThread, INFINITE);
			CloseHandle(hThread);
		}
		else
		{
			CreateMiniDump(&stInfo);
		}
	}
	else
	{
		CreateMiniDump(&stInfo);
	}

	return EXCEPTION_EXECUTE_HANDLER;
}

#endif

////////////////////////////////////////////////////////////////////////////////
// 
log_component_impl::log_component_impl()
	: m_nRefs(1)
	, m_uiSelf(nmsp::_NMSP_RESERVED_SERVICETYPE_NULL)
	, m_cConfig(this)
	, m_cLogImpl(this)
{
}

log_component_impl::~log_component_impl()
{
	// 혹시나 있을지도 모르는 로그를 위해... 명시적으로 호출을...
	m_cLogImpl.Uninit();
}

int log_component_impl::QueryInterface(const nmsp::UUID* iid, void** pInterface)
{
	// 모든 정의된 인터페이스에서는 어떤 다른 인터페이스라도 QueryInterface가 성공해야 한다
	// 이 Component에서 지원하는 인터페이스를 다 모아놓았음.
	if (*iid == nmsp::UUID_IComponentBase)
	{
		*pInterface = static_cast<nmsp::IComponentBase*>(this);
		reinterpret_cast<nmsp::IComponentBase*>(*pInterface)->AddRef();
		return nmsp::_NMSP_NOERROR;
	}
	else
	if (*iid == nmsp::UUID_IComponent)
	{
		*pInterface = static_cast<nmsp::IComponent*>(this);
		reinterpret_cast<nmsp::IComponent*>(*pInterface)->AddRef();
		return nmsp::_NMSP_NOERROR;
	}
	else
	if (*iid == nmsp::log::UUID_ILog)
	{
		*pInterface = static_cast<nmsp::log::ILog*>(&m_cLogImpl);
		reinterpret_cast<nmsp::log::ILog*>(*pInterface)->AddRef();
		return nmsp::_NMSP_NOERROR;
	}

	return nmsp::make_nmsp_error(m_uiSelf, _LOG_ERROR_INVALID_INTERFACE_REQ);
}

int log_component_impl::AddRef(void)
{
	return ++m_nRefs;
}

int log_component_impl::Release(void)
{
	int nLastRef = --m_nRefs;
	if (0 == nLastRef)
	{
		delete this;
		return 0;
	}

	return nLastRef;
}

int log_component_impl::SetBaseInfo(unsigned short uiServiceType, nmsp::IComponentContainer* pISink, int nLenPath, const char* pszCfgPath, int logLevel, bool outConsole, const char* timeZoneName)
{
	m_uiSelf = uiServiceType;

	int nRet = pISink->QueryInterface(&nmsp::UUID_IComponentContainer, static_cast<void**>(m_cRefContainer));
	if (nmsp::_NMSP_NOERROR != nRet)
		return nRet;

	// 설정
	std::string cCfg(pszCfgPath, nLenPath);

	if (false == m_cConfig.Load(cCfg.c_str()))
		return nmsp::make_nmsp_error(uiServiceType, _LOG_ERROR_CONFIG);

	//
#if defined(_WIN32) || defined(_WIN64)
	if (true == m_cConfig.GetDumpFlag())
	{
		s_dumpPath = m_cConfig.GetDumpPath();
		SetUnhandledExceptionFilter(UnhandledExceptionHandler);
	}
#endif

	//
	if (false == m_cLogImpl.Init())
		return nmsp::make_nmsp_error(uiServiceType, _LOG_ERROR_IMPL_INIT);

	return nmsp::_NMSP_NOERROR;
}

int log_component_impl::PreInit()
{
	return nmsp::_NMSP_NOERROR;
}

int log_component_impl::Init()
{
	return nmsp::_NMSP_NOERROR;
}

void log_component_impl::Uninit()
{
}

void log_component_impl::PostUninit()
{
}
