﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __LOG_H__
#define __LOG_H__

//
class log_component_impl: public nmsp::IComponent
{
public:
	log_component_impl();
	virtual ~log_component_impl();

	virtual int QueryInterface(const nmsp::UUID* iid, void** pInterface) override;
	virtual int AddRef(void) override;
	virtual int Release(void) override;
	virtual int SetBaseInfo(unsigned short uiServiceType, nmsp::IComponentContainer* pISink, int nLenPath, const char* pszCfgPath, int logLevel, bool outConsole, const char* timeZoneName) override;
	virtual int PreInit() override;
	virtual int Init() override;
	virtual void Uninit() override;
	virtual void PostUninit() override;
	//
	inline unsigned short GetServiceType() const
	{
		return m_uiSelf;
	}
	inline operator log_config& ()
	{
		return m_cConfig;
	}
	inline operator nmsp::IComponentContainer* ()
	{
		return m_cRefContainer;
	}

private:
	std::atomic_int m_nRefs;
	unsigned short m_uiSelf;
	nmsp::smartinterface<nmsp::IComponentContainer> m_cRefContainer;
	log_config m_cConfig;
	log_impl m_cLogImpl;
};

#endif
