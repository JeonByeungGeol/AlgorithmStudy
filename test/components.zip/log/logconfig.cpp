////////////////////////////////////////////////////////////////////////////////
// �ۼ���: huelee
// ��  ��:
//
//

// �����ϸ� �̰� �ϳ���..
#include "logbase.h"

//#include <filesystem>
#define _SILENCE_EXPERIMENTAL_FILESYSTEM_DEPRECATION_WARNING 1
#include <experimental/filesystem>


//
log_config::log_config(log_component_impl* pcComponentImpl)
	: m_pcComponentImpl(pcComponentImpl)
{
}

log_config::~log_config()
{
}

bool log_config::Load(const char* pszConfig)
{
	try
	{
		boost::property_tree::ptree props;
		boost::property_tree::read_json(pszConfig, props);

		m_cstrPath = props.get<std::string>("log path", "");
		m_cstrPrefixName = props.get<std::string>("logfile prefix name", "");
#if defined(_WIN32) || defined(_WIN64)
		m_cstrDumpPath = props.get<std::string>("dump path", "");
		m_bDumpFlag = props.get<bool>("dump flag", true);
#endif
		m_bAutoRefresh = props.get<bool>("auto refresh", true);
		m_nMaxLogSize = props.get<int>("rotation logfile size", 10);						// mega����
		m_nRefreshHour = props.get<int>("rotation hour", 0);
		m_nRefreshMin = props.get<int>("rotation minute", 0);
		m_nRefreshSec = props.get<int>("rotation second", 0);

		if (0 >= m_nMaxLogSize)
			return false;

		if (0 > m_nRefreshHour || 24 <= m_nRefreshHour)
			return false;

		if (0 > m_nRefreshMin || 59 <= m_nRefreshMin)
			return false;

		if (0 > m_nRefreshSec || 59 <= m_nRefreshSec)
			return false;

		// dump path�� �����.
#if defined(_WIN32) || defined(_WIN64)
		if (true == m_cstrDumpPath.empty())
		{
			m_cstrDumpPath = m_cstrPath;
			m_cstrDumpPath += '/';
		}
#endif
	}
	catch (std::exception&)
	{
		return false;
	}

	return true;
}
