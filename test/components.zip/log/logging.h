////////////////////////////////////////////////////////////////////////////////
// �ۼ���: 
// ��  ��: 
//
//

// ȣȯ���� ���ؼ�..
#pragma once
#ifndef __LOGGING_H__
#define __LOGGING_H__

/*
class xxxx :
	public boost::log::sinks::basic_formatted_sink_backend<char, boost::log::sinks::concurrent_feeding >
{
public:
	// The function consumes the log records that come from the frontend
	void consume(boost::log::record_view const& rec, string_type const& command_line)
	{
		boost::log::trivial::severity_level eSeverity = boost::log::trivial::severity_level::info;
		auto itr = rec.attribute_values().find("Severity");
		if (itr != rec.attribute_values().end())
		{
			const boost::log::value_ref< boost::log::trivial::severity_level > level = itr->second.extract<boost::log::trivial::severity_level>();
			eSeverity = level.get();
		}
		//boost::log::value_ref< boost::log::trivial::severity_level > level = boost::log::extract< boost::log::trivial::severity_level >("Severity", rec);
		//eSeverity = level.get();

		const char* pszString = command_line.c_str();
		auto len = command_line.size();
		std::cout << pszString;
	}
};
*/

class logging : public boost::log::sources::severity_logger_mt<boost::log::trivial::severity_level>
{
	static const std::size_t MAX_QUEUE_SIZE = 100000;
	// record queuing strategy : bounded_fifo_queue, drop_on_overflow
	// http://www.boost.org/doc/libs/1_54_0/libs/log/doc/html/log/detailed/sink_frontends.html#log.detailed.sink_frontends.async.customizing_record_queueing_strategy
	typedef boost::log::sinks::asynchronous_sink<boost::log::sinks::text_file_backend, boost::log::sinks::bounded_fifo_queue<MAX_QUEUE_SIZE, boost::log::sinks::drop_on_overflow>> text_sink_t;
	// for console log
	typedef boost::log::sinks::synchronous_sink<boost::log::sinks::text_ostream_backend> console_sink_t;

public:
	logging(void);
	~logging(void);
	bool Init(const std::string& path, const std::string& prefix_name = "", bool auto_flush = true, int size = 10, int hour = 0, int min = 0, int sec = 0);
	void Uninit();

private:
	boost::shared_ptr<text_sink_t> m_sink;
};

#endif
