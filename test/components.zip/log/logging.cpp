////////////////////////////////////////////////////////////////////////////////
// �ۼ���: 
// ��  ��:
//
//
#include "logbase.h"

//
logging::logging(void)
{
}

logging::~logging(void)
{
}

bool logging::Init(const std::string& path, const std::string& prefix_name, bool auto_flush, int size, int hour, int min, int sec)
{
	boost::filesystem::path log_path;

	if (true == path.empty())
	{
		log_path = boost::filesystem::initial_path();
		log_path /= "/logs";
	}
	else
	{
		log_path = path;
	}

	if (true == log_path.has_filename())
	{
		log_path /= "/";
	}

	boost::log::process_id pid = boost::log::aux::this_process::get_id();

	if (true == prefix_name.empty())
	{
		log_path /= (boost::log::aux::get_process_name() + "_%Y-%m-%d_%H-%M-%S.%2N_" + std::to_string(pid.native_id()) + ".log");
	}
	else
	{
		log_path /= prefix_name + "_" + (boost::log::aux::get_process_name() + "_%Y-%m-%d_%H-%M-%S.%2N_" + std::to_string(pid.native_id()) + ".log");
	}

	boost::shared_ptr<boost::log::sinks::text_file_backend> backend =
		boost::make_shared<boost::log::sinks::text_file_backend>(
			boost::log::keywords::file_name = log_path.string(),
			boost::log::keywords::rotation_size = size * 1024 * 1024,
			boost::log::keywords::time_based_rotation = boost::log::sinks::file::rotation_at_time_point(hour, min, sec)
			);

	backend->auto_flush(auto_flush);

	m_sink = boost::make_shared<text_sink_t>(backend);
	boost::log::core::get()->add_sink(m_sink);

	return true;
}

void logging::Uninit()
{
	if (m_sink)
	{
		boost::log::core::get()->remove_sink(m_sink);
		m_sink->stop(); // Break the feeding loop
		m_sink->flush(); // Flush all log records that may have left buffered
		m_sink.reset();
	}
}
