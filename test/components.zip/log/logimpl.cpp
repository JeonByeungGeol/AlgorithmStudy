﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 가능하면 이것 하나로..
#include "logbase.h"

//
log_impl::log_impl(log_component_impl* pcComponentImpl)
	: m_pcComponentImpl(pcComponentImpl)
{
}
log_impl::~log_impl()
{
}

bool log_impl::Init()
{
	try
	{
		if (false == m_cLogging.Init(
								static_cast<log_config&>(*m_pcComponentImpl).GetPath(),
								static_cast<log_config&>(*m_pcComponentImpl).GetPrefixName(),
								static_cast<log_config&>(*m_pcComponentImpl).GetAutoRefresh(),
								static_cast<log_config&>(*m_pcComponentImpl).GetSize(),
								static_cast<log_config&>(*m_pcComponentImpl).GetHour(),
								static_cast<log_config&>(*m_pcComponentImpl).GetMinute(),
								static_cast<log_config&>(*m_pcComponentImpl).GetSecond()))
		{
			return false;
		}

		BOOST_LOG_SEV(m_cLogging, boost::log::trivial::info) << "start!";
	}
	catch (const std::exception&)
	{
		return false;
	}

	return true;
}

void log_impl::Uninit()
{
	m_cLogging.Uninit();
}

int log_impl::QueryInterface(const nmsp::UUID* iid, void **ppvObject)
{
	return m_pcComponentImpl->QueryInterface(iid, ppvObject);
}

int log_impl::AddRef()
{
	return m_pcComponentImpl->AddRef();
}

int log_impl::Release()
{
	return m_pcComponentImpl->Release();
}

int log_impl::LogAnsi(unsigned short uiServiceType, int nSeverity, const char* achData)
{
	if (m_serv2Severities.Get(uiServiceType) > nSeverity)
		return nmsp::_NMSP_NOERROR;

	// 기록을 하는곳
	BOOST_LOG_SEV(m_cLogging, boost::log::trivial::info) << achData;

	return nmsp::_NMSP_NOERROR;
}

int log_impl::Log2Ansi(unsigned short uiServiceType, int nSeverity, int nLen, const char* achData)
{
	if (m_serv2Severities.Get(uiServiceType) > nSeverity)
		return nmsp::_NMSP_NOERROR;

	BOOST_LOG_SEV(m_cLogging, boost::log::trivial::info).write(achData, nLen);
	return nmsp::_NMSP_NOERROR;
}

int log_impl::LogUnicode(unsigned short uiServiceType, int nSeverity, const wchar_t* awcData)
{
	if (m_serv2Severities.Get(uiServiceType) > nSeverity)
		return nmsp::_NMSP_NOERROR;

	// 기록을 하는곳
	BOOST_LOG_SEV(m_cLogging, boost::log::trivial::info) << awcData;

	return nmsp::_NMSP_NOERROR;
}

int log_impl::Log2Unicode(unsigned short uiServiceType, int nSeverity, int nLen, const wchar_t* awcData)
{
	if (m_serv2Severities.Get(uiServiceType) > nSeverity)
		return nmsp::_NMSP_NOERROR;

	BOOST_LOG_SEV(m_cLogging, boost::log::trivial::info).write(awcData, nLen);
	return nmsp::_NMSP_NOERROR;
}

int log_impl::SetSeverity(unsigned short uiServiceType, int nNewSeverity, int* pnOldLevel)
{
	m_serv2Severities.Update(uiServiceType, nNewSeverity, *pnOldLevel);
	return nmsp::_NMSP_NOERROR;
}

int log_impl::GetSeverity(unsigned short uiServiceType, int* pnOldLevel)
{
	*pnOldLevel = m_serv2Severities.Get(uiServiceType);
	return nmsp::_NMSP_NOERROR;
}
