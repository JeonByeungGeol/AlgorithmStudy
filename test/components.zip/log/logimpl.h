////////////////////////////////////////////////////////////////////////////////
// �ۼ���: huelee
// ��  ��: csv�� parse  �Լ��� �� �߰��ϱ� ���ؼ�
//
//

// ȣȯ���� ���ؼ�..
#pragma once
#ifndef __LOGIMPL_H__
#define __LOGIMPL_H__

//
class log_impl : public nmsp::log::ILog
{
	// servicetype�� ���� severity�� �����Ѵ�
	class _serv2severities_t
	{
		using _severity_map_t = std::unordered_map<unsigned short, int>;
	public:
		_serv2severities_t() = default;
		virtual ~_serv2severities_t() = default;

		inline void Update(unsigned short serv, int severity, int& oldseverity)
		{
			std::unique_lock<std::shared_mutex> cLk(m_cLock);

			oldseverity = m_cSeverity[serv];
			m_cSeverity[serv] = severity;
		}
		inline int Get(unsigned short serv)
		{
			std::shared_lock<std::shared_mutex> cLk(m_cLock);

			return m_cSeverity[serv];
		}

	private:
		std::shared_mutex m_cLock;
		_severity_map_t m_cSeverity;
	};

public:
	log_impl(log_component_impl* pcComponentImpl);
	virtual ~log_impl();
	bool Init();
	void Uninit();

	virtual int QueryInterface(const nmsp::UUID* iid, void **ppvObject);
	virtual int AddRef();
	virtual int Release();
	virtual int LogAnsi(unsigned short uiServiceType, int nSeverity, const char* achData) override;
	virtual int Log2Ansi(unsigned short uiServiceType, int nSeverity, int nLen, const char* achData) override;
	virtual int LogUnicode(unsigned short uiServiceType, int nSeverity, const wchar_t* awcData) override;
	virtual int Log2Unicode(unsigned short uiServiceType, int nSeverity, int nLen, const wchar_t* awcData) override;
	virtual int SetSeverity(unsigned short uiServiceType, int nNewSeverity, int* pnOldLevel) override;
	virtual int GetSeverity(unsigned short uiServiceType, int* pnOldLevel) override;

private:
	logging m_cLogging;
	_serv2severities_t m_serv2Severities;

private:
	log_component_impl* m_pcComponentImpl;
};

#endif
