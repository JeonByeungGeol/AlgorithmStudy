////////////////////////////////////////////////////////////////////////////////
// �ۼ���: huelee
// ��  ��:
//
//

// ȣȯ���� ���ؼ�..
#pragma once
#ifndef __LOGONFIG_H__
#define __LOGONFIG_H__

// ���������� �д´�.
class log_config
{
	enum
	{
	};

public:
	log_config(log_component_impl* pcComponentImpl);
	virtual ~log_config();

	bool Load(const char* pszConfig);

public:
	inline const std::string& GetPath() const
	{
		return m_cstrPath;
	}
	inline const std::string& GetPrefixName() const
	{
		return m_cstrPrefixName;
	}
	inline bool GetAutoRefresh() const
	{
		return m_bAutoRefresh;
	}
	inline int GetSize() const
	{
		return m_nMaxLogSize;
	}
	inline int GetHour() const
	{
		return m_nRefreshHour;
	}
	inline int GetMinute() const
	{
		return m_nRefreshMin;
	}
	inline int GetSecond() const 
	{
		return m_nRefreshSec;
	}
#if defined(_WIN32) || defined(_WIN64)
	inline const std::string& GetDumpPath() const
	{
		return m_cstrDumpPath;
	}
	inline bool GetDumpFlag() const
	{
		return m_bDumpFlag;
	}
#endif

private:
	std::string m_cstrPath;
	std::string m_cstrPrefixName;
	bool m_bAutoRefresh;
	int m_nMaxLogSize;
	int m_nRefreshHour;
	int m_nRefreshMin;
	int m_nRefreshSec;
#if defined(_WIN32) || defined(_WIN64)
	bool m_bDumpFlag;
	std::string m_cstrDumpPath;
#endif

private:
	log_component_impl* m_pcComponentImpl;
};

#endif
