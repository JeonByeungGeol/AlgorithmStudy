﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __LOGBASE_H__
#define __LOGBASE_H__

// component implementation class
class log_component_impl;
class log_config;
class log_impl;

// 컴포넌트 내부에서 사용할 오류 정의
enum _LOG_ERROR_T
{
	_LOG_ERROR_INVALID_INTERFACE_REQ	= 1,
	_LOG_ERROR_CONFIG					= 2,
	_LOG_ERROR_IMPL_INIT				= 3,
};

#if defined(_WIN32) || defined(_WIN64)
#pragma warning(disable : 4819)
#pragma warning(error : 4715)

#ifdef _DEBUG
#define DEBUG_NEW   new( _NORMAL_BLOCK, __FILE__, __LINE__)
#else
#define DEBUG_NEW
#endif 

#define _CRTDBG_MAP_ALLOC 
#include <stdlib.h> 
#include <crtdbg.h>

#endif

//
////////////////////////////////////////////////////////////////////////////////
//
#include <atomic>
#include <string>
#include <map>
#include <list>
#include <vector>
#include <unordered_map>
#include <thread>
#include <shared_mutex>
#include <assert.h>
#include <iostream>
#include <set>
#include <functional>

#include <boost/property_tree/json_parser.hpp>
#include <boost/filesystem.hpp>
#include <boost/log/core.hpp>
#include <boost/log/expressions.hpp>
#include <boost/log/expressions/keyword.hpp>
#include <boost/log/expressions/predicates/is_in_range.hpp>
#include <boost/log/expressions/formatters/date_time.hpp>
#include <boost/log/trivial.hpp>
#include <boost/log/sinks/text_multifile_backend.hpp>
#include <boost/log/sinks/async_frontend.hpp>
#include <boost/log/sinks/sync_frontend.hpp>
#include <boost/log/sinks/text_file_backend.hpp>
#include <boost/log/sinks/text_ostream_backend.hpp>
#include <boost/log/sinks/bounded_fifo_queue.hpp>
#include <boost/log/sinks/drop_on_overflow.hpp>
#include <boost/log/sources/severity_logger.hpp>
#include <boost/log/sources/record_ostream.hpp>
#include <boost/log/utility/formatting_ostream.hpp>
#include <boost/log/utility/manipulators/to_log.hpp>
#include <boost/log/utility/setup/file.hpp>
#include <boost/log/utility/setup/console.hpp>
#include <boost/log/utility/setup/common_attributes.hpp>
#include <boost/log/attributes/mutable_constant.hpp>
#include <boost/log/attributes/scoped_attribute.hpp>
#include <boost/log/attributes/named_scope.hpp>
#include <boost/log/attributes/current_thread_id.hpp>
#include <boost/log/attributes/current_process_id.hpp>
#include <boost/log/attributes/current_process_name.hpp>
#include <boost/log/support/date_time.hpp>
#include <boost/log/detail/default_attribute_names.hpp>

#if defined(_WIN32) || defined(_WIN64)
#include <windows.h>
#endif

////////////////////////////////////////////////////////////////////////////////
// ours include
#include "nmsputil.h"
#include "nmspInterface.h"
#include "nmspsmart.h"
#include "nmsperror.h"
#include "nmspmemallocate.h"
#include "nmspmemchunk.h"
#include "nmspmmgrchunk.h"
#include "nmspcomponentmain.h"
#include "nmspnewfrompool.h"

////////////////////////////////////////////////////////////////////////////////
// 인터페이스..
#include "loginterface.h"

////////////////////////////////////////////////////////////////////////////////
// 구현 의존적인 것임
#include "logconfig.h"
#include "logging.h"
#include "logimpl.h"
#include "log.h"

#endif
