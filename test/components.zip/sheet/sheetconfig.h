////////////////////////////////////////////////////////////////////////////////
// �ۼ���: huelee
// ��  ��:
//
//

// ȣȯ���� ���ؼ�..
#pragma once
#ifndef __SHEETCONFIG_H__
#define __SHEETCONFIG_H__

// ���������� �д´�.
class sheet_config
{
public:
	sheet_config()
	{
	}
	virtual ~sheet_config()
	{
	}
	bool Load(const char* pszConfig)
	{
		try
		{
			boost::property_tree::ptree props;
			boost::property_tree::read_json(pszConfig, props);

			m_cstrSheetsPath = props.get<std::string>("sheets path");
		}
		catch (std::exception&)
		{
			return false;
		}

		return true;
	}

public:
	inline const char* GetSheetsPath() const
	{
		return m_cstrSheetsPath.c_str();
	}

private:
	std::string m_cstrSheetsPath;
};

#endif
