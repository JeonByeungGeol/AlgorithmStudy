﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명: csv에 parse  함수를 더 추가하기 위해서
//
//

// 호환성을 위해서..
#pragma once
#ifndef __SHEETSIMPL_H__
#define __SHEETSIMPL_H__

//
class sheets_impl : public nmsp::sheet::ISheets
{
	using _sink_map_t = std::map<unsigned short, nmsp::smartinterface<nmsp::sheet::ISheetSink>>;

public:
	sheets_impl(sheet_component_impl* pcComponentImpl)
		: m_pcComponentImpl(pcComponentImpl)
	{
	}
	virtual ~sheets_impl()
	{
	}
	bool Init();
	void Uninit();

	virtual int QueryInterface(const nmsp::UUID* iid, void **ppvObject);
	virtual int AddRef();
	virtual int Release();
	virtual int SetSinkInterface(unsigned short uiServiceType, nmsp::sheet::ISheetSink* piSink);
	virtual int ResetSinkInterface(unsigned short uiServiceType);
	virtual int SheetReload();
	virtual int SheetCommit();
	virtual int SheetRollback();

private:
	bool Load();

private:
	sheet_component_impl* m_pcComponentImpl;
	std::shared_mutex m_cLock;
	_sink_map_t m_cSinkMap;
};

#endif
