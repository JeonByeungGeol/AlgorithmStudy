﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __SHEET_H__
#define __SHEET_H__

//
class sheet_component_impl: public nmsp::IComponent
{
public:
	sheet_component_impl();
	virtual ~sheet_component_impl();

	virtual int QueryInterface(const nmsp::UUID* iid, void** pInterface) override;
	virtual int AddRef(void) override;
	virtual int Release(void) override;
	virtual int SetBaseInfo(unsigned short uiServiceType, nmsp::IComponentContainer* pISink, int nLenPath, const char* pszCfgPath, int logLevel, bool outConsole, const char* timeZoneName) override;
	virtual int PreInit() override;
	virtual int Init() override;
	virtual void Uninit() override;
	virtual void PostUninit() override;

	inline unsigned short GetServiceType() const
	{
		return m_uiSelf;
	}
	inline operator nmsp::log::ILog* ()
	{
		return m_cRefLog;
	}
	inline operator nmsp::logger::logger& ()
	{
		return m_logger;
	}

private:
	std::atomic_int m_nRefs;
	unsigned short m_uiSelf;
	std::string m_cstrCfgPath;
	nmsp::logger::lv::severity_level m_logLevel;
	bool m_outConsole = false;

	sheet_config m_cConfig;
	nmsp::smartinterface<nmsp::IComponentContainer> m_cRefContainer;
	nmsp::smartinterface<nmsp::log::ILog> m_cRefLog;
	sheets_impl m_cSheetsImpl;
	nmsp::logger::logger m_logger;
};

#endif
