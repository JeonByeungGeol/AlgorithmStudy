﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 가능하면 이것 하나로..
#include "sheetbase.h"

//
bool sheets_impl::Init()
{
	return true;
}

void sheets_impl::Uninit()
{
}

int sheets_impl::QueryInterface(const nmsp::UUID* iid, void **ppvObject)
{
	return m_pcComponentImpl->QueryInterface(iid, ppvObject);
}

int sheets_impl::AddRef()
{
	return m_pcComponentImpl->AddRef();
}

int sheets_impl::Release()
{
	return m_pcComponentImpl->Release();
}

int sheets_impl::SetSinkInterface(unsigned short uiServiceType, nmsp::sheet::ISheetSink* piSink)
{
	std::unique_lock<std::shared_mutex> cLk(m_cLock);

	auto pairRet = m_cSinkMap.insert(_sink_map_t::value_type(uiServiceType, piSink));
	if (false == pairRet.second)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _SHEET_ERROR_DUP_SINKINTERFACE);

	return nmsp::_NMSP_NOERROR;
}

int sheets_impl::ResetSinkInterface(unsigned short uiServiceType)
{
	std::unique_lock<std::shared_mutex> cLk(m_cLock);

	m_cSinkMap.erase(uiServiceType);
	return nmsp::_NMSP_NOERROR;
}

int sheets_impl::SheetReload()
{
	int nRet = nmsp::_NMSP_NOERROR;

	std::shared_lock<std::shared_mutex> cLk(m_cLock);

	// 쉬트가 변경 됬다는 것을 알린다..

	for (auto& itr : m_cSinkMap)
	{
		nRet = itr.second->NotifyReload();

		if (nmsp::_NMSP_NOERROR != nRet)
			break;
	}

	return nRet;
}

int sheets_impl::SheetCommit()
{
	int nRet = nmsp::_NMSP_NOERROR;

	std::shared_lock<std::shared_mutex> cLk(m_cLock);

	// 쉬트가 변경 됬다는 것을 알린다..
	for (auto& itr : m_cSinkMap)
	{
		nRet = itr.second->NotifyCommit();

		if (nmsp::_NMSP_NOERROR != nRet)
			break;
	}

	return nRet;
}

int sheets_impl::SheetRollback()
{
	int nRet = nmsp::_NMSP_NOERROR;

	std::shared_lock<std::shared_mutex> cLk(m_cLock);

	// 쉬트가 변경 됬다는 것을 알린다..
	for (auto& itr : m_cSinkMap)
	{
		nRet = itr.second->NotifyRollback();

		if (nmsp::_NMSP_NOERROR != nRet)
			break;
	}

	return nRet;
}
