﻿// 가능하면 이것 하나로..
#include "messagequeuebase.h"

//
bool messagequeue_impl::Init()
{
	messagequeue_worker_pool_t.Init(1);
	return true;
}

void messagequeue_impl::Uninit()
{
	messagequeue_worker_pool_t.Uninit();
}

int messagequeue_impl::QueryInterface(const nmsp::UUID* iid, void **ppvObject)
{
	return m_pcComponentImpl->QueryInterface(iid, ppvObject);
}

int messagequeue_impl::AddRef()
{
	return m_pcComponentImpl->AddRef();
}

int messagequeue_impl::Release()
{
	return m_pcComponentImpl->Release();
}

int messagequeue_impl::SetSinkInterface(unsigned short uiServiceType, nmsp::messagequeue::IMessageQueueSink* piSink)
{
	std::unique_lock<std::shared_mutex> cLk(m_queueSinkLock);

	auto pairRet = m_cMessageQueueSinkMap.insert(_messagequeue_sink_map_t::value_type(uiServiceType, piSink));
	if (false == pairRet.second)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _MESSAGEQUEUE_ERROR_DUP_SINKINTERFACE);

	return nmsp::_NMSP_NOERROR;
}

int messagequeue_impl::ResetSinkInterface(unsigned short uiServiceType)
{
	std::unique_lock<std::shared_mutex> cLk(m_queueSinkLock);
	m_cMessageQueueSinkMap.erase(uiServiceType);
	return nmsp::_NMSP_NOERROR;
}

int messagequeue_impl::OpenQueue(nmsp::messagequeue::open_info& openInfo)
{
	_messagequeue_entity_ptr_t pEntity = GetEntity(openInfo.queuePath, true);
	if ( pEntity == nullptr )
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _MESSAGEQUEUE_ERROR_CREATE_ENTITY);
	// queueID 는 queuePATH 를 사용한다.
	openInfo.queueID = openInfo.queuePath;
	return pEntity->OpenQueue(openInfo);
}

_messagequeue_entity_ptr_t messagequeue_impl::GetEntity(const _messagequeue_id_t& queueID, bool create) {
	_messagequeue_entity_ptr_t pEntity = nullptr;
	
	std::unique_lock<std::shared_mutex> cLk(m_queueEntityLock);
	// 해당 messagequeue entity 를 찾는다.
	auto itrEntity = messagequeueEntitylMap.find(queueID);
	if (itrEntity != messagequeueEntitylMap.end()) {
		pEntity = itrEntity->second;
	}
	
	// 해당 entity 가 없고 create 값이 true 면 새로 생성하여 messagequeueEntitylMap 에 추가
	if (pEntity == nullptr && create) {
		pEntity = new messagequeue_entity(m_pcComponentImpl, queueID);
		messagequeueEntitylMap.insert(_messagequeue_entity_map::value_type(queueID, pEntity));
	}

	return pEntity;
}

int messagequeue_impl::AsyncSend( const _messagequeue_id_t& queueID, int nLen, const unsigned char* pData)
{
	// 해당 messagequeue entity 를 찾는다.
	auto pEntity = GetEntity(queueID, false);
	if (pEntity == nullptr) {
		LOG_DEBUG_SYS(m_pcComponentImpl) << "Failed to async send MQ Data. NotFoundEntity. " << queueID.c_str();
		return _MESSAGEQUEUE_ERROR_NOT_OPEND;
	}
	
	// 보낼 데이터 pool 에 등록
	_messagequeue_worker_pool_t::_param_t param;
	param.MakeParam(queueID, pData, nLen);
	messagequeue_worker_pool_t.Push(pEntity, std::move(param));
	
	return nmsp::_NMSP_NOERROR;
}

int messagequeue_impl::Send(const _messagequeue_id_t& queueID, int nLen, const unsigned char* pData)
{
	// 해당 messagequeue entity 를 찾는다.
	auto pEntity = GetEntity(queueID, false);
	if (pEntity == nullptr) {
		LOG_DEBUG_SYS(m_pcComponentImpl) << "Failed to sync send MQ Data. NotFoundEntity. " << queueID.c_str();
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _MESSAGEQUEUE_ERROR_NOT_OPEND);
	}

	return pEntity->Send( nLen, pData);
}

int messagequeue_impl::Receive(const _messagequeue_id_t& queueID, int& nLen, unsigned char* pData)
{
	// 해당 messagequeue entity 를 찾는다.
	auto pEntity = GetEntity(queueID, false);
	if (pEntity == nullptr) {
		LOG_DEBUG_SYS(m_pcComponentImpl) << "Failed to sync receive MQ Data. NotFoundEntity. " << queueID.c_str();
		return nmsp::_CONTAINER_ERROR_T::_CONTAINER_ERROR_INTERFACE_NOT_FOUND;
	}

	// 해당 message queue 에서 데이터를 pop 한다.
	int error = pEntity->Receive(pData, nLen);
	if (error != nmsp::_NMSP_NOERROR)
		return error;

	// pop 한데이터를 통보 받아야하는 sink 구현자들에게 통보 한다.
	if (!m_cMessageQueueSinkMap.empty()) {
		std::unique_lock<std::shared_mutex> cLk(m_queueSinkLock);
		for (auto itrSinkImpl : m_cMessageQueueSinkMap) {
			itrSinkImpl.second->NotifyPopData(queueID, pData, nLen);
		}
	}

	return nmsp::_NMSP_NOERROR;
}
