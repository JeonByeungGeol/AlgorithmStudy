﻿#pragma once
#ifndef __MESSAGEQUEUEBASE_H__
#define __MESSAGEQUEUEBASE_H__

// component implementation class
class messagequeue_component_impl;

// 컴포넌트 내부에서 사용할 오류 정의
enum _MSMQ_ERROR_T
{
	_MESSAGEQUEUE_ERROR_INVALID_INTERFACE_REQ = 1,
	_MESSAGEQUEUE_ERROR_CONFIG = 2,
	_MESSAGEQUEUE_ERROR_INIT = 3,
	_MESSAGEQUEUE_ERROR_DUP_SINKINTERFACE = 4,
	_MESSAGEQUEUE_ERROR_INIT_LOG = 5,
	_MESSAGEQUEUE_ERROR_OPEN_INFO = 6,	// message queue entity 를 opne 하려고 하는데 open info 정보 오류
	_MESSAGEQUEUE_ERROR_CREATE_ENTITY = 7,	// message queue entity 를 새로 생성하는데 에러 발생
	_MESSAGEQUEUE_ERROR_NOT_OPEND = 8,	// message queue 가 open 되지 않은 상태에서 send 도는 receive 사용
};

//  항상 component instance를 필요로 한다..
#define LV_TRACE	nmsp::logger::lv::trace
#define LV_DEBUG	nmsp::logger::lv::debug
#define LV_INFO		nmsp::logger::lv::info
#define LV_WARNING	nmsp::logger::lv::warning
#define LV_ERROR	nmsp::logger::lv::error
#define LV_FATAL	nmsp::logger::lv::fatal


#define LOG_TRACE_SYS(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_TRACE) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_DEBUG_SYS(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_DEBUG) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_INFO_SYS(component)				BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_INFO) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_WARNING_SYS(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_WARNING) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_ERROR_SYS(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_ERROR) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_FATAL_SYS(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_FATAL) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
//
#if defined(_WIN32) || defined(_WIN64)

#pragma warning(disable : 4819)
#pragma warning(error : 4715)

#ifdef _DEBUG
#define DEBUG_NEW   new( _NORMAL_BLOCK, __FILE__, __LINE__)
#else
#define DEBUG_NEW
#endif	// _DEBUG

#define _CRTDBG_MAP_ALLOC 
#include <stdlib.h> 
#include <crtdbg.h>

#endif	// defined(_WIN32) || defined(_WIN64)

////////////////////////////////////////////////////////////////////////////////
//
#include <atomic>
#include <string>
#include <map>
#include <list>
#include <vector>
#include <unordered_map>
#include <thread>
#include <shared_mutex>
#include <assert.h>
#include <boost/property_tree/json_parser.hpp>
#include <iostream>
#include <limits>
#include <codecvt>
#include <boost/noncopyable.hpp>


// MSMQ headers
#include <windows.h>
#include <Mq.h>

////////////////////////////////////////////////////////////////////////////////
// ours include
#include "nmspInterface.h"
#include "nmspsmart.h"
#include "nmsperror.h"
#include "nmspmemallocate.h"
#include "nmspmemchunk.h"
#include "nmspmmgrchunk.h"
#include "nmspnewfrompool.h"
#include "nmspcondition.h"
#include "nmspdispatchthread.h"
#include "nmspdispatchobjpool.h"
#include "nmspcomponentmain.h"
#include "nmsplogger.h"
#include "nmspmemorypool.h"
#include "nmspmemallocate.h"
#include "nmspstring.h"
#include <tbb/concurrent_queue.h>
#include <tbb/concurrent_hash_map.h>


#ifdef _DEBUG
using _allocator_t = nmsp::default_allocator;
#else
using _allocator_t = nmsp::pool::allocator_from_pool<>;
#endif

template< class T >
using TArray = std::vector< T, nmsp::stl_default_allocator<T, _allocator_t> >;

////////////////////////////////////////////////////////////////////////////////
// 
#include "loginterface.h"
#include "messagequeueinterface.h"
#include "servicetypedef.h"

////////////////////////////////////////////////////////////////////////////////
// 구현 의존적인 것임
#include "messagequeuedefine.h"
#include "messagequeue_entity.h"
#include "messagequeueimpl.h"
#include "messagequeueconfig.h"
#include "messagequeue.h"

#endif	// __MESSAGEQUEUEBASE_H__