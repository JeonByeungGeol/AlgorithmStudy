﻿#include "messagequeuebase.h"



messagequeue_entity::messagequeue_entity(messagequeue_component_impl* pcComponentImpl, _messagequeue_worker_pool_t::_key_t queueID)
	: m_pcComponentImpl(pcComponentImpl)
	, _messagequeue_worker_pool_t::dispatch_obj(queueID)
	, entityID(queueID)
	, m_hSendQueue(nullptr)
	, m_hRecvQueue(nullptr)
	, m_bEnableSend(false)
	, m_bEnableReceive(false)
{
}


messagequeue_entity::~messagequeue_entity()
{
}


bool messagequeue_entity::Init()
{
	return true;
}

void messagequeue_entity::Uninit()
{
	MQCloseQueue(m_hSendQueue);
	MQCloseQueue(m_hRecvQueue);
}

int messagequeue_entity::OpenQueue(nmsp::messagequeue::open_info& openInfo) {

	std::unique_lock<std::shared_mutex> cLk(m_cLock);
	boolean openReceive = false;
	boolean openSend = false;
	// 이미 열려 있는게 있을 경우 처리
	if (m_bEnableReceive || m_bEnableSend ) {
		// queue path 가 같아야만 추가로 open 가능하다.
		if (0 != m_queuePath.compare(openInfo.queuePath))
			return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _MESSAGEQUEUE_ERROR_OPEN_INFO);

		// receive open 요청이 있는데 기존에 열려있지 않다면 열수 있도록 flag 설정
		if (!m_bEnableSend && openInfo.useSendQueue) {
			openSend = true;
		}

		// send open 요청이 있는데 기존에 열려있지 않으면  열수 있도록 flag 설정
		if (!m_bEnableReceive && openInfo.useReceiveQueue)
			openReceive = true;
	}
	else {
		// queue 정보를 멤버 변수에 설정
		openSend = openInfo.useSendQueue;
		openReceive = openInfo.useReceiveQueue;
		m_queuePath = openInfo.queuePath;
	}

	if (!openSend && !openReceive )
		return nmsp::_NMSP_NOERROR;
	
	// std::wstring_convert<std::codecvt_utf8<wchar_t>> converter;
	// std::wstring wqueuePath = converter.from_bytes(m_queuePath);
	std::wstring wqueuePath;
	nmsp::StringConvert::UTF8ToUnicode(m_queuePath, wqueuePath);

	// Send Queue 오픈 요청이 있다면 open 한다.
	if (openSend) {
		messagequeue_config& config = static_cast<messagequeue_config&>(*m_pcComponentImpl);
		// send 복구 사용 여부
		bool recoverable = config.GetRecoverable();
		HRESULT hr = MQOpenQueue(
			wqueuePath.c_str(),		// Format name of the queue  
			MQ_SEND_ACCESS,			// Access mode  
			MQ_DENY_NONE,			// Share mode  
			&m_hSendQueue			// OUT: Queue handle  
		);
		if (FAILED(hr))
		{
			LOG_DEBUG_SYS(m_pcComponentImpl)<< "Failed to open send queue. queuePath: " << m_queuePath.c_str();
			return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _MESSAGEQUEUE_ERROR_INIT);
		}
		LOG_DEBUG_SYS(m_pcComponentImpl) << "The send queue is opened. queuePath: " << m_queuePath.c_str();
		m_bEnableSend = true;
	}

	// receive queue 오픈 요청이 있다면 open 한다.
	if (openReceive) {
		messagequeue_config& config = static_cast<messagequeue_config&>(*m_pcComponentImpl);
		// send 복구 사용 여부
		bool recoverable = config.GetRecoverable();
		HRESULT hr = MQOpenQueue(
			wqueuePath.c_str(),		// Format name of the queue  
			MQ_RECEIVE_ACCESS,		// Access mode  
			MQ_DENY_RECEIVE_SHARE,	// Share mode  
			&m_hRecvQueue			// OUT: Queue handle  
		);
		if (FAILED(hr))
		{
			LOG_DEBUG_SYS(m_pcComponentImpl) << "Failed to open receive queue. queuePath: " << m_queuePath.c_str();
			return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _MESSAGEQUEUE_ERROR_INIT);
		}
		LOG_DEBUG_SYS(m_pcComponentImpl) << "The receive queue is opened. queuePath: " << m_queuePath.c_str();
		m_bEnableReceive = true;
	}
	return nmsp::_NMSP_NOERROR;
}

int messagequeue_entity::Send(int nLen, const BYTE* pData)
{
	// send queue open 여부 확인
	if (!m_bEnableSend) {
		LOG_DEBUG_SYS(m_pcComponentImpl) << "send messagequeue - Not opened: " << entityID.c_str();
		return nmsp::_CONTAINER_ERROR_T::_CONTAINER_ERROR_INTERFACE_NOT_FOUND;
	}

	std::shared_lock<std::shared_mutex> cLk(m_cLock);

	/*
	보낼 메세지 속성 정의
	*/
	const int NUMBEROFPROPERTIES = 2;
	DWORD pIdx = 0;

	MSGPROPID aMsgPropId[NUMBEROFPROPERTIES];
	MQPROPVARIANT aMsgPropVar[NUMBEROFPROPERTIES];
	HRESULT aMsgStatus[NUMBEROFPROPERTIES];

	// 라벨은 일단 사용하지 않도록
	// 	// 라벨 정보
	// 	aMsgPropId[pIdx] = PROPID_M_LABEL;
	// 	aMsgPropVar[pIdx].vt = VT_LPWSTR;
	// 	aMsgPropVar[pIdx].pwszVal = const_cast<WCHAR*>(pLabel);
	// 	pIdx++;

	// 바디 정보
	aMsgPropId[pIdx] = PROPID_M_BODY;
	aMsgPropVar[pIdx].vt = VT_VECTOR | VT_UI1;
	aMsgPropVar[pIdx].caub.pElems = const_cast<BYTE*>(pData);
	aMsgPropVar[pIdx].caub.cElems = nLen;
	pIdx++;

	if (static_cast<messagequeue_config&>(*m_pcComponentImpl).GetRecoverable())
	{
		// 복구 가능 플래그 추가 (서비스나 장비가 재시작되어도 데이터 유지)
		aMsgPropId[pIdx] = PROPID_M_DELIVERY;
		aMsgPropVar[pIdx].vt = VT_UI1;
		aMsgPropVar[pIdx].bVal = MQMSG_DELIVERY_RECOVERABLE;
		pIdx++;
	}

	// 메세지 속성 구조체 정의
	MQMSGPROPS msgProps;
	msgProps.cProp = pIdx;
	msgProps.aPropID = aMsgPropId;
	msgProps.aPropVar = aMsgPropVar;
	msgProps.aStatus = aMsgStatus;

	HRESULT hr = MQSendMessage(
		m_hSendQueue,
		&msgProps,
		MQ_NO_TRANSACTION
	);

	if (FAILED(hr)) {
		LOG_DEBUG_SYS(m_pcComponentImpl) << "send messagequeue - Failed to RecreateMemory. err: " << hr;
		return nmsp::_CONTAINER_ERROR_T::_CONTAINER_ERROR_INTERFACE_NOT_FOUND;
	}

	//// Send 완료 알림
	//for (auto& itr : m_cMessageQueueMap)
	//{
	//	int nRet = itr.second->NotifySend();
	//	if (nmsp::_NMSP_NOERROR != nRet)
	//		break;
	//}

	return nmsp::_NMSP_NOERROR;
}

int messagequeue_entity::Receive(unsigned char* pData, int& nLen)
{
	if (!m_bEnableReceive) {
		LOG_DEBUG_SYS(m_pcComponentImpl) << "Receive messagequeue - Not opened: " << entityID.c_str();
		return nmsp::_CONTAINER_ERROR_T::_CONTAINER_ERROR_INTERFACE_NOT_FOUND;
	}

	std::shared_lock<std::shared_mutex> cLk(m_cLock);

	/*
	받을 메세지 속성 정의
	*/
	const int NUMBEROFPROPERTIES = 2;
	DWORD pIdx = 0;

	MSGPROPID aMsgPropId[NUMBEROFPROPERTIES];
	MQPROPVARIANT aMsgPropVar[NUMBEROFPROPERTIES];
	HRESULT aMsgStatus[NUMBEROFPROPERTIES];

	// 라벨은 일단 사용하지 않도록
	// 	// 라벨 길이
	// 	aMsgPropId[pIdx] = PROPID_M_LABEL_LEN;				// Property ID  
	// 	aMsgPropVar[pIdx].vt = VT_UI4;						// Type indicator  
	// 	aMsgPropVar[pIdx].ulVal = MQ_MAX_MSG_LABEL_LEN;		// Length of label  
	// 	pIdx++;
	// 
	// 	// 라벨 정보
	// 	WCHAR wszLabelBuffer[MQ_MAX_MSG_LABEL_LEN];			// Label buffer  
	// 	aMsgPropId[pIdx] = PROPID_M_LABEL;					// Property ID  
	// 	aMsgPropVar[pIdx].vt = VT_LPWSTR;					// Type indicator  
	// 	aMsgPropVar[pIdx].pwszVal = wszLabelBuffer;			// Label buffer  
	// 	pIdx++;

	// 바디 길이
	aMsgPropId[pIdx] = PROPID_M_BODY_SIZE;					// Property ID  
	aMsgPropVar[pIdx].vt = VT_NULL;							// Type indicator  
	pIdx++;

	// 바디 정보
	memset(pData, 0, nLen);
	aMsgPropId[pIdx] = PROPID_M_BODY;					// Property ID  
	aMsgPropVar[pIdx].vt = VT_VECTOR | VT_UI1;			// Type indicator  
	aMsgPropVar[pIdx].caub.pElems = pData;				// Body buffer  
	aMsgPropVar[pIdx].caub.cElems = nLen;				// Buffer size  
	pIdx++;

	// 메세지 속성 구조체 정의
	MQMSGPROPS msgprops;
	msgprops.cProp = pIdx;								// Number of message properties  
	msgprops.aPropID = aMsgPropId;                      // IDs of the message properties  
	msgprops.aPropVar = aMsgPropVar;                    // Values of the message properties  
	msgprops.aStatus = aMsgStatus;                      // Error reports  

	HRESULT hr = MQ_OK;                                 // Return code  
	while (true)
	{
		//		aMsgPropVar[0].ulVal = MQ_MAX_MSG_LABEL_LEN;
		hr = MQReceiveMessage(
			m_hRecvQueue,               // Queue handle  
			1000,                       // Max time to (msec) to receive the message  
			MQ_ACTION_RECEIVE,          // Receive action  
			&msgprops,                  // Message property structure  
			NULL,                       // No OVERLAPPED structure  
			NULL,                       // No callback function  
			NULL,                       // No cursor handle  
			MQ_NO_TRANSACTION           // Not in a transaction  
		);

		// 버퍼가 부족하면 확장 후 다시시도
		if (hr == MQ_ERROR_BUFFER_OVERFLOW)
		{
			nLen = aMsgPropVar[0].ulVal * sizeof(UCHAR);
			void* pReMem = _allocator_t::RecreateMemory(reinterpret_cast<void*>(pData), 0, nLen);
			if (pReMem == nullptr)
			{
				// 메모리 할당 실패..
				LOG_DEBUG_SYS(m_pcComponentImpl) << "Receive - Failed to RecreateMemory";
				return nmsp::_CONTAINER_ERROR_T::_CONTAINER_ERROR_MEMORY;
			}

			pData = reinterpret_cast<BYTE*>(pReMem);

			aMsgPropVar[1].caub.pElems = pData;
			aMsgPropVar[1].caub.cElems = nLen;
			continue;
		}

		// 받을 메세지가 없다면 종료
		if (FAILED(hr))
			return nmsp::_CONTAINER_ERROR_T::_CONTAINER_ERROR_NO_MESSAGE;

		// 일단 하나만 Receive 하고 종료
		break;
	}

	//// Recv 완료 알림
	//for (auto& itr : m_cMessageQueueMap)
	//{
	//	int nRet = itr.second->NotifyReceive();
	//	if (nmsp::_NMSP_NOERROR != nRet)
	//		break;
	//}

	return nmsp::_NMSP_NOERROR;
}

void messagequeue_entity::Pop(_messagequeue_worker_pool_t::_param_t& param) {
	this->Send(param.length, param.buf.data());
}