﻿#pragma once
#ifndef __MESSAGEQUEUE_DEFINE_H_
#define __MESSAGEQUEUE_DEFINE_H_


// Message Queue 에 Send 할 데이터 param
struct messagequeue_data_obj_param
{
public:
	using _messagequeue_id_t = nmsp::messagequeue::_messagequeue_id_t;

	// message queue 에 send 할 데이터 설정 또는 POP 요청
	void MakeParam(const _messagequeue_id_t& queueID, const uint8_t* data, int32_t length)
	{
		this->queueID = queueID;
		SetData(data, length);
	}

private:
	void SetData(const uint8_t* data, int32_t length)
	{
		this->buf.resize(length);
		memcpy(this->buf.data(), data, length);
		this->length = length;
	}

public:

	// messagequeue id
	_messagequeue_id_t queueID;

	// Raw Packet 
	TArray<uint8_t> buf;

	// Raw Packet 길이
	int32_t length;
};

using _messagequeue_worker_pool_t = nmsp::dispatch_obj_pool< nmsp::messagequeue::_messagequeue_id_t, messagequeue_data_obj_param, tbb::strict_ppl::concurrent_queue, nmsp::pool::allocator_from_pool<>>;

#endif	// __MESSAGEQUEUE_DEFINE_H_