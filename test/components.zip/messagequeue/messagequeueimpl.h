#pragma once
#ifndef __MESSAGEQUEUEIMPL_H__
#define __MESSAGEQUEUEIMPL_H__

// messqgue ��ü ���� �� ������ ���� ����
class messagequeue_impl : public nmsp::messagequeue::IMessageQueue// , public nmsp::new_from_pool<_allocator_t>
{
	using _messagequeue_sink_map_t = std::map<unsigned short, nmsp::smartinterface<nmsp::messagequeue::IMessageQueueSink>>;
public:
	using _messagequeue_id_t = nmsp::messagequeue::_messagequeue_id_t;
	using _messagequeue_entity_map = std::unordered_map < _messagequeue_id_t, _messagequeue_entity_ptr_t >;
	// using _messagequeue_entity_map = tbb::concurrent_hash_map< _messagequeue_id_t, _messagequeue_entity_ptr_t, tbb::tbb_hash_compare<_messagequeue_id_t>, nmsp::stl_default_allocator<std::pair<const _messagequeue_id_t, _messagequeue_entity_ptr_t>, _allocator_t>>;
	
	messagequeue_impl(messagequeue_component_impl* pcComponentImpl)
		: m_pcComponentImpl(pcComponentImpl)
	{
	}
	virtual ~messagequeue_impl()
	{
	}
	bool Init();
	void Uninit();

	virtual int QueryInterface(const nmsp::UUID* iid, void **ppvObject) override;
	virtual int AddRef() override;
	virtual int Release() override;
	virtual int SetSinkInterface(unsigned short uiServiceType, nmsp::messagequeue::IMessageQueueSink* piSink) override;
	virtual int ResetSinkInterface(unsigned short uiServiceType) override;
	virtual int OpenQueue(nmsp::messagequeue::open_info& openInfo) override;
	virtual int AsyncSend( const _messagequeue_id_t& queueID, int nLen, const unsigned char* pData) override;
	virtual int Send( const _messagequeue_id_t& queueID, int nLen, const unsigned char* pData) override;
	virtual int Receive( const _messagequeue_id_t& queueID, int& nLen, unsigned char* pData) override;

private:
	/** queueID �� �ش��ϴ� messagequeue entity �� messagequeueEntitylMap ���� �����´�. ���ٸ� �����ؼ� �߰��� �� �����´�. */
	_messagequeue_entity_ptr_t GetEntity(const _messagequeue_id_t& queueID, bool create);

private:
	std::shared_mutex m_queueEntityLock;	// messagequeueEntitylMap ���� Lock
	_messagequeue_entity_map messagequeueEntitylMap;	// message queue ���� �� ��ü

	std::shared_mutex m_queueSinkLock;	// m_cMessageQueueSinkMap ���� Lock
	_messagequeue_sink_map_t m_cMessageQueueSinkMap;	// sink ��ü

	_messagequeue_worker_pool_t messagequeue_worker_pool_t;	// MessageQueue �� Async Send �Ϸ��� Job Data
	messagequeue_component_impl* m_pcComponentImpl;	// MessageQueue Component ������
};

#endif