﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __NETWORKBASE_H__
#define __NETWORKBASE_H__

// component implementation class
class network_component_impl;

// 설정 
class network_config;

// 컴포넌트 내부에서 사용할 오류 정의
enum _NETWORK_ERROR_T
{
	_NETWORK_ERROR_INVALID_INTERFACE_REQ			= 1,
	_NETWORK_ERROR_ALREADY_SINK_INTERFACE			= 2,	// SINK인터페이스가 이미 설정되어 있다.
	_NETWORK_ERROR_CONFIG							= 3,
	_NETWORK_ERROR_INIT_SESSIONS					= 4,
	_NETWORK_ERROR_OUT								= 5,
	_NETWORK_ERROR_CLOSE							= 6,
	_NETWORK_ERROR_POST								= 7,
	_NETWORK_ERROR_TIMER							= 8,
	_NETWORK_ERROR_MEMORY							= 9,
	_NETWORK_ERROR_INIT_LOG							= 10,
	_NETWORK_ERROR_ASSEMBLE							= 11,
};

// 항상 component instance를 필요로 한다..
#define LV_TRACE	nmsp::logger::lv::trace
#define LV_DEBUG	nmsp::logger::lv::debug
#define LV_INFO		nmsp::logger::lv::info
#define LV_WARNING	nmsp::logger::lv::warning
#define LV_ERROR	nmsp::logger::lv::error
#define LV_FATAL	nmsp::logger::lv::fatal

#define LOG_TRACE_SYS(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_TRACE) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_DEBUG_SYS(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_DEBUG) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_INFO_SYS(component)				BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_INFO) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_WARNING_SYS(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_WARNING) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_ERROR_SYS(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_ERROR) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_FATAL_SYS(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_FATAL) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["

//
#if defined(_WIN32) || defined(_WIN64)

#pragma warning(disable : 4819)
#pragma warning(error : 4715)

#ifdef _DEBUG
#define DEBUG_NEW   new( _NORMAL_BLOCK, __FILE__, __LINE__)
#else
#define DEBUG_NEW
#endif 

#define _CRTDBG_MAP_ALLOC 
#include <stdlib.h> 
#include <crtdbg.h>

#endif

//
////////////////////////////////////////////////////////////////////////////////
//
#include <atomic>
#include <string>
#include <map>
#include <list>
#include <vector>
#include <unordered_map>
#include <thread>
#include <shared_mutex>
#include <assert.h>
#include <boost/property_tree/json_parser.hpp>
#include <boost/asio.hpp>
#include <iostream>

#if defined(_WIN32) || defined(_WIN64)
#include <windows.h>
#endif

////////////////////////////////////////////////////////////////////////////////
// ours include
#include "nmsputil.h"
#include "nmspInterface.h"
#include "nmspsmart.h"
#include "nmsperror.h"
#include "nmspmemallocate.h"
#include "nmspmemchunk.h"
#include "nmspmmgrchunk.h"
#include "nmspcomponentmain.h"
#include "nmspnewfrompool.h"
#include "nmspmemorypool.h"
#include "nmspnet.h"
#include "nmsplogger.h"

////////////////////////////////////////////////////////////////////////////////
// 
#include "networkinterface.h"
#include "loginterface.h"
#include "servicetypedef.h"

////////////////////////////////////////////////////////////////////////////////
// 
#include "networkconfig.h"
#include "networkmessage.h"
#include "networkimpl.h"
#include "network.h"

#endif
