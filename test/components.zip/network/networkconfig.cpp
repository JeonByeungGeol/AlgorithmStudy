﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 가능하면 이것 하나로..
#include "networkbase.h"

////////////////////////////////////////////////////////////////////////////////
// 
network_config::network_config(network_component_impl* pcComponentImpl)
	: m_pcComponentImpl(pcComponentImpl)
{
	m_uiServerListenPort = LISTENPORT;
	m_bReuse = false;
	m_byThreadCount = THREADCOUNT;
	m_nMaxClientSession = MAXCLIENTSESSION;
	m_nMaxAcceptSession = MAXACCEPTSESSION;
	m_nMss = MSS;
	m_nRecvIdleTime = RECVIDLETIME;
	m_nSendIdleTime = SENDIDLETIME;
	m_bNagle = NAGLE;
	m_nIdleCheckTime = IDLECHECKTIME;
	m_nIdleCheckCountPerPeriod = IDLECHECKCOUNTPERPERIOD;
	m_nInitPoolCount = POOL_INIT_COUNT;
	m_nExtPoolCount = POOL_EXT_COUNT;
	m_nNormalPacketSize = NORMAL_PACKET_SIZE;
}
network_config::~network_config()
{
}

bool network_config::Load(const char* pszConfig)
{
	try
	{
		boost::property_tree::ptree props;
		boost::property_tree::read_json(pszConfig, props);

		m_cServerAddress = props.get<std::string>("server address", "0.0.0.0");
		m_uiServerListenPort = props.get<int>("listen port", LISTENPORT);
		m_bReuse = props.get<bool>("server port reuse", false);
		m_byThreadCount = props.get<int>("thread count", THREADCOUNT);
		m_nMaxClientSession = props.get<int>("concurrent max client session", MAXCLIENTSESSION);
		m_nMaxAcceptSession = props.get<int>("max accept", MAXACCEPTSESSION);
		m_nMss = props.get<int>("generic packet size", MSS);
		m_nRecvIdleTime = props.get<int>("receive idle time", RECVIDLETIME);
		m_nSendIdleTime = props.get<int>("send idle time", SENDIDLETIME);
		m_bNagle = props.get<bool>("nagle", NAGLE);
		m_nIdleCheckTime = props.get<int>("idle check time period", IDLECHECKTIME);
		m_nIdleCheckCountPerPeriod = props.get<int>("idle check count per period", IDLECHECKCOUNTPERPERIOD);
		m_nInitPoolCount = props.get<int>("pool init count", POOL_INIT_COUNT);
		m_nExtPoolCount = props.get<int>("pool expand count", POOL_EXT_COUNT);
		m_nNormalPacketSize = props.get<int>("normal packet size", NORMAL_PACKET_SIZE);

		if (0 >= m_byThreadCount)
		{
			LOG_ERROR_SYS(m_pcComponentImpl) << "config:: thread count " << m_byThreadCount;
			return false;
		}

		if (0 >= m_nMaxClientSession)
		{
			LOG_ERROR_SYS(m_pcComponentImpl) << "config:: concurrent max client session  " << m_nMaxClientSession;
			return false;
		}

		if (0 >= m_nMaxAcceptSession)
		{
			LOG_ERROR_SYS(m_pcComponentImpl) << "config:: max accept " << m_nMaxAcceptSession;
			return false;
		}

		if (0 >= m_nMss)
		{
			LOG_ERROR_SYS(m_pcComponentImpl) << "config:: generic packet size " << m_nMss;
			return false;
		}

		if (0 >= m_nRecvIdleTime)
		{
			LOG_ERROR_SYS(m_pcComponentImpl) << "config:: receive idle time " << m_nMss;
			return false;
		}

		if (0 >= m_nSendIdleTime)
		{
			LOG_ERROR_SYS(m_pcComponentImpl) << "config:: send idle time " << m_nMss;
			return false;
		}

		if (0 >= m_nIdleCheckTime)
		{
			LOG_ERROR_SYS(m_pcComponentImpl) << "config:: idle check time period " << m_nIdleCheckTime;
			return false;
		}

		if (0 >= m_nIdleCheckCountPerPeriod)
		{
			LOG_ERROR_SYS(m_pcComponentImpl) << "config:: idle check count per period " << m_nIdleCheckCountPerPeriod;
			return false;
		}

		if (0 >= m_nInitPoolCount)
		{
			LOG_ERROR_SYS(m_pcComponentImpl) << "config:: pool init count " << m_nInitPoolCount;
			return false;
		}

		if (0 >= m_nExtPoolCount)
		{
			LOG_ERROR_SYS(m_pcComponentImpl) << "config:: pool expand count " << m_nExtPoolCount;
			return false;
		}

		if (0 >= m_nNormalPacketSize)
		{
			LOG_ERROR_SYS(m_pcComponentImpl) << "config:: normal packet size " << m_nNormalPacketSize;
			return false;
		}
	}
	catch (std::exception& e)
	{
		LOG_ERROR_SYS(m_pcComponentImpl) << "config:: exception " << e.what();
		return false;
	}

	return true;
}

