﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 가능하면 이것 하나로..
#include "networkbase.h"

////////////////////////////////////////////////////////////////////////////////
// session..
bool network_session::OnAccept(_shared_session_t& sess, std::shared_ptr<boost::asio::ip::tcp::acceptor>& _acceptor, const boost::system::error_code& error)
{
	// 상위
	if (false == __super_t::OnAccept(sess, _acceptor, error))
		return false;

	static_cast<network_impl&>(__super_t::m_pumpbase).SetTcpOption(*this);
	return true;
}

bool network_session::OnReceive(_shared_session_t& sess, _shared_read_ctrl_t& read_ctrl, const boost::system::error_code& error, const std::size_t& trans)
{
	if (false == __super_t::OnReceive(sess, read_ctrl, error, trans))
		return false;

	// 여기서 추가로 필요한 것들을 해봅시다
	return true;
}

bool network_session::OnSend(_shared_session_t& sess, _shared_writevector_t& vecBuff, const boost::system::error_code& error, const std::size_t& trans)
{
	if (false == __super_t::OnSend(sess, vecBuff, error, trans))
		return false;

	// 여기서 추가로 필요한 것들을 해봅시다
	return true;
}

bool network_session::OnSend2(_shared_session_t& sess, _shared_write_buffer_t& buffer, const boost::system::error_code& error, const std::size_t& trans)
{
	if (false == __super_t::OnSend2(sess, buffer, error, trans))
		return false;

	// 여기서 추가로 필요한 것들을 해봅시다
	return true;
}

bool network_session::OnClose(_shared_session_t& sess)
{
	if (false == __super_t::OnClose(sess))
		return false;

	// 여기서 추가로 필요한 것들을 해봅시다
	return true;
}

bool network_session::OnConnect(_shared_session_t& sess, const boost::system::error_code& error)
{
	if (false == __super_t::OnConnect(sess, error))
		return false;

	// 여기서 추가로 필요한 것들을 해봅시다
	static_cast<network_impl&>(__super_t::m_pumpbase).SetTcpOption(*this);
	return true;
}

void network_session::SetTcpOption()
{
	// 필요한 옵션을 설정하자!.. Receive / Send Buffer size, keep alive, nagle 등등
}

////////////////////////////////////////////////////////////////////////////////
//
network_impl::network_impl(network_component_impl* pcComponentImpl)
	: m_pcComponentImpl(pcComponentImpl)
{
	m_piParse = nullptr;
	m_piSink = nullptr;
	m_nCurrIndex = 0;
}

network_impl::~network_impl()
{
	if (m_piParse)
		m_piParse->Release();

	if (m_piSink)
		m_piSink->Release();
}

bool network_impl::Assemble(int nPktLen, int nMaxHdLen, int* pnLen, unsigned char* pchHd)
{
	nmsp::smartinterface<nmsp::network::INetworkParse> cParse;
	{
		std::shared_lock<std::shared_mutex> cRL(m_cRwLockInterface);
		cParse = m_piParse;
	}

	if (nullptr == cParse)
	{
		*pnLen = 0;
		return false;
	}

	if (nmsp::_NMSP_NOERROR != cParse->Assemble(nPktLen, nMaxHdLen, pnLen, pchHd))
	{
		*pnLen = 0;
		return false;
	}

	return true;
}

bool network_impl::Disassemble(int nIndex, int nIdentity, int nLen, const unsigned char* pchData, int* pnTotalLen, int* pnHdLen, int* pnDataLen)
{
	nmsp::smartinterface<nmsp::network::INetworkParse> cParse;
	{
		std::shared_lock<std::shared_mutex> cRL(m_cRwLockInterface);
		cParse = m_piParse;
	}

	if (nullptr == cParse)
	{
		*pnTotalLen = nLen;
		*pnHdLen = 0;
		return false;
	}

	if (nmsp::_NMSP_NOERROR != m_piParse->DisAssemble(network_session::MakeSessionID(nIndex, nIdentity), nLen, pchData, pnTotalLen, pnHdLen, pnDataLen))
	{
		*pnTotalLen = nLen;
		*pnHdLen = 0;
		return false;
	}

	return true;
}

void network_impl::OnTimer(int nId, const boost::system::error_code& error)
{
	if (IDLE_TIMER_ID == nId)
	{
		int nCheckCount = static_cast<network_config&>(*m_pcComponentImpl).GetIdleCheckCountPerPeriod();
		int nDiff = static_cast<network_config&>(*m_pcComponentImpl).GetRecvIdleTime();
		int nTotal = __super_t::GetPoolCount();
		time_t curr = std::time(nullptr);

		if (nCheckCount >= nTotal)
		{
			m_nCurrIndex = 0;

			for (; m_nCurrIndex < nTotal; ++m_nCurrIndex)
			{
				_shared_session_t sess;
				if (false == __super_t::Find(m_nCurrIndex, sess))
					continue;

				if (false == sess->IsConn())
					continue;

				if (nDiff < curr - sess->GetLastReceivedTime())
				{
					__super_t::Close(sess->GetIndex(), sess->GetIdentity());
					LOG_INFO_SYS(m_pcComponentImpl) << "OnTimer :: idle time :: closed " << nDiff;
				}
			}
		}
		else
		{
			if (m_nCurrIndex >= nTotal)
				m_nCurrIndex = 0;

			int nLastIndex = std::min((m_nCurrIndex + nCheckCount), nTotal);

			for (; m_nCurrIndex < nLastIndex; ++m_nCurrIndex)
			{
				_shared_session_t sess;
				if (false == __super_t::Find(m_nCurrIndex, sess))
					continue;

				if (false == sess->IsConn())
					continue;

				if (nDiff < curr - sess->GetLastReceivedTime())
				{
					__super_t::Close(sess->GetIndex(), sess->GetIdentity());
					LOG_INFO_SYS(m_pcComponentImpl) << "OnTimer :: idle time :: closed " << nDiff;
				}
			}
		}
	}
	else
	{
		nmsp::smartinterface<nmsp::network::INetworkSink> cSink;
		{
			std::shared_lock<std::shared_mutex> cRL(m_cRwLockInterface);
			cSink = m_piSink;
		}

		if (nullptr != cSink)
		{
			cSink->Time(nId);
		}
	}
}

void network_impl::OnAccepted(int nIndex, int nIdentity, _session_t* pcSess)
{
	nmsp::smartinterface<nmsp::network::INetworkSink> cSink;
	{
		std::shared_lock<std::shared_mutex> cRL(m_cRwLockInterface);
		cSink = m_piSink;
	}

	if (nullptr != cSink)
	{
		auto address = static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().address().to_string();

		cSink->Bind(network_session::MakeSessionID(nIndex, nIdentity), static_cast<int>(address.size()), address.c_str());
	}
}

void network_impl::OnConnected(int nIndex, int nIdentity, _session_t* pcSess)
{
}

void network_impl::OnClosed(int nIndex, int nIdentity, _session_t* pcSess)
{
	nmsp::smartinterface<nmsp::network::INetworkSink> cSink;
	{
		std::shared_lock<std::shared_mutex> cRL(m_cRwLockInterface);
		cSink = m_piSink;
	}

	if (nullptr != cSink)
		cSink->Unbind(network_session::MakeSessionID(nIndex, nIdentity));
}

void network_impl::OnReceived(int nIndex, int nIdentity, int nLen, const unsigned char* pchData, _session_t* pcSess)
{
	nmsp::smartinterface<nmsp::network::INetworkSink> cSink;
	{
		std::shared_lock<std::shared_mutex> cRL(m_cRwLockInterface);
		cSink = m_piSink;
	}

	if (nullptr != cSink && 0 < nLen)
		cSink->In(network_session::MakeSessionID(nIndex, nIdentity), nLen, pchData);
}

void network_impl::OnSent(int nIndex, int nIdentity, int nSentBytes, _session_t* pcSess)
{
}

void network_impl::OnPosted(int nIndex, int nIdentity, int nOption, int nLen, const unsigned char* pchData, _session_t* pcSess)
{
	nmsp::smartinterface<nmsp::network::INetworkSink> cSink;
	{
		std::shared_lock<std::shared_mutex> cRL(m_cRwLockInterface);
		cSink = m_piSink;
	}

	if (nullptr != cSink)
		cSink->Posted(network_session::MakeSessionID(nIndex, nIdentity), nOption, nLen, pchData);
}

// 에러 로그를 출력하도록 한다
void network_impl::OnError(const boost::system::error_code& error)
{
	if (boost::asio::error::eof == error.value() ||
		boost::asio::error::already_open == error.value())
	{
		LOG_DEBUG_SYS(m_pcComponentImpl) << "network_impl::OnError :: boost system warning :: value:" << error.value() << " msg:" << error.message();
		return;
	}
	
	LOG_ERROR_SYS(m_pcComponentImpl) << "network_impl::OnError :: boost system error :: value:" << error.value() << " msg:" << error.message();
}

void network_impl::OnError(int32_t index, int32_t identify, const boost::system::error_code& error)
{
	nmsp::network::_client_t sessionID = network_session::MakeSessionID(index, identify);

	LOG_ERROR_SYS(m_pcComponentImpl) << "network_impl::OnError :: boost system error :: session_id:" << sessionID << " value:" << error.value() << " msg:" << error.message();
}

void network_impl::OnError(const std::exception& error)
{
	LOG_ERROR_SYS(m_pcComponentImpl) << "OnError :: exception :: " << error.what();
}

void network_impl::OnError(const char* pszError)
{
	LOG_ERROR_SYS(m_pcComponentImpl) << "OnError :: " << pszError;
}

bool network_impl::Init()
{
	// boost::asio초기화
	if (false == __super_t::Init(
		static_cast<network_config&>(*m_pcComponentImpl).GetInitPoolCount(),
		static_cast<network_config&>(*m_pcComponentImpl).GetExtPoolCount(),
		static_cast<network_config&>(*m_pcComponentImpl).GetNormalPacketSize()))
	{
		LOG_ERROR_SYS(m_pcComponentImpl) << "network :: init error";
		return false;
	}

	//
	if (false == __super_t::InitTcpServer(
		static_cast<network_config&>(*m_pcComponentImpl).GetServerAddress().c_str(),
		static_cast<network_config&>(*m_pcComponentImpl).GetServerListenPort(),
		static_cast<network_config&>(*m_pcComponentImpl).GetReuse(),
		static_cast<network_config&>(*m_pcComponentImpl).GetMaxAcceptSession()))
	{
		LOG_ERROR_SYS(m_pcComponentImpl) << "network :: initTcpServer(network) error";
		return false;
	}

	// asio thread...
	if (false == __super_t::InitThreads(static_cast<network_config&>(*m_pcComponentImpl).GetThreadCount()))
	{
		LOG_ERROR_SYS(m_pcComponentImpl) << "network :: InitThreads error";
		return false;
	}

	// 타이머
	if (false == __super_t::SetTimer(IDLE_TIMER_ID, static_cast<network_config&>(*m_pcComponentImpl).GetIdleCheckPeriod()))
	{
		LOG_ERROR_SYS(m_pcComponentImpl) << "network :: SetTimer error";
		return false;
	}

	return true;
}

void network_impl::Uninit()
{
	// asio 정리
	__super_t::Uninit();

	// 인터페이스를 삭제한다..
	nmsp::network::INetworkParse* piTmpParse;
	nmsp::network::INetworkSink* piTmpSink;

	{
		std::unique_lock<std::shared_mutex> cRL(m_cRwLockInterface);

		//
		piTmpParse = m_piParse;
		piTmpSink = m_piSink;

		//
		m_uiServiceType = 0;
		m_piParse = nullptr;
		m_piSink = nullptr;
	}

	if (piTmpParse)
		piTmpParse->Release();

	if (piTmpSink)
		piTmpSink->Release();
}

int network_impl::QueryInterface(const nmsp::UUID* iid, void** pInterface)
{
	return m_pcComponentImpl->QueryInterface(iid, pInterface);
}

// network_component_impl의 life time내에 같이 공존하기 위해서..
int network_impl::AddRef(void)
{
	return m_pcComponentImpl->AddRef();
}

// network_component_impl의 life time내에 같이 공존하기 위해서..
int network_impl::Release(void)
{
	return m_pcComponentImpl->Release();
}

int network_impl::SetSink(unsigned short uiServiceType, nmsp::network::INetworkParse* piParse, nmsp::network::INetworkSink* piSink)
{
	nmsp::network::INetworkParse* piTmpParse;
	nmsp::network::INetworkSink* piTmpSink;

	{
		std::unique_lock<std::shared_mutex> cRL(m_cRwLockInterface);

		piTmpParse = m_piParse;
		piTmpSink = m_piSink;

		m_uiServiceType = uiServiceType;

		m_piParse = piParse;
		if (m_piParse)
			m_piParse->AddRef();

		m_piSink = piSink;
		if (m_piSink)
			m_piSink->AddRef();
	}

	if (piTmpParse)
		piTmpParse->Release();

	if (piTmpSink)
		piTmpSink->Release();

	return nmsp::_NMSP_NOERROR;
}

void network_impl::ResetSink(unsigned short uiServiceType)
{
	nmsp::network::INetworkParse* piTmpParse;
	nmsp::network::INetworkSink* piTmpSink;

	{
		std::unique_lock<std::shared_mutex> cRL(m_cRwLockInterface);

		if (uiServiceType != m_uiServiceType)
			return;

		//
		piTmpParse = m_piParse;
		piTmpSink = m_piSink;

		//
		m_uiServiceType = 0;
		m_piParse = nullptr;
		m_piSink = nullptr;
	}

	if (piTmpParse)
		piTmpParse->Release();

	if (piTmpSink)
		piTmpSink->Release();
}

int network_impl::Out(const nmsp::network::_client_t& session, int nLen, const unsigned char* pchData)
{
	// 문제 없다면 보내봅시다
	int nIndex;
	int nIdentity;
	network_session::SeperateSessionID(session, nIndex, nIdentity);

	if (false == __super_t::Send(nIndex, nIdentity, nLen, pchData))
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _NETWORK_ERROR_OUT);

	return nmsp::_NMSP_NOERROR;
}

int network_impl::Close(const nmsp::network::_client_t& session)
{
	// 문제 없다면 보내봅시다
	int nIndex;
	int nIdentity;
	network_session::SeperateSessionID(session, nIndex, nIdentity);

	if (false == __super_t::Close(nIndex, nIdentity))
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _NETWORK_ERROR_CLOSE);

	return nmsp::_NMSP_NOERROR;
}

int network_impl::Post(const nmsp::network::_client_t& session, int nOption, int nLen, const unsigned char* pchData)
{
	// 문제 없다면 보내봅시다
	int nIndex;
	int nIdentity;
	network_session::SeperateSessionID(session, nIndex, nIdentity);

	if (false == __super_t::Post(nIndex, nIdentity, nOption, nLen, pchData))
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _NETWORK_ERROR_POST);

	return nmsp::_NMSP_NOERROR;
}

int network_impl::SetTimer(int id, int milisec)
{
	//IDLE_TIMER_ID는 내부에서 사용하므로
	if (IDLE_TIMER_ID == id)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _NETWORK_ERROR_TIMER);

	// IDLE_TIMER_ID가 아닌것만 등록하도록 한다..
	if (false == __super_t::SetTimer(id, milisec))
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _NETWORK_ERROR_TIMER);

	return nmsp::_NMSP_NOERROR;
}

int network_impl::ResetTimer(int id)
{
	if (false == __super_t::ResetTimer(id))
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _NETWORK_ERROR_TIMER);

	return nmsp::_NMSP_NOERROR;
}

void network_impl::GetConfigInfo(nmsp::network::IConfigInfo & info)
{
	using boost::asio::ip::tcp;
	boost::asio::io_service io_service;
	tcp::resolver resolver(io_service);
	tcp::resolver::query query(boost::asio::ip::host_name(), "");
	tcp::resolver::iterator iter = resolver.resolve(query);
	while (iter != boost::asio::ip::tcp::resolver::iterator())
	{
		boost::asio::ip::address addr = (iter++)->endpoint().address();
		if (addr.is_v6())
			info.PushLocalIPv6(addr.to_string());
		else
			info.PushLocalIPv4(addr.to_string());
	}

	info.SetUrl(static_cast<network_config&>(*m_pcComponentImpl).GetServerAddress());
	info.SetPort(static_cast<network_config&>(*m_pcComponentImpl).GetServerListenPort());
}

int network_impl::GetNetworkMessage(nmsp::network::INetworkMessage** ppiNetworkMessage)
{
	*ppiNetworkMessage = new _network_message_impl_t(m_pcComponentImpl);
	if (nullptr == *ppiNetworkMessage)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _NETWORK_ERROR_MEMORY);

	return nmsp::_NMSP_NOERROR;
}

int network_impl::GetNetworkMessageBuffer(int nLen, nmsp::network::INetworkMessageBuffer** ppiMessageBuffer)
{
	*ppiMessageBuffer = new _network_message_buffer_impl_t(m_pcComponentImpl);
	if (nullptr == *ppiMessageBuffer)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _NETWORK_ERROR_MEMORY);

	if (nmsp::_NMSP_NOERROR != (*ppiMessageBuffer)->Allocate(nLen))
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _NETWORK_ERROR_MEMORY);

	return nmsp::_NMSP_NOERROR;
}

int network_impl::Out(const nmsp::network::_client_t& session, nmsp::network::INetworkMessage* piNetworkMessage)
{
	nmsp::smartinterface<_network_message_impl_t> cRefX = static_cast<_network_message_impl_t*>(piNetworkMessage);

	// 문제 없다면 보내봅시다
	int nIndex;
	int nIdentity;
	network_session::SeperateSessionID(session, nIndex, nIdentity);

	if (false == __super_t::Post(nIndex, nIdentity, std::move(cRefX)))
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _NETWORK_ERROR_POST);

	//_shared_session_t sess;
	//if (false == __super_t::Find(nIndex, sess))
	//	return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _NETWORK_ERROR_POST);

	//if (nIdentity != sess->GetIdentity())
	//	return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _NETWORK_ERROR_POST);

	//if (false == sess->PostSend(std::move(cRefX)))
	//	return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _NETWORK_ERROR_POST);

	return nmsp::_NMSP_NOERROR;
}

int network_impl::Out(const nmsp::network::_client_t& session, int nLen, const unsigned char* pchData, int nLen2, const unsigned char* pchData2)
{
	// 문제 없다면 보내봅시다
	int nIndex;
	int nIdentity;
	network_session::SeperateSessionID(session, nIndex, nIdentity);

	_shared_session_t sess;
	if (false == __super_t::Find(nIndex, sess))
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _NETWORK_ERROR_OUT);

	if (nIdentity != sess->GetIdentity())
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _NETWORK_ERROR_OUT);

	if (false == sess->PostSend(nLen, pchData, nLen2, pchData2))
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _NETWORK_ERROR_OUT);

	return nmsp::_NMSP_NOERROR;
}

void network_impl::SetTcpOption(network_session& sess)
{
	boost::asio::ip::tcp::socket& sock = sess.GetSocket();

	try
	{
		// 수신버퍼
		{
			boost::asio::socket_base::receive_buffer_size option(static_cast<network_config&>(*m_pcComponentImpl).GetMss());
			sock.set_option(option);
		}
		// 송신버퍼
		{
			boost::asio::socket_base::send_buffer_size option(static_cast<network_config&>(*m_pcComponentImpl).GetMss());
			sock.set_option(option);
		}
		// keep-alive
		{
			boost::asio::socket_base::keep_alive option(false);
			sock.set_option(option);
		}
		// nagle (true이면 값을 false로 false이면 true로 반전시켜야 한다.)
		{
			boost::asio::ip::tcp::no_delay option(!static_cast<network_config&>(*m_pcComponentImpl).GetNagle());
			sock.set_option(option);
		}
	}
	catch (const std::exception& e)
	{
		LOG_ERROR_SYS(m_pcComponentImpl) << "SetTcpOption" << e.what();
	}
}
