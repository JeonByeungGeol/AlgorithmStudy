﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __NETWORKMESSAGE_H__
#define __NETWORKMESSAGE_H__

// network_message 내부에서 사용되는 buffer 클래스 입니다.
// network_session 메모리 할당자에서 메모리 할당 후 header 까지 Assemble 합니다.
// network_message에 포인터 전달 후 Reset을 통해 내부 데이터를 초기화 합니다.
// 만익 Reset이 호출되지 않았다면 소멸 시 할당한 메모리를 반환하게 됩니다.
// 
// 사용법
// buffer buf;
// if (false == buf.Allocate(sizeoof(len) + len /* 24 length */))
//     return false;
// memcpy(buf.Current(), &len, sizeof(len)); buf.AddOffset(sizeof(len)); // 4byte
// memcpy(buf.Current(), &data, len); buf.AddOffset(len); // 20 byte
template <class ALLOC>
class network_message_buffer_impl : public nmsp::network::INetworkMessageBuffer, public nmsp::new_from_pool<ALLOC>
{
public:
	network_message_buffer_impl(network_component_impl* pcComponentImpl)
		: m_pcComponentImpl(pcComponentImpl)
		, m_nRefs(1)
		, m_offset(0)
		, m_data(nullptr)
	{
	}

	virtual ~network_message_buffer_impl()
	{
		m_maxBufferSize = 0;
		m_offset = 0;
		m_pcComponentImpl = nullptr;

		if (nullptr != m_data)
		{
			network_session::_allocator_t::Destroy(m_data);
			m_data = nullptr;
		}
	}

	virtual int AddRef(void) override
	{
		return ++m_nRefs;
	}

	virtual int Release(void) override
	{
		int nRefs = --m_nRefs;
		if (0 == nRefs)
		{
			delete this;
			return 0;
		}

		return nRefs;
	}

	// 데이터를 반환합니다. 
	virtual unsigned char* GetData() override { return m_data; }
	virtual int GetSize() override { return m_offset; }

	// buffer에 데이터를 추가합니다.
	// memcpy + 자동 offset 기능을 합니다.
	// 해당 버퍼를 이용할 경우 Append를 통해 데이터를 추가하셔야 합니다.
	virtual bool Append(const void* src, size_t len) override
	{
		if (m_maxBufferSize < (m_offset + len))
			return false;

		memcpy(Current(), src, len);

		m_offset += static_cast<int>(len);

		return true;
	}
	
	// 헤더 + nLen(패킷 크기) 만큼 메모리를 할당합니다.
	// 이때 nLen을 이용해 헤더를 구성하기 때문에 실제 nLen은 실제 데이터 크기를 넣어 주셔야 합니다.
	virtual int Allocate(int nLen) override
	{
		unsigned char achHead[network_session::MAX_HD_SIZE];

		if (false == static_cast<network_impl&>(*m_pcComponentImpl).Assemble(nLen, sizeof(achHead), &m_offset, achHead))
			return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _NETWORK_ERROR_ASSEMBLE);
		
		m_maxBufferSize = m_offset + nLen;

		m_data = reinterpret_cast<unsigned char*>(network_session::_allocator_t::CreateMemory(m_maxBufferSize));	// network_session::_allocator_t의 allocator를 사용한 이유는 나중에 소멸의 주체가 그쪽이기 때문이다..
		if (nullptr == m_data)
			return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _NETWORK_ERROR_MEMORY);

		if (0 < m_offset)
		{
			memcpy(m_data, achHead, m_offset);
		}

		return nmsp::_NMSP_NOERROR;
	}

	// network message에 내용이 전달된 후 데이터를 초기화 합니다.(Move 개념)
	// * 레퍼런스 카운트는 객체 생명 주기와 관련이 있으므로 건들지 않습니다.
	virtual void Reset() override
	{
		m_offset = 0;
		m_maxBufferSize = 0;
		m_data = nullptr;
	}

private:
	unsigned char* Current() { return m_data + m_offset; }

	std::atomic_int m_nRefs;

	int m_offset;
	int m_maxBufferSize;
	// header + data
	// 외부에서 사용할 경우 Header가 들어갈 자리는 제외하고 사용해야 한다.
	unsigned char* m_data;

	network_component_impl* m_pcComponentImpl;
};

// 메시지를 한번에 전송할 수 있도록 하기 위한..
template <class ALLOC>
class network_message_impl : public nmsp::network::INetworkMessage, public nmsp::new_from_pool<ALLOC>
{
public:
	using _allocator_t = ALLOC;
	using __this_t = network_message_impl<_allocator_t>;
	using _len_vec_t = std::vector<int, nmsp::stl_default_allocator<int, _allocator_t>>;
	using _data_vec_t = std::vector<unsigned char*, nmsp::stl_default_allocator<unsigned char*, _allocator_t>>;

public:
	network_message_impl(network_component_impl* pcComponentImpl)
		: m_pcComponentImpl(pcComponentImpl)
	{
		m_nRefs = 1;
		m_nTotal = 0;
	}
	virtual ~network_message_impl()
	{
		for (auto& itr : m_vecData)
		{
			if (nullptr != itr)
				network_session::_allocator_t::DestroyMemory(itr);			// network_session::_allocator_t의 allocator를 사용한 이유는 나중에 소멸의 주체가 그쪽이기 때문이다..
		}
	}
	virtual int AddRef(void) override
	{
		return ++m_nRefs;
	}
	virtual int Release(void) override
	{
		int nRefs = --m_nRefs;
		if (0 == nRefs)
		{
			delete this;
			return 0;
		}

		return nRefs;
	}

	virtual int Put(nmsp::network::INetworkMessageBuffer* buffer) override
	{
		std::lock_guard<std::mutex> cLk(m_lock);

		m_nTotal += buffer->GetSize();

		// 복사한 데이터를 넣는다.
		m_vecLen.push_back(buffer->GetSize());
		m_vecData.push_back(buffer->GetData());

		// 데이터가 전달됐으므로 초기화 합니다.(Move와 같은 개념)
		buffer->Reset();

		return nmsp::_NMSP_NOERROR;
	}

	virtual int Put(int nLen, const unsigned char* pchData) override
	{
		std::lock_guard<std::mutex> cLk(m_lock);

		//
		int nLenHd;
		unsigned char achHead[network_session::MAX_HD_SIZE];

		if (false == static_cast<network_impl&>(*m_pcComponentImpl).Assemble(nLen, sizeof(achHead), &nLenHd, achHead))
			return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _NETWORK_ERROR_ASSEMBLE);

		int32_t totalLen = nLenHd + nLen;

		unsigned char* pClone = reinterpret_cast<unsigned char*>(network_session::_allocator_t::CreateMemory(totalLen));	// network_session::_allocator_t의 allocator를 사용한 이유는 나중에 소멸의 주체가 그쪽이기 때문이다..
		if (nullptr == pClone)
			return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _NETWORK_ERROR_MEMORY);

		if (0 < nLenHd)
			memcpy(pClone, achHead, nLenHd);

		if (0 < nLen)
			memcpy(pClone + nLenHd, pchData, nLen);

		m_nTotal += totalLen;

		// 처음인 경우는 빈것을 넣는다
		if (m_vecLen.empty())
		{
			//m_vecLen.push_back(0);
			//m_vecData.push_back(nullptr);
		}

		// 복사한 데이터를 넣는다.
		m_vecLen.push_back(totalLen);
		m_vecData.push_back(pClone);

		return nmsp::_NMSP_NOERROR;
	}
	virtual int Merge(nmsp::network::INetworkMessage* pOtherMessage)
	{
		auto messages = static_cast<__this_t*>(pOtherMessage);

		std::lock_guard<std::mutex> cLk(m_lock);
		std::lock_guard<std::mutex> cLkOther(messages->m_lock);

		this->m_vecLen.insert(this->m_vecLen.end(), messages->m_vecLen.begin(), messages->m_vecLen.end());
		this->m_vecData.insert(this->m_vecData.end(), messages->m_vecData.begin(), messages->m_vecData.end());
		this->m_nTotal += messages->m_nTotal;

		messages->m_nTotal = 0;
		messages->m_vecLen.clear();
		messages->m_vecData.clear();

		return nmsp::_NMSP_NOERROR;
	}
	template <class T>
	bool Reset(T& _t)
	{
		std::lock_guard<std::mutex> cLk(m_lock);

		// 비어있거나 이미 보내진거라면..
		if (m_vecData.empty()/* || nullptr != m_vecData[0]*/)
			return false;

		//
		/*
		int nLenHd;
		unsigned char achHead[network_session::MAX_HD_SIZE];

		if (false == static_cast<network_impl&>(*m_pcComponentImpl).Assemble(m_nTotal, sizeof(achHead), &nLenHd, achHead))
			return false;

		unsigned char* pHead = reinterpret_cast<unsigned char*>(network_session::_allocator_t::CreateMemory(nLenHd));	// network_session::_allocator_t의 allocator를 사용한 이유는 나중에 소멸의 주체가 그쪽이기 때문이다..
		if (nullptr == pHead)
			return false;

		memcpy(pHead, achHead, nLenHd);

		// header를 넣었다
		m_vecLen[0] = nLenHd;
		m_vecData[0] = pHead;
		*/
		///
		for (_len_vec_t::size_type sL = 0; sL < m_vecLen.size(); ++sL)
			_t(m_vecData[sL], m_vecLen[sL]);

		m_vecLen.clear();
		m_vecData.clear();
		return true;
	}
	virtual int Total() override
	{
		return m_nTotal;
	}

private:
	std::atomic_int m_nRefs;
	std::mutex m_lock;
	int m_nTotal;
	_len_vec_t m_vecLen;
	_data_vec_t m_vecData;
	network_component_impl* m_pcComponentImpl;
};

#endif
