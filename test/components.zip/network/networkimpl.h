﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __NETWORKPUMP_H__
#define __NETWORKPUMP_H__

////////////////////////////////////////////////////////////////////////////////
// session을 재정의하자
class network_session
#ifdef _DEBUG
	: public nmsp::session<nmsp::default_allocator>
#else
	: public nmsp::session<nmsp::pool::allocator_from_pool<>>
#endif
{
public:
#ifdef _DEBUG
	using _allocator_t = nmsp::default_allocator;
#else
	using _allocator_t = nmsp::pool::allocator_from_pool<>;
#endif
	using __super_t = nmsp::session<_allocator_t>;

public:
	network_session(_net_pump_base_t& pumpbase)
		: __super_t(pumpbase)
	{
	}
	virtual ~network_session()
	{
	}
	virtual bool OnAccept(_shared_session_t& sess, std::shared_ptr<boost::asio::ip::tcp::acceptor>& _acceptor, const boost::system::error_code& error) override;
	virtual bool OnReceive(_shared_session_t& sess, _shared_read_ctrl_t&, const boost::system::error_code& error, const std::size_t& trans) override;
	virtual bool OnSend(_shared_session_t& sess, _shared_writevector_t& vecBuff, const boost::system::error_code& error, const std::size_t& trans) override;
	virtual bool OnSend2(_shared_session_t& sess, _shared_write_buffer_t& buffer, const boost::system::error_code& error, const std::size_t& trans) override;
	virtual bool OnClose(_shared_session_t& sess) override;
	virtual bool OnConnect(_shared_session_t& sess, const boost::system::error_code& error) override;
	virtual void SetTcpOption() override;

	inline nmsp::network::_client_t MakeSessionID()
	{
		return (static_cast<nmsp::network::_client_t>(this->GetIndex()) << 32) | this->GetIdentity();
	}
	inline static nmsp::network::_client_t MakeSessionID(int nIndex, int nIdentity)
	{
		return (static_cast<nmsp::network::_client_t>(nIndex) << 32) | nIdentity;
	}
	inline static void SeperateSessionID(const nmsp::network::_client_t& session, int& nIndex, int& nIdentity)
	{
		nIndex = (session >> 32) & 0x00000000FFFFFFFF;
		nIdentity = session & 0x00000000FFFFFFFF;
	}
};

////////////////////////////////////////////////////////////////////////////////
// network_impl 은 coordinator로 동작하거나 서버간에 peer로 동작하게 된다. 
// 각 peer는 coordinator에 접속을 해서 각 peer의 정보를 획득한다.. 
// 이 획득한 정보를 사용하여 각 peer에 접속을 하고 정보를 주고 받는다
// 또한 다른 컴포넌트들이 요청을 받아 peer에 정보를 전송하거나 접속한 peer의 정보를 컴포넌트들에 알려주게 된다. 
//
class network_impl
	: public nmsp::network::INetwork
	, public nmsp::net_pump<network_session, network_session::_allocator_t>
{
	using __this_t = network_impl;
	using _allocator_t = network_session::_allocator_t;
	using __super_t = nmsp::net_pump<network_session, _allocator_t>;
	using _network_message_impl_t = network_message_impl<_allocator_t>;
	using _network_message_buffer_impl_t = network_message_buffer_impl<_allocator_t>;
	enum { IDLE_TIMER_ID = 0, };

public:
	network_impl(network_component_impl* pcComponentImpl);
	virtual ~network_impl();

	bool Init();
	void Uninit();

	// -------
	// 패킷의 조합에 필요한것임
	virtual bool Assemble(int nPktLen, int nMaxHdLen, int* pnLen, unsigned char* pchHd) override;
	virtual bool Disassemble(int nIndex, int nIdentity, int nLen, const unsigned char* pchData, int* pnTotalLen, int* pnHdLen, int* pnDataLen) override;
	// 타이머 핸들러
	virtual void OnTimer(int nId, const boost::system::error_code& error);
	// TCP 통신 핸들러
	virtual void OnAccepted(int nIndex, int nIdentity, _session_t* pcSess) override;
	virtual void OnConnected(int nIndex, int nIdentity, _session_t* pcSess) override;
	virtual void OnClosed(int nIndex, int nIdentity, _session_t* pcSess) override;
	virtual void OnReceived(int nIndex, int nIdentity, int nLen, const unsigned char* pchData, _session_t* pcSess) override;
	virtual void OnSent(int nIndex, int nIdentity, int nSentBytes, _session_t* pcSess) override;
	virtual void OnPosted(int nIndex, int nIdentity, int nOption, int nLen, const unsigned char* pchData, _session_t* pcSess) override;
	// 에러 로그 핸들러
	virtual void OnError(const boost::system::error_code& error) override;
	virtual void OnError(int32_t index, int32_t identify, const boost::system::error_code& error) override;
	virtual void OnError(const std::exception& error) override;
	virtual void OnError(const char* pszError) override;

	// -------
	virtual int QueryInterface(const nmsp::UUID* iid, void** pInterface) override;
	virtual int AddRef(void) override;
	virtual int Release(void) override;
	virtual int SetSink(unsigned short uiServiceType, nmsp::network::INetworkParse* piParser, nmsp::network::INetworkSink* piSink) override;
	virtual void ResetSink(unsigned short uiServiceType) override;
	virtual int Out(const nmsp::network::_client_t& session, int nLen, const unsigned char* pchData) override;
	virtual int Close(const nmsp::network::_client_t& session) override;
	virtual int Post(const nmsp::network::_client_t& session, int nOption, int nLen, const unsigned char* pchData) override;
	
	// id는 0이 아닌 값으로...
	virtual int SetTimer(int id, int milisec);
	virtual int ResetTimer(int id);

	virtual void GetConfigInfo(nmsp::network::IConfigInfo & info);

	virtual int GetNetworkMessage(nmsp::network::INetworkMessage** piConnectorMessage) override;
	virtual int GetNetworkMessageBuffer(int nLen, nmsp::network::INetworkMessageBuffer** ppiConnectorMessage) override;

	virtual int Out(const nmsp::network::_client_t& session, nmsp::network::INetworkMessage* piConnectorMessage) override;
	virtual int Out(const nmsp::network::_client_t& session, int nLen, const unsigned char* pchData, int nLen2, const unsigned char* pchData2);

	// 옵션을 설정하자
	void SetTcpOption(network_session& sess);

private:
	std::shared_mutex m_cRwLockInterface;
	unsigned short m_uiServiceType;
	nmsp::network::INetworkParse* m_piParse;
	nmsp::network::INetworkSink* m_piSink;
	int m_nCurrIndex;

private:
	network_component_impl* m_pcComponentImpl;
};

#endif
