﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 가능하면 이것 하나로..
#include "timerbase.h"

//
timer_mmgr timer_impl::m_cTimerMngr;

//
bool timer_impl::Init(unsigned int nResolution)
{
	if (false == m_cCtrlTimers.Init())
		return false;

	m_cCtrlTimers.SetResolution(nResolution);

	if (false == m_cCtrlTimers.Start())
		return false;

	return true;
}

void timer_impl::Uninit()
{
	m_cCtrlTimers.DoEnd();
	m_cCtrlTimers.End();
	m_cCtrlTimers.Uninit();
}

//
int timer_impl::QueryInterface(const nmsp::UUID* iid, void** pInterface)
{
	return m_pcComponentImpl->QueryInterface(iid, pInterface);
}

// network_component_impl의 life time내에 같이 공존하기 위해서..
int timer_impl::AddRef(void)
{
	return m_pcComponentImpl->AddRef();
}

// network_component_impl의 life time내에 같이 공존하기 위해서..
int timer_impl::Release(void)
{
	return m_pcComponentImpl->Release();
}

int timer_impl::RegTimer(nmsp::timer::_TIMER_KEY_T* ptkTimerKey, const nmsp::timer::_TIMER_REL_KEY_T& rkVal, nmsp::timer::ITimerSink* pISink)
{
	nmsp::smartinterface<nmsp::timer::ITimerSink> cRefTimerSink;

	int nRet = pISink->QueryInterface(&nmsp::timer::UUID_ITimerSink, static_cast<void**>(cRefTimerSink));
	if (nmsp::_NMSP_NOERROR != nRet)
		return nRet;

	_CT_T::_KEY_T _kId;
	if (false == m_cCtrlTimers.RegTimer<_VPIMPL_T>(_kId))
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _TIMER_ERROR_REGTIMER);

	nmsp::smartinterface<_VT_T::_TIME_T> cRefTimer;
	if (false == m_cCtrlTimers.FindTimer(_kId, cRefTimer))
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _TIMER_ERROR_FINDTIMER);

	static_cast<_VT_T*>(static_cast<_VT_T::_TIME_T*>(cRefTimer))->GetPolicy().operator()(_kId, rkVal, cRefTimerSink);

	*ptkTimerKey = _kId;

	return nmsp::_NMSP_NOERROR;
}

int timer_impl::UnregTimer(const nmsp::timer::_TIMER_KEY_T& tkTimerKey)
{
	m_cCtrlTimers.UnregTimer(tkTimerKey);
	return nmsp::_NMSP_NOERROR;
}

int timer_impl::ChangeResolution(const nmsp::timer::_TIMER_KEY_T& tkTimerKey, int nResolution)
{
	nmsp::smartinterface<_VT_T::_TIME_T> cRefTimer;
	if (false == m_cCtrlTimers.FindTimer(tkTimerKey, cRefTimer))
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _TIMER_ERROR_FINDTIMER);

	static_cast<_VT_T*>(static_cast<_VT_T::_TIME_T*>(cRefTimer))->GetPolicy().operator()(typename _CT_T::_TIME_T::_CMD_SETRESOLUTION_T(), nResolution);

	return nmsp::_NMSP_NOERROR;
}

int timer_impl::GetTimeInfo(
	const nmsp::timer::_TIMER_KEY_T& tkTimerKey,
	nmsp::timer::_TIMER_REL_KEY_T& rkVal,
	nmsp::timer::_TIMER_VALUE_T& _tvCurrTime,
	nmsp::timer::_TIMER_VALUE_T& _tvFixedCurrTime,
	nmsp::timer::_TIMER_VALUE_T& _tvElapsedTime,
	nmsp::timer::_TIMER_VALUE_T& _tvScaleCurrTime)
{
	nmsp::smartinterface<_VT_T::_TIME_T> cRefTimer;
	if (false == m_cCtrlTimers.FindTimer(tkTimerKey, cRefTimer))
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _TIMER_ERROR_FINDTIMER);

	//
	rkVal = static_cast<_VT_T*>(static_cast<_VT_T::_TIME_T*>(cRefTimer))->GetPolicy().GetTimerRelKet();

	//
	m_cCtrlTimers.FetchAllTimes(_tvCurrTime, _tvFixedCurrTime, _tvElapsedTime);

	//
	_tvScaleCurrTime = cRefTimer->GetCurrTime();

	return nmsp::_NMSP_NOERROR;
}

