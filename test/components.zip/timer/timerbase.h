﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __BASE_H__
#define __BASE_H__

// component implementation class
class timer_component_impl;

// 컴포넌트 내부에서 사용할 오류 정의
enum _TIMER_ERROR_T
{
	_TIMER_ERROR_INVALID_INTERFACE_REQ	= 1,
	_TIMER_ERROR_CONFIG					= 2,
	_TIMER_ERROR_INIT					= 3,
	_TIMER_ERROR_REGTIMER				= 4,
	_TIMER_ERROR_FINDTIMER				= 5,
	_TIMER_ERROR_INIT_LOG				= 6,
};

// 항상 component instance를 필요로 한다..
#define LV_TRACE	nmsp::logger::lv::trace
#define LV_DEBUG	nmsp::logger::lv::debug
#define LV_INFO		nmsp::logger::lv::info
#define LV_WARNING	nmsp::logger::lv::warning
#define LV_ERROR	nmsp::logger::lv::error
#define LV_FATAL	nmsp::logger::lv::fatal

#define LOG_TRACE_SYS(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_TRACE) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_DEBUG_SYS(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_DEBUG) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_INFO_SYS(component)				BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_INFO) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_WARNING_SYS(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_WARNING) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_ERROR_SYS(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_ERROR) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_FATAL_SYS(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_FATAL) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["

//
#if defined(_WIN32) || defined(_WIN64)

#pragma warning(disable : 4819)
#pragma warning(error : 4715)

#ifdef _DEBUG
#define DEBUG_NEW   new( _NORMAL_BLOCK, __FILE__, __LINE__)
#else
#define DEBUG_NEW
#endif 

#define _CRTDBG_MAP_ALLOC 
#include <stdlib.h> 
#include <crtdbg.h>

#endif

////////////////////////////////////////////////////////////////////////////////
//
#include <atomic>
#include <string>
#include <map>
#include <list>
#include <vector>
#include <unordered_map>
#include <thread>
#include <shared_mutex>
#include <assert.h>
#include <boost/property_tree/json_parser.hpp>
#include <iostream>

#if defined(_WIN32) || defined(_WIN64)
#include <windows.h>
#endif

////////////////////////////////////////////////////////////////////////////////
// ours include
#include "nmspInterface.h"
#include "nmspsmart.h"
#include "nmsperror.h"
#include "nmspmemallocate.h"
#include "nmspmemchunk.h"
#include "nmspmmgrchunk.h"
#include "nmspcondition.h"
#include "nmspcomponentmain.h"
#include "nmsplogger.h"

////////////////////////////////////////////////////////////////////////////////
// 
#include "loginterface.h"
#include "timerinterface.h"
#include "servicetypedef.h"

////////////////////////////////////////////////////////////////////////////////
// 구현 의존적인 것임
#include "timerconfig.h"
#include "timermemory.h"
#include "timerlogic.h"
#include "timerimpl.h"
#include "timer.h"

#endif
