﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __TIMERBASE_H__
#define __TIMERBASE_H__

////////////////////////////////////////////////////////////////////////////////

class timer_interface{
public:
	using _CLOCK_T = unsigned __int64;
	enum { MSEC_PER_SEC = 1000, };

public:
	virtual unsigned int GetResolution() = 0;
	virtual void SetResolution(unsigned int) = 0;
	virtual _CLOCK_T FetchCurrTime() = 0;
	virtual _CLOCK_T GetCurrTime() = 0;
	virtual _CLOCK_T GetFixedCurrTime() = 0;
	virtual _CLOCK_T GetElapsedTime() = 0;
	virtual void FetchAllTimes(_CLOCK_T& ckCurrMsec, _CLOCK_T& ckFixedCurrMsec, _CLOCK_T& ckElapsedMsec) = 0;
	virtual void OnTimer(const _CLOCK_T& ckCurrMsec, const _CLOCK_T& ckFixedCurrMsec, const _CLOCK_T& ckElapsedMsec) = 0;
};

// 타이머를 위한 기본.템플릿 클래스..
template <class ALLOC>
class timer_base : public timer_interface
{
	typedef ALLOC _ALLOC_T;
	template <typename T, T V>
	struct _value_2_type { enum { VALUE = V, }; };
	typedef enum { CMD_CURRTIME = 1, CMD_FIXEDCURRTIME, CMD_ELAPSEDTIME, CMD_CHECKTIME, CMD_GETRESOLUTION, CMD_SETRESOLUTION, CMD_ONTIMER, } _CMD_T;

public:
	typedef _value_2_type<_CMD_T, CMD_CURRTIME> _CMD_CURRTIME_T;
	typedef _value_2_type<_CMD_T, CMD_FIXEDCURRTIME> _CMD_FIXEDCURRTIME_T;
	typedef _value_2_type<_CMD_T, CMD_ELAPSEDTIME> _CMD_ELAPSEDTIME_T;
	typedef _value_2_type<_CMD_T, CMD_CHECKTIME> _CMD_CHECKTIME_T;
	typedef _value_2_type<_CMD_T, CMD_GETRESOLUTION> _CMD_GETRESOLUTION_T;
	typedef _value_2_type<_CMD_T, CMD_SETRESOLUTION> _CMD_SETRESOLUTION_T;
	typedef _value_2_type<_CMD_T, CMD_ONTIMER> _CMD_ONTIMER_T;

public:
	timer_base() 
		: m_nRefs(1)
	{
	}
	virtual ~timer_base() 
	{
	}
	virtual int AddRef(void)
	{
		return ++m_nRefs;
	}
	virtual int Release(void)
	{
		int nRefs = --m_nRefs;
		if (0 == nRefs)
		{
			_ALLOC_T::Destroy(this);
			return 0;
		}

		return nRefs;
	}
	
public:
	virtual void OnTimer(const _CLOCK_T &ckCurrMsec, const _CLOCK_T &ckFixedCurrMsec, const _CLOCK_T &ckElapsedMsec) override {}

private:
	std::atomic_int m_nRefs;
};

////////////////////////////////////////////////////////////////////////////////
// 타이머 구현 !!!
template <class POLICY, class ALLOC>
class steady_timer: public timer_base<ALLOC>
{
public:
	using _CLOCK_T = timer_interface::_CLOCK_T;

	typedef POLICY _POLICY_T;
	typedef std::chrono::time_point<std::chrono::steady_clock> _TIME_POINT_T;

public:
	steady_timer();
	virtual ~steady_timer();

	virtual bool Init();
	virtual void Uninit();
	virtual unsigned int GetResolution();
	virtual void SetResolution(unsigned int);
	virtual _CLOCK_T FetchCurrTime();
	virtual _CLOCK_T GetCurrTime();
	virtual _CLOCK_T GetFixedCurrTime();
	virtual _CLOCK_T GetElapsedTime();
	virtual _CLOCK_T GetFrequency();
	virtual void FetchAllTimes(_CLOCK_T &ckCurrMsec, _CLOCK_T &ckFixedCurrMsec, _CLOCK_T &ckElapsedMsec);
	virtual void OnTimer(const _CLOCK_T &ckCurrMsec, const _CLOCK_T &ckFixedCurrMsec, const _CLOCK_T &ckElapsedMsec);

public:
	inline _POLICY_T& GetPolicy() { return m_cPolicy; }

private:
	_TIME_POINT_T m_tpPerfCounter;
	_TIME_POINT_T m_tpStartPerfCounter;
	_TIME_POINT_T m_tpPrevPerfCounter;
	_CLOCK_T m_ckElapsedMsec;
	_CLOCK_T m_ckCurrMsec;
	_CLOCK_T m_ckFixedCurrMsec;
	
private:
	_POLICY_T m_cPolicy;
	std::shared_mutex m_clock;
};

template <class POLICY, class ALLOC>
steady_timer<POLICY, ALLOC>::steady_timer()
{
	m_tpPerfCounter = std::chrono::steady_clock::now();
	m_tpPrevPerfCounter = m_tpPerfCounter;
	m_tpStartPerfCounter = m_tpPerfCounter;
	m_ckElapsedMsec = 0;
	m_ckCurrMsec = 0;
	m_ckFixedCurrMsec = 0;
}

template <class POLICY, class ALLOC>
steady_timer<POLICY, ALLOC>::~steady_timer()
{
}

template <class POLICY, class ALLOC>
bool
steady_timer<POLICY, ALLOC>::Init()
{
	m_clock.lock();

	//
	m_tpPerfCounter = std::chrono::steady_clock::now();
	m_tpStartPerfCounter = m_tpPerfCounter;
	m_tpPrevPerfCounter = m_tpPerfCounter;
	m_ckElapsedMsec = 0;
	m_ckCurrMsec = 0;
	m_ckFixedCurrMsec = 0;

	m_clock.unlock();

	return true;
}

template <class POLICY, class ALLOC>
void
steady_timer<POLICY, ALLOC>::Uninit()
{
}

template <class POLICY, class ALLOC>
unsigned int
steady_timer<POLICY, ALLOC>::GetResolution()
{
	return m_cPolicy(_CMD_GETRESOLUTION_T(), 0);
}

template <class POLICY, class ALLOC>
void
steady_timer<POLICY, ALLOC>::SetResolution(unsigned int dwResolution)
{
	m_cPolicy(_CMD_SETRESOLUTION_T(), dwResolution);
}

template <class POLICY, class ALLOC>
typename steady_timer<POLICY, ALLOC>::_CLOCK_T
steady_timer<POLICY, ALLOC>::FetchCurrTime()
{
	auto tpCurr = std::chrono::steady_clock::now();

	//
	m_clock.lock();

	// Policy에 시간을 가져와도 되는지를 판단해 달라고 요청한다...
	auto durationElapsed = tpCurr - m_tpPerfCounter;
	_CLOCK_T ckElapsedMsec = std::chrono::duration_cast<std::chrono::milliseconds>(durationElapsed).count();

	auto duration = tpCurr - m_tpStartPerfCounter;
	_CLOCK_T ckCurrMsec = std::chrono::duration_cast<std::chrono::milliseconds>(duration).count();

	_CLOCK_T ckFixedCurrMsec = m_cPolicy(_CMD_CHECKTIME_T(), const_cast<const _CLOCK_T&>(m_ckCurrMsec), const_cast<const _CLOCK_T&>(m_ckFixedCurrMsec), const_cast<const _CLOCK_T&>(ckCurrMsec), const_cast<const _CLOCK_T&>(ckElapsedMsec));

	//
	if (0 != ckFixedCurrMsec)
	{
		// 기존 시간을 저장한다..
		m_tpPrevPerfCounter = m_tpPerfCounter;
		m_tpPerfCounter = tpCurr;
		m_ckElapsedMsec = ckElapsedMsec;
		m_ckCurrMsec = ckCurrMsec;
		m_ckFixedCurrMsec = ckFixedCurrMsec;
	}
	
	//
	m_clock.unlock();

	//
	return ckElapsedMsec;
}

template <class POLICY, class ALLOC>
typename steady_timer<POLICY, ALLOC>::_CLOCK_T
steady_timer<POLICY, ALLOC>::GetCurrTime()
{
	m_clock.lock_shared();

	// 스케일을 본인이 조정하도록 한다..
	_CLOCK_T ckRet = m_cPolicy(_CMD_CURRTIME_T(), const_cast<const _CLOCK_T&>(m_ckCurrMsec), const_cast<const _CLOCK_T&>(m_ckFixedCurrMsec), 0, const_cast<const _CLOCK_T&>(m_ckElapsedMsec));

	m_clock.unlock_shared();
	return ckRet;
}

template <class POLICY, class ALLOC>
typename steady_timer<POLICY, ALLOC>::_CLOCK_T
steady_timer<POLICY, ALLOC>::GetFixedCurrTime()
{
	m_clock.lock_shared();

	// 스케일을 본인이 조정하도록 한다..
	_CLOCK_T ckRet = m_cPolicy(_CMD_FIXEDCURRTIME_T(), const_cast<const _CLOCK_T&>(m_ckCurrMsec), const_cast<const _CLOCK_T&>(m_ckFixedCurrMsec), 0, const_cast<const _CLOCK_T&>(m_ckElapsedMsec));

	m_clock.unlock_shared();
	return ckRet;
}

template <class POLICY, class ALLOC>
typename steady_timer<POLICY, ALLOC>::_CLOCK_T
steady_timer<POLICY, ALLOC>::GetElapsedTime()
{
	m_clock.lock_shared();

	// 스케일을 본인이 조정하도록 한다..
	_CLOCK_T ckRet = m_cPolicy(_CMD_ELAPSEDTIME_T(), const_cast<const _CLOCK_T&>(m_ckCurrMsec), const_cast<const _CLOCK_T&>(m_ckFixedCurrMsec), 0, const_cast<const _CLOCK_T&>(m_ckElapsedMsec));

	m_clock.unlock_shared();
	return ckRet;
}

template <class POLICY, class ALLOC>
typename steady_timer<POLICY, ALLOC>::_CLOCK_T
steady_timer<POLICY, ALLOC>::GetFrequency()
{
	m_clock.lock_shared();

	_CLOCK_T ckRet = 1;

	m_clock.unlock_shared();
	return ckRet;
}

template <class POLICY, class ALLOC>
void
steady_timer<POLICY, ALLOC>::FetchAllTimes(_CLOCK_T &ckCurrMsec, _CLOCK_T &ckFixedCurrMsec, _CLOCK_T &ckElapsedMsec)
{
	m_clock.lock_shared();

	ckElapsedMsec = m_ckElapsedMsec;
	ckCurrMsec = m_ckCurrMsec;
	ckFixedCurrMsec = m_ckFixedCurrMsec;

	m_clock.unlock_shared();
}

template <class POLICY, class ALLOC>
void
steady_timer<POLICY, ALLOC>::OnTimer(const _CLOCK_T &, const _CLOCK_T &, const _CLOCK_T &)
{
	m_clock.lock_shared();

	m_cPolicy(_CMD_ONTIMER_T(), *this, const_cast<const _CLOCK_T&>(m_ckCurrMsec), const_cast<const _CLOCK_T&>(m_ckFixedCurrMsec), 0, const_cast<const _CLOCK_T&>(m_ckElapsedMsec));

	m_clock.unlock_shared();
}
//

////////////////////////////////////////////////////////////////////////////////
// 다른 타이머를 베이스로 하는 타이머 구현 !!!
template <class POLICY, class ALLOC>
class virtual_timer: public timer_base<ALLOC>
{
public:
	using _CLOCK_T = timer_interface::_CLOCK_T;

	typedef timer_base<ALLOC> _TIME_T;
	typedef POLICY _POLICY_T;

public:
	virtual_timer(_TIME_T& cBaseTime);
	virtual ~virtual_timer();

	virtual bool Init() { return true; }
	virtual void Uninit() {}
	virtual unsigned int GetResolution();
	virtual void SetResolution(unsigned int);
	virtual _CLOCK_T FetchCurrTime();
	virtual _CLOCK_T GetCurrTime();
	virtual _CLOCK_T GetFixedCurrTime();
	virtual _CLOCK_T GetElapsedTime();
	virtual void FetchAllTimes(_CLOCK_T &ckCurrMsec, _CLOCK_T &ckFixedCurrMsec, _CLOCK_T &ckElapsedMsec);
	virtual void OnTimer(const _CLOCK_T &ckCurrMsec, const _CLOCK_T &ckFixedCurrMsec, const _CLOCK_T &ckElapsedMsec);

public:
	inline _POLICY_T& GetPolicy() { return m_cPolicy; }

private:
	_POLICY_T m_cPolicy;
	_TIME_T& m_cBaseTime;
};

template <class POLICY, class ALLOC>
virtual_timer<POLICY, ALLOC>::virtual_timer(_TIME_T& cBaseTime)
	:m_cBaseTime(cBaseTime)
{
	m_cBaseTime.AddRef();
}

template <class POLICY, class ALLOC>
virtual_timer<POLICY, ALLOC>::~virtual_timer()
{
	m_cBaseTime.Release();
}

template <class POLICY, class ALLOC>
unsigned int
virtual_timer<POLICY, ALLOC>::GetResolution()
{
	return m_cPolicy(_CMD_GETRESOLUTION_T(), m_cBaseTime.GetResolution());
}

template <class POLICY, class ALLOC>
void
virtual_timer<POLICY, ALLOC>::SetResolution(unsigned int dwResolution)
{
	m_cPolicy(_CMD_SETRESOLUTION_T(), dwResolution);
}

template <class POLICY, class ALLOC>
typename virtual_timer<POLICY, ALLOC>::_CLOCK_T
virtual_timer<POLICY, ALLOC>::FetchCurrTime()
{
	return m_cBaseTime.FetchCurrTime();
}

template <class POLICY, class ALLOC>
typename virtual_timer<POLICY, ALLOC>::_CLOCK_T
virtual_timer<POLICY, ALLOC>::GetCurrTime()
{
	_CLOCK_T ckCurrMsec;
	_CLOCK_T ckFixedCurrMsec;
	_CLOCK_T ckElapsedMsec;

	m_cBaseTime.FetchAllTimes(ckCurrMsec, ckFixedCurrMsec, ckElapsedMsec);

	// 스케일을 본인이 조정하도록 한다..
	return m_cPolicy(_CMD_CURRTIME_T(), const_cast<const _CLOCK_T&>(ckCurrMsec), const_cast<const _CLOCK_T&>(ckFixedCurrMsec), 0, const_cast<const _CLOCK_T&>(ckElapsedMsec));
}

template <class POLICY, class ALLOC>
typename virtual_timer<POLICY, ALLOC>::_CLOCK_T
virtual_timer<POLICY, ALLOC>::GetFixedCurrTime()
{
	_CLOCK_T ckCurrMsec;
	_CLOCK_T ckFixedCurrMsec;
	_CLOCK_T ckElapsedMsec;

	m_cBaseTime.FetchAllTimes(ckCurrMsec, ckFixedCurrMsec, ckElapsedMsec);

	// 스케일을 본인이 조정하도록 한다..
	return m_cPolicy(_CMD_FIXEDCURRTIME_T(), const_cast<const _CLOCK_T&>(ckCurrMsec), const_cast<const _CLOCK_T&>(ckFixedCurrMsec), 0, const_cast<const _CLOCK_T&>(ckElapsedMsec));
}

template <class POLICY, class ALLOC>
typename virtual_timer<POLICY, ALLOC>::_CLOCK_T
virtual_timer<POLICY, ALLOC>::GetElapsedTime()
{
	_CLOCK_T ckCurrMsec;
	_CLOCK_T ckFixedCurrMsec;
	_CLOCK_T ckElapsedMsec;

	m_cBaseTime.FetchAllTimes(ckCurrMsec, ckFixedCurrMsec, ckElapsedMsec);

	// 스케일을 본인이 조정하도록 한다..
	return m_cPolicy(_CMD_ELAPSEDTIME_T(), const_cast<const _CLOCK_T&>(ckCurrMsec), const_cast<const _CLOCK_T&>(ckFixedCurrMsec), 0, const_cast<const _CLOCK_T&>(ckElapsedMsec));
}

template <class POLICY, class ALLOC>
void
virtual_timer<POLICY, ALLOC>::FetchAllTimes(_CLOCK_T &ckCurrMsec, _CLOCK_T &ckFixedCurrMsec, _CLOCK_T &ckElapsedMsec)
{
	m_cBaseTime.FetchAllTimes(ckCurrMsec, ckFixedCurrMsec, ckElapsedMsec);
}

template <class POLICY, class ALLOC>
void
virtual_timer<POLICY, ALLOC>::OnTimer(const _CLOCK_T &ckCurrMsec, const _CLOCK_T &ckFixedCurrMsec, const _CLOCK_T &ckElapsedMsec)
{
	m_cPolicy(_CMD_ONTIMER_T(), *this, const_cast<const _CLOCK_T&>(ckCurrMsec), const_cast<const _CLOCK_T&>(ckFixedCurrMsec), 0, const_cast<const _CLOCK_T&>(ckElapsedMsec));
}
//

////////////////////////////////////////////////////////////////////////////////
// 타이머에 적용되는 정책을 구현한 클래스..., 다른 타이머를 구현해도 된다...
template <class ALLOC, int RESOLUTION = 50>
class real_timer_policy
{
public:
	typedef timer_base<ALLOC> _TIME_T;

private:
	enum { RESOLUTION_MSEC = RESOLUTION, RESOLUTION_2MSEC = RESOLUTION_MSEC << 1};

public:
	real_timer_policy() 
	{
		m_dwResolutionMsec = RESOLUTION_MSEC;
		m_dwResolution2Msec = RESOLUTION_2MSEC;
	}
	virtual ~real_timer_policy() {}

	inline typename _TIME_T::_CLOCK_T operator() (typename _TIME_T::_CMD_CURRTIME_T, const typename _TIME_T::_CLOCK_T& ckCurrTime, const typename _TIME_T::_CLOCK_T& ckFixedCurrTime, const typename _TIME_T::_CLOCK_T& ckLastCurrTime, const typename _TIME_T::_CLOCK_T& ckElapsedTime)
	{
		return ckCurrTime;
	}
	inline typename _TIME_T::_CLOCK_T operator() (typename _TIME_T::_CMD_FIXEDCURRTIME_T, const typename _TIME_T::_CLOCK_T& ckCurrTime, const typename _TIME_T::_CLOCK_T& ckFixedCurrTime, const typename _TIME_T::_CLOCK_T& ckLastCurrTime, const typename _TIME_T::_CLOCK_T& ckElapsedTime)
	{
		return ckFixedCurrTime;
	}
	inline typename _TIME_T::_CLOCK_T operator() (typename _TIME_T::_CMD_CHECKTIME_T, const typename _TIME_T::_CLOCK_T& ckCurrTime, const typename _TIME_T::_CLOCK_T& ckFixedCurrTime, const typename _TIME_T::_CLOCK_T& ckLastCurrTime, const typename _TIME_T::_CLOCK_T& ckElapsedTime)
	{
		if (m_dwResolutionMsec > ckElapsedTime + (ckCurrTime - ckFixedCurrTime))
		{
			return 0;
		}

		if (ckFixedCurrTime + m_dwResolutionMsec > ckLastCurrTime)
		{
			return ckLastCurrTime;
		}

		if (ckFixedCurrTime + m_dwResolution2Msec < ckLastCurrTime)
		{
			return ckLastCurrTime;
		}

		return ckFixedCurrTime + m_dwResolutionMsec;
	}
	inline typename _TIME_T::_CLOCK_T operator() (typename _TIME_T::_CMD_ELAPSEDTIME_T, const typename _TIME_T::_CLOCK_T& ckCurrTime, const typename _TIME_T::_CLOCK_T& ckFixedCurrTime, const typename _TIME_T::_CLOCK_T& ckLastCurrTime, const typename _TIME_T::_CLOCK_T& ckElapsedTime)
	{
		return ckElapsedTime;
	}
	inline unsigned int operator() (typename _TIME_T::_CMD_GETRESOLUTION_T, const unsigned int&)
	{
		return m_dwResolutionMsec;
	}
	inline void operator() (typename _TIME_T::_CMD_SETRESOLUTION_T, const unsigned int& dwResolution)
	{
		m_dwResolutionMsec = dwResolution;
		m_dwResolution2Msec = dwResolution << 1;
	}
	inline void operator() (typename _TIME_T::_CMD_ONTIMER_T, _TIME_T& cTimer, const typename _TIME_T::_CLOCK_T& ckCurrTime, const typename _TIME_T::_CLOCK_T& ckFixedCurrTime, const typename _TIME_T::_CLOCK_T& ckLastCurrTime, const typename _TIME_T::_CLOCK_T& ckElapsedTime)
	{
	}

private:
	unsigned int m_dwResolutionMsec;
	unsigned int m_dwResolution2Msec;
};

////////////////////////////////////////////////////////////////////////////////
// 타이머에 적용되는 정책을 구현한 클래스..., 다른 타이머를 구현해도 된다...
template <class ALLOC, int SCALE = 1>
class virtual_timer_policy
{
public:
	typedef timer_base<ALLOC> _TIME_T;

private:
	enum { RESOLUTION_SCALE = SCALE };

public:
	virtual_timer_policy() 
	{
		m_unScale = RESOLUTION_SCALE;
	}
	virtual ~virtual_timer_policy() {}
	inline typename _TIME_T::_CLOCK_T operator() (typename _TIME_T::_CMD_CURRTIME_T, const typename _TIME_T::_CLOCK_T& ckCurrTime, const typename _TIME_T::_CLOCK_T& ckFixedCurrTime, const typename _TIME_T::_CLOCK_T& ckLastCurrTime, const typename _TIME_T::_CLOCK_T& ckElapsedTime)
	{
		return ckCurrTime * m_unScale;
	}
	inline typename _TIME_T::_CLOCK_T operator() (typename _TIME_T::_CMD_FIXEDCURRTIME_T, const typename _TIME_T::_CLOCK_T& ckCurrTime, const typename _TIME_T::_CLOCK_T& ckFixedCurrTime, const typename _TIME_T::_CLOCK_T& ckLastCurrTime, const typename _TIME_T::_CLOCK_T& ckElapsedTime)
	{
		return ckFixedCurrTime * m_unScale;
	}
	inline typename _TIME_T::_CLOCK_T operator() (typename _TIME_T::_CMD_CHECKTIME_T, const typename _TIME_T::_CLOCK_T& ckCurrTime, const typename _TIME_T::_CLOCK_T& ckFixedCurrTime, const typename _TIME_T::_CLOCK_T& ckLastCurrTime, const typename _TIME_T::_CLOCK_T& ckElapsedTime)
	{
		return ckFixedCurrTime * m_unScale;
	}
	inline typename _TIME_T::_CLOCK_T operator() (typename _TIME_T::_CMD_ELAPSEDTIME_T, const typename _TIME_T::_CLOCK_T& ckCurrTime, const typename _TIME_T::_CLOCK_T& ckFixedCurrTime, const typename _TIME_T::_CLOCK_T& ckLastCurrTime, const typename _TIME_T::_CLOCK_T& ckElapsedTime)
	{
		return ckElapsedTime * m_unScale;
	}
	inline unsigned int operator() (typename _TIME_T::_CMD_GETRESOLUTION_T, const unsigned int& dwResolution)
	{
		return m_unScale;
	}
	inline void operator() (typename _TIME_T::_CMD_SETRESOLUTION_T, const unsigned int& dwResolution)
	{
		m_unScale = dwResolution;
	}
	inline void operator() (typename _TIME_T::_CMD_ONTIMER_T, _TIME_T& cTimer, const typename _TIME_T::_CLOCK_T& ckCurrTime, const typename _TIME_T::_CLOCK_T& ckFixedCurrTime, const typename _TIME_T::_CLOCK_T& ckLastCurrTime, const typename _TIME_T::_CLOCK_T& ckElapsedTime)
	{
	}

private:
	unsigned int m_unScale;
};

////////////////////////////////////////////////////////////////////////////////
// Timer관리를 위한. 구조 및 루프를 만듦.
template <template <class _P, class _A> class TIMER, class POLICY, class ALLOC>
class ctrl_timers: public TIMER<POLICY, ALLOC>
{
public:
	typedef POLICY _POLICY_T;
	typedef ALLOC _ALLOC_T;
	typedef TIMER<_POLICY_T, _ALLOC_T> _SUPER_T;
	typedef timer_base<_ALLOC_T> _TIME_T;
	typedef unsigned long long _KEY_T;
	typedef std::vector<typename _TIME_T*, nmsp::stl_default_allocator<_TIME_T*, _ALLOC_T>> _VEC_TIMERS_T;
	typedef std::pair<const _KEY_T, typename _TIME_T*> _KEYPAIR_T;
	typedef std::map<_KEY_T, typename _TIME_T*, std::less<_KEY_T>, nmsp::stl_default_allocator<_KEYPAIR_T, _ALLOC_T>> _MAP_T;
	typedef typename _SUPER_T::_CLOCK_T _CLOCK_T;

private:
	enum 
	{
		CTRLTIMERS_REPEAT_FOR_KEYGENERATION = 0xFFFFFFFF,
	};

public:
	ctrl_timers();
	virtual ~ctrl_timers();

	bool Init();
	void Uninit();
	bool DoEnd();
	bool Start();
	void End();

	template <class P> bool RegTimer(_KEY_T& kVal);
	bool UnregTimer(const _KEY_T& kVal);
	bool FindTimer(const _KEY_T& kVal, _TIME_T** timer);
	void FetchTimers(_VEC_TIMERS_T& vecTimers);

private:
	void TriggerEvents(const _CLOCK_T &ckCurrMsec, const _CLOCK_T &ckFixedCurrMsec, const _CLOCK_T &ckElapsedMsec);
	bool GenerateKey(_KEY_T& kVal);

private:
	_KEY_T m_tkIdSeq;
	_MAP_T m_cTimerTable;

private:
	bool m_bEnd;
	std::unique_ptr<std::thread> m_cThr;
	nmsp::thread_for_condition m_cSync;
	std::shared_mutex m_clock;
};

template <template <class _P, class _A> class TIMER, class POLICY, class ALLOC>
ctrl_timers<TIMER, POLICY, ALLOC>::ctrl_timers()
	:m_tkIdSeq(0)
{
	m_bEnd = false;
}

template <template <class _P, class _A> class TIMER, class POLICY, class ALLOC>
ctrl_timers<TIMER, POLICY, ALLOC>::~ctrl_timers()
{
	std::unique_lock<std::shared_mutex> lk(m_clock);
	for_each(m_cTimerTable.begin(), m_cTimerTable.end(), [](const _KEYPAIR_T& _t) { _t.second->Release(); });
}

template <template <class _P, class _A> class TIMER, class POLICY, class ALLOC>
bool
ctrl_timers<TIMER, POLICY, ALLOC>::Init()
{
	return _SUPER_T::Init();
}

template <template <class _P, class _A> class TIMER, class POLICY, class ALLOC>
void
ctrl_timers<TIMER, POLICY, ALLOC>::Uninit()
{
	// 제거하자
	{
		std::unique_lock<std::shared_mutex> lk(m_clock);
		for_each(m_cTimerTable.begin(), m_cTimerTable.end(), [](const _KEYPAIR_T& _t) { _t.second->Release(); });
		m_cTimerTable.clear();
	}

	_SUPER_T::Uninit();
}

template <template <class _P, class _A> class TIMER, class POLICY, class ALLOC>
template<class P> 
bool
ctrl_timers<TIMER, POLICY, ALLOC>::RegTimer(_KEY_T& kVal)
{
	virtual_timer<P, ALLOC>* pcVirtualTimer;

	// 메모리 할당 오류.. exception을 throw할수 있다!
	try
	{
		pcVirtualTimer = _ALLOC_T::Create<virtual_timer<P, ALLOC> >(*this);
		if (nullptr == pcVirtualTimer)
		{
			return false;
		}
	}
	catch (const std::exception&)
	{
		return false;
	}

	//
	std::unique_lock<std::shared_mutex> lk(m_clock);

	//
	if (false == GenerateKey(kVal))
	{
		pcVirtualTimer->Release();
		return false;
	}

	std::pair<_MAP_T::iterator, bool> pairRet = m_cTimerTable.insert(_KEYPAIR_T(kVal, pcVirtualTimer));
	if (false == pairRet.second)
	{
		pcVirtualTimer->Release();
		return false;
	}
	//

	return true;
}

template <template <class _P, class _A> class TIMER, class POLICY, class ALLOC>
bool
ctrl_timers<TIMER, POLICY, ALLOC>::UnregTimer(const _KEY_T& kVal)
{
	std::unique_lock<std::shared_mutex> lk(m_clock);

	_MAP_T::iterator itrRet = m_cTimerTable.find(kVal);
	if (itrRet == m_cTimerTable.end())
	{
		return false;
	}

	_TIME_T* pcDelTime = itrRet->second;

	m_cTimerTable.erase(itrRet);

	pcDelTime->Release();
	return true;
}

template <template <class _P, class _A> class TIMER, class POLICY, class ALLOC>
bool
ctrl_timers<TIMER, POLICY, ALLOC>::FindTimer(const _KEY_T& kVal, _TIME_T** ppcTimerObj)
{
	std::shared_lock<std::shared_mutex> lk(m_clock);

	_MAP_T::iterator itrRet = m_cTimerTable.find(kVal);
	if (itrRet == m_cTimerTable.end())
		return false;

	_TIME_T* pcTime = itrRet->second;
	pcTime->AddRef();

	*ppcTimerObj = pcTime;
	return true;
}

template <template <class _P, class _A> class TIMER, class POLICY, class ALLOC>
void
ctrl_timers<TIMER, POLICY, ALLOC>::TriggerEvents(const _CLOCK_T &ckCurrMsec, const _CLOCK_T &ckFixedCurrMsec, const _CLOCK_T &ckElapsedMsec)
{
	_VEC_TIMERS_T vecTimers;

	//
	{
		std::shared_lock<std::shared_mutex> lk(m_clock);

		vecTimers.reserve(m_cTimerTable.size());

		for_each(m_cTimerTable.begin(), m_cTimerTable.end(), [&vecTimers](const _KEYPAIR_T& pair) {
			pair.second->AddRef();
			vecTimers.push_back(pair.second);
		});
	}
	//

	//
	for (auto& itr: vecTimers)
	{
		itr->OnTimer(ckCurrMsec, ckFixedCurrMsec, ckElapsedMsec);
		itr->Release();
	}
	//
}

template <template <class _P, class _A> class TIMER, class POLICY, class ALLOC>
void
ctrl_timers<TIMER, POLICY, ALLOC>::FetchTimers(_VEC_TIMERS_T& vecTimers)
{
	std::shared_lock<std::shared_mutex> lk(m_clock);

	for_each(m_cTimerTable.begin(), m_cTimerTable.end(), [&vecTimers](const _KEYPAIR_T& pair) {
		pair.second->AddRef();
		vecTimers.push_back(pair.second);
	});
}

template <template <class _P, class _A> class TIMER, class POLICY, class ALLOC>
bool
ctrl_timers<TIMER, POLICY, ALLOC>::GenerateKey(_KEY_T& kVal)
{
	_MAP_T::iterator itrTimer;

	for (unsigned int unCnt = 0; unCnt < CTRLTIMERS_REPEAT_FOR_KEYGENERATION; unCnt++)
	{
		itrTimer = m_cTimerTable.find(m_tkIdSeq);
		if (itrTimer == m_cTimerTable.end())
		{
			kVal = m_tkIdSeq++;
			return true;
		}

		m_tkIdSeq++;
	}

	return false;
}

template <template <class _P, class _A> class TIMER, class POLICY, class ALLOC>
bool
ctrl_timers<TIMER, POLICY, ALLOC>::DoEnd()
{
	m_bEnd = true;
	m_cSync.SetNotificationAll();

	return true;
}

template <template <class _P, class _A> class TIMER, class POLICY, class ALLOC>
void
ctrl_timers<TIMER, POLICY, ALLOC>::End()
{
	if (nullptr != m_cThr)
		m_cThr->join();
}

template <template <class _P, class _A> class TIMER, class POLICY, class ALLOC>
bool
ctrl_timers<TIMER, POLICY, ALLOC>::Start()
{
	try
	{
		m_cThr = std::make_unique<std::thread>([this]()
		{
			_VEC_TIMERS_T vecTimers;

			unsigned int unResolution = 0;
			int nIdle = 0;

			_TIME_T::_CLOCK_T ckTotalElapsed = 0;
			_TIME_T::_CLOCK_T ckFetchElapsed = 0;
			_TIME_T::_CLOCK_T ckCurr = 0;
			_TIME_T::_CLOCK_T ckElapsed = 0;

			while (false == m_bEnd)
			{
				m_cSync.Wait(nIdle);

				unResolution = GetResolution();
				ckFetchElapsed = FetchCurrTime();

				if (unResolution > ckFetchElapsed + (ckCurr - ckTotalElapsed))
				{
					nIdle = static_cast<int>(unResolution - (ckFetchElapsed + (ckCurr - ckTotalElapsed)));
					continue;
				}

				nIdle = 0;

				//
				_SUPER_T::FetchAllTimes(ckCurr, ckTotalElapsed, ckElapsed);
				FetchTimers(vecTimers);

				//
				for_each(vecTimers.begin(), vecTimers.end(), [&](_VEC_TIMERS_T::value_type& _t) {
					_t->OnTimer(ckCurr, ckTotalElapsed, ckElapsed);
					_t->Release();
				});

				vecTimers.clear();
				//
			}
		});
	}
	catch (std::exception&)
	{
		return false;
	}

	return true;
}

#endif
