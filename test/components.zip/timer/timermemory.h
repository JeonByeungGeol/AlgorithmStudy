////////////////////////////////////////////////////////////////////////////////
// �ۼ���: huelee
// ��  ��:
//
//

// ȣȯ���� ���ؼ�..
#pragma once
#ifndef __TIMERMEMORY_H__
#define __TIMERMEMORY_H__

//
class timer_mmgr: protected nmsp::mmgr<nmsp::default_allocator>
{
	typedef nmsp::mmgr<nmsp::default_allocator> __parent;

public:
	// �޸𸮸� �Ҵ��û�Ҽ��� �����Ƿ�.. �����ڿ��� �ʱ�ȭ�� �õ���...
	timer_mmgr(int lMin = 32, int lMax = 32768)
	{
		m_bInitFlag = __parent::Init(lMin, lMax);
	}
	virtual ~timer_mmgr()
	{
		__parent::Uninit();
	}

public:
	inline void* Allocate(int lSize) 
	{ 
		void* pRet;

		m_cLk.lock(); 
	
		pRet = __parent::Allocate(lSize); 

		m_cLk.unlock(); 
		return pRet; 
	}
	inline void Deallocate(void* pBack)
	{
		m_cLk.lock();
		
		__parent::Deallocate(pBack);
		
		m_cLk.unlock();
	}
	inline bool CheckMemory()
	{
		bool bRet;
		
		m_cLk.lock();
		
		bRet = __parent::CheckMemory();
		
		m_cLk.unlock();
		return bRet;
	}
	inline bool GetFreeStatus()
	{
		int nCount;
		
		m_cLk.lock();
		
		nCount = __parent::GetAllocationCount();
		
		m_cLk.unlock();
		
		return nCount?false:true;
	}
	inline int GetAllocationCount()
	{
		int nCount;
		
		m_cLk.lock();
		
		nCount = __parent::GetAllocationCount();
		
		m_cLk.unlock();
		
		return nCount;
	}
	inline int GetCorruptCount()
	{
		int nCount;
		
		m_cLk.lock();
		
		nCount = __parent::GetCorruptCount();
		
		m_cLk.unlock();
		
		return nCount;
	}
	inline int GetFreeCount()
	{
		int nCount;
		
		m_cLk.lock();
		
		nCount = __parent::GetFreeCount();
		
		m_cLk.unlock();
		
		return nCount;
	}

public:
	inline bool GetInitFlag() const
	{
		return m_bInitFlag;
	}

private:
	std::mutex m_cLk;

private:
	bool m_bInitFlag;
};

#endif
