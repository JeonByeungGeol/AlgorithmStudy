////////////////////////////////////////////////////////////////////////////////
// �ۼ���: huelee
// ��  ��:
//
//

// ȣȯ���� ���ؼ�..
#pragma once
#ifndef __TIMERCONFIG_H__
#define __TIMERCONFIG_H__

// ���������� �д´�.
class timer_config
{
	enum
	{
		RESOLUTION					= 1000,					// �ػ�
	};

public:
	timer_config()
	{
		m_unResolution				= RESOLUTION;
	}
	virtual ~timer_config()
	{
	}
	bool Load(const char* pszConfig)
	{
		try
		{
			boost::property_tree::ptree props;
			boost::property_tree::read_json(pszConfig, props);

			m_unResolution = props.get<unsigned int>("timer resolution", RESOLUTION);

			if (0 == m_unResolution)
				return false;
		}
		catch (std::exception&)
		{
			return false;
		}

		return true;
	}

public:
	inline unsigned int GetResolution() const 
	{ 
		return m_unResolution;
	}

private:
	unsigned int m_unResolution;
};

#endif
