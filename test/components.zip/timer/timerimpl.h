////////////////////////////////////////////////////////////////////////////////
// �ۼ���: huelee
// ��  ��:
//
//

// ȣȯ���� ���ؼ�..
#pragma once
#ifndef __TIMERINTERFACEIMPL_H__
#define __TIMERINTERFACEIMPL_H__

// 
template <class ALLOC, LONG SCALE = 1>
class virtual_timer_policy_impl
{
public:
	typedef timer_base<ALLOC> _TIME_T;

private:
	enum { RESOLUTION_SCALE = SCALE };

public:
	virtual_timer_policy_impl()
	{
		m_unScale = RESOLUTION_SCALE;
		m_piTimerSink = NULL;
	}
	virtual ~virtual_timer_policy_impl()
	{
		if (m_piTimerSink)
		{
			m_piTimerSink->Release();
		}
	}
	inline typename _TIME_T::_CLOCK_T operator() (typename _TIME_T::_CMD_CURRTIME_T, const typename _TIME_T::_CLOCK_T& ckCurrTime, const typename _TIME_T::_CLOCK_T& ckFixedCurrTime, const typename _TIME_T::_CLOCK_T& ckLastCurrTime, const typename _TIME_T::_CLOCK_T& ckElapsedTime)
	{
		return ckCurrTime * m_unScale;
	}
	inline typename _TIME_T::_CLOCK_T operator() (typename _TIME_T::_CMD_FIXEDCURRTIME_T, const typename _TIME_T::_CLOCK_T& ckCurrTime, const typename _TIME_T::_CLOCK_T& ckFixedCurrTime, const typename _TIME_T::_CLOCK_T& ckLastCurrTime, const typename _TIME_T::_CLOCK_T& ckElapsedTime)
	{
		return ckFixedCurrTime * m_unScale;
	}
	inline typename _TIME_T::_CLOCK_T operator() (typename _TIME_T::_CMD_CHECKTIME_T, const typename _TIME_T::_CLOCK_T& ckCurrTime, const typename _TIME_T::_CLOCK_T& ckFixedCurrTime, const typename _TIME_T::_CLOCK_T& ckLastCurrTime, const typename _TIME_T::_CLOCK_T& ckElapsedTime)
	{
		return ckFixedCurrTime * m_unScale;
	}
	inline typename _TIME_T::_CLOCK_T operator() (typename _TIME_T::_CMD_ELAPSEDTIME_T, const typename _TIME_T::_CLOCK_T& ckCurrTime, const typename _TIME_T::_CLOCK_T& ckFixedCurrTime, const typename _TIME_T::_CLOCK_T& ckLastCurrTime, const typename _TIME_T::_CLOCK_T& ckElapsedTime)
	{
		return ckElapsedTime * m_unScale;
	}
	inline unsigned int operator() (typename _TIME_T::_CMD_GETRESOLUTION_T, const unsigned int& dwResolution)
	{
		return m_unScale;
	}
	inline void operator() (typename _TIME_T::_CMD_SETRESOLUTION_T, const unsigned int& dwResolution)
	{
		m_unScale = dwResolution;
	}
	inline void operator() (typename _TIME_T::_CMD_ONTIMER_T, _TIME_T& cTimer, const typename _TIME_T::_CLOCK_T& ckCurrTime, const typename _TIME_T::_CLOCK_T& ckFixedCurrTime, const typename _TIME_T::_CLOCK_T& ckLastCurrTime, const typename _TIME_T::_CLOCK_T& ckElapsedTime)
	{
		nmsp::timer::ITimerSink* piOrgTimerSink = NULL;

		// �湮�� �ʿ���.. ��ü������ ��´�..
		{
			std::shared_lock<std::shared_mutex> cLk(m_cLock);

			if (NULL != m_piTimerSink)
			{
				m_piTimerSink->AddRef();
				piOrgTimerSink = m_piTimerSink;
			}
		}

		//
		if (NULL == piOrgTimerSink)
		{
			return;
		}

		// �ڵ鷯�� ȣ���Ѵ�..
		piOrgTimerSink->OnTimer(
			m_tkKey,
			m_rkVal,
			ckCurrTime,
			ckFixedCurrTime,
			ckElapsedTime,
			cTimer.GetCurrTime());

		piOrgTimerSink->Release();
	}
public:
	inline void operator() (const nmsp::timer::_TIMER_KEY_T& tkKey, const nmsp::timer::_TIMER_REL_KEY_T& rkVal, nmsp::timer::ITimerSink* piTimerSink)
	{
		std::unique_lock<std::shared_mutex> cLk(m_cLock);

		//
		m_tkKey = tkKey;
		m_rkVal = rkVal;

		//
		nmsp::timer::ITimerSink* piOldTimerSink = m_piTimerSink;

		//
		m_piTimerSink = piTimerSink;
		if (m_piTimerSink)
		{
			m_piTimerSink->AddRef();
		}

		//
		if (piOldTimerSink)
			piOldTimerSink->Release();
	}
	inline const nmsp::timer::_TIMER_REL_KEY_T& GetTimerRelKet()
	{
		return m_rkVal;
	}

private:
	nmsp::timer::_TIMER_KEY_T m_tkKey;
	nmsp::timer::_TIMER_REL_KEY_T m_rkVal;
	unsigned int m_unScale;
	nmsp::timer::ITimerSink* m_piTimerSink;
	std::shared_mutex m_cLock;
};

// ������Ʈ�� ����ī��Ʈ�� ���� ����Ѵ�
class timer_impl: public nmsp::timer::ITimer
{
	typedef timer_impl _ALLOC_T;
	typedef real_timer_policy<_ALLOC_T, 1000> _RP_T;
	typedef virtual_timer_policy_impl<_ALLOC_T> _VPIMPL_T;
	typedef virtual_timer<_VPIMPL_T, _ALLOC_T> _VT_T;
	typedef ctrl_timers<steady_timer, _RP_T, _ALLOC_T> _CT_T;

public:
	timer_impl(timer_component_impl* pcComponentImpl)
		: m_pcComponentImpl(pcComponentImpl)
	{
	}
	virtual ~timer_impl()
	{
	}
	bool Init(unsigned int nResolution);
	void Uninit();
	int QueryInterface(const nmsp::UUID* iid, void** pInterface);
	int AddRef(void);
	int Release(void);
	int RegTimer(nmsp::timer::_TIMER_KEY_T* ptkTimerKey, const nmsp::timer::_TIMER_REL_KEY_T& rkVal, nmsp::timer::ITimerSink* pISink);
	int UnregTimer(const nmsp::timer::_TIMER_KEY_T& tkTimerKey);
	int ChangeResolution(const nmsp::timer::_TIMER_KEY_T& tkTimerKey, int nResolution);
	int GetTimeInfo(const nmsp::timer::_TIMER_KEY_T& tkTimerKey, nmsp::timer::_TIMER_REL_KEY_T& rkVal, nmsp::timer::_TIMER_VALUE_T& _tvCurrTime, nmsp::timer::_TIMER_VALUE_T& _tvFixedCurrTime, nmsp::timer::_TIMER_VALUE_T& _tvElapsedTime, nmsp::timer::_TIMER_VALUE_T& _tvScaleCurrTime);

public:
	template <class T, class ..._ARGS_T>
	static T* Create(_ARGS_T&&... _ARGX)
	{
		void* pObject = m_cTimerMngr.Allocate(sizeof(T));
		if (nullptr == pObject)
		{
			return nullptr;
		}

		//
		new (pObject) T(std::forward<_ARGS_T>(_ARGX) ...);
		//

		return reinterpret_cast<T*>(pObject);
	}
	template <class T>
	static void Destroy(T* pT)
	{
		if (nullptr == pT)
		{
			return;
		}

		pT->~T();
		m_cTimerMngr.Deallocate(reinterpret_cast<void*>(pT));
	}
	template <class T>
	static T* CreateArray(LONG lSize)
	{
		T* pObject = reinterpret_cast<T*>(m_cTimerMngr.Allocate(sizeof(T) * lSize));
		if (nullptr == pObject)
		{
			return nullptr;
		}

		//
		for (LONG lStep = 0; lStep < lSize; lStep++)
		{
			new (pObject + lStep) T;
		}
		//

		return reinterpret_cast<T*>(pObject);
	}
	template <class T>
	static void DestroyArray(LONG lSize, T* pT)
	{
		if (nullptr == pT)
		{
			return;
		}

		for (LONG lStep = 0; lStep < lSize; lStep++)
		{
			pT[lStep].~T();
		}

		m_cTimerMngr.Deallocate(reinterpret_cast<void*>(pT));
	}
	static void* CreateMemory(int nSize)
	{
		void* pObject = m_cTimerMngr.Allocate(nSize);
		if (nullptr == pObject)
		{
			return nullptr;
		}

		return reinterpret_cast<void*>(pObject);
	}
	static void* RecreateMemory(void* pT, int nSizeForCopy, int nSize)
	{
		// ���ο� ����� 0�ϰ��� ���� ���۸� �����Ѵ�.
		if (0 == nSize)
		{
			m_cTimerMngr.Deallocate(pT);
			return nullptr;
		}

		//
		void* pObject = m_cTimerMngr.Allocate(nSize);
		if (nullptr == pObject)
		{
			return nullptr;
		}

		//
		if (pT)
		{
			memcpy(pObject, pT, min(nSizeForCopy, nSize));
			m_cTimerMngr.Deallocate(pT);
		}

		return reinterpret_cast<void*>(pObject);
	}
	static void DestroyMemory(void* pT)
	{
		if (nullptr == pT)
		{
			return;
		}

		m_cTimerMngr.Deallocate(pT);
	}

private:
	_CT_T m_cCtrlTimers;
	timer_component_impl* m_pcComponentImpl;

	// �̰� �޸� �Ҵ�����
	static timer_mmgr m_cTimerMngr;
};

#endif
