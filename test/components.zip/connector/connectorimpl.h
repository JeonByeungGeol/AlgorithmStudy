﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __CONNECTORIMPL_H__
#define __CONNECTORIMPL_H__

////////////////////////////////////////////////////////////////////////////////
// session을 재정의하자
class connector_session 
#ifdef _DEBUG
	: public nmsp::session<nmsp::default_allocator>
#else
	: public nmsp::session<nmsp::pool::allocator_from_pool<>>
#endif
{
public:
#ifdef _DEBUG
	using _allocator_t = nmsp::default_allocator;
#else
	using _allocator_t = nmsp::pool::allocator_from_pool<>;
#endif
	using __super_t = nmsp::session<_allocator_t>;
	using _serverid_t = nmsp::connector::_serverid_t;
	// 연결의 종류
	enum _session_type_t
	{
		SESSION_TYPE_NONE			= 0,
		SESSION_TYPE_C2C_CLIENT		= 1,			// peer connector에 연결을 요청한 경우
		SESSION_TYPE_C2C_SERVER		= 2,			// peer connector로부터 연결 요청을 받은 경우
		SESSION_TYPE_C2CD_CLIENT	= 3,			// coordinator에 연결을 요청한 경우
		SESSION_TYPE_C2CD_SERVER	= 4,			// coordinator가 연결 요청을 받은 경우
	};

public:
	connector_session(_net_pump_base_t& pumpbase)
		: __super_t(pumpbase)
	{
		m_bLink = false;
		m_eSessionType = SESSION_TYPE_NONE;
		m_eForSessionType = SESSION_TYPE_NONE;
		m_serverid = nmsp::connector::SERVERID_NULL;
	}
	virtual ~connector_session()
	{
	}
	virtual bool OnAccept(_shared_session_t& sess, std::shared_ptr<boost::asio::ip::tcp::acceptor>& _acceptor, const boost::system::error_code& error) override;
	virtual bool OnReceive(_shared_session_t& sess, _shared_read_ctrl_t&, const boost::system::error_code& error, const std::size_t& trans) override;
	virtual bool OnSend(_shared_session_t& sess, _shared_writevector_t& vecBuff, const boost::system::error_code& error, const std::size_t& trans) override;
	virtual bool OnSend2(_shared_session_t& sess, _shared_write_buffer_t& buffer, const boost::system::error_code& error, const std::size_t& trans) override;
	virtual bool OnClose(_shared_session_t& sess) override;
	virtual bool OnConnect(_shared_session_t& sess, const boost::system::error_code& error) override;
	virtual void SetTcpOption() override;

public:
	inline _session_type_t GetSessionType() const { return m_eSessionType; }
	inline void SetForSessionType(_session_type_t eForSessionType) { m_eForSessionType = eForSessionType; }
	inline _session_type_t GetForSessionType() const { return m_eForSessionType; }
	inline void SetLink(bool bLink) { m_bLink = bLink; }
	inline bool IsLink() const { return m_bLink; };
	inline void SetServerId(_serverid_t serverid) { m_serverid = serverid; }
	inline _serverid_t GetServerId() const { return m_serverid; }
	
	inline void SetGroupID(nmsp::connector::_group_id_t groupID) { m_groupID = groupID; }
	inline nmsp::connector::_group_id_t GetGroupID() const { return m_groupID; }

	inline void SetGroupLayer(nmsp::connector::group_layer groupLayer) { m_groupLayer = groupLayer; }
	inline nmsp::connector::group_layer GetGroupLayer() const { return m_groupLayer; }

private:
	bool m_bLink;
	_session_type_t m_eSessionType;					// 현재 상태
	_session_type_t m_eForSessionType;				// 요청된
	_serverid_t m_serverid;

	nmsp::connector::_group_id_t m_groupID;		// 그룹 ID
	nmsp::connector::group_layer m_groupLayer;	// 그룹 계층
};

////////////////////////////////////////////////////////////////////////////////
// connector_impl 은 coordinator로 동작하거나 서버간에 peer로 동작하게 된다. 
// 각 peer는 coordinator에 접속을 해서 각 peer의 정보를 획득한다.. 
// 이 획득한 정보를 사용하여 각 peer에 접속을 하고 정보를 주고 받는다
// 또한 다른 컴포넌트들이 요청을 받아 peer에 정보를 전송하거나 접속한 peer의 정보를 컴포넌트들에 알려주게 된다. 
//
class connector_impl 
	: public nmsp::connector::IConnector
	, public nmsp::net_pump<connector_session, connector_session::_allocator_t>
{
	// 패킷 정의
	// Hd ->	Field : Length(4)			/* 길이는 Body의 길이만을 얘기한다. */
	// BD ->	~
	enum 
	{ 
		IDLE_TIMER_ID = 0,
		HD_SIZE = sizeof(int),
		FLATBUFFER_INITIAL_SIZE = 1024,
	};
	using __this_t = connector_impl;
	using _allocator_t = connector_session::_allocator_t;
	using __super_t = nmsp::net_pump<connector_session, _allocator_t>;
	using _serverid_t = nmsp::connector::_serverid_t;
	using _packet_func_t = std::array<void (connector_impl::*)(const nmsp::connector::message::ConnectorPkt*, __super_t::_session_t*, flatbuffers::uoffset_t, const unsigned char*), static_cast<int32_t>(nmsp::connector::message::ConnectorBodyAll::MAX) + 1>;
	using _session_type_t = connector_session::_session_type_t;
	using _serverid_vec_t = std::vector<unsigned short, nmsp::stl_default_allocator<unsigned short, _allocator_t>>;
	using _serverid_set_t = std::set<_serverid_t, std::less<_serverid_t>, nmsp::stl_default_allocator<_serverid_t, _allocator_t>>;
	using _servicetype_vec_t = std::vector<unsigned short>;
	using _servicetype_set_t = std::set<unsigned short, std::less<unsigned short>, nmsp::stl_default_allocator<unsigned short, _allocator_t>>;
	using _connector_message_impl_t = connector_message_impl<_allocator_t>;
	// flat buffer용 메모리 할당자임
	class _flatbuffer_allocator_t : public flatbuffers::DefaultAllocator
	{
	public:
		_flatbuffer_allocator_t() = default;
		virtual ~_flatbuffer_allocator_t() = default;
		virtual uint8_t *allocate(size_t size) 
		{
			return reinterpret_cast<uint8_t *>(_allocator_t::CreateMemory(static_cast<int>(size)));
		}
		virtual void deallocate(uint8_t *p, size_t size) 
		{
			_allocator_t::DestroyMemory(p);
		}
	};

private:
	// endpoint를 관리하도록 하자
	class _serverid2serviceinfo_map_t
	{
		using _value_t = std::tuple<__super_t::_shared_session_t, _servicetype_set_t, _servicetype_set_t>;
		using _container_t = std::unordered_map<_serverid_t, _value_t, std::hash<_serverid_t>, std::equal_to<_serverid_t>, nmsp::stl_default_allocator<std::pair<const _serverid_t, _value_t>, _allocator_t>>;
	public:
		_serverid2serviceinfo_map_t();
		virtual ~_serverid2serviceinfo_map_t();
		bool Add(_serverid_t serverid, _session_t* pcSess, const _servicetype_set_t& servs, const _servicetype_set_t& activeServs);
		void Activate(_serverid_t serverid, unsigned short serviceType);
		bool Del(_serverid_t serverid);
		int Count();
		void Clear();
		template <typename T> inline bool Exe(_serverid_t serverid, T& _t)
		{
			std::shared_lock<std::shared_mutex> cLk(m_cLock);

			auto itr = m_cContainer.find(serverid);
			if (itr == m_cContainer.end())
				return false;

			_t(std::get<0>(itr->second), std::get<1>(itr->second));
			return true;
		}

		template <typename T> inline void Exe(_serverid_t serverid, nmsp::connector::_group_id_t groupID, nmsp::connector::_group_layer_t groupLayer, T& _t)
		{
			std::shared_lock<std::shared_mutex> cLk(m_cLock);

			for (auto& itr : m_cContainer)
			{
				// 유효하지 않은 SERVERID 이거나 나 자신일 경우 보내지 않음.
				if (nmsp::connector::SERVERID_NULL == serverid || serverid == itr.first)
					continue;

				// common layer가 연결된 경우 모든 서버에 전송한다.
				if (0 < (nmsp::connector::group_layer::local & groupLayer))
				{
					auto session = std::get<0>(itr.second);
					auto sessionLayer = static_cast<connector_session*>(session.get())->GetGroupLayer();
					auto sessionGroupID = static_cast<connector_session*>(session.get())->GetGroupID();
					
					// local layer일 경우 groupID를 체크하고 그렇지 않을 경우 통과
					bool isLocalLayer = 0 < (nmsp::connector::group_layer::local & sessionLayer);
					if (true == isLocalLayer && groupID != sessionGroupID)
						continue;
				}

				_t(itr.first, std::get<0>(itr.second), std::get<1>(itr.second), std::get<2>(itr.second));
			}
		}

		template <typename T> inline void Exe(T& _t)
		{
			std::shared_lock<std::shared_mutex> cLk(m_cLock);

			for (auto& itr: m_cContainer)
				_t(itr.first, std::get<0>(itr.second), std::get<1>(itr.second), std::get<2>(itr.second));
		}
		bool GetEndPoint(_serverid_t serverid, boost::asio::ip::tcp::endpoint & dest)
		{
			std::shared_lock<std::shared_mutex> cLk(m_cLock);

			auto itr = m_cContainer.find(serverid);
			if (itr == m_cContainer.end())
				return false;

			auto first = std::get<0>(itr->second);
			auto second = std::get<1>(itr->second);

			dest = first->GetSocket().remote_endpoint();
			return true;
		}

		bool GetGroupID(_serverid_t serverid, nmsp::connector::_group_id_t& groupID)
		{
			std::shared_lock<std::shared_mutex> cLk(m_cLock);

			auto itr = m_cContainer.find(serverid);
			if (itr == m_cContainer.end())
				return false;

			_session_t* sess = std::get<0>(itr->second);
			
			groupID = static_cast<connector_session*>(sess)->GetGroupID();

			return true;
		}

		void GetServiceTypes(const _serverid_t& serverid, _servicetype_set_t& serviceTypes);
		bool GetGroupLayer(_serverid_t serverid, nmsp::connector::_group_layer_t& groupLayer)
		{
			std::shared_lock<std::shared_mutex> cLk(m_cLock);

			auto itr = m_cContainer.find(serverid);
			if (itr == m_cContainer.end())
				return false;

			_session_t* sess = std::get<0>(itr->second);

			groupLayer = static_cast<connector_session*>(sess)->GetGroupLayer();

			return true;
		}

	private:
		std::shared_mutex m_cLock;
		_container_t m_cContainer;
	};
	// index, identity로 peer connector나 coordinator에 연결할 때 사용하는 세션들을 관리하기 위한 컨테이터임
	// serverid는 내부적으로 key로 사용되므로.. 한번 설정하면 바꾸지 않도록 한다.. container에 넣은 후에는 바꾸지 않는다..
	class _sess2serverinfo_t
	{
		using _serverid2sess_t = std::unordered_map<_serverid_t, _shared_session_t, std::hash<_serverid_t>, std::equal_to<_serverid_t>, nmsp::stl_default_allocator<std::pair<const _serverid_t, _shared_session_t>, _allocator_t>>;
		using _value_t = std::tuple<boost::asio::ip::tcp::endpoint, __super_t::_shared_session_t>;	// identity, serverid
		using _container_t = std::unordered_map<int, _value_t, std::hash<int>, std::equal_to<int>, nmsp::stl_default_allocator<std::pair<const int, _value_t>, _allocator_t>>;
	public:
		_sess2serverinfo_t();
		virtual ~_sess2serverinfo_t();
		bool Add(int nIndex, _serverid_t serverid, boost::asio::ip::tcp::endpoint&, __super_t::_shared_session_t&);
		//bool Del(int nIndex);
		bool Del(_serverid_t serverid);
		////bool Del(int nIndex, int nIdentity);
		//bool Is(int nIndex);
		//bool Is(int nIndex, int nIdentity);
		//bool Find(int nIndex, int& nIdentity, _serverid_t& serverid);
		bool Is(_serverid_t serverid);
		void Clear();
		template <typename T> inline void Exe(T& _t)
		{
			std::shared_lock<std::shared_mutex> cLk(m_cLock);

			for (auto& itr : m_cContainer)
				_t(itr.first, std::get<1>(itr.second)->GetIdentity(), std::get<0>(itr.second), std::get<1>(itr.second));
		}
	private:
		std::shared_mutex m_cLock;
		_container_t m_cContainer;
		_serverid2sess_t m_cDupCheck;
	};
	// IConnectorSink관리
	class _sinks_t
	{
		using _value_t = nmsp::smartinterface<nmsp::connector::IConnectorSink>;	// identity, serverid
		using _shared_sink_t = nmsp::smartinterface<nmsp::connector::IConnectorSink>;	// identity, serverid
		using _container_t = std::map<unsigned short, _value_t, std::less<unsigned short>, nmsp::stl_default_allocator<std::pair<const unsigned short, _value_t>, _allocator_t>>;
	public:
		_sinks_t();
		virtual ~_sinks_t();
		bool Add(unsigned short uiServicetype, nmsp::connector::IConnectorSink* pcSink);
		bool Del(unsigned short uiServicetype);
		void Clear();
		// T는 functor로서 const boost::asio::ip::tcp::endpoint& endpoint_, __super_t::_shared_session_t& sess개의 인자를 받도록 한다..
		template <typename T> bool Exe(unsigned short uiServiceType, T& _t)
		{
			_value_t val;
			{
				std::shared_lock<std::shared_mutex> cLk(m_cLock);

				auto itr = m_cContainer.find(uiServiceType);
				if (itr == m_cContainer.end())
					return false;

				val = itr->second;
			}

			/*
			auto end = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
			static auto log = end;
			static int32_t total_cnt = 0;
			if (log + 1000 < end)
			{
				std::cout << "_sinks_t total cnt:" << total_cnt << std::endl;
				log = end;
			}
			++total_cnt;
			*/

			_t(static_cast<nmsp::connector::IConnectorSink*>(val));
			return true;
		}
		template <typename T> bool Exe(T& _t)
		{
			std::shared_lock<std::shared_mutex> cLk(m_cLock);
				
			for (auto& itr : m_cContainer)
				_t(static_cast<nmsp::connector::IConnectorSink*>(itr.second));

			return true;
		}
	private:
		std::shared_mutex m_cLock;
		_container_t m_cContainer;
	};

public:
	connector_impl(connector_component_impl* pcComponentImpl);
	virtual ~connector_impl();

	bool Init();
	void Uninit();

	virtual bool connector_impl::GetServerInfo(_serverid_t serverid, std::string & addr, int32_t & port) override;

	// -------
	virtual int QueryInterface(const nmsp::UUID* iid, void** pInterface) override;
	virtual int AddRef(void) override;
	virtual int Release(void) override;
	virtual int SetSink(unsigned short uiServiceType, nmsp::connector::IConnectorSink* piSink) override;
	virtual int ResetSink(unsigned short uiServiceType) override;
	virtual int Activate(unsigned short uiServiceType) override;
	virtual int GetServerID(_serverid_t* pServerId) override;
	virtual int GetServerGroupID(_serverid_t serverID, nmsp::connector::_group_id_t* pServerGroupID) override;
	virtual int GetServerGroupLayer(_serverid_t serverID, nmsp::connector::_group_layer_t* pServerGroupLayer) override;
	virtual int GetAllServerIDs(int* pulLen, _serverid_t** ppuiServerIDs) override;
	virtual int ResetAllServerIDs(_serverid_t* puiServerIDs) override;
	virtual int GetAllServerIDsByServiceType(unsigned short uiServiceType, int* pulLen, _serverid_t** ppuiServerIDs) override;
	virtual int GetAllServerIDsByServiceTypeAndGroupID(unsigned short uiServiceType, nmsp::connector::_group_id_t groupID, int* pulLen, _serverid_t** ppuiServerIDs) override;
	virtual int ResetAllServerIDsByServiceType(_serverid_t* puiServerIDs) override;
	virtual int IsServiceInServer(nmsp::connector::_serverid_t serverId, unsigned short uiServiceType, bool* pbIs) override;
	virtual int GetServerIdCount(int* pnServerIdCount) override;
	virtual int GetServiceTypeCount(nmsp::connector::_serverid_t serverId, int* pnServiceTypeCount) override;
	virtual int IsOnline(nmsp::connector::_serverid_t serverId, unsigned short uiServiceType, bool* pbIsOnline) override;
	virtual int NotifyMessage(nmsp::connector::_serverid_t toServerId, unsigned short toServiceType, unsigned short fromServiceType, int nOption, int nLen, const unsigned char* pbyData) override;
	virtual int NotifyMessage(nmsp::connector::_serverid_t toServerId, unsigned short toServiceType, unsigned short fromServiceType, int nOption, int nLen, const unsigned char* pbyData, int nLen2, const unsigned char* pbyData2) override;
	virtual int NotifyPost(_serverid_t toServerId, int nOption, int nLen, const unsigned char* pchData) override;
	virtual int SetTimer(int id, int milisec) override;
	virtual int ResetTimer(int id) override;
	virtual int GetConnectorMessage(nmsp::connector::IConnectorMessage** piConnectorMessage) override;
	virtual int NotifyMessage(_serverid_t toServerId, unsigned short toServiceType, unsigned short fromServiceType, int nOption, nmsp::connector::IConnectorMessage* piConnectorMessage) override;

	// -------
	// 패킷의 조합에 필요한것임
	virtual bool Assemble(int nPktLen, int nMaxHdLen, int* pnLen, unsigned char* pchHd) override;
	virtual bool Disassemble(int nIndex, int nIdentity, int nLen, const unsigned char* pchData, int* pnTotalLen, int* pnHdLen, int* pnDataLen) override;
	// 타이머 핸들러
	virtual void OnTimer(int nId, const boost::system::error_code& error);
	// TCP 통신 핸들러
	virtual void OnAccepted(int nIndex, int nIdentity, _session_t* pcSess) override;
	virtual void OnConnected(int nIndex, int nIdentity, _session_t* pcSess) override;
	virtual void OnClosed(int nIndex, int nIdentity, _session_t* pcSess) override;
	virtual void OnReceived(int nIndex, int nIdentity, int nLen, const unsigned char* pchData, _session_t* pcSess) override;
	virtual void OnSent(int nIndex, int nIdentity, int nSentBytes, _session_t* pcSess) override;
	virtual void OnPosted(int nIndex, int nIdentity, int nOption, int nLen, const unsigned char* pchData, _session_t* pcSess) override;
	// 에러 로그 핸들러
	virtual void OnError(const boost::system::error_code& error) override;
	virtual void OnError(int32_t index, int32_t identify, const boost::system::error_code& error) override;
	virtual void OnError(const std::exception& error) override;
	virtual void OnError(const char* pszError) override;

	// peer간/Coordinator간의 통신에 사용하는 패킷 핸들러들
	void MSG_C2CD_REQ_REG(const nmsp::connector::message::ConnectorPkt*, __super_t::_session_t*, flatbuffers::uoffset_t nextLen, const unsigned char* pbyNext);
	void MSG_CD2C_RES_REG(const nmsp::connector::message::ConnectorPkt*, __super_t::_session_t*, flatbuffers::uoffset_t nextLen, const unsigned char* pbyNext);
	void MSG_C2CD_REQ_UNREG(const nmsp::connector::message::ConnectorPkt*, __super_t::_session_t*, flatbuffers::uoffset_t nextLen, const unsigned char* pbyNext);
	void MSG_CD2C_NOTI_SERVER(const nmsp::connector::message::ConnectorPkt*, __super_t::_session_t*, flatbuffers::uoffset_t nextLen, const unsigned char* pbyNext);
	void MSG_C2CD_REQ_LIST(const nmsp::connector::message::ConnectorPkt*, __super_t::_session_t*, flatbuffers::uoffset_t nextLen, const unsigned char* pbyNext);
	void MSG_CD2C_RES_LIST(const nmsp::connector::message::ConnectorPkt*, __super_t::_session_t*, flatbuffers::uoffset_t nextLen, const unsigned char* pbyNext);
	void MSG_C2C_REQ_REG(const nmsp::connector::message::ConnectorPkt*, __super_t::_session_t*, flatbuffers::uoffset_t nextLen, const unsigned char* pbyNext);
	void MSG_C2C_RES_REG(const nmsp::connector::message::ConnectorPkt*, __super_t::_session_t*, flatbuffers::uoffset_t nextLen, const unsigned char* pbyNext);
	void MSG_C2C_REQ_UNREG(const nmsp::connector::message::ConnectorPkt*, __super_t::_session_t*, flatbuffers::uoffset_t nextLen, const unsigned char* pbyNext);
	void MSG_C2C_RES_UNREG(const nmsp::connector::message::ConnectorPkt*, __super_t::_session_t*, flatbuffers::uoffset_t nextLen, const unsigned char* pbyNext);
	void MSG_C2C_NOTI_ACTIVATION(const nmsp::connector::message::ConnectorPkt* pPkt, __super_t::_session_t* pcSess, flatbuffers::uoffset_t nextLen, const unsigned char* pbyNext);
	void MSG_C2C_DATA(const nmsp::connector::message::ConnectorPkt*, __super_t::_session_t*, flatbuffers::uoffset_t nextLen, const unsigned char* pbyNext);

	// 옵션을 설정하자
	void SetTcpOption(connector_session& sess);
	// wrapping이 필요하다
	template <typename T> bool MakeMSG_C2C_DATA(unsigned short toServiceType, unsigned short fromServiceType, int nOption, T& _t);

private:
	bool connector_impl::InitCoordinator();
	bool connector_impl::InitCoordinator(const std::string& cCoordinatorAddress, unsigned short uiPort);
	bool Process_SERVER_INFO(_serverid_t selfserverid, const flatbuffers::Vector<flatbuffers::Offset<nmsp::connector::message::SERVER_INFO>>* servers);
	bool Process_SERVER_INFO(_serverid_t selfserverid, const nmsp::connector::message::SERVER_INFO* server);

private:
	bool m_isCoordinator;
	_servicetype_vec_t m_vecServiceTypes; // 내가 보유한 전체 서비스 정보
	_servicetype_vec_t m_vecActiveServiceTypes; // 내가 보유한 서비스 정보 중 활성화된 서비스 정보
	_serverid_t m_serverid;
	_serverid2serviceinfo_map_t m_severid2serv;
	_sess2serverinfo_t m_sess2serverinfo;
	_sinks_t m_sinks;

private:
	_flatbuffer_allocator_t m_flatbufferallocator;
	connector_component_impl* m_pcComponentImpl;
	static _packet_func_t m_pktFunc;
};

#endif
