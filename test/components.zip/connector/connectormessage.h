////////////////////////////////////////////////////////////////////////////////
// �ۼ���: huelee
// ��  ��:
//
//

// ȣȯ���� ���ؼ�..
#pragma once
#ifndef __CONNECTORMESSAGE_H__
#define __CONNECTORMESSAGE_H__

template <typename ALLOC>
class ScopedBuffer : private boost::noncopyable
{
public:
	using _allocator_t = ALLOC;

	ScopedBuffer()
		: m_pointer(nullptr)
	{
	}

	explicit ScopedBuffer(size_t length)
		: m_pointer(nullptr)
	{
		Resize(length);
	}

	~ScopedBuffer()
	{
		if (Available() == true)
		{
			_allocator_t::DestroyMemory(m_pointer);
			m_pointer = nullptr;
		}
	}

	void Resize(size_t length)
	{
		if (Available() == true)
		{
			_allocator_t::DestroyMemory(m_pointer);
			m_pointer = nullptr;
		}

		m_pointer = _allocator_t::CreateMemory(static_cast<int32_t>(length));
	}

	uint8_t* Data()
	{
		if (Available() == false)
			return nullptr;

		return reinterpret_cast<uint8_t*>(m_pointer);
	}

	bool Available()
	{
		return m_pointer != nullptr;
	}

private:
	void* m_pointer;
};

// �޽����� �ѹ��� ������ �� �ֵ��� �ϱ� ����..
template <class ALLOC>
class connector_message_impl: public nmsp::connector::IConnectorMessage, public nmsp::new_from_pool<ALLOC>
{
	enum 
	{
		mesage_prefix_length = 0,
		mesage_prefix_wrapper = 1,
		mesage_prefix_count = 2,
	};
public:
	using  _allocator_t = ALLOC;
	using __this_t = connector_message_impl<_allocator_t>;
	using _len_vec_t = std::vector<int, nmsp::stl_default_allocator<int, _allocator_t>>;
	using _data_vec_t = std::vector<unsigned char*, nmsp::stl_default_allocator<unsigned char*, _allocator_t>>;

public:
	connector_message_impl(connector_component_impl* pcComponentImpl)
		: m_pcComponentImpl(pcComponentImpl)
	{
		m_nRefs = 1;
		m_nTotal = 0;
		m_toServiceType = 0;
		m_fromServiceType = 0;
		m_nOption = 0;
	}
	virtual ~connector_message_impl()
	{
		for (auto& itr : m_vecData)
		{
			if (nullptr != itr)
				_allocator_t::DestroyMemory(itr);			
		}
	}
	virtual int AddRef(void) override
	{
		return ++m_nRefs;
	}
	virtual int Release(void) override
	{
		int nRefs = --m_nRefs;
		if (0 == nRefs)
		{
			delete this;
			return 0;
		}

		return nRefs;
	}
	virtual int Put(int nLen, const unsigned char* pchData) override
	{
		std::lock_guard<std::mutex> cLk(m_lock);

		// ������ ��Ŷ�� �����Ѵ�
		unsigned char* pClone = reinterpret_cast<unsigned char*>(_allocator_t::CreateMemory(nLen));
		if (nullptr == pClone)
			return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_MEMORY);

		memcpy(pClone, pchData, nLen);
		m_nTotal += nLen;

		// ó���� ���� ����� �ִ´�
		if (m_vecLen.empty())
		{
			m_vecLen.push_back(0);					// �̰� ��� ����
			m_vecData.push_back(nullptr);			// �̰� ��� ������
			m_vecLen.push_back(0);					// �̰� wrapper ����
			m_vecData.push_back(nullptr);			// �̰� wrapper ������
		}

		// ������ �����͸� �ִ´�.
		m_vecLen.push_back(nLen);
		m_vecData.push_back(pClone);

		return nmsp::_NMSP_NOERROR;
	}
	virtual int Merge(nmsp::connector::IConnectorMessage* pOtherMessage) override
	{
		auto messages = static_cast<__this_t*>(pOtherMessage);

		std::lock_guard<std::mutex> cLk(m_lock);
		std::lock_guard<std::mutex> cLkOther(messages->m_lock);

		if (true == messages->m_vecLen.empty() || messages->m_vecLen.size() < mesage_prefix_count)
			return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_INVALID_MESSAGE);

		this->m_vecLen.insert(this->m_vecLen.end(), messages->m_vecLen.begin() + mesage_prefix_count, messages->m_vecLen.end());
		this->m_vecData.insert(this->m_vecData.end(), messages->m_vecData.begin() + mesage_prefix_count, messages->m_vecData.end());
		this->m_nTotal += (messages->m_nTotal - (messages->m_vecLen[mesage_prefix_length] + messages->m_vecLen[mesage_prefix_wrapper]));
		
		messages->m_nTotal = 0;
		messages->m_vecLen.clear();
		messages->m_vecData.clear();

		return nmsp::_NMSP_NOERROR;
	}
	template <class T>
	bool Reset(T& _t)
	{
		std::lock_guard<std::mutex> cLk(m_lock);

		// ����ְų� �̹� �������Ŷ��..
		if (m_vecData.empty() || nullptr != m_vecData[mesage_prefix_length])
			return false;

		_len_vec_t vecLen;
		_data_vec_t vecData;

		vecLen.push_back(0);
		vecData.push_back(nullptr);

		vecLen.push_back(0);
		vecData.push_back(nullptr);

		// Wrapping�� �ؾ� �ϹǷ�...
		{
			auto wrap = [this, &vecLen, &vecData](unsigned char* pbykt, int nLen) -> bool {
				unsigned char* pWrapPkt = reinterpret_cast<unsigned char*>(_allocator_t::CreateMemory(nLen));
				if (nullptr == pWrapPkt)
					return false;

				memcpy(pWrapPkt, pbykt, nLen);

				vecLen[mesage_prefix_wrapper] = nLen;
				vecData[mesage_prefix_wrapper] = pWrapPkt;
				m_nTotal += nLen;
				return true;
			};

			if (false == static_cast<connector_impl&>(*m_pcComponentImpl).MakeMSG_C2C_DATA<decltype(wrap)>(m_toServiceType, m_fromServiceType, m_nOption, wrap))
				return false;
		}

		size_t compressedLength = 0;
		int32_t totalLength = m_nTotal;

		// ���� �����Ͱ� ���� ��� ������ ������..(�׽�Ʈ..�ڵ�..)
		if (m_vecLen.size() > mesage_prefix_count)
		{
			ScopedBuffer<_allocator_t> tmp(m_nTotal);
			if (tmp.Available() == false)
				return false;

			// ���� �Ҵ��� ���ۿ� ��� �����͸� ����!!
			int32_t offset = 0;
			for (_len_vec_t::size_type i = mesage_prefix_count; i < m_vecLen.size(); ++i)
			{
				memcpy(tmp.Data() + offset, m_vecData[i], m_vecLen[i]);
				offset += m_vecLen[i];

				// ���� �� ��� ��ȯ!
				_allocator_t::DestroyMemory(m_vecData[i]);
			}

			compressedLength = snappy::MaxCompressedLength(totalLength);
			unsigned char* compressBuffer = reinterpret_cast<unsigned char*>(_allocator_t::CreateMemory(static_cast<int32_t>(compressedLength)));
			if (nullptr == compressBuffer)
				return false;
						
			snappy::RawCompress(reinterpret_cast<const char*>(tmp.Data()), offset, reinterpret_cast<char*>(compressBuffer), &compressedLength);

			vecLen.push_back(static_cast<_len_vec_t::value_type>(compressedLength));
			vecData.push_back(compressBuffer);

			totalLength = vecLen[mesage_prefix_wrapper] + static_cast<int32_t>(compressedLength);
		}

		//
		{
			int nLenHd;
			unsigned char achHead[connector_session::MAX_HD_SIZE];

			if (false == static_cast<connector_impl&>(*m_pcComponentImpl).Assemble(totalLength, sizeof(achHead), &nLenHd, achHead))
				return false;

			unsigned char* pHead = reinterpret_cast<unsigned char*>(_allocator_t::CreateMemory(nLenHd));
			if (nullptr == pHead)
				return false;

			memcpy(pHead, achHead, nLenHd);

			// header�� �־���
			vecLen[mesage_prefix_length] = nLenHd;
			vecData[mesage_prefix_length] = pHead;
		}

		///
		for (_len_vec_t::size_type sL = 0; sL < vecLen.size(); ++sL)
			_t(vecData[sL], vecLen[sL]);

		m_vecLen.clear();
		m_vecData.clear();
		m_nTotal = 0;
		
		return true;
	}
	template <class T>
	bool LoopbackReset(T& _t)
	{
		unsigned char* pTotal = nullptr;
		int nTotal = 0;

		// ������
		{
			std::lock_guard<std::mutex> cLk(m_lock);

			// ����ְų� �̹� �������Ŷ��..
			if (m_vecData.empty())
				return false;

			nTotal = m_nTotal;

			pTotal = reinterpret_cast<unsigned char*>(_allocator_t::CreateMemory(m_nTotal));
			if (nullptr == pTotal)
				return false;

			unsigned char* pCurr = pTotal;
			int nLenCurr = 0;

			for (_len_vec_t::size_type sL = mesage_prefix_count; sL < m_vecLen.size(); ++sL)
			{
				int nTmp = m_vecLen[sL];
				unsigned char* pTmp = m_vecData[sL];

				if (nLenCurr + nTmp > m_nTotal)
				{
					_allocator_t::DestroyMemory(pTotal);
					return false;
				}

				memcpy(pCurr, pTmp, nTmp);

				nLenCurr += nTmp;
				pCurr += nTmp;

				_allocator_t::DestroyMemory(pTmp);
				m_vecData[sL] = nullptr;
			}

			m_vecLen.clear();
			m_vecData.clear();
		}

		_t(pTotal, m_nTotal);

		_allocator_t::DestroyMemory(pTotal);

		m_nTotal = 0;
		
		return true;
	}
	inline int Total() const
	{
		return m_nTotal;
	}

	virtual int Count() override
	{
		return static_cast<int32_t>(m_vecLen.size());
	}

	inline void SetInfo(unsigned short toServiceType, unsigned short fromServiceType, int nOption)
	{
		m_toServiceType = toServiceType;
		m_fromServiceType = fromServiceType;
		m_nOption = nOption;
	}

private:
	std::atomic_int m_nRefs;
	std::mutex m_lock;
	int m_nTotal;
	int m_nCount;
	_len_vec_t m_vecLen;
	_data_vec_t m_vecData;
	connector_component_impl* m_pcComponentImpl;

	unsigned short m_toServiceType;
	unsigned short m_fromServiceType;
	int m_nOption;
};

#endif
