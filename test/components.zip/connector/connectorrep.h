﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __CONNECTORREP_H__
#define __CONNECTORREP_H__

// 
// 서버의 정보들을 저장하는데 사용하는..
//
class connector_repository_ctrl
{
public:
	class _server_info_t
	{
	public:
		explicit _server_info_t(nmsp::connector::_group_id_t groupID, nmsp::connector::group_layer groupLayer, const unsigned short& service_type, const std::string& cstrAddress, unsigned short uiPort)
		{
			m_groupID = groupID;
			m_groupLayer = groupLayer;
			m_service_type = service_type;
			m_cstrAddress = cstrAddress;
			m_uiPort = uiPort;
		}
		inline const std::string& GetAddress() const
		{
			return m_cstrAddress;
		}
		inline unsigned short GetPort()
		{
			return m_uiPort;
		}
		inline nmsp::connector::_group_id_t GetGroupID()
		{
			return m_groupID;
		}
		inline nmsp::connector::group_layer GetGroupLayer()
		{
			return m_groupLayer;
		}
		inline unsigned short GetServiceType()
		{
			return m_service_type;
		}

		inline bool operator < (const _server_info_t& _server)
		{
			if (m_cstrAddress < _server.m_cstrAddress)
				return true;
			else
				if (m_cstrAddress == _server.m_cstrAddress)
				{
					if (m_uiPort < _server.m_uiPort)
						return true;
				}

			return false;
		}

	private:
		nmsp::connector::_group_id_t m_groupID;
		nmsp::connector::group_layer m_groupLayer;
		unsigned short m_service_type;
		std::string m_cstrAddress;
		unsigned short m_uiPort;
	};
	using _shared_server_info_t = std::shared_ptr<_server_info_t>;
	using _serverid2addr_t = std::map<nmsp::connector::_serverid_t, _shared_server_info_t>;
	struct _less_t
	{
		inline bool operator()(const _shared_server_info_t& _Left, const _shared_server_info_t& _Right) const
		{
			return *_Left < *_Right;
		}
	};
	using _addr2serverid_t = std::map<_shared_server_info_t, nmsp::connector::_serverid_t, _less_t>;

	// region 내에 한개만 존재해야하는 서비스 타입의 검증에 사용한다.
	using _set_service_type_t = std::set<nmsp::connector::_serverid_t>;
	using _region_one_service_type_t = std::map<unsigned short, _set_service_type_t>;

public:
	connector_repository_ctrl(connector_component_impl* pcComponentImpl);
	virtual ~connector_repository_ctrl();

	// 전체 서버 정보를 로딩한다
	bool Load(const std::string& path);
	// 서버 정보를 저장한다.
	bool Save();
	// 기존에 서버 정보가 있었다면 Update하고 없었다면 추가한다.
	bool AddOrUpdate(nmsp::connector::_serverid_t& id, const nmsp::connector::_group_id_t& groupID, const nmsp::connector::group_layer& groupLayer, const unsigned short& service_type, const std::string& address, unsigned short uiPort);
	// ACTIVE서버 정보 하나를 지운다.
	bool Del(nmsp::connector::_serverid_t id);
	// ACTIVE서버의 목록을 모두
	void Get(_serverid2addr_t& servers);
	// 존재하는지만 확인해 본다
	bool Is(nmsp::connector::_serverid_t id, const std::string& address, unsigned short uiPort);

private:
	nmsp::connector::_serverid_t AllocateServerId();

private:
	std::shared_mutex m_cLock;
	std::string m_cstrPath;
	_serverid2addr_t m_cSid2addr;
	_serverid2addr_t m_cActiveSid2addr;
	_addr2serverid_t m_cAddr2sid;
	_region_one_service_type_t m_region_one_service_type;
	connector_component_impl* m_pcComponentImpl;
	nmsp::connector::_serverid_t m_uiServerIdSeq;
	bool m_bSaveFlag;
};

#endif
