﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 가능하면 이것 하나로..
#include "connectorbase.h"

connector_repository_ctrl::connector_repository_ctrl(connector_component_impl* pcComponentImpl)
	: m_pcComponentImpl(pcComponentImpl)
{
	m_uiServerIdSeq = nmsp::connector::SERVERID_NULL;
}

connector_repository_ctrl::~connector_repository_ctrl()
{
}

// 전체 서버 정보를 로딩한다
bool connector_repository_ctrl::Load(const std::string& path)
{
	std::unique_lock<std::shared_mutex> cLk(m_cLock);

	try
	{
		boost::property_tree::ptree props;
		boost::property_tree::read_json(path, props);
		auto seq = props.get<nmsp::connector::_serverid_t>("current sequance number", 0);

		nmsp::connector::_serverid_t maxSeq = 0;

		auto servers = props.get_child("servers");
		for (const auto& component : servers)
		{
			auto id = component.second.get<nmsp::connector::_serverid_t>("server id");
			auto address = component.second.get<std::string>("address");
			auto port = component.second.get<unsigned short>("port");
			auto groupID = component.second.get<nmsp::connector::_group_id_t>("group id");
			auto groupLayer = static_cast<nmsp::connector::group_layer>(component.second.get<int32_t>("group layer"));
			auto enabled = (1 == component.second.get<int32_t>("enabled", 1)) ? true : false;

			if (enabled)
			{
				auto serverinfo = std::make_shared<_server_info_t>(groupID, groupLayer, std::numeric_limits<unsigned short>::max(), address, port);

				auto pairS2A = m_cSid2addr.insert(_serverid2addr_t::value_type(id, serverinfo));
				if (false == pairS2A.second)
				{
					LOG_ERROR(m_pcComponentImpl) << "connector_repository_ctrl :: Load :: invalid serverid :: " << id;
					return false;
				}

				auto pairA2S = m_cAddr2sid.insert(_addr2serverid_t::value_type(serverinfo, id));
				if (false == pairA2S.second)
				{
					LOG_ERROR(m_pcComponentImpl) << "connector_repository_ctrl :: Load :: invalid serverinfo :: " << id << ',' << address << ',' << port;
					return false;
				}
			}

			if (nmsp::connector::SERVERID_NULL == id)
			{
				LOG_ERROR(m_pcComponentImpl) << "connector_repository_ctrl :: Load :: invalid serverid";
				return false;
			}

			//
			if (maxSeq < id)
				maxSeq = id;
		}

		m_uiServerIdSeq = seq;
		if (0 >= m_uiServerIdSeq)
			m_uiServerIdSeq = maxSeq;
		
		m_cstrPath = path;
		m_bSaveFlag = false;
	}
	catch (const std::exception& e)
	{
		LOG_ERROR(m_pcComponentImpl) << "connector_repository_ctrl :: load :: " << e.what();
		return false;
	}

	return true;
}

// 서버 정보를 저장한다.
bool connector_repository_ctrl::Save()
{
	std::unique_lock<std::shared_mutex> cLk(m_cLock);

	// 저장할게 없으면 그냥 true리턴한다
	if (false == m_bSaveFlag)
		return true;

	// 저장할게 있다면 저장을..
	try
	{
		boost::property_tree::ptree props;
		boost::property_tree::ptree servers;

		for_each(m_cSid2addr.begin(), m_cSid2addr.end(), [&servers](const _serverid2addr_t::value_type& v) {
			boost::property_tree::ptree server;

			server.put("server id", v.first);
			server.put("group id", v.second->GetGroupID());
			server.put("group layer", static_cast<int32_t>(v.second->GetGroupLayer()));
			server.put("address", v.second->GetAddress());
			server.put("port", v.second->GetPort());

			servers.push_back(std::make_pair("", server));
		});

		props.add_child("servers", servers);
		props.add("current sequance number", m_uiServerIdSeq);
		
		// 기존에 뭔가 존재했다면.. backup파일로 만든다..
		std::string backup = m_cstrPath + ".bak";
		std::remove(backup.c_str());
		std::rename(m_cstrPath.c_str(), backup.c_str());

		// 저장한다..
		boost::property_tree::write_json(m_cstrPath, props);

		//
		m_bSaveFlag = false;
	}
	catch (const std::exception& e)
	{
		LOG_ERROR(m_pcComponentImpl) << "connector_repository_ctrl :: save :: " << e.what();
	}

	return true;
}

// 기존에 서버 정보가 있었다면 Update하고 없었다면 추가한다.
bool connector_repository_ctrl::AddOrUpdate(nmsp::connector::_serverid_t& id, const nmsp::connector::_group_id_t& groupID, const nmsp::connector::group_layer& groupLayer, const unsigned short& service_type, const std::string& address, unsigned short uiPort)
{
	auto itr_service = m_region_one_service_type.find(service_type);
	if (itr_service == m_region_one_service_type.end())
	{
		auto pair = m_region_one_service_type.emplace(service_type, std::move(_set_service_type_t()));
		itr_service = pair.first;
	}
	else
	{
		// region 내에 한개만 실행 되어야 하는 service type 에 대한 검증.
		if (nmsp::IsReginOneServicetype(static_cast<nmsp::_USER_DEFINED_SERVICETYPE_T>(service_type)) == true)
			return false;
	}

	auto serverinfo = std::make_shared<_server_info_t>(groupID, groupLayer, service_type, address, uiPort);

	// Lock
	std::unique_lock<std::shared_mutex> cLk(m_cLock);
	{
		// 존재하는 경우의 오류처리
		{
			auto itrA2S = m_cAddr2sid.find(serverinfo);
			if (itrA2S != m_cAddr2sid.end())
			{
				auto itrS2A = m_cSid2addr.find(itrA2S->second);
				if (itrS2A == m_cSid2addr.end())
				{
					LOG_ERROR(m_pcComponentImpl) << "connector_repository_ctrl :: no serverid :: " << address << ',' << uiPort;
					return false;							// 이런 경우는 나올수 없다
				}

				//
				auto itrAS2A = m_cActiveSid2addr.find(itrA2S->second);
				if (itrAS2A != m_cActiveSid2addr.end())
				{
					id = itrA2S->second;
					return true;
				}

				auto pairRetAS2A = m_cActiveSid2addr.insert(_serverid2addr_t::value_type(itrA2S->second, itrA2S->first));
				if (false == pairRetAS2A.second)
				{
					LOG_ERROR(m_pcComponentImpl) << "connector_repository_ctrl :: no serverid :: " << address << ',' << uiPort;
					return false;							// 이런 경우는 나올수 없다
				}

				id = itrA2S->second;
				return true;
			}
		}

		// 더이상 할당할 수 없다
		if (m_cSid2addr.size() == std::numeric_limits<nmsp::connector::_serverid_t>::max())
			return false;

		// 새로 할당한다
		nmsp::connector::_serverid_t newserverid = nmsp::connector::SERVERID_NULL;

		for (int nI = 0; nI < std::numeric_limits<nmsp::connector::_serverid_t>::max(); ++nI)
		{
			auto tmp = AllocateServerId();
			auto itrS2A = m_cSid2addr.find(tmp);
			if (itrS2A == m_cSid2addr.end())
			{
				newserverid = tmp;
				break;
			}
		}

		if (nmsp::connector::SERVERID_NULL == newserverid)
		{
			LOG_ERROR(m_pcComponentImpl) << "connector_repository_ctrl :: serverid allocation error";
			return false;
		}

		//  신규처리
		{
			auto itr_id = itr_service->second.find(id);
			if (itr_id != itr_service->second.end())
				return false;
			itr_service->second.emplace(id);

			auto pairRetS2A = m_cSid2addr.insert(_serverid2addr_t::value_type(newserverid, serverinfo));
			if (false == pairRetS2A.second)
				return false;

			auto pairRetA2S = m_cAddr2sid.insert(_addr2serverid_t::value_type(serverinfo, newserverid));
			if (false == pairRetA2S.second)
			{
				m_cSid2addr.erase(pairRetS2A.first);
				return false;
			}

			auto pairRetAS2A = m_cActiveSid2addr.insert(_serverid2addr_t::value_type(newserverid, serverinfo));
			if (false == pairRetAS2A.second)
			{
				m_cSid2addr.erase(pairRetS2A.first);
				m_cAddr2sid.erase(pairRetA2S.first);
				return false;
			}
		}

		id = newserverid;
		m_bSaveFlag = true;
	}

	return true;
}

// 서버 정보 하나를 지운다.
bool connector_repository_ctrl::Del(nmsp::connector::_serverid_t id)
{
	std::unique_lock<std::shared_mutex> cLk(m_cLock);

	auto itrS2A = m_cSid2addr.find(id);
	if (itrS2A == m_cSid2addr.end())
		return false;

	auto itr_service = m_region_one_service_type.find(itrS2A->second->GetServiceType());
	if (itr_service != m_region_one_service_type.end())
	{
		auto itr_id = itr_service->second.find(id);
		if (itr_id != itr_service->second.end())
			itr_service->second.erase(itr_id);
	}

	m_cActiveSid2addr.erase(id);

	return true;
}

void connector_repository_ctrl::Get(_serverid2addr_t& servers)
{
	std::shared_lock<std::shared_mutex> cLk(m_cLock);

	servers = m_cActiveSid2addr;
}

bool connector_repository_ctrl::Is(nmsp::connector::_serverid_t id, const std::string& address, unsigned short uiPort)
{
	std::shared_lock<std::shared_mutex> cLk(m_cLock);

	auto server = m_cSid2addr.find(id);
	if (server != m_cSid2addr.end())
		return false;

	if (address != server->second->GetAddress())
		return false;

	if (uiPort != server->second->GetPort())
		return false;

	return true;
}

nmsp::connector::_serverid_t connector_repository_ctrl::AllocateServerId()
{
	nmsp::connector::_serverid_t serverid = nmsp::connector::SERVERID_NULL;

	for (int nI = 0; nI < 2; ++nI)
	{
		serverid = ++m_uiServerIdSeq;

		if (nmsp::connector::SERVERID_NULL == serverid)
			continue;

		break;
	}

	return serverid;
}
