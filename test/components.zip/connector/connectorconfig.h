////////////////////////////////////////////////////////////////////////////////
// �ۼ���: huelee
// ��  ��:
//
//

// ȣȯ���� ���ؼ�..
#pragma once
#ifndef __CONNECTORCONFIG_H__
#define __CONNECTORCONFIG_H__

// ���������� �д´�.
class connector_config
{
	enum
	{
		SERVER_LISTENPORT			= 30001,				// PORT
		COORDINATOR_LISTENPORT		= 30002,				// PORT
		THREADCOUNT					= 1,					// ASIO �������� ����
		MAXACCEPTSESSION			= 10,					// ���� ��� ��
		MSS							= 10240,				// Maximum segment size
		BUFFER_SIZE					= 20480,				// receive/send buffer
		KEEPALIVE_PERIOD			= 5,					// �ʴ��� (0�̸� OFF, ���� ������ ���)
#ifdef _DEBUG
		POOL_INIT_COUNT				= 1,
		POOL_EXT_COUNT				= 1,
#else
		POOL_INIT_COUNT				= 1000,
		POOL_EXT_COUNT				= 1000,
#endif
		NORMAL_PACKET_SIZE			= 102400,
		CONNECTION_CHECK_PERIOD		= 5,
	};

public:
	connector_config(connector_component_impl* pcComponentImpl);
	virtual ~connector_config();

	bool Load(const char* pszConfig);

public:
	inline bool IsCoordinator() const
	{
		return m_bCoordinator;
	}
	inline unsigned short GetServerListenPort() const 
	{ 
		return m_uiServerListenPort; 
	}
	inline unsigned short GetCoordinatorListenPort() const
	{
		return m_uiCoordinatorListenPort;
	}
	inline char GetThreadCount() const
	{ 
		return m_byThreadCount; 
	}
	inline int GetMaxAcceptSession() const 
	{ 
		return m_nMaxAcceptSession; 
	}
	inline int GetMss() const 
	{ 
		return m_nMss; 
	}
	inline int GetBufferSize() const
	{
		return m_nBufferSize;
	}
	inline bool GetNagle() const
	{ 
		return m_bNagle; 
	}
	inline int GetKeepAlivePeriod() const
	{
		return m_nKeepAliveTime;
	}
	inline const std::string& GetRep() const
	{
		return m_cRep;
	}
	inline int GetInitPoolCount() const
	{
		return m_nInitPoolCount;
	}
	inline int GetExtPoolCount() const
	{
		return m_nExtPoolCount;
	}
	inline int GetNormalPacketSize() const
	{
		return m_nNormalPacketSize;
	}
	inline const std::string& GetServerAddress() const
	{
		return m_cServerAddress;
	}
	inline const std::string& GetCoordinatorAddress() const
	{
		return m_cCoordinatorAddress;
	}
	inline bool GetReuse() const
	{
		return m_bReuse;
	}
	inline int GetConnectionCheckPeriod() const
	{
		return m_nConnectionCheckPeriod;
	}
	inline int GetGroupID() const 
	{ 
		return m_groupID; 
	}
	inline int GetGroupLayer() const
	{
		return m_groupLayer; 
	}

private:
	bool m_bCoordinator;
	unsigned short m_uiServerListenPort;
	unsigned short m_uiCoordinatorListenPort;

	int32_t m_groupID;
	int32_t m_groupLayer;

	char m_byThreadCount;
	int m_nMaxAcceptSession;
	int m_nMss;
	int m_nBufferSize;
	bool m_bNagle;
	int m_nKeepAliveTime;
	int m_nInitPoolCount;
	int m_nExtPoolCount;
	int m_nNormalPacketSize;
	bool m_bReuse;
	int m_nConnectionCheckPeriod;
	std::string m_cRep;
	std::string m_cServerAddress;
	std::string m_cCoordinatorAddress;
	connector_component_impl* m_pcComponentImpl;
};

#endif
