﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 가능하면 이것 하나로..
#include "connectorbase.h"

////////////////////////////////////////////////////////////////////////////////
// session..
bool connector_session::OnAccept(_shared_session_t& sess, std::shared_ptr<boost::asio::ip::tcp::acceptor>& _acceptor, const boost::system::error_code& error)
{
	// 상위
	if (false == __super_t::OnAccept(sess, _acceptor, error))
		return false;

	static_cast<connector_impl&>(__super_t::m_pumpbase).SetTcpOption(*this);
	return true;
}

bool connector_session::OnReceive(_shared_session_t& sess, _shared_read_ctrl_t& read_ctrl, const boost::system::error_code& error, const std::size_t& trans)
{
	if (false == __super_t::OnReceive(sess, read_ctrl, error, trans))
		return false;

	// 여기서 추가로 필요한 것들을 해봅시다
	return true;
}

bool connector_session::OnSend(_shared_session_t& sess, _shared_writevector_t& vecBuff, const boost::system::error_code& error, const std::size_t& trans)
{
	if (false == __super_t::OnSend(sess, vecBuff, error, trans))
		return false;

	// 여기서 추가로 필요한 것들을 해봅시다
	return true;
}

bool connector_session::OnSend2(_shared_session_t& sess, _shared_write_buffer_t& buffer, const boost::system::error_code& error, const std::size_t& trans)
{
	if (false == __super_t::OnSend2(sess, buffer, error, trans))
		return false;

	// 여기서 추가로 필요한 것들을 해봅시다
	return true;
}

bool connector_session::OnClose(_shared_session_t& sess)
{
	if (false == __super_t::OnClose(sess))
		return false;

	// 여기서 추가로 필요한 것들을 해봅시다
	return true;
}

bool connector_session::OnConnect(_shared_session_t& sess, const boost::system::error_code& error)
{
	if (false == __super_t::OnConnect(sess, error))
		return false;

	// 여기서 추가로 필요한 것들을 해봅시다
	static_cast<connector_impl&>(__super_t::m_pumpbase).SetTcpOption(*this);
	return true;
}

void connector_session::SetTcpOption()
{
	// 필요한 옵션을 설정하자!.. Receive / Send Buffer size, keep alive, nagle 등등
}

////////////////////////////////////////////////////////////////////////////////
//
connector_impl::_serverid2serviceinfo_map_t::_serverid2serviceinfo_map_t()
{
}

connector_impl::_serverid2serviceinfo_map_t::~_serverid2serviceinfo_map_t()
{
}

bool connector_impl::_serverid2serviceinfo_map_t::Add(_serverid_t serverid, _session_t* pcSess, const _servicetype_set_t& servs, const _servicetype_set_t& activeServs)
{
	std::unique_lock<std::shared_mutex> cLk(m_cLock);

	const auto pair = m_cContainer.insert(_container_t::value_type(serverid, std::make_tuple(pcSess, servs, activeServs)));
	if (false == pair.second)
		return false;

	return true;
}

void connector_impl::_serverid2serviceinfo_map_t::Activate(_serverid_t serverid, unsigned short serviceType)
{
	std::unique_lock<std::shared_mutex> cLk(m_cLock);

	auto itr = m_cContainer.find(serverid);
	if (itr == m_cContainer.end())
		return;

	std::get<2>(itr->second).insert(serviceType);
}

bool connector_impl::_serverid2serviceinfo_map_t::Del(_serverid_t serverid)
{
	__super_t::_shared_session_t tmp;
	{
		std::unique_lock<std::shared_mutex> cLk(m_cLock);

		auto itr = m_cContainer.find(serverid);
		if (itr == m_cContainer.end())
			return false;

		tmp = std::get<0>(itr->second);

		m_cContainer.erase(itr);
	}
	return true;
}

int connector_impl::_serverid2serviceinfo_map_t::Count()
{
	std::unique_lock<std::shared_mutex> cLk(m_cLock);
	return static_cast<int>(m_cContainer.size());
}

void connector_impl::_serverid2serviceinfo_map_t::Clear()
{
	_container_t tmp;
	{
		std::unique_lock<std::shared_mutex> cLk(m_cLock);

		tmp = m_cContainer;

		m_cContainer.clear();
	}
}

void connector_impl::_serverid2serviceinfo_map_t::GetServiceTypes(const _serverid_t & serverid, _servicetype_set_t & serviceTypes)
{
	std::unique_lock<std::shared_mutex> cLk(m_cLock);

	auto iter = m_cContainer.find(serverid);
	if (iter == m_cContainer.end())
		return;

	_value_t tuple = (iter->second);
	serviceTypes = std::get<1>(tuple);
}

////////////////////////////////////////////////////////////////////////////////
//
connector_impl::_sess2serverinfo_t::_sess2serverinfo_t()
{
}

connector_impl::_sess2serverinfo_t::~_sess2serverinfo_t()
{
}

bool connector_impl::_sess2serverinfo_t::Add(int nIndex, _serverid_t serverid, boost::asio::ip::tcp::endpoint& endpoint_, __super_t::_shared_session_t& sess)
{
	std::unique_lock<std::shared_mutex> cLk(m_cLock);

	// Index가 같은게 존재한다면 오류다
	auto itr = m_cContainer.find(nIndex);
	if (itr != m_cContainer.end())
		return false;

	// 이미 해당 서버를 위한 세션이 등록이 되어 있는가도 검사하자
	const auto itr_serverid = m_cDupCheck.find(serverid);
	if (itr_serverid != m_cDupCheck.end())
		return false;

	// 없다면 insert한다.
	const auto pair = m_cContainer.insert(_container_t::value_type(nIndex, std::make_tuple(endpoint_, sess)));
	if (false == pair.second)
		return false;

	// serverid에 등록이 실패하면 container에 등록된것을 지우고 false리턴한다.
	const auto pairDup = m_cDupCheck.insert(_serverid2sess_t::value_type(serverid, sess));
	if (false == pairDup.second)
	{
		m_cContainer.erase(pair.first);
		return false;
	}

	return true;
}

bool connector_impl::_sess2serverinfo_t::Del(_serverid_t serverid)
{
	//
	_shared_session_t tmp1;
	_shared_session_t tmp2;
	{
		std::unique_lock<std::shared_mutex> cLk(m_cLock);

		auto itrDup = m_cDupCheck.find(serverid);
		if (itrDup == m_cDupCheck.end())
			return false;

		auto itr = m_cContainer.find(static_cast<connector_session*>(static_cast<__super_t::_session_t*>(itrDup->second))->GetIndex());
		if (itr == m_cContainer.end())
			return false;

		tmp1 = std::get<1>(itr->second);
		tmp2 = itrDup->second;

		m_cContainer.erase(itr);
		m_cDupCheck.erase(itrDup);
	}

	return true;
}

bool connector_impl::_sess2serverinfo_t::Is(_serverid_t serverid)
{
	std::shared_lock<std::shared_mutex> cLk(m_cLock);

	auto itr = m_cDupCheck.find(serverid);
	if (itr != m_cDupCheck.end())
		return true;

	return false;
}

void connector_impl::_sess2serverinfo_t::Clear()
{
	_serverid2sess_t tmp1;
	_container_t tmp2;
	{
		std::unique_lock<std::shared_mutex> cLk(m_cLock);

		tmp1 = m_cDupCheck;
		tmp2 = m_cContainer;

		m_cDupCheck.clear();
		m_cContainer.clear();
	}
}

////////////////////////////////////////////////////////////////////////////////
//
connector_impl::_sinks_t::_sinks_t()
{
}

connector_impl::_sinks_t::~_sinks_t()
{
}

bool connector_impl::_sinks_t::Add(unsigned short uiServicetype, nmsp::connector::IConnectorSink* pcSink)
{
	std::unique_lock<std::shared_mutex> cLk(m_cLock);

	const auto pair = m_cContainer.insert(_container_t::value_type(uiServicetype, pcSink));
	if (false == pair.second)
		return false;

	return true;
}

bool connector_impl::_sinks_t::Del(unsigned short uiServicetype)
{
	_shared_sink_t tmp;
	{
		std::unique_lock<std::shared_mutex> cLk(m_cLock);

		auto itr = m_cContainer.find(uiServicetype);
		if (itr == m_cContainer.end())
			return false;

		tmp = itr->second;

		m_cContainer.erase(itr);
	}
	return true;
}

void connector_impl::_sinks_t::Clear()
{
	_container_t tmp;
	{
		std::unique_lock<std::shared_mutex> cLk(m_cLock);

		tmp = m_cContainer;

		m_cContainer.clear();
	}
}

////////////////////////////////////////////////////////////////////////////////
//
connector_impl::_packet_func_t connector_impl::m_pktFunc = 
{
	nullptr,											// ConnectorBodyAll_NONE = 0,
	&connector_impl::MSG_C2CD_REQ_REG,					// ConnectorBodyAll_MSG_C2CD_REQ_REG = 1,
	&connector_impl::MSG_CD2C_RES_REG,					// ConnectorBodyAll_MSG_CD2C_RES_REG = 2,
	&connector_impl::MSG_C2CD_REQ_UNREG,				// ConnectorBodyAll_MSG_C2CD_REQ_UNREG = 3,
	&connector_impl::MSG_CD2C_NOTI_SERVER,				// ConnectorBodyAll_MSG_CD2C_NOTI_SERVER = 4,
	&connector_impl::MSG_C2CD_REQ_LIST,					// ConnectorBodyAll_MSG_C2CD_REQ_LIST = 5,
	&connector_impl::MSG_CD2C_RES_LIST,					// ConnectorBodyAll_MSG_CD2C_RES_LIST = 6,
	&connector_impl::MSG_C2C_REQ_REG,					// ConnectorBodyAll_MSG_C2C_REQ_REG = 7,
	&connector_impl::MSG_C2C_RES_REG,					// ConnectorBodyAll_MSG_C2C_RES_REG = 8,
	&connector_impl::MSG_C2C_REQ_UNREG,					// ConnectorBodyAll_MSG_C2C_REQ_UNREG = 9,
	&connector_impl::MSG_C2C_RES_UNREG,					// ConnectorBodyAll_MSG_C2C_RES_UNREG = 10,
	&connector_impl::MSG_C2C_NOTI_ACTIVATION,			// ConnecotrBodyAll_MSG_C2C_NOTI_ACTIVATION = 11,
	&connector_impl::MSG_C2C_DATA						// ConnectorBodyAll_MSG_C2C_DATA = 12,
};

//
connector_impl::connector_impl(connector_component_impl* pcComponentImpl)
	: m_pcComponentImpl(pcComponentImpl)
{
	m_isCoordinator = true;
	m_serverid = nmsp::connector::SERVERID_NULL;
}

connector_impl::~connector_impl()
{
}

bool connector_impl::InitCoordinator()
{
	m_isCoordinator = true;

	return static_cast<connector_repository_ctrl&>(*m_pcComponentImpl).Load(static_cast<connector_config&>(*m_pcComponentImpl).GetRep());
}

// Coordinator connection을 하도록 하자
bool connector_impl::InitCoordinator(const std::string& cCoordinatorAddress, unsigned short uiPort)
{
	m_isCoordinator = false;

	boost::asio::ip::tcp::endpoint coordinatorEndpoint;
	
	try
	{
		coordinatorEndpoint.address(boost::asio::ip::address::from_string(cCoordinatorAddress));
		coordinatorEndpoint.port(uiPort);
	}
	catch (std::bad_exception& e)
	{
		LOG_ERROR(m_pcComponentImpl) << "InitCoordinator :: " << e.what();
		return false;
	}
	catch (std::exception& e)
	{
		LOG_ERROR(m_pcComponentImpl) << "InitCoordinator :: " << e.what();
		return false;
	}

	int nSlot;
	int nIdentity;
	_shared_session_t sess;

	if (false == __super_t::Allocate(nSlot, nIdentity, sess))
		return false;

	// coordinator클라이언트로 동작하도록..
	static_cast<connector_session*>(static_cast<__super_t::_session_t*>(sess))->SetForSessionType(connector_session::SESSION_TYPE_C2CD_CLIENT);

	// 연결을 시도한다
	if (false == sess->PostConnect(coordinatorEndpoint))
		return false;

	// 연결을 시도하고 나서는 container에 추가한다
	if (false == m_sess2serverinfo.Add(nSlot, nmsp::connector::SERVERID_NULL, coordinatorEndpoint, sess))
		return false;

	return true;
}

bool connector_impl::Assemble(int nPktLen, int nMaxHdLen, int* pnLen, unsigned char* pchHd)
{
	if (HD_SIZE > nMaxHdLen)
	{
		LOG_ERROR(m_pcComponentImpl) << "Assemble error :: " << nMaxHdLen;
		return false;
	}

	// Big Endian으로 맞추자.. 
	*reinterpret_cast<int*>(pchHd) = ::htonl(nPktLen);
	*pnLen = HD_SIZE;

	return true;
}

bool connector_impl::Disassemble(int nIndex, int nIdentity, int nLen, const unsigned char* pchData, int* pnTotalLen, int* pnHdLen, int* pnDataLen)
{
	// 헤더보다 적게 받아졌을때..
	if (HD_SIZE > nLen)
	{
		*pnHdLen = HD_SIZE;
		*pnTotalLen = HD_SIZE;
		*pnDataLen = 0;

		return true;
	}

	// 헤더는 받아졌을때..
	const int nBodySize = ntohl(*reinterpret_cast<const int*>(pchData));

	*pnTotalLen = HD_SIZE + nBodySize;
	*pnHdLen = HD_SIZE;
	*pnDataLen = nBodySize;

	return true;
}

void connector_impl::OnTimer(int nId, const boost::system::error_code& error)
{
	if (IDLE_TIMER_ID == nId)
	{
		// 여기서 주기적으로 상태를 처리하도록 한다..
		m_sess2serverinfo.Exe([](int nIndex, int nIdentity, const boost::asio::ip::tcp::endpoint& endpoint_, __super_t::_shared_session_t& sess) {
			// 연결된 상태라면 그냥 리턴한다
			if (true == static_cast<connector_session*>(static_cast<__super_t::_session_t*>(sess))->IsConn())
				return;

			// 이미 연결 시도 중이라면 그냥 리턴한다
			if (true == static_cast<connector_session*>(static_cast<__super_t::_session_t*>(sess))->IsConnecting())
				return;

			// 어떤 상태도 아니라면 연결을 시도한다
			sess->PostConnect(endpoint_);
		});
	}
	else
	{
		m_sinks.Exe([nId](nmsp::connector::IConnectorSink* pcSink) {
			pcSink->NotifiedTimer(nId);
		});
	}
}

void connector_impl::OnAccepted(int nIndex, int nIdentity, _session_t* pcSess)
{
	// 타입들을.. 설정한다.
	if (true == m_isCoordinator)
		static_cast<connector_session*>(pcSess)->SetForSessionType(connector_session::SESSION_TYPE_C2CD_SERVER);
	else
		static_cast<connector_session*>(pcSess)->SetForSessionType(connector_session::SESSION_TYPE_C2C_SERVER);
}

void connector_impl::OnConnected(int nIndex, int nIdentity, _session_t* pcSess)
{
	auto& config = static_cast<connector_config&>(*m_pcComponentImpl);

	// 일단 접속을 하게 되면 자신의 정보를 리포트한다
	switch (static_cast<connector_session*>(pcSess)->GetForSessionType())
	{
	case connector_session::SESSION_TYPE_C2CD_CLIENT:
		{
			flatbuffers::FlatBufferBuilder fbbReq(FLATBUFFER_INITIAL_SIZE, &m_flatbufferallocator);
			auto _req = nmsp::connector::message::CreateMSG_C2CD_REQ_REG(
				fbbReq,
				config.GetGroupID(),
				config.GetGroupLayer(),
				config.GetServerListenPort(),
				m_pcComponentImpl->GetServiceType()
			);
			auto _pkt = nmsp::connector::message::CreateConnectorPkt(fbbReq, nmsp::connector::message::ConnectorBodyAll::MSG_C2CD_REQ_REG, _req.Union());
			fbbReq.FinishSizePrefixed(_pkt);

			if (false == pcSess->PostSend(fbbReq.GetSize(), fbbReq.GetBufferPointer()))
			{
				pcSess->PostClose();
				return;
			}
		}
		break;
	case connector_session::SESSION_TYPE_C2C_CLIENT:
		{
			flatbuffers::FlatBufferBuilder fbbReq(FLATBUFFER_INITIAL_SIZE, &m_flatbufferallocator);
			auto serviceTypes = fbbReq.CreateVector<unsigned short>(m_vecServiceTypes);
			auto activeServiceTypes = fbbReq.CreateVector<unsigned short>(m_vecActiveServiceTypes);
			auto _req = nmsp::connector::message::CreateMSG_C2C_REQ_REG(
				fbbReq, 
				config.GetGroupID(),
				config.GetGroupLayer(),
				m_serverid, 
				serviceTypes,
				activeServiceTypes);
			auto _pkt = nmsp::connector::message::CreateConnectorPkt(fbbReq, nmsp::connector::message::ConnectorBodyAll::MSG_C2C_REQ_REG, _req.Union());
			fbbReq.FinishSizePrefixed(_pkt);

			if (false == pcSess->PostSend(fbbReq.GetSize(), fbbReq.GetBufferPointer()))
			{
				pcSess->PostClose();
				return;
			}
		}
		break;
	default: break;
	}
}

void connector_impl::OnClosed(int nIndex, int nIdentity, _session_t* pcSess)
{
	if (true == m_isCoordinator)
	{
		// serverid를 확인하여 지워준다
		if (nmsp::connector::SERVERID_NULL != static_cast<connector_session*>(pcSess)->GetServerId())
			m_severid2serv.Del(static_cast<connector_session*>(pcSess)->GetServerId());
	}
	else
	{
		bool bNoti = false;

		// 아래에서 m_severid2serv에서 지우기 전에 service type을 확인한다.
		_servicetype_set_t serviceTypes;
		m_severid2serv.GetServiceTypes(static_cast<connector_session*>(pcSess)->GetServerId(), serviceTypes);

		// serverid를 확인하여 지워준다
		if (nmsp::connector::SERVERID_NULL != static_cast<connector_session*>(pcSess)->GetServerId())
			bNoti = m_severid2serv.Del(static_cast<connector_session*>(pcSess)->GetServerId());

		// 논리 연결 설정을 끊는다.
		static_cast<connector_session*>(pcSess)->SetLink(false);

		// 컴포넌트들에게도 오프라인이 된 것을 알려준다
		if (true == bNoti)
		{
			_servicetype_vec_t servs_vec;
			servs_vec.reserve(serviceTypes.size());
			servs_vec.assign(serviceTypes.begin(), serviceTypes.end());

			m_sinks.Exe([&pcSess, &servs_vec](nmsp::connector::IConnectorSink* pcSink) {
				pcSink->NotifiedOffLineService(static_cast<connector_session*>(pcSess)->GetServerId(),
					static_cast<int>(servs_vec.size()),
					servs_vec.data());
			});
		}
	}
}

void connector_impl::OnReceived(int nIndex, int nIdentity, int nLen, const unsigned char* pchData, _session_t* pcSess)
{
	// 길이 데이터가 오는가 ?
	if (nLen < sizeof(flatbuffers::uoffset_t))
	{
		pcSess->PostClose();
		return;
	}

	const int nBodySize = flatbuffers::ReadScalar<flatbuffers::uoffset_t>(pchData) + sizeof(flatbuffers::uoffset_t);

	flatbuffers::Verifier verifier(pchData, nBodySize);
	if (false == verifier.VerifySizePrefixedBuffer<nmsp::connector::message::ConnectorPkt>(nullptr))
	{
		pcSess->PostClose();
		return;
	}

	const nmsp::connector::message::ConnectorPkt* req = flatbuffers::GetSizePrefixedRoot<nmsp::connector::message::ConnectorPkt>(pchData);

	const auto funcIdx = static_cast<int32_t>(req->body_type());

	// 핸들러가 있는지 검사해 본다
	if (m_pktFunc.max_size() <= funcIdx)
		return;

	// 아직 핸들러가 지원이 안된다면..
	if (nullptr == m_pktFunc[funcIdx])
		return;

	(this->*m_pktFunc[funcIdx])(req, pcSess, nLen - nBodySize, pchData + nBodySize);
}

void connector_impl::OnSent(int nIndex, int nIdentity, int nSentBytes, _session_t* pcSess)
{
}

void connector_impl::OnPosted(int nIndex, int nIdentity, int nOption, int nLen, const unsigned char* pchData, _session_t* pcSess)
{
	m_sinks.Exe([&nOption, &nLen, &pchData, &pcSess](nmsp::connector::IConnectorSink* pcSink) {
		pcSink->NotifiedPost(static_cast<connector_session*>(pcSess)->GetServerId(), nOption, nLen, pchData);
	});
}

// 에러 로그를 출력하도록 한다
void connector_impl::OnError(const boost::system::error_code& error)
{
	LOG_ERROR(m_pcComponentImpl) << "connector_impl::OnError :: boost system error :: value:" << error.value() << " msg:" << error.message();
}

void connector_impl::OnError(int32_t index, int32_t identify, const boost::system::error_code& error)
{
	LOG_ERROR(m_pcComponentImpl) << "connector_impl::OnError :: boost system error :: index:" << index << " identify:" << identify << " value:" << error.value() << " msg:" << error.message();
}

void connector_impl::OnError(const std::exception& error)
{
	LOG_ERROR(m_pcComponentImpl) << "OnError :: exception :: " << error.what();
}

void connector_impl::OnError(const char* pszError)
{
	LOG_ERROR(m_pcComponentImpl) << "OnError :: " << pszError;
}

void connector_impl::MSG_C2CD_REQ_REG(const nmsp::connector::message::ConnectorPkt* pPkt, __super_t::_session_t* pcSess, flatbuffers::uoffset_t nextLen, const unsigned char* pbyNext)
{
	LOG_INFO(m_pcComponentImpl) << "MSG_C2CD_REQ_REG " << static_cast<connector_session*>(pcSess)->GetForSessionType() << ":: START :: from address " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().address().to_string() << ", port " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().port();

	const auto* res = pPkt->body_as_MSG_C2CD_REQ_REG();
	// 접속한 서버 정보임
	const auto address = static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().address().to_string();
	nmsp::connector::_serverid_t newserverid;

	const nmsp::connector::_group_id_t groupID = res->group_id();
	const auto groupLayer = static_cast<nmsp::connector::group_layer>(res->group_layer());
	const unsigned short service_type = res->service_type();

	// 등록결과도 알려준다
	const bool bIsReg = static_cast<connector_repository_ctrl&>(*m_pcComponentImpl).AddOrUpdate(newserverid, groupID, groupLayer, service_type, address, res->port());
	if (true == bIsReg)
		static_cast<connector_repository_ctrl&>(*m_pcComponentImpl).Save();

	connector_repository_ctrl::_serverid2addr_t infos;
	static_cast<connector_repository_ctrl&>(*m_pcComponentImpl).Get(infos);

	// 결과를 보낸다
	{
		flatbuffers::FlatBufferBuilder fbbReq(FLATBUFFER_INITIAL_SIZE, &m_flatbufferallocator);

		std::vector<flatbuffers::Offset<nmsp::connector::message::SERVER_INFO>> vec;

		for (auto& itr : infos)
		{
			auto& data = itr.second;

			// 내 정보를 빼고 보냄!!
			if (itr.first == newserverid)
				continue;

			// 공통이 들어 왔을 경우 모든 서버 정보를 다 전송해야 한다.
			if (0 < (nmsp::connector::group_layer::local & groupLayer))
			{
				// Local Layer일 경우 GroupID를 체크하고 그렇지 않을 경우 통과
				if (0 < (nmsp::connector::group_layer::local & data->GetGroupLayer()) && groupID != data->GetGroupID())
				{
					continue;
				}
			}

			vec.push_back(nmsp::connector::message::CreateSERVER_INFO(fbbReq, fbbReq.CreateString(itr.second->GetAddress()), itr.second->GetPort(), itr.first, data->GetGroupID(), static_cast<int32_t>(data->GetGroupLayer())));
		}

		const auto _servers = fbbReq.CreateVector(vec);
		const auto _body = nmsp::connector::message::CreateMSG_CD2C_RES_REG(fbbReq, bIsReg, fbbReq.CreateString(address), res->port(), newserverid, _servers);
		const auto _pkt = nmsp::connector::message::CreateConnectorPkt(fbbReq, nmsp::connector::message::ConnectorBodyAll::MSG_CD2C_RES_REG, _body.Union());
		fbbReq.FinishSizePrefixed(_pkt);

		if (false == pcSess->PostSend(fbbReq.GetSize(), fbbReq.GetBufferPointer()))
		{
			pcSess->PostClose();

			LOG_INFO(m_pcComponentImpl) << "MSG_C2CD_REQ_REG " << static_cast<connector_session*>(pcSess)->GetForSessionType() << ":: SEND ERROR :: from address " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().address().to_string() << ", port " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().port();
			return;
		}
	}

	// 등록에 실패했다면...
	if (false == bIsReg)
	{
		LOG_INFO(m_pcComponentImpl) << "MSG_C2CD_REQ_REG " << static_cast<connector_session*>(pcSess)->GetForSessionType() << ":: REGISTRATION ERROR :: from address " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().address().to_string() << ", port " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().port();
		return;
	}
	
	static_cast<connector_session*>(pcSess)->SetServerId(newserverid);
	static_cast<connector_session*>(pcSess)->SetGroupID(groupID);
	static_cast<connector_session*>(pcSess)->SetGroupLayer(groupLayer);

	// 서버 정보를 등록한다.
	{
		if (false == m_severid2serv.Add(newserverid, pcSess, _servicetype_set_t(), _servicetype_set_t()))
		{
			pcSess->PostClose();

			LOG_INFO(m_pcComponentImpl) << "MSG_C2CD_REQ_REG " << static_cast<connector_session*>(pcSess)->GetForSessionType() << ":: m_severid2serv add error " << newserverid << ":: from address " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().address().to_string() << ", port " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().port();
			return;
		}
	}

	// 접속한 다른 이들에게도 알려준다. 그리고 세션을 저장한다
	{
		flatbuffers::FlatBufferBuilder fbbReq(FLATBUFFER_INITIAL_SIZE, &m_flatbufferallocator);
		const auto _body = nmsp::connector::message::CreateMSG_CD2C_NOTI_SERVER(fbbReq, nmsp::connector::message::CreateSERVER_INFO(fbbReq, fbbReq.CreateString(address), res->port(), newserverid, groupID, static_cast<int32_t>(groupLayer)));
		const auto _pkt = nmsp::connector::message::CreateConnectorPkt(fbbReq, nmsp::connector::message::ConnectorBodyAll::MSG_CD2C_NOTI_SERVER, _body.Union());
		fbbReq.FinishSizePrefixed(_pkt);

		// 다 보내 버린다..
		m_severid2serv.Exe(newserverid, groupID, groupLayer, [this, &fbbReq](nmsp::connector::_serverid_t serverid, __super_t::_shared_session_t& sess, _servicetype_set_t&, _servicetype_set_t&) {
			if (false == sess->PostSend(fbbReq.GetSize(), fbbReq.GetBufferPointer()))
				sess->PostClose();
		});
	}
	//
}

void connector_impl::MSG_CD2C_RES_REG(const nmsp::connector::message::ConnectorPkt* pPkt, __super_t::_session_t* pcSess, flatbuffers::uoffset_t nextLen, const unsigned char* pbyNext)
{
	LOG_INFO(m_pcComponentImpl) << "MSG_CD2C_RES_REG " << static_cast<connector_session*>(pcSess)->GetForSessionType() << ":: START :: from address " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().address().to_string() << ", port " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().port();

	const nmsp::connector::message::MSG_CD2C_RES_REG* res = pPkt->body_as_MSG_CD2C_RES_REG();
	if (false == res->isReg())
	{
		LOG_INFO(m_pcComponentImpl) << "MSG_CD2C_RES_REG " << static_cast<connector_session*>(pcSess)->GetForSessionType() << ":: REGISTRATION ERROR :: from address " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().address().to_string() << ", port " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().port();
		return;
	}

	// 받은 서버 목록에 대한 처리함수를 호출한다
	if (nullptr != res->servers())
	{
		if (false == this->Process_SERVER_INFO(res->serverid(), res->servers()))
		{
			pcSess->PostClose();
			LOG_INFO(m_pcComponentImpl) << "MSG_CD2C_RES_REG " << static_cast<connector_session*>(pcSess)->GetForSessionType() << ":: Process_SERVER_INFO ERROR :: from address " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().address().to_string() << ", port " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().port();
			return;
		}
	}

	// 등록된 서버 ID
	m_serverid = res->serverid();
	m_serverid = res->serverid();
	std::string address = res->address()->str();
	unsigned short port = res->port();

	LOG_INFO(m_pcComponentImpl) << "MSG_CD2C_RES_REG serverid=" << m_serverid;

	// 자기 자신에게...통지해주기 위한..
	m_sinks.Exe([this, &address, &port](nmsp::connector::IConnectorSink* pcSink) {
		pcSink->NotifiedOnLineService(m_serverid, static_cast<int>(m_vecServiceTypes.size()), m_vecServiceTypes.data());
		pcSink->NotifiedActivation(m_serverid, static_cast<int>(m_vecActiveServiceTypes.size()), m_vecActiveServiceTypes.data(), address.c_str(), port);
	});
}

void connector_impl::MSG_C2CD_REQ_UNREG(const nmsp::connector::message::ConnectorPkt* pPkt, __super_t::_session_t* pcSess, flatbuffers::uoffset_t nextLen, const unsigned char* pbyNext)
{
	LOG_INFO(m_pcComponentImpl) << "MSG_C2CD_REQ_UNREG " << static_cast<connector_session*>(pcSess)->GetForSessionType() << ":: START :: from address " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().address().to_string() << ", port " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().port();
}

void connector_impl::MSG_CD2C_NOTI_SERVER(const nmsp::connector::message::ConnectorPkt* pPkt, __super_t::_session_t* pcSess, flatbuffers::uoffset_t nextLen, const unsigned char* pbyNext)
{
	LOG_INFO(m_pcComponentImpl) << "MSG_CD2C_NOTI_SERVER " << static_cast<connector_session*>(pcSess)->GetForSessionType() << ":: START :: from address " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().address().to_string() << ", port " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().port();

	// 아직 등록이 완료되지 않았다면 받는것은 모두 SKIP한다
	if (nmsp::connector::SERVERID_NULL == m_serverid)
	{
		LOG_INFO(m_pcComponentImpl) << "MSG_CD2C_NOTI_SERVER " << static_cast<connector_session*>(pcSess)->GetForSessionType() << ":: nmsp::connector::SERVERID_NULL == m_serverid :: from address " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().address().to_string() << ", port " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().port();
		return;
	}

	const nmsp::connector::message::MSG_CD2C_NOTI_SERVER* res = pPkt->body_as_MSG_CD2C_NOTI_SERVER();

	// 받은 서버 목록에 대한 처리함수를 호출한다
	if (false == this->Process_SERVER_INFO(m_serverid, res->server()))
	{
		pcSess->PostClose();
		LOG_INFO(m_pcComponentImpl) << "MSG_CD2C_NOTI_SERVER " << static_cast<connector_session*>(pcSess)->GetForSessionType() << ":: Process_SERVER_INFO error :: from address " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().address().to_string() << ", port " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().port();
	}
}

void connector_impl::MSG_C2CD_REQ_LIST(const nmsp::connector::message::ConnectorPkt* pPkt, __super_t::_session_t* pcSess, flatbuffers::uoffset_t nextLen, const unsigned char* pbyNext)
{
	LOG_INFO(m_pcComponentImpl) << "MSG_C2CD_REQ_LIST " << static_cast<connector_session*>(pcSess)->GetForSessionType() << ":: START :: from address " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().address().to_string() << ", port " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().port();
}

void connector_impl::MSG_CD2C_RES_LIST(const nmsp::connector::message::ConnectorPkt* pPkt, __super_t::_session_t* pcSess, flatbuffers::uoffset_t nextLen, const unsigned char* pbyNext)
{
	LOG_INFO(m_pcComponentImpl) << "MSG_CD2C_RES_LIST " << static_cast<connector_session*>(pcSess)->GetForSessionType() << ":: START :: from address " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().address().to_string() << ", port " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().port();
}

void connector_impl::MSG_C2C_REQ_REG(const nmsp::connector::message::ConnectorPkt* pPkt, __super_t::_session_t* pcSess, flatbuffers::uoffset_t nextLen, const unsigned char* pbyNext)
{
	LOG_INFO(m_pcComponentImpl) << "MSG_C2C_REQ_REG " << static_cast<connector_session*>(pcSess)->GetForSessionType() << ":: START :: from address " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().address().to_string() << ", port " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().port();

	if (connector_session::SESSION_TYPE_C2C_SERVER != static_cast<connector_session*>(pcSess)->GetForSessionType())
	{
		pcSess->PostClose();

		LOG_INFO(m_pcComponentImpl) << "MSG_C2C_REQ_REG " << static_cast<connector_session*>(pcSess)->GetForSessionType() << ":: SESSION_TYPE_C2C_SERVER is not << " << static_cast<connector_session*>(pcSess)->GetForSessionType() << " :: from address " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().address().to_string() << ", port " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().port();
		return;
	}

	// 아직 등록 전이라면 접속을 종료한다..
	if (nmsp::connector::SERVERID_NULL == m_serverid)
	{
		pcSess->PostClose();

		LOG_INFO(m_pcComponentImpl) << "MSG_C2C_REQ_REG " << static_cast<connector_session*>(pcSess)->GetForSessionType() << ":: nmsp::connector::SERVERID_NULL == m_serverid :: from address " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().address().to_string() << ", port " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().port();
		return;
	}

	// 받은 정보를 정리하고
	const nmsp::connector::message::MSG_C2C_REQ_REG* res = pPkt->body_as_MSG_C2C_REQ_REG();
	
	_servicetype_set_t servs;
	_servicetype_set_t activeServiceTypes;
	_servicetype_vec_t servs_vec;

	const auto* serviceTypes = res->serviceTypes();

	servs_vec.reserve(serviceTypes->size());

	for (auto& itr = serviceTypes->begin(); itr != serviceTypes->end(); ++itr)
	{
		servs.insert(*itr);
		servs_vec.push_back(*itr);
	}

	std::stringstream ss;

	for (auto& itr = res->activeServiceTypes()->begin(); itr != res->activeServiceTypes()->end(); ++itr)
	{
		activeServiceTypes.insert(*itr);
	}

	_serverid_t serverid = res->serverid();
	nmsp::connector::_group_id_t groupID = res->group_id();
	auto groupLayer = static_cast<nmsp::connector::group_layer>(res->group_layer());

	LOG_DEBUG(m_pcComponentImpl) << __FUNCTION__ << ". self server id=" << m_serverid << ", req server id=" << serverid << ", active servicetypes=" << ss.str();

	static_cast<connector_session*>(pcSess)->SetServerId(serverid);
	static_cast<connector_session*>(pcSess)->SetGroupID(groupID);
	static_cast<connector_session*>(pcSess)->SetGroupLayer(groupLayer);

	// 응답을 보낸다
	{
		flatbuffers::FlatBufferBuilder fbbReq(FLATBUFFER_INITIAL_SIZE, &m_flatbufferallocator);
		auto serviceTypes = fbbReq.CreateVector<unsigned short>(m_vecServiceTypes);
		auto activeServiceTypes = fbbReq.CreateVector<unsigned short>(m_vecActiveServiceTypes);
		auto _req = nmsp::connector::message::CreateMSG_C2C_RES_REG(fbbReq, m_serverid, serviceTypes, activeServiceTypes);
		auto _pkt = nmsp::connector::message::CreateConnectorPkt(fbbReq, nmsp::connector::message::ConnectorBodyAll::MSG_C2C_RES_REG, _req.Union());
		fbbReq.FinishSizePrefixed(_pkt);

		if (false == pcSess->PostSend(fbbReq.GetSize(), fbbReq.GetBufferPointer()))
		{
			pcSess->PostClose();
			return;
		}
	}

	// 마지막으로 등록을..
	if (false == m_severid2serv.Add(serverid, pcSess, servs, activeServiceTypes))
	{
		pcSess->PostClose();
		return;
	}

	static_cast<connector_session*>(pcSess)->SetLink(true);

	auto& config = static_cast<connector_config&>(*m_pcComponentImpl);
	std::string serverAddress = config.GetServerAddress();
	unsigned short listenPort = config.GetServerListenPort();

	// 컴포넌트들에게도 온라인이 된 것을 알려준다
	m_sinks.Exe([this, &serverid, &servs_vec, &activeServiceTypes, &serverAddress, &listenPort](nmsp::connector::IConnectorSink* pcSink) {
		pcSink->NotifiedOnLineService(serverid, static_cast<int>(servs_vec.size()), servs_vec.data());

		for (unsigned short serviceType : activeServiceTypes)
		{
			pcSink->NotifiedActivation(serverid, 1, &serviceType, serverAddress.c_str(), listenPort);
		}
	});
}

void connector_impl::MSG_C2C_RES_REG(const nmsp::connector::message::ConnectorPkt* pPkt, __super_t::_session_t* pcSess, flatbuffers::uoffset_t nextLen, const unsigned char* pbyNext)
{
	LOG_INFO(m_pcComponentImpl) << "MSG_C2C_RES_REG " << static_cast<connector_session*>(pcSess)->GetForSessionType() << ":: START :: from address " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().address().to_string() << ", port " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().port();

	if (connector_session::SESSION_TYPE_C2C_CLIENT != static_cast<connector_session*>(pcSess)->GetForSessionType())
	{
		pcSess->PostClose();

		LOG_INFO(m_pcComponentImpl) << "MSG_C2C_RES_REG " << static_cast<connector_session*>(pcSess)->GetForSessionType() << ":: SESSION_TYPE_C2C_CLIENT is not " << static_cast<connector_session*>(pcSess)->GetForSessionType() << " :: from address " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().address().to_string() << ", port " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().port();
		return;
	}

	// 받은 정보를 정리하고
	_servicetype_set_t servs;
	_servicetype_set_t activeServiceTypes;
	_servicetype_vec_t servs_vec;
	_serverid_t serverid;
	{
		const nmsp::connector::message::MSG_C2C_RES_REG* res = pPkt->body_as_MSG_C2C_RES_REG();
		const auto* serviceTypes = res->serviceTypes();

		servs_vec.reserve(serviceTypes->size());

		for (auto& itr = serviceTypes->begin(); itr != serviceTypes->end(); ++itr)
		{
			servs.insert(*itr);
			servs_vec.push_back(*itr);
		}

		for (auto& itr = res->activeServiceTypes()->begin(); itr != res->activeServiceTypes()->end(); ++itr)
		{
			activeServiceTypes.insert(*itr);
		}

		serverid = res->serverid();
	}

	// 요청할때의 서버정보와 받은게 다르다면 접속을 종료한다..
	if (serverid != static_cast<connector_session*>(pcSess)->GetServerId())
	{
		pcSess->PostClose();

		LOG_INFO(m_pcComponentImpl) << "MSG_C2C_RES_REG " << static_cast<connector_session*>(pcSess)->GetForSessionType() << ":: serverid is not same " << static_cast<connector_session*>(pcSess)->GetServerId() << " :: from address " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().address().to_string() << ", port " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().port();
		return;
	}

	// 마지막으로 등록을..
	if (false == m_severid2serv.Add(serverid, pcSess, servs, activeServiceTypes))
	{
		pcSess->PostClose();
		return;
	}

	static_cast<connector_session*>(pcSess)->SetLink(true);

	auto& config = static_cast<connector_config&>(*m_pcComponentImpl);
	const std::string& serverAddress = config.GetServerAddress();
	unsigned short listenPort = config.GetServerListenPort();

	// 컴포넌트들에게도 온라인이 된 것을 알려준다
	m_sinks.Exe([this, &serverid, &servs_vec, &activeServiceTypes, &serverAddress, &listenPort](nmsp::connector::IConnectorSink* pcSink) {
		
		pcSink->NotifiedOnLineService(serverid, static_cast<int>(servs_vec.size()), servs_vec.data());

		for (unsigned short serviceType : activeServiceTypes)
		{
			pcSink->NotifiedActivation(serverid, 1, &serviceType, serverAddress.c_str(), listenPort);
		}
	});
}

void connector_impl::MSG_C2C_REQ_UNREG(const nmsp::connector::message::ConnectorPkt* pPkt, __super_t::_session_t* pcSess, flatbuffers::uoffset_t nextLen, const unsigned char* pbyNext)
{
}

void connector_impl::MSG_C2C_RES_UNREG(const nmsp::connector::message::ConnectorPkt* pPkt, __super_t::_session_t* pcSess, flatbuffers::uoffset_t nextLen, const unsigned char* pbyNext)
{
}

void connector_impl::MSG_C2C_NOTI_ACTIVATION(const nmsp::connector::message::ConnectorPkt* pPkt, __super_t::_session_t* pcSess, flatbuffers::uoffset_t nextLen, const unsigned char* pbyNext)
{
	LOG_INFO(m_pcComponentImpl) << "MSG_C2C_NOTI_ACTIVATION " << static_cast<connector_session*>(pcSess)->GetForSessionType() << ":: START :: from address " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().address().to_string() << ", port " << static_cast<boost::asio::ip::tcp::socket&>(*pcSess).remote_endpoint().port();

	// 아직 등록 전이라면 접속을 종료한다..
	if (nmsp::connector::SERVERID_NULL == m_serverid)
	{
		LOG_INFO(m_pcComponentImpl) << "MSG_C2C_NOTI_ACTIVATION. m_serverid is null.";
		return;
	}

	// 연결된 상태가 아니라면..
	if (false == static_cast<connector_session*>(pcSess)->IsLink())
	{
		LOG_INFO(m_pcComponentImpl) << "MSG_C2C_NOTI_ACTIVATION. no link. serverid=" << m_serverid;
		return;
	}
	
	// 받은 정보를 정리하고
	const nmsp::connector::message::MSG_C2C_NOTI_ACTIVATION* res = pPkt->body_as_MSG_C2C_NOTI_ACTIVATION();

	unsigned short serverID = res->serverID();
	unsigned short serviceType = res->serviceType();
	std::string serverAddress = res->serverAddress()->str();
	unsigned short serverPort = res->serverPort();

	// 활성화
	m_severid2serv.Activate(serverID, serviceType);

	LOG_DEBUG(m_pcComponentImpl) << __FUNCTION__ << ". m_serverid=" << m_serverid << ", req_serverid=" << serverID << ", req_service_type=" << serviceType;

	// 컴포넌트들에게도 온라인이 된 것을 알려준다
	m_sinks.Exe([this, serverID, serviceType, &serverAddress, &serverPort](nmsp::connector::IConnectorSink* pcSink) {
		unsigned short type = serviceType;

		pcSink->NotifiedActivation(serverID, 1, &type, serverAddress.c_str(), serverPort);
	}); 
}

void connector_impl::MSG_C2C_DATA(const nmsp::connector::message::ConnectorPkt* pPkt, __super_t::_session_t* pcSess, flatbuffers::uoffset_t nextLen, const unsigned char* pbyNext)
{
	if (connector_session::SESSION_TYPE_C2C_SERVER != static_cast<connector_session*>(pcSess)->GetForSessionType() &&
		connector_session::SESSION_TYPE_C2C_CLIENT != static_cast<connector_session*>(pcSess)->GetForSessionType())
	{
		pcSess->PostClose();
		return;
	}

	// 아직 등록 전이라면 접속을 종료한다..
	if (nmsp::connector::SERVERID_NULL == m_serverid)
		return;

	// 연결된 상태가 아니라면..
	if (false == static_cast<connector_session*>(pcSess)->IsLink())
		return;

	// 받은 정보를 정리하고
	const nmsp::connector::message::MSG_C2C_DATA* res = pPkt->body_as_MSG_C2C_DATA();

	const uint8_t* data = pbyNext;
	int32_t length = nextLen;
	
	ScopedBuffer<_allocator_t> decompressedBuffer;
	
	// 압축 해제 작업 진행!!
	if (nextLen > 0)
	{
		// 압축 해제 후 사이즈를 얻어 옵니다.
		size_t decompressedLength;
		snappy::GetUncompressedLength(reinterpret_cast<const char*>(pbyNext), nextLen, &decompressedLength);

		// 버퍼 크기를 지정합니다.
		decompressedBuffer.Resize(decompressedLength);

		snappy::RawUncompress(reinterpret_cast<const char*>(pbyNext), nextLen, reinterpret_cast<char*>(decompressedBuffer.Data()));
	
		data = decompressedBuffer.Data();
		length = static_cast<int32_t>(decompressedLength);
	}

	// 찾아서 넘긴다
	m_sinks.Exe(res->toServiceType(), [&res, &length, &data, &pcSess](nmsp::connector::IConnectorSink* pcSink) {
		pcSink->NotifiedMessage(static_cast<connector_session*>(pcSess)->GetServerId(), res->fromServiceType(), res->option(), length, data);
	});
}

bool connector_impl::Init()
{
	// boost::asio초기화
	if (false == __super_t::Init(
								static_cast<connector_config&>(*m_pcComponentImpl).GetInitPoolCount(),
								static_cast<connector_config&>(*m_pcComponentImpl).GetExtPoolCount(),
								static_cast<connector_config&>(*m_pcComponentImpl).GetNormalPacketSize()))
	{
		LOG_ERROR(m_pcComponentImpl) << "connector :: init error";
		return false;
	}

	// 서버 초기화
	const bool IsCoordinator = static_cast<connector_config&>(*m_pcComponentImpl).IsCoordinator();
	if (true == IsCoordinator)
	{
		if (false == __super_t::InitTcpServer(
								static_cast<connector_config&>(*m_pcComponentImpl).GetCoordinatorAddress().c_str(),
								static_cast<connector_config&>(*m_pcComponentImpl).GetCoordinatorListenPort(),
								static_cast<connector_config&>(*m_pcComponentImpl).GetReuse(),
								static_cast<connector_config&>(*m_pcComponentImpl).GetMaxAcceptSession()))
		{
			LOG_ERROR(m_pcComponentImpl) << "connector :: initTcpServer(coordinator) error";
			return false;
		}

		// coordinator로 동작할때
		if (false == this->InitCoordinator())
		{
			LOG_ERROR(m_pcComponentImpl) << "connector :: InitCoordinator error";
			return false;
		}

		// coordinator인 경우는 thread를 하나로 고정한다..
		if (false == __super_t::InitThreads(1))
		{
			LOG_ERROR(m_pcComponentImpl) << "connector :: InitThreads error";
			return false;
		}
	}
	else
	{
		// 인터페이스 정보들을 일단 가져온다
		{
			int nLenServiceTypes = 0;
			unsigned short* puiServiceTypes = nullptr;

			int nRet = static_cast<nmsp::IComponentContainer*>(*m_pcComponentImpl)->GetServiceTypes(&nLenServiceTypes, &puiServiceTypes);
			if (nmsp::_NMSP_NOERROR != nRet)
			{
				LOG_ERROR(m_pcComponentImpl) << "connector :: init error :: " << nRet;
				return false;
			}

			// 일단 모아 놓는다
			for (int nI = 0; nI < nLenServiceTypes; ++nI)
				m_vecServiceTypes.push_back(puiServiceTypes[nI]);

			static_cast<nmsp::IComponentContainer*>(*m_pcComponentImpl)->ResetServiceTypes(puiServiceTypes);
		}

		if (false == __super_t::InitTcpServer(
			static_cast<connector_config&>(*m_pcComponentImpl).GetServerAddress().c_str(),
			static_cast<connector_config&>(*m_pcComponentImpl).GetServerListenPort(),
			static_cast<connector_config&>(*m_pcComponentImpl).GetReuse(),
			static_cast<connector_config&>(*m_pcComponentImpl).GetMaxAcceptSession()))
		{
			LOG_ERROR(m_pcComponentImpl) << "connector :: initTcpServer(connector) error";
			return false;
		}

		// coordinator로 동작할때
		if (false == this->InitCoordinator(static_cast<connector_config&>(*m_pcComponentImpl).GetCoordinatorAddress(), static_cast<connector_config&>(*m_pcComponentImpl).GetCoordinatorListenPort()))
		{
			LOG_ERROR(m_pcComponentImpl) << "connector :: InitCoordinator error";
			return false;
		}

		// asio thread...
		if (false == __super_t::InitThreads(static_cast<connector_config&>(*m_pcComponentImpl).GetThreadCount()))
		{
			LOG_ERROR(m_pcComponentImpl) << "connector :: InitThreads error";
			return false;
		}

		// 타이어
		if (false == __super_t::SetTimer(IDLE_TIMER_ID, static_cast<connector_config&>(*m_pcComponentImpl).GetConnectionCheckPeriod()))
		{
			LOG_ERROR(m_pcComponentImpl) << "connector :: SetTimer error";
			return false;
		}
	}

	return true;
}

void connector_impl::Uninit()
{
	// 타이머 중단
	if (false == static_cast<connector_config&>(*m_pcComponentImpl).IsCoordinator())
		__super_t::ResetTimer(IDLE_TIMER_ID);

	// asio 정리
	__super_t::Uninit();

	// 모든 세션 관리 정리
	m_sess2serverinfo.Clear();
	m_severid2serv.Clear();
	m_sinks.Clear();
}

int connector_impl::QueryInterface(const nmsp::UUID* iid, void** pInterface)
{
	return m_pcComponentImpl->QueryInterface(iid, pInterface);
}

// connector_component_impl의 life time내에 같이 공존하기 위해서..
int connector_impl::AddRef(void)
{
	return m_pcComponentImpl->AddRef();
}

// connector_component_impl의 life time내에 같이 공존하기 위해서..
int connector_impl::Release(void)
{
	return m_pcComponentImpl->Release();
}

int connector_impl::SetSink(unsigned short uiServiceType, nmsp::connector::IConnectorSink* piSink)
{
	if (true == m_isCoordinator)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_IS_NOT_CONNECTOR);

	if (false == m_sinks.Add(uiServiceType, piSink))
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_DUP_SINK_INTERFACE);

	// 자기 자신은 등록할때. 알려주면 된다
	if (nmsp::connector::SERVERID_NULL != m_serverid)
	{
		piSink->NotifiedOnLineService(
						m_serverid,
						static_cast<int>(m_vecServiceTypes.size()),
						m_vecServiceTypes.data());
	}

	return nmsp::_NMSP_NOERROR;
}

int connector_impl::ResetSink(unsigned short uiServiceType)
{
	if (true == m_isCoordinator)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_IS_NOT_CONNECTOR);

	if (false == m_sinks.Del(uiServiceType))
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_NO_SINK_INTERFACE);

	return nmsp::_NMSP_NOERROR;
}

// 통신 가능한 상태일때 나와 연결을 맺은 Connector 들에게 활성화를 알림
int connector_impl::Activate(unsigned short uiServiceType)
{
	if (true == m_isCoordinator)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_IS_NOT_CONNECTOR);
	
	// 활성화 목록에 추가
	m_vecActiveServiceTypes.push_back(uiServiceType);

	LOG_DEBUG(m_pcComponentImpl) << __FUNCTION__ << ". server_id=" << m_serverid << ", add_service_type=" << uiServiceType;

	// 연결된 세션에 활성화를 알림
	if (nmsp::connector::SERVERID_NULL == m_serverid)
	{
		LOG_ERROR(m_pcComponentImpl) << __FUNCTION__ << ". serverid is 0";
		return nmsp::_NMSP_NOERROR;
	}

	auto& config = static_cast<connector_config&>(*m_pcComponentImpl);
	const std::string& serverAddress = config.GetServerAddress();
	unsigned short listenPort = config.GetServerListenPort();
	
	nmsp::connector::_group_id_t groupID = 0;
	nmsp::connector::_group_layer_t groupLayer = nmsp::connector::group_layer::none;
	m_severid2serv.GetGroupID(m_serverid, groupID);
	m_severid2serv.GetGroupLayer(m_serverid, groupLayer);

	{
		flatbuffers::FlatBufferBuilder fbbReq(FLATBUFFER_INITIAL_SIZE, &m_flatbufferallocator);
		auto _req = nmsp::connector::message::CreateMSG_C2C_NOTI_ACTIVATION(fbbReq, m_serverid, uiServiceType, fbbReq.CreateString(serverAddress), listenPort);
		auto _pkt = nmsp::connector::message::CreateConnectorPkt(fbbReq, nmsp::connector::message::ConnectorBodyAll::MSG_C2C_NOTI_ACTIVATION, _req.Union());
		fbbReq.FinishSizePrefixed(_pkt);

		m_severid2serv.Exe(m_serverid, groupID, groupLayer, [this, &fbbReq, uiServiceType](nmsp::connector::_serverid_t serverID, __super_t::_shared_session_t& sess, const _servicetype_set_t&, _servicetype_set_t& activeServs) {
			
			LOG_DEBUG(m_pcComponentImpl) << "connector_impl::Activate. send packet. " << m_serverid << "->" << static_cast<connector_session*>(sess.get())->GetServerId() << ", servicetype=" << uiServiceType;

			if (false == sess->PostSend(fbbReq.GetSize(), fbbReq.GetBufferPointer()))
			{
				sess->PostClose();
				return;
			}
		});
	}
	
	// 연결된 sink에 활성화됨을 알림.
	m_sinks.Exe([this, uiServiceType, &serverAddress, &listenPort](nmsp::connector::IConnectorSink* pcSink) {
		unsigned short serviceType = uiServiceType;
		pcSink->NotifiedActivation(m_serverid, 1, &serviceType, serverAddress.c_str(), listenPort);
	});

	// 연결된 sink에 기존에 active되었던 service들을 알림.
	m_sinks.Exe(uiServiceType, [this, uiServiceType, &serverAddress, &listenPort](nmsp::connector::IConnectorSink* pcSink) {
		for (unsigned short serviceType : m_vecActiveServiceTypes)
		{
			// 나에게 나의 service type은 위에서 알림
			if (serviceType != uiServiceType)
			{
				pcSink->NotifiedActivation(m_serverid, 1, &serviceType, serverAddress.c_str(), listenPort);
			}
		}
	});

	
	m_severid2serv.Exe([this, uiServiceType, &serverAddress, &listenPort](nmsp::connector::_serverid_t serverID, __super_t::_shared_session_t& sess, const _servicetype_set_t&, _servicetype_set_t& activeServiceTypes) {
		
		// 나한테 기존에 연결된 정보를 공유한다.
		m_sinks.Exe(uiServiceType, [this, serverID, &activeServiceTypes, &serverAddress, &listenPort](nmsp::connector::IConnectorSink* pcSink) {
			for (unsigned short serviceType : activeServiceTypes)
			{
				pcSink->NotifiedActivation(serverID, 1, &serviceType, serverAddress.c_str(), listenPort);
			}
		});
		

	});
	
	return nmsp::_NMSP_NOERROR;
}

int connector_impl::GetServerID(_serverid_t* pServerId)
{
	if (true == m_isCoordinator)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_IS_NOT_CONNECTOR);

	*pServerId = m_serverid;
	return nmsp::_NMSP_NOERROR;
}

int connector_impl::GetServerGroupID(_serverid_t serverID, nmsp::connector::_group_id_t* pServerGroupID)
{
	if (true == m_isCoordinator)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_IS_NOT_CONNECTOR);

	if (serverID == m_serverid)
	{
		auto& config = static_cast<connector_config&>(*m_pcComponentImpl);

		*pServerGroupID = config.GetGroupID();

		return nmsp::_NMSP_NOERROR;
	}

	if (false == m_severid2serv.GetGroupID(serverID, *pServerGroupID))
	{
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_INVALID_SERVERID);
	}

	return nmsp::_NMSP_NOERROR;
}

int connector_impl::GetServerGroupLayer(_serverid_t serverID, nmsp::connector::_group_layer_t* pServerGroupLayer)
{
	if (true == m_isCoordinator)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_IS_NOT_CONNECTOR);

	if (serverID == m_serverid)
	{
		auto& config = static_cast<connector_config&>(*m_pcComponentImpl);

		*pServerGroupLayer = config.GetGroupLayer();

		return nmsp::_NMSP_NOERROR;
	}

	if (false == m_severid2serv.GetGroupLayer(serverID, *pServerGroupLayer))
	{
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_INVALID_SERVERID);
	}

	return nmsp::_NMSP_NOERROR;
}

int connector_impl::GetAllServerIDs(int* pulLen, _serverid_t** ppuiServerIDs)
{
	if (true == m_isCoordinator)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_IS_NOT_CONNECTOR);

	_serverid_vec_t serverids;

	//
	m_severid2serv.Exe([&serverids](_serverid_t serverid, const __super_t::_shared_session_t&, const _servicetype_set_t&, const _servicetype_set_t&) {
		serverids.push_back(serverid);
	});

	// 자신도 이미 등록이 되어 있다면..
	if (nmsp::connector::SERVERID_NULL != m_serverid)
		serverids.push_back(m_serverid);

	//
	*pulLen = static_cast<int>(serverids.size());
	*ppuiServerIDs = reinterpret_cast<_serverid_t*>(_allocator_t::CreateMemory(static_cast<int>(serverids.size() * sizeof(_serverid_vec_t::value_type))));
	if (nullptr == *ppuiServerIDs)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_MEMORY);

	for (_serverid_vec_t::size_type sL = 0; sL != serverids.size(); ++sL)
		(*ppuiServerIDs)[sL] = serverids[sL];

	return nmsp::_NMSP_NOERROR;
}

int connector_impl::ResetAllServerIDs(_serverid_t* puiServerIDs)
{
	_allocator_t::DestroyMemory(puiServerIDs);
	return nmsp::_NMSP_NOERROR;
}

int connector_impl::GetAllServerIDsByServiceType(unsigned short uiServiceType, int* pulLen, _serverid_t** ppuiServerIDs)
{
	return GetAllServerIDsByServiceTypeAndGroupID(uiServiceType, 0, pulLen, ppuiServerIDs);
}

int connector_impl::GetAllServerIDsByServiceTypeAndGroupID(unsigned short uiServiceType, nmsp::connector::_group_id_t groupID, int* pulLen, _serverid_t** ppuiServerIDs)
{
	if (true == m_isCoordinator)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_IS_NOT_CONNECTOR);

	_serverid_vec_t serverids;

	// 특정 servicetype에 해당하는 것만..
	m_severid2serv.Exe([&serverids, uiServiceType, groupID](_serverid_t serverid, const __super_t::_shared_session_t& sess, const _servicetype_set_t& st, const _servicetype_set_t&) {
		
		auto connectorSession = static_cast<const connector_session*>(static_cast<const __super_t::_session_t*>(sess));
		if (0 < groupID && groupID != connectorSession->GetGroupID())
			return;

		if (0 < st.count(uiServiceType))
			serverids.push_back(serverid);
	});

	// 자신도 이미 등록이 되어 있다면..
	auto& config = static_cast<connector_config&>(*m_pcComponentImpl);
	if (nmsp::connector::SERVERID_NULL != m_serverid && (0 == groupID || groupID == config.GetGroupID()))
	{
		if (std::count(m_vecServiceTypes.begin(), m_vecServiceTypes.end(), uiServiceType))
			serverids.push_back(m_serverid);
	}

	//
	*pulLen = static_cast<int>(serverids.size());
	*ppuiServerIDs = reinterpret_cast<_serverid_t*>(_allocator_t::CreateMemory(static_cast<int>(serverids.size() * sizeof(_serverid_vec_t::value_type))));
	if (nullptr == *ppuiServerIDs)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_MEMORY);

	for (_serverid_vec_t::size_type sL = 0; sL != serverids.size(); ++sL)
		(*ppuiServerIDs)[sL] = serverids[sL];

	return nmsp::_NMSP_NOERROR;
}

int connector_impl::ResetAllServerIDsByServiceType(_serverid_t* puiServerIDs)
{
	_allocator_t::DestroyMemory(puiServerIDs);
	return nmsp::_NMSP_NOERROR;
}

int connector_impl::IsServiceInServer(nmsp::connector::_serverid_t serverId, unsigned short uiServiceType, bool* pbIs)
{
	if (true == m_isCoordinator)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_IS_NOT_CONNECTOR);

	// 자기 자신이라면..
	if (serverId == m_serverid)
	{
		if (0 < std::count(m_vecServiceTypes.begin(), m_vecServiceTypes.end(), uiServiceType))
			*pbIs = true;
		else
			*pbIs = false;

		return nmsp::_NMSP_NOERROR;
	}

	//
	*pbIs = false;

	m_severid2serv.Exe(serverId, [&pbIs, &uiServiceType](const __super_t::_shared_session_t&, const _servicetype_set_t& servs) {
		auto itr = servs.find(uiServiceType);
		if (itr != servs.end())
			*pbIs = true;
	});

	return nmsp::_NMSP_NOERROR;
}

int connector_impl::GetServerIdCount(int* pnServerIdCount)
{
	if (true == m_isCoordinator)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_IS_NOT_CONNECTOR);

	// 자기 자신도 포함이 되어야 하므로 +1을 한다.. 자신은 무조건 존재하는 걸로..
	*pnServerIdCount = m_severid2serv.Count() + 1;
	return nmsp::_NMSP_NOERROR;
}

int connector_impl::GetServiceTypeCount(nmsp::connector::_serverid_t serverId, int* pnServiceTypeCount)
{
	if (true == m_isCoordinator)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_IS_NOT_CONNECTOR);

	// 자기 자신이라면..
	if (serverId == m_serverid)
	{
		*pnServiceTypeCount = static_cast<int>(m_vecServiceTypes.size());
		return nmsp::_NMSP_NOERROR;
	}

	*pnServiceTypeCount = 0;

	m_severid2serv.Exe(serverId, [&pnServiceTypeCount](const __super_t::_shared_session_t&, const _servicetype_set_t& servs) {
		*pnServiceTypeCount = static_cast<int>(servs.size());
	});

	return nmsp::_NMSP_NOERROR;
}

int connector_impl::IsOnline(nmsp::connector::_serverid_t serverId, unsigned short uiServiceType, bool* pbIsOnline)
{
	if (true == m_isCoordinator)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_IS_NOT_CONNECTOR);

	// 자기 자신이라면..
	if (serverId == m_serverid)
	{
		*pbIsOnline = true;
		return nmsp::_NMSP_NOERROR;
	}

	*pbIsOnline = false;

	m_severid2serv.Exe(serverId, [uiServiceType, &pbIsOnline](const __super_t::_shared_session_t& sess, const _servicetype_set_t& servs) {
		auto itr = servs.find(uiServiceType);
		if (itr != servs.end())
			*pbIsOnline = static_cast<const connector_session*>(static_cast<const __super_t::_session_t*>(sess))->IsLink();
	});

	return nmsp::_NMSP_NOERROR;
}

int connector_impl::NotifyMessage(nmsp::connector::_serverid_t toServerId, unsigned short toServiceType, unsigned short fromServiceType, int nOption, int nLen, const unsigned char* pbyData)
{
	if (true == m_isCoordinator)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_IS_NOT_CONNECTOR);

	// 초기화 전이라면
	if (nmsp::connector::SERVERID_NULL == m_serverid)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_INIT);

	// 자기자신에게 보내는 거라면 ?
	if (toServerId == m_serverid)
	{
		int nRet = nmsp::_NMSP_NOERROR;

		if (false == m_sinks.Exe(toServiceType, [&nRet, toServerId, toServiceType, fromServiceType, nOption, nLen, pbyData](nmsp::connector::IConnectorSink* pcSink) {
			nRet = pcSink->NotifiedMessage(toServerId, fromServiceType, nOption, nLen, pbyData);
		}))
		{
			nRet = nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_NO_SERVICETYPE);
		}

		return nRet;
	}

	//
	flatbuffers::FlatBufferBuilder fbbReq(FLATBUFFER_INITIAL_SIZE, &m_flatbufferallocator);
	const auto _req = nmsp::connector::message::CreateMSG_C2C_DATA(fbbReq, toServiceType, fromServiceType, nOption);
	const auto _pkt = nmsp::connector::message::CreateConnectorPkt(fbbReq, nmsp::connector::message::ConnectorBodyAll::MSG_C2C_DATA, _req.Union());
	fbbReq.FinishSizePrefixed(_pkt);

	// 압축 시도!!
	size_t compressedLength = snappy::MaxCompressedLength(nLen);
	ScopedBuffer<_allocator_t> buf(compressedLength);

	snappy::RawCompress(reinterpret_cast<const char*>(pbyData), nLen, reinterpret_cast<char*>(buf.Data()), &compressedLength);
	
	//
	bool bSend = false;

	// 찾아서 보내본다
	m_severid2serv.Exe(toServerId, [&bSend, toServiceType, &buf, &compressedLength, &fbbReq](__super_t::_shared_session_t& sess, const _servicetype_set_t& servs) {
		auto itr = servs.find(toServiceType);
		if (itr == servs.end())
			return;
		
		if (false == static_cast<const connector_session*>(static_cast<const __super_t::_session_t*>(sess))->IsLink())
			return;

		bSend = static_cast<connector_session*>(static_cast<__super_t::_session_t*>(sess))->PostSend(fbbReq.GetSize(), fbbReq.GetBufferPointer(), static_cast<int32_t>(compressedLength), buf.Data());
	});

	if (false == bSend)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_SEND);

	return nmsp::_NMSP_NOERROR;
}

int connector_impl::NotifyMessage(nmsp::connector::_serverid_t toServerId, unsigned short toServiceType, unsigned short fromServiceType, int nOption, int nLen, const unsigned char* pbyData, int nLen2, const unsigned char* pbyData2)
{
	if (true == m_isCoordinator)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_IS_NOT_CONNECTOR);

	// 초기화 전이라면
	if (nmsp::connector::SERVERID_NULL == m_serverid)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_INIT);

	// 자기자신에게 보내는 거라면 ?
	if (toServerId == m_serverid)
	{
		int nRet = nmsp::_NMSP_NOERROR;

		if (false == m_sinks.Exe(toServiceType, [&nRet, toServerId, toServiceType, fromServiceType, nOption, nLen, pbyData](nmsp::connector::IConnectorSink* pcSink) {
			nRet = pcSink->NotifiedMessage(toServerId, fromServiceType, nOption, nLen, pbyData);
		}))
		{
			nRet = nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_NO_SERVICETYPE);
		}

		return nRet;
	}

	flatbuffers::FlatBufferBuilder fbbReq(FLATBUFFER_INITIAL_SIZE, &m_flatbufferallocator);
	const auto _req = nmsp::connector::message::CreateMSG_C2C_DATA(fbbReq, toServiceType, fromServiceType, nOption);
	const auto _pkt = nmsp::connector::message::CreateConnectorPkt(fbbReq, nmsp::connector::message::ConnectorBodyAll::MSG_C2C_DATA, _req.Union());
	fbbReq.FinishSizePrefixed(_pkt);

	LOG_INFO(m_pcComponentImpl) << "NotifyMessage(2). toServerId=" << toServerId << ", toServiceType=" << toServiceType << ", fromServiceType=" << fromServiceType << ", Len=" << nLen;
	
	bool bSend = false;

	// 찾아서 보내본다
	m_severid2serv.Exe(toServerId, [&bSend, toServiceType, nLen, pbyData, nLen2, pbyData2, &fbbReq](__super_t::_shared_session_t& sess, const _servicetype_set_t& servs) {
		auto itr = servs.find(toServiceType);
		if (itr == servs.end())
			return;

		if (false == static_cast<const connector_session*>(static_cast<const __super_t::_session_t*>(sess))->IsLink())
			return;

		bSend = static_cast<connector_session*>(static_cast<__super_t::_session_t*>(sess))->PostSend(fbbReq.GetSize(), fbbReq.GetBufferPointer(), nLen, pbyData, nLen2, pbyData2);
	});

	if (false == bSend)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_SEND);

	return nmsp::_NMSP_NOERROR;
}

int connector_impl::NotifyPost(_serverid_t toServerId, int nOption, int nLen, const unsigned char* pchData)
{
	bool bSend = false;

	m_severid2serv.Exe(toServerId, [&bSend, nOption, nLen, pchData](__super_t::_shared_session_t& sess, const _servicetype_set_t& servs) {
		if (false == static_cast<const connector_session*>(static_cast<const __super_t::_session_t*>(sess))->IsLink())
			return;

		bSend = static_cast<connector_session*>(static_cast<__super_t::_session_t*>(sess))->Post(nOption, nLen, pchData);
	});

	if (false == bSend)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_POST);

	return nmsp::_NMSP_NOERROR;
}

int connector_impl::SetTimer(int id, int milisec)
{
	//IDLE_TIMER_ID는 내부에서 사용하므로
	if (IDLE_TIMER_ID == id)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_TIMER);

	// IDLE_TIMER_ID가 아닌것만 등록하도록 한다..
	if (false == __super_t::SetTimer(id, milisec))
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_TIMER);

	return nmsp::_NMSP_NOERROR;
}

int connector_impl::ResetTimer(int id)
{
	if (false == __super_t::ResetTimer(id))
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_TIMER);

	return nmsp::_NMSP_NOERROR;
}

int connector_impl::GetConnectorMessage(nmsp::connector::IConnectorMessage** ppiConnectorMessage)
{
	*ppiConnectorMessage = new _connector_message_impl_t(m_pcComponentImpl);
	if (nullptr == *ppiConnectorMessage)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_MEMORY);

	return nmsp::_NMSP_NOERROR;
}

int connector_impl::NotifyMessage(_serverid_t toServerId, unsigned short toServiceType, unsigned short fromServiceType, int nOption, nmsp::connector::IConnectorMessage* piConnectorMessage)
{
	if (piConnectorMessage == nullptr)
	{
		std::cout << "==================================================================================================================================" << std::endl;
		std::cout << "============================ connector_impl::NotifyMessage=piConnectorMessage is nullptr =========================================" << std::endl;
		std::cout << "==================================================================================================================================" << std::endl;
		return false;
	}

	nmsp::smartinterface<_connector_message_impl_t> cRefX = static_cast<_connector_message_impl_t*>(piConnectorMessage);

	// 초기화 전이라면
	if (nmsp::connector::SERVERID_NULL == m_serverid)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_INIT);

	// 자기자신에게 보내는 거라면 ?
	if (toServerId == m_serverid)
	{
		int nRet = nmsp::_NMSP_NOERROR;

		if (false == m_sinks.Exe(toServiceType, [this, &nRet, toServerId, fromServiceType, nOption, &cRefX](nmsp::connector::IConnectorSink* pcSink) {
			if (false == cRefX->LoopbackReset([this, &nRet, toServerId, fromServiceType, nOption, &cRefX, &pcSink](const unsigned char* pbyPkt, int nLen) { 
				nRet = pcSink->NotifiedMessage(toServerId, fromServiceType, nOption, nLen, pbyPkt); 
			}))
			{
				nRet = nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_NO_SERVICETYPE);
			}
		}))
		{
			nRet = nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_NO_SERVICETYPE);
		}

		return nRet;
	}

	//
	bool bSend = false;

	// 어디로부터 오는지..
	cRefX->SetInfo(toServiceType, fromServiceType, nOption);

	// 보내자!
	m_severid2serv.Exe(toServerId, [&bSend, &cRefX](__super_t::_shared_session_t& sess, const _servicetype_set_t& servs) {
		if (false == static_cast<const connector_session*>(static_cast<const __super_t::_session_t*>(sess))->IsLink())
			return;

		bSend = static_cast<connector_session*>(static_cast<__super_t::_session_t*>(sess))->PostSend(std::move(cRefX));
	});

	if (false == bSend)
		return nmsp::make_nmsp_error(m_pcComponentImpl->GetServiceType(), _CONNECTOR_ERROR_POST);

	return nmsp::_NMSP_NOERROR;
}

bool connector_impl::Process_SERVER_INFO(_serverid_t selfserverid, const flatbuffers::Vector<flatbuffers::Offset<nmsp::connector::message::SERVER_INFO>>* servers)
{
	// 자 접속할 서버들의 정보를 파악해 보자..
	// 계속 누적하자!!!
	for (auto itr = servers->begin(); itr != servers->end(); ++itr)
	{
		if (false == Process_SERVER_INFO(selfserverid, *itr))
			return false;
	}

	return true;
}

bool connector_impl::Process_SERVER_INFO(_serverid_t selfserverid, const nmsp::connector::message::SERVER_INFO* server)
{
	if (nullptr == server)
		return false;

	const auto address = server->address()->str();
	const auto port = server->port();
	const auto serverId = server->serverid();
	const auto groupID = server->group_id();
	const auto groupLayer = static_cast<nmsp::connector::group_layer>(server->group_layer());

	// serverid가 자신의 serverid보다 작다면 상대방이 접속 요청을 하는 것이므로.. 그냥 skip한다
	// 서버가 이미 이전에 존재하는 것과 같은 것이라면..
	if (selfserverid >= serverId || true == m_sess2serverinfo.Is(serverId))
	{
		return true;
	}

	// 새로운 것이라면
	boost::asio::ip::tcp::endpoint peerEndpoint;
	int nSlot;
	int nIdentity;
	_shared_session_t new_sess;

	try
	{
		peerEndpoint.address(boost::asio::ip::address::from_string(address.c_str()));
		peerEndpoint.port(port);

		if (false == __super_t::Allocate(nSlot, nIdentity, new_sess))
			return false;

		// serverid는 container에 등록하기 전에 설정하고 바꾸지 않는다..
		static_cast<connector_session*>(static_cast<__super_t::_session_t*>(new_sess))->SetServerId(serverId);
		static_cast<connector_session*>(static_cast<__super_t::_session_t*>(new_sess))->SetGroupID(groupID);
		static_cast<connector_session*>(static_cast<__super_t::_session_t*>(new_sess))->SetGroupLayer(groupLayer);

		// coordinator클라이언트로 동작하도록..
		static_cast<connector_session*>(static_cast<__super_t::_session_t*>(new_sess))->SetForSessionType(connector_session::SESSION_TYPE_C2C_CLIENT);

		// 연결을 시도해 봅시다..
		if (false == new_sess->PostConnect(peerEndpoint))
			return false;
	}
	catch (std::exception& e)
	{
		LOG_ERROR(m_pcComponentImpl) << "Process_SERVER_INFO :: " << e.what();
		return false;
	}

	if (false == m_sess2serverinfo.Add(nSlot, serverId, peerEndpoint, new_sess))
	{
		LOG_ERROR(m_pcComponentImpl) << "Process_SERVER_INFO :: DUP :: " << nSlot;
		return false;
	}

	return true;
}

bool connector_impl::GetServerInfo(_serverid_t serverid, std::string & addr, int32_t & port)
{
	if (serverid == m_serverid)
	{
		addr = static_cast<connector_config&>(*m_pcComponentImpl).GetServerAddress().c_str();
		port = static_cast<connector_config&>(*m_pcComponentImpl).GetServerListenPort();
		return true;
	}

	boost::asio::ip::tcp::endpoint dest;
	if (m_severid2serv.GetEndPoint(serverid, dest) == false)
		return false;

	addr = dest.address().to_string();
	port = dest.port();

	return true;
}


void connector_impl::SetTcpOption(connector_session& sess)
{
	try
	{
		boost::asio::ip::tcp::socket& sock = sess.GetSocket();

		// 수신버퍼
		{
			boost::asio::socket_base::receive_buffer_size option(static_cast<connector_config&>(*m_pcComponentImpl).GetMss());
			sock.set_option(option);
		}
		// 송신버퍼
		{
			boost::asio::socket_base::send_buffer_size option(static_cast<connector_config&>(*m_pcComponentImpl).GetBufferSize());
			sock.set_option(option);
		}
		// keep-alive
		{
			boost::asio::socket_base::keep_alive option(false);
			sock.set_option(option);
		}
		// nagle (true이면 값을 false로 false이면 true로 반전시켜야 한다.)
		{
			boost::asio::ip::tcp::no_delay option(!static_cast<connector_config&>(*m_pcComponentImpl).GetNagle());
			sock.set_option(option);
		}
		// max segment
		{
#if defined(_WIN32) || defined(_WIN64)
			boost::asio::detail::socket_option::integer<SOL_SOCKET, TCP_MAXSEG> maxSeg(static_cast<connector_config&>(*m_pcComponentImpl).GetMss());
#else
			boost::asio::detail::socket_option::integer<SOL_SOCKET, TCP_MSS> maxSeg(static_cast<connector_config&>(*m_pcComponentImpl).GetMss());
#endif
			sock.set_option(maxSeg);
		}
	}
	catch (const std::exception& e)
	{
		LOG_ERROR(m_pcComponentImpl) << "SetTcpOption error :: " << e.what();
	}
}

// wrapping이 필요하다
template <typename T>
bool connector_impl::MakeMSG_C2C_DATA(unsigned short toServiceType, unsigned short fromServiceType, int nOption, T& _t)
{
	flatbuffers::FlatBufferBuilder fbbReq(FLATBUFFER_INITIAL_SIZE, &m_flatbufferallocator);
	auto _req = nmsp::connector::message::CreateMSG_C2C_DATA(fbbReq, toServiceType, fromServiceType, nOption);
	auto _pkt = nmsp::connector::message::CreateConnectorPkt(fbbReq, nmsp::connector::message::ConnectorBodyAll::MSG_C2C_DATA, _req.Union());
	fbbReq.FinishSizePrefixed(_pkt);

	return _t(fbbReq.GetBufferPointer(), fbbReq.GetSize());
}
