﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 가능하면 이것 하나로..
#include "connectorbase.h"

//
connector_config::connector_config(connector_component_impl* pcComponentImpl)
	: m_pcComponentImpl(pcComponentImpl)
{
	m_bCoordinator = false;
	m_uiServerListenPort = SERVER_LISTENPORT;
	m_uiCoordinatorListenPort = COORDINATOR_LISTENPORT;
	m_byThreadCount = THREADCOUNT;
	m_nMaxAcceptSession = MAXACCEPTSESSION;
	m_nMss = MSS;
	m_nBufferSize = BUFFER_SIZE;
	m_bNagle = false;
	m_nKeepAliveTime = KEEPALIVE_PERIOD;
	m_nInitPoolCount = POOL_INIT_COUNT;
	m_nExtPoolCount = POOL_EXT_COUNT;
	m_nNormalPacketSize = NORMAL_PACKET_SIZE;
	m_bReuse = false;
	m_nConnectionCheckPeriod = CONNECTION_CHECK_PERIOD;
}

connector_config::~connector_config()
{
}

bool connector_config::Load(const char* pszConfig)
{
	try
	{
		boost::property_tree::ptree props;
		boost::property_tree::read_json(pszConfig, props);

		m_bCoordinator = props.get<bool>("is coordinator", false);

		// coordinator인 경우와 아닌 경우에 필요한 설정을 구분하려고..
		if (true == m_bCoordinator)
		{
			m_cRep = props.get<std::string>("repository");

			if (m_cRep.empty())
			{
				LOG_ERROR(m_pcComponentImpl) << "config:: repository " << m_cRep;
				return false;
			}
		}
		else
		{
			m_cServerAddress = props.get<std::string>("server address", "0.0.0.0");
			m_uiServerListenPort = props.get<int>("server listen port", SERVER_LISTENPORT);
			m_byThreadCount = props.get<int>("thread count", THREADCOUNT);										// coordinator인 경우는 무조건 1개..
			m_nConnectionCheckPeriod = props.get<int>("connection check period", CONNECTION_CHECK_PERIOD);
			m_groupID = props.get<int32_t>("group id", 0);
			m_groupLayer = props.get<int32_t>("group layer", 0);

			if (0 >= m_groupID || 0 >= m_groupLayer)
			{
				LOG_ERROR(m_pcComponentImpl) << "config:: invalid group id or group layer. group_id=" << m_groupID << ", group layer=" << m_groupLayer;
				return false;
			}

			if (0 >= m_byThreadCount)
			{
				LOG_ERROR(m_pcComponentImpl) << "config:: thread count " << m_byThreadCount;
				return false;
			}

			if (m_cServerAddress.empty())
			{
				LOG_ERROR(m_pcComponentImpl) << "config:: server address " << m_cServerAddress;
				return false;
			}

			if (0 >= m_nConnectionCheckPeriod)
			{
				LOG_ERROR(m_pcComponentImpl) << "config:: connection check period " << m_nConnectionCheckPeriod;
				return false;
			}
		}

		// 공통
		m_uiCoordinatorListenPort = props.get<int>("coordinator listen port", COORDINATOR_LISTENPORT);
		m_cCoordinatorAddress = props.get<std::string>("coordinator address", "0.0.0.0");
		m_nMaxAcceptSession = props.get<int>("max accept", MAXACCEPTSESSION);
		m_nMss = props.get<int>("mss", MSS);
		m_nBufferSize = props.get<int>("buffer size", BUFFER_SIZE);
		m_bNagle = props.get<bool>("nagle", false);
		m_nKeepAliveTime = props.get<int>("keep alive period", KEEPALIVE_PERIOD);
		m_nInitPoolCount = props.get<int>("pool init count", POOL_INIT_COUNT);
		m_nExtPoolCount = props.get<int>("pool expand count", POOL_EXT_COUNT);
		m_nNormalPacketSize = props.get<int>("normal packet size", NORMAL_PACKET_SIZE);
		m_bReuse = props.get<bool>("server port reuse", false);

		if (0 >= m_nMaxAcceptSession)
		{
			LOG_ERROR(m_pcComponentImpl) << "config:: max accept " << m_nMaxAcceptSession;
			return false;
		}

		if (0 >= m_nMss)
		{
			LOG_ERROR(m_pcComponentImpl) << "config:: mss " << m_nMss;
			return false;
		}

		if (0 > m_nKeepAliveTime)
		{
			LOG_ERROR(m_pcComponentImpl) << "config:: keep alive period " << m_nKeepAliveTime;
			return false;
		}

		if (0 >= m_nInitPoolCount)
		{
			LOG_ERROR(m_pcComponentImpl) << "config:: pool init count " << m_nInitPoolCount;
			return false;
		}

		if (0 >= m_nExtPoolCount)
		{
			LOG_ERROR(m_pcComponentImpl) << "config:: pool expand count " << m_nExtPoolCount;
			return false;
		}

		if (0 >= m_nNormalPacketSize)
		{
			LOG_ERROR(m_pcComponentImpl) << "config:: normal packet size " << m_nNormalPacketSize;
			return false;
		}
	}
	catch (const std::exception& e)
	{
		LOG_ERROR(m_pcComponentImpl) << "config:: exception " << e.what();
		return false;
	}

	LOG_INFO(m_pcComponentImpl) << "config:: ok ";
	return true;
}
