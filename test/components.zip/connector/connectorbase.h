﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __CONNECTORBASE_H__
#define __CONNECTORBASE_H__

// component implementation class
class connector_component_impl;
// config
class connector_config;
// 
class connector_impl;

// 컴포넌트 내부에서 사용할 오류 정의
enum _CONNECTOR_ERROR_T
{
	_CONNECTOR_ERROR_INVALID_INTERFACE_REQ	= 1,
	_CONNECTOR_ERROR_CONFIG					= 2,
	_CONNECTOR_ERROR_IMPL_INIT				= 3,
	_CONNECTOR_ERROR_MEMORY					= 4,
	_CONNECTOR_ERROR_DUP_SINK_INTERFACE		= 5,
	_CONNECTOR_ERROR_NO_SINK_INTERFACE		= 6,
	_CONNECTOR_ERROR_INIT					= 7,
	_CONNECTOR_ERROR_SEND					= 8,
	_CONNECTOR_ERROR_IS_NOT_CONNECTOR		= 9,
	_CONNECTOR_ERROR_NO_SERVICETYPE			= 10,
	_CONNECTOR_ERROR_POST					= 11,
	_CONNECTOR_ERROR_TIMER					= 12,
	_CONNECTOR_ERROR_INIT_LOG				= 13,
	_CONNECTOR_ERROR_INVALID_MESSAGE		= 14,
	_CONNECTOR_ERROR_INVALID_SERVERID		= 15,
};


// 항상 component instance를 필요로 한다..
#define LV_TRACE	nmsp::logger::lv::trace
#define LV_DEBUG	nmsp::logger::lv::debug
#define LV_INFO		nmsp::logger::lv::info
#define LV_WARNING	nmsp::logger::lv::warning
#define LV_ERROR	nmsp::logger::lv::error
#define LV_FATAL	nmsp::logger::lv::fatal

#define LOG_TRACE(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_TRACE) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_DEBUG(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_DEBUG) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_INFO(component)				BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_INFO) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_WARNING(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_WARNING) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_ERROR(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_ERROR) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["
#define LOG_FATAL(component)			BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_FATAL) << __FUNCTION__ << "(" << __LINE__ << ")][" << component->GetServiceType() << "]["

#if defined(_WIN32) || defined(_WIN64)

#pragma warning(disable : 4819)
#pragma warning(error : 4715)

#ifdef _DEBUG
#define DEBUG_NEW   new( _NORMAL_BLOCK, __FILE__, __LINE__)
#else
#define DEBUG_NEW
#endif 

#define _CRTDBG_MAP_ALLOC 
#include <stdlib.h> 
#include <crtdbg.h>

#endif

//
////////////////////////////////////////////////////////////////////////////////
//
#include <atomic>
#include <string>
#include <map>
#include <list>
#include <vector>
#include <unordered_map>
#include <thread>
#include <shared_mutex>
#include <assert.h>
#include <iostream>
#include <set>
#include <functional>
#include <boost/property_tree/json_parser.hpp>
#include <boost/asio.hpp>
#include "snappy.h"

#if defined(_WIN32) || defined(_WIN64)
#include <windows.h>
#endif

////////////////////////////////////////////////////////////////////////////////
// ours include
#include "nmsputil.h"
#include "nmspInterface.h"
#include "nmspsmart.h"
#include "nmsperror.h"
#include "nmspmemallocate.h"
#include "nmspmemchunk.h"
#include "nmspmmgrchunk.h"
#include "nmspcomponentmain.h"
#include "nmspnewfrompool.h"
#include "nmspmemorypool.h"
#include "nmspnet.h"
#include "nmsplogger.h"

#ifdef _DEBUG
using _allocator_t = nmsp::default_allocator;
#else
using _allocator_t = nmsp::pool::allocator_from_pool<>;
#endif

template <typename _Ty>
using _stl_allocator_t = nmsp::stl_default_allocator<_Ty, _allocator_t>;

////////////////////////////////////////////////////////////////////////////////
// 인터페이스..
#include "loginterface.h"
#include "connectorinterface.h"
#include "servicetypedef.h"

////////////////////////////////////////////////////////////////////////////////
// 구현 의존적인 것임
#include "protocol\connector_generated.h"

#include "connectorrep.h"
#include "connectorconfig.h"
#include "connectormessage.h"
#include "connectorimpl.h"
#include "connector.h"

#endif
