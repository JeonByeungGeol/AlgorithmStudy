﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __CONNECTOR_H__
#define __CONNECTOR_H__

//
class connector_component_impl: public nmsp::IComponent
{
public:
	connector_component_impl();
	virtual ~connector_component_impl();

	virtual int QueryInterface(const nmsp::UUID* iid, void** pInterface) override;
	virtual int AddRef(void) override;
	virtual int Release(void) override;
	virtual int SetBaseInfo(unsigned short uiServiceType, nmsp::IComponentContainer* pISink, int nLenPath, const char* pszCfgPath, int logLevel, bool outConsole, const char* timeZoneName) override;
	virtual int PreInit() override;
	virtual int Init() override;
	virtual void Uninit() override;
	virtual void PostUninit() override;
	//
	inline unsigned short GetServiceType() const
	{
		return m_uiSelf;
	}
	inline operator connector_repository_ctrl& ()
	{
		return m_cRep;
	}
	inline operator connector_config& ()
	{
		return m_cConfig;
	}
	inline operator nmsp::IComponentContainer* ()
	{
		return m_cRefContainer;
	}
	inline operator connector_impl& ()
	{
		return m_cConnectorImpl;
	}
	inline operator nmsp::log::ILog* ()
	{
		return m_cRefLog;
	}
	inline operator nmsp::logger::logger& ()
	{
		return *m_logger;
	}

private:
	std::atomic_int m_nRefs;
	unsigned short m_uiSelf;
	std::string m_cstrCfgPath;
	nmsp::logger::lv::severity_level m_logLevel;
	bool m_outConsole = false;

	nmsp::smartinterface<nmsp::IComponentContainer> m_cRefContainer;
	nmsp::smartinterface<nmsp::log::ILog> m_cRefLog;
	connector_config m_cConfig;
	connector_repository_ctrl m_cRep;
	connector_impl m_cConnectorImpl;
	bool m_bLogInit;
	static std::shared_ptr<nmsp::logger::logger> m_logger;
};

#endif
