﻿#include "httpbase.h"


httpclient::httpclient(http_component_impl* component)
	:m_component(component)
{

}
void httpclient::Start(nmsp::smartinterface<nmsp::http::IRequest> request, nmsp::smartinterface<nmsp::http::IResponse> response, const uint32_t& timeOutMilliSeconds)
{
	auto ConvertWstr = [](std::string& str) -> std::wstring {
		std::wstring wstr;
		wstr.assign(str.begin(), str.end());
		return wstr;
	};

	auto ConvertStr = [](std::wstring& wstr) -> std::string {
		std::string str;
		str.assign(wstr.begin(), wstr.end());
		return str;
	};

	std::ostringstream message;

	std::string schema = request->Schema();
	std::string method = request->Method();
	std::string path = request->Path();
	std::string host = request->Host();
	std::wstring body = request->Body();
	std::string port = std::to_string(request->Port());

	// setting
	web::http::client::http_client_config config;

	web::http::uri_builder uri;
	uri.set_scheme(ConvertWstr(schema));	// http https
	uri.set_host(ConvertWstr(host));		// host
	if (0 != port.compare("80"))			// port if only not 80
	{
		uri.set_port(ConvertWstr(port));
	}
	uri.set_path(ConvertWstr(path));		//	path

	if (0 == method.compare("GET"))			// param if only GET method
	{
		uri.set_query(body);
	}

	// timeout
	std::chrono::milliseconds timeout(timeOutMilliSeconds);
	if (timeout.count() > 0)
	{
		config.set_timeout(timeout);
	}

	try
	{
		web::http::client::http_client client(uri.to_string(), config);

		if (method == "POST")
		{
			client.request(web::http::methods::POST, L"", web::uri::encode_uri(body), L"application/x-www-form-urlencoded")
			.then([this, request, response](pplx::task<web::http::http_response> t)
			{
				try
				{
					return t.get();
				}
				catch (web::json::json_exception & je)
				{
					exception(request, response, 5, je.what());
					return web::http::http_response{};
				}
				catch (std::exception & ex)
				{
					exception(request, response, 5, ex.what());
					return web::http::http_response{};
				}
				catch (...)
				{
					exception(request, response, 5, "Unknown error while reaching the stormancer API server.");
					return web::http::http_response{};
				}
			})
			
			.then([this, request, response](web::http::http_response resp)
			{
				if (false == response->IsException())
				{
					process(request, response, resp);
				}	
			});
		}
		else if (method == "GET")
		{
			client.request(web::http::methods::GET)
			.then([this, request, response](pplx::task<web::http::http_response> t)
			{
				try
				{
					return t.get();
				}
				catch (web::json::json_exception & je)
				{
					exception(request, response, 5, je.what());
					return web::http::http_response{};
				}
				catch (std::exception & ex)
				{
					exception(request, response, 5, ex.what());
					return web::http::http_response{};
				}
				catch (...)
				{
					exception(request, response, 5, "Unknown error while reaching the stormancer API server.");
					return web::http::http_response{};
				}
			})
				
			.then([this, request, response](web::http::http_response resp)
			{
				if (false == response->IsException())
				{
					process(request, response, resp);
				}
			});
		}
		else
		{
			exception(request, response, 1, "not exist method define.");
		}
	}

	catch (web::json::json_exception & je)
	{
		exception(request, response, 1, je.what());
	}
	catch (std::exception & ex)
	{
		exception(request, response, 1, ex.what());
	}
	catch (...)
	{
		exception(request, response, 1, "Unknown error while reaching the stormancer API server.");		
	}
}

void httpclient::process(nmsp::smartinterface<nmsp::http::IRequest> request, nmsp::smartinterface<nmsp::http::IResponse> response, web::http::http_response resp)
{
	if (response->IsException())
	{
		// 예외가 발생했을 때 이곳을 타면 비정상 상황
		LOG_ERROR(m_component) << "httpclient error. host=" << request->Host();/* << ", body=" << request->Body();*/
		return;
	}

	std::ostringstream message;

	auto status = resp.status_code();
	if (web::http::status_codes::OK != status)
	{
		message.clear();
		message << "Error: " << "status=" << status << "\n";
		LOG_ERROR(m_component) << "response failed. status=" << static_cast<int32_t>(status);
		close(request, response, 3, message.str());
		return;
	}

	auto wstrBody = resp.extract_string().get();
	std::string body;
	body.assign(wstrBody.begin(), wstrBody.end());
	message << body;
	close(request, response, 0, message.str());
}

void httpclient::exception(nmsp::smartinterface<nmsp::http::IRequest> request, nmsp::smartinterface<nmsp::http::IResponse> response, int error, std::string message)
{
	response->Exception(true);

	std::ostringstream oss;
	oss.clear();
	oss << "error="  << error << "msg=" << message << "\n";

	LOG_ERROR(m_component) << oss.str();
	close(request, response, error, oss.str());
}

void httpclient::close(nmsp::smartinterface<nmsp::http::IRequest> request, nmsp::smartinterface<nmsp::http::IResponse> response, int error, std::string message)
{
	if (nullptr != response)
	{
		response->Process(request, error, message.c_str());
	}
}