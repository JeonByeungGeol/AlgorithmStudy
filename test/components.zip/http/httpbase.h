﻿////////////////////////////////////////////////////////////////////////////////
// 작성:
// 설명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __HTTPCLIENTBASE_H__
#define __HTTPCLIENTBASE_H__

#ifndef WINVER // Allow use of features specific to Windows 95 and Windows NT 4 or later.
#define WINVER 0x0601 // Change this to the appropriate value to target Windows 98 and Windows 2000 or later.
#endif

#ifndef _WIN32_WINNT // Allow use of features specific to Windows NT 4 or later.
#define _WIN32_WINNT 0x0601 // Change this to the appropriate value to target Windows 98 and Windows 2000 or later.
#endif

#ifndef _WIN32_WINDOWS // Allow use of features specific to Windows 98 or later.
#define _WIN32_WINDOWS 0x0601 // Change this to the appropriate value to target Windows Me or later.
#endif

#if defined(_WIN32) || defined(_WIN64)
#pragma warning(disable : 4819 4244 4267)
#endif

///
#ifdef _DEBUG
#define DEBUG_NEW   new( _NORMAL_BLOCK, __FILE__, __LINE__)
#else
#define DEBUG_NEW
#endif 

#define _CRTDBG_MAP_ALLOC 
#include <stdlib.h> 
#include <crtdbg.h>

//
////////////////////////////////////////////////////////////////////////////////
//
#include <atomic>
#include <string>
#include <map>
#include <set>
#include <list>
#include <vector>
#include <unordered_map>
#include <thread>
#include <shared_mutex>
#include <assert.h>
#include <iostream>
#include <istream>
#include <fstream>
#include <ostream>
#include <chrono>
#include <future>

// boost
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/json_parser.hpp>
#include <boost/property_tree/ptree_fwd.hpp>
#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <boost/thread.hpp>

// cpprest
#include <cpprest/http_client.h>
#include <cpprest/filestream.h>

#if defined(_WIN32) || defined(_WIN64)
#include <windows.h>
#ifdef min
#undef min
#endif

#ifdef max
#undef max
#endif
#else
#endif

////////////////////////////////////////////////////////////////////////////////
// ours include
#include "nmspinterface.h"
#include "nmspsmart.h"
#include "nmsperror.h"
#include "nmsplogger.h"
#include "nmbsdkinterface.h"
#include "nmspmemallocate.h"
#include "nmspmmgrchunk.h"
#include "nmspcomponentmain.h"
#include "nmspnewfrompool.h"
#include "nmspmemorypool.h"

////////////////////////////////////////////////////////////////////////////////
// 인터페이스
#include "timerinterface.h"
#include "servicetypedef.h"
#include "loginterface.h"
#include "httpinterface.h"

////////////////////////////////////////////////////////////////////////////////
// 내부에서 전역적으로 사용할 것들을 정의한다

// component implementation class
class http_component_impl;

// 컴포넌트 내부에서 사용할 오류 정의
enum _ERROR_T
{
	_ERROR_INVALID_INTERFACE_REQ = 1,
	_ERROR_ALREADY_SINK_INTERFACE = 2,	// SINK인터페이스가 이미 설정되어 있다.
	_ERROR_CONFIG = 3,
	_ERROR_INIT_SESSIONS = 4,
	_ERROR_OUT = 5,
	_ERROR_CLOSE = 6,
	_ERROR_POST = 7,
	_ERROR_TIMER = 8,
	_ERROR_MEMORY = 9,
	_ERROR_INIT_LOG = 10,
	_ERROR_ASSEMBLE = 11,
};

//  항상 component instance를 필요로 한다.
#define LV_TRACE	nmsp::logger::lv::trace
#define LV_DEBUG	nmsp::logger::lv::debug
#define LV_INFO		nmsp::logger::lv::info
#define LV_WARNING	nmsp::logger::lv::warning
#define LV_ERROR	nmsp::logger::lv::error
#define LV_FATAL	nmsp::logger::lv::fatal

#define LOG_TRACE(component) BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_TRACE) << __FUNCTION__ << "(" << __LINE__ << ")]"
#define LOG_DEBUG(component) BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_DEBUG) << __FUNCTION__ << "(" << __LINE__ << ")]"
#define LOG_INFO(component) BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_INFO) << __FUNCTION__ << "(" << __LINE__ << ")]"
#define LOG_WARNING(component) BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_WARNING) << __FUNCTION__ << "(" << __LINE__ << ")]"
#define LOG_ERROR(component) BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_ERROR) << __FUNCTION__ << "(" << __LINE__ << ")]"
#define LOG_FATAL(component) BOOST_LOG_SEV(static_cast<nmsp::logger::logger&>(*component), LV_FATAL) << __FUNCTION__ << "(" << __LINE__ << ")]"

#ifdef _DEBUG
using _http_allocator_t = nmsp::default_allocator;
#else
using _http_allocator_t = nmsp::pool::allocator_from_pool<>;
#endif

// 
#ifndef ENUM_INT
#define ENUM_INT(value) (static_cast<int32_t>(value))
#endif // ENUM_INT

////////////////////////////////////////////////////////////////////////////////
//  구현 의존적인 것임
#include "timersinkimpl.h"
#include "httpclient.h"
#include "httpclientthread.h"
//#include "httpclientimpl.h"
#include "http.h"

#endif


