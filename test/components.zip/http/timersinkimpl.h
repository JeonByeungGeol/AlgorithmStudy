#pragma once

class timer_sink_impl : public nmsp::timer::ITimerSink
{
public:
	timer_sink_impl(http_component_impl* componentImpl);
	virtual ~timer_sink_impl();

	virtual int QueryInterface(const nmsp::UUID* iid, void** pInterface);
	virtual int AddRef(void) override;
	virtual int Release(void) override;
	virtual int OnTimer(
		const nmsp::timer::_TIMER_KEY_T& tkTimerKey,
		const nmsp::timer::_TIMER_REL_KEY_T& rkVal,
		const nmsp::timer::_TIMER_VALUE_T& _tvCurrTime,
		const nmsp::timer::_TIMER_VALUE_T& _tvFixedCurrTime,
		const nmsp::timer::_TIMER_VALUE_T& _tvElapsedTime,
		const nmsp::timer::_TIMER_VALUE_T& _tvScaleCurrTime) override;

	inline const nmsp::timer::_TIMER_VALUE_T& GetFixedCurrTime() const
	{
		return m_tvFixedCurrTime;
	}

private:
	nmsp::timer::_TIMER_VALUE_T m_tvFixedCurrTime;
	nmsp::timer::_TIMER_VALUE_T m_tvLastServerInfoSync;
	http_component_impl* m_componentImpl;
};