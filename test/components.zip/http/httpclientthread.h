﻿#pragma once

//////////////////////////////////////////////////////////////////////////

// http 통신을 담당하는 기반 클래스
//
class httpclient_thread : public nmsp::http::IHttpClient
{
	using _allocator_t = _http_allocator_t;
	using _httpclient_ptr_t = std::shared_ptr<httpclient>;

	using task_t = boost::packaged_task<void>;

public:
	explicit httpclient_thread(http_component_impl* component);
	virtual ~httpclient_thread();

	virtual int QueryInterface(const nmsp::UUID* iid, void** pInterface) override; 
	virtual int AddRef(void) override;
	virtual int Release(void) override;

	virtual void Init(int threadCount, int sessionPoolCount);
	virtual void Uninit();
	virtual bool Request(nmsp::http::IRequest* request, nmsp::http::IResponse* response, const uint32_t& timeOutMilliSeconds = 0);
	
private:
	_httpclient_ptr_t m_httpClient;

	http_component_impl* m_component;
};



