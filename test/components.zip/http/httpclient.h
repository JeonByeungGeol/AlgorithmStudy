﻿#pragma once

class httpclient : public nmsp::new_from_pool<_http_allocator_t>
{
public:
	httpclient(http_component_impl* component);
	
	void Start(nmsp::smartinterface<nmsp::http::IRequest> request, nmsp::smartinterface<nmsp::http::IResponse> response, const uint32_t& timeOutMilliSeconds);
	
private:
	void process(nmsp::smartinterface<nmsp::http::IRequest> request, nmsp::smartinterface<nmsp::http::IResponse> response, web::http::http_response resp);

	void close(nmsp::smartinterface<nmsp::http::IRequest> request, nmsp::smartinterface<nmsp::http::IResponse> response, int error, std::string message);

	void exception(nmsp::smartinterface<nmsp::http::IRequest> request, nmsp::smartinterface<nmsp::http::IResponse> response, int error, std::string message);

private:
	http_component_impl* m_component;
};
