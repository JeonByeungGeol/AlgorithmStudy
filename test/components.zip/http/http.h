﻿////////////////////////////////////////////////////////////////////////////////
// 설명: 
//
//

// 호환성을 위해서..
#pragma once
#ifndef __HTTP_CLIENT_H__
#define __HTTP_CLIENT_H__

class http_component_impl : public nmsp::IComponent
{
public:
	http_component_impl();
	virtual ~http_component_impl();

	virtual int QueryInterface(const nmsp::UUID* iid, void** pInterface) override;
	virtual int AddRef(void) override;
	virtual int Release(void) override;
	virtual int SetBaseInfo(unsigned short uiServiceType, nmsp::IComponentContainer* pISink, int nLenPath, const char* pszCfgPath, int logLevel, bool outConsole, const char* timeZoneName) override;
	virtual int PreInit() override;
	virtual int Init() override;
	virtual void Uninit() override;
	virtual void PostUninit() override;

	inline unsigned short GetServiceType() const { return m_uiSelf; }
	inline operator nmsp::log::ILog* () { return m_cRefLog; }
	inline operator nmsp::logger::logger& () { return m_logger; }

private:
	std::atomic_int m_nRefs;
	uint16_t m_uiSelf;
	std::string m_cstrCfgPath;
	nmsp::logger::lv::severity_level m_logLevel;
	bool m_outConsole;

	nmsp::smartinterface<nmsp::IComponentContainer> m_cRefContainer;
	nmsp::smartinterface<nmsp::log::ILog> m_cRefLog;
	nmsp::smartinterface<nmsp::timer::ITimer> m_cRefTimer;

	timer_sink_impl m_timerSinkImpl;
	nmsp::timer::_TIMER_KEY_T m_timerKey;
	bool m_bRegTimer;

	httpclient_thread m_httpClientThread;

	nmsp::logger::logger m_logger;
};


#endif
