﻿#include "httpbase.h"

// 이 정의가 꼭 필요하다..
IMPLEMENT_NMSPMODULE(http_component_impl)

http_component_impl::http_component_impl()
	: m_nRefs(1)
	, m_uiSelf(nmsp::_NMSP_RESERVED_SERVICETYPE_NULL)
	, m_bRegTimer(false)
	, m_timerSinkImpl(this)
	, m_httpClientThread(this)
	, m_outConsole(false)
{

}

http_component_impl::~http_component_impl()
{
	if (nullptr != m_cRefLog)
		m_cRefLog = nullptr;
}

int http_component_impl::QueryInterface(const nmsp::UUID* iid, void** pInterface)
{
	// 모든 정의된 인터페이스에서는 어떤 다른 인터페이스라도 QueryInterface가 성공해야 한다
	// 이 Component에서 지원하는 인터페이스를 다 모아놓았음.
	if (*iid == nmsp::UUID_IComponentBase)
	{
		*pInterface = static_cast<nmsp::IComponentBase*>(this);
		reinterpret_cast<nmsp::IComponentBase*>(*pInterface)->AddRef();
		return nmsp::_NMSP_NOERROR;
	}
	else if (*iid == nmsp::UUID_IComponent)
	{
		*pInterface = static_cast<nmsp::IComponent*>(this);
		reinterpret_cast<nmsp::IComponent*>(*pInterface)->AddRef();
		return nmsp::_NMSP_NOERROR;
	}
	else if (*iid == nmsp::http::UUID_IHttpClient)
	{
		return m_httpClientThread.QueryInterface(iid, pInterface);
	}
	
	return nmsp::make_nmsp_error(m_uiSelf, _ERROR_INVALID_INTERFACE_REQ);
}

int http_component_impl::AddRef(void)
{
	return ++m_nRefs;
}

int http_component_impl::Release(void)
{
	int32_t nLastRef = --m_nRefs;
	if (0 == nLastRef)
	{
		delete this;
		return 0;
	}

	return nLastRef;
}

int http_component_impl::SetBaseInfo(unsigned short uiServiceType, nmsp::IComponentContainer* pISink, int nLenPath, const char* pszCfgPath, int logLevel, bool outConsole, const char* timeZoneName)
{
	m_uiSelf = uiServiceType;

	int nRet = pISink->QueryInterface(&nmsp::UUID_IComponentContainer, static_cast<void**>(m_cRefContainer));
	if (nmsp::_NMSP_NOERROR != nRet)
		return nRet;

	// 설정
	m_cstrCfgPath.assign(pszCfgPath, nLenPath);

	m_logLevel = static_cast<nmsp::logger::lv::severity_level>(logLevel);
	m_outConsole = outConsole;

	return nmsp::_NMSP_NOERROR;
}

int http_component_impl::PreInit()
{
	// 다른 컴포넌트들을 참조해 봅시다
	int nRet = m_cRefContainer->QueryComponent(nmsp::_SERVICETYPE_LOG, &nmsp::log::UUID_ILog, static_cast<void**>(m_cRefLog));
	if (nmsp::_NMSP_NOERROR != nRet)
		return nRet;

	// 로그를 초기화 한다
	if (false == m_logger.init(m_uiSelf, m_cRefLog, m_logLevel, "", m_outConsole))
		return nmsp::make_nmsp_error(m_uiSelf, _ERROR_INIT_LOG);

	return nmsp::_NMSP_NOERROR;
}

int http_component_impl::Init()
{
	// 다른 컴포넌트들을 참조해 봅시다
	auto nRet = m_cRefContainer->QueryComponent(nmsp::_SERVICETYPE_TIMER, &nmsp::timer::UUID_ITimer, static_cast<void**>(m_cRefTimer));
	if (nmsp::_NMSP_NOERROR != nRet)
		return nRet;

	// 타이머를 등록
	nRet = m_cRefTimer->RegTimer(&m_timerKey, 0, &m_timerSinkImpl);
	if (nmsp::_NMSP_NOERROR != nRet)
		return nRet;

	m_bRegTimer = true;

	return nmsp::_NMSP_NOERROR;
}

void http_component_impl::Uninit()
{
	// 타이머가 발생하지 않도록 한다
	if (nullptr != m_cRefTimer)
	{
		if (m_bRegTimer)
		{
			m_cRefTimer->UnregTimer(m_timerKey);
			m_bRegTimer = false;
		}

		m_cRefTimer = nullptr;
	}
}

void http_component_impl::PostUninit()
{

}
