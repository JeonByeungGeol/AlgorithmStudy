﻿#include "httpbase.h"

httpclient_thread::httpclient_thread(http_component_impl* component)
	: m_component(component)
{
}

httpclient_thread::~httpclient_thread()
{
}

int httpclient_thread::QueryInterface(const nmsp::UUID* iid, void** pInterface)
{
	*pInterface = static_cast<nmsp::http::IHttpClient*>(this);
	reinterpret_cast<nmsp::http::IHttpClient*>(*pInterface)->AddRef();
	return nmsp::_NMSP_NOERROR;
}

int httpclient_thread::AddRef(void)
{
	return m_component->AddRef();
}

int httpclient_thread::Release(void)
{
	return m_component->Release();
}

void httpclient_thread::Init(int threadCount, int sessionPoolCount)
{
	m_httpClient = std::make_shared<httpclient>(m_component);
}

void httpclient_thread::Uninit()
{
}

bool httpclient_thread::Request(nmsp::http::IRequest* request, nmsp::http::IResponse* response, const uint32_t& timeOutMilliSeconds/* = 0*/)
{
	m_httpClient->Start(request, response, timeOutMilliSeconds);

	return true;
}

