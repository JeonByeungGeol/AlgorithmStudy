﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

/* 
// node type 은 
// sequence				-> 여러개의 하위 노드를 가질 수 있다. and 연산
// selector				-> 여러개의 하위 노드를 가질 수 있다. or 연산
// randomsequence		-> 여러개의 하위 노드를 가질 수 있다. and 연산 (불규칙한 실행 순서)
// randomselector		-> 여러개의 하위 노드를 가질 수 있다. or 연산 (불규칙한 실행 순서)
// parallel				-> 여러개의 하위 노드를 가질 수 있다. 동시에 실행 (n개의 child중 일정 갯수 이상이면 성공 리턴)
// inverter				-> 하나의 하위 노드를 가질 수 있다. not 연산 (child의 처리 결과를 반대로 만듦)
// succeeder			-> 하나의 하위 노드를 가질 수 있다. (항상 성공)
// repeater				-> 하나의 하위 노드를 가질 수 있다. (일정 횟수 이상 반복)
// failer				-> 하나의 하위 노드를 가질 수 있다. (항상 실패)
// untilfailer			-> 하나의 하위 노드를 가질 수 있다. (실패할 때까지 실행)
// untilsucceeder		-> 하나의 하위 노드를 가질 수 있다. (성공할 때까지 실행)
// condition			-> 1 ~ 2개의 하위 노드를 가질 수 있다 (if 같은) -- (함수 실행)
// randomcondition		-> 1 ~ 2개의 하위 노드를 가질 수 있다 (if 같은) -- (함수 실행)
// timelimit			-> 하나의 하위 노드를 가질 수 있다. (시작후 일정 시간동안 하위노드가 실행하기를 기다리다 시간이 모두 경과하면 강제 종료한다)
// cooldown				-> 하나의 하위 노드를 가질 수 있다. (시작후 일정 시간동안 하위노드가 실행되는 것을 막는다.)
// task					-> 하위 노드를 가질 수 없다. (moveTo, Search, Skill, Spawn, Wait, RunAway, DistanceTo, ...)
// service				-> (sequence/selector/parallel/random sequence/random selector)등에 추가 기능으로 add-on 됨
// message				-> message 수신
// call					-> sub module 호출
// submodule			-> sub module root
// once					-> child node를 한번만 실행하도록 한다.

// child nodes 를 가짐 나머지는 child node
//sequence
//selector
//randomsequence
//randomselector
//parallel
//condition
//randomcondition
//service

//----------------------------call example
{
	"node name" : "xxxxxx",
	"group name" : "npc",
	"parent name" : "",
	"node type" : "call",
	"submodule" : "xxxxxxxxxx",
	"input values" : [{ "scope": "const", "name" : "there", "type":"vector", "value": [10.1, 11.1, 12.1 ] }]
}


//----------------------------submodule example
{
	"node name" : "xxxxxx",
	"group name" : "npc",
	"is root" : true,
	"node type" : "submodule",
	"input values" : [{ "scope": "local", "name" : "there", "type":"vector"}],
	"child node": "wait"
}


//----------------------------once example
{
"node name" : "xxxxxx",
"group name" : "npc",
"node type" : "once",
"child node": "wait"
}


//----------------------------sequence example
{
	"node name" : "xxxxxx",
	"group name" : "npc",
	"parent name" : "",
	"node type" : "sequence",
}

//----------------------------selector example
{
	"node name" : "xxxxxx",
	"group name" : "npc",
	"parent name" : "",
	"node type" : "selector",
}

//----------------------------random sequence example
{
	"node name" : "xxxxxx",
	"group name" : "npc",
	"parent name" : "",
	"node type" : "random sequence",
}

//----------------------------random selector example
{
	"node name" : "xxxxxx",
	"group name" : "npc",
	"parent name" : "",
	"node type" : "random selector",
}

//----------------------------parallel example
{
	"node name" : "xxxxxx",
	"group name" : "npc",
	"parent name" : "",
	"node type" : "parallel",
	"success count" : 10, 
}

//----------------------------task example
// scope는 
// "global"		-> 글로벌 blackboard에 존재하는 값
// "member"		-> 실행 주체의 영역에만 존재하는 값
// "const"		-> 글로벌 상수 테이블에 존재하는 값
// "local"		-> 서브모듈에서 존재하는 값
// ------
// input / output의 type은
// vector, tile, float, double, int8_t, int16_t, int32_t, int64_t, object,가 존재한다.
// input type으로 object type은 작성시에 지정할 수 없다
// ------
// function type은 
// 
{
	"node name" : "sel1",
	"group name" : "npc",
	"parent name" : "xxxxxx",
	"node type" : "task",
	"zoneid" : "xxx",
	"function type" : "moveTo",
	"input values" : [{ "scope": "member", "name" : "there", "type":"vector", "value": [10.1, 11.1, 12.1 ] }],
	"output value" : { "scope": "member", "name" : "there", "type":"vector" } 
}

//----------------------------condition example
// operator는
{
	"node name" : "xxxxxx",
	"group name" : "npc",
	"parent name" : "",
	"node type" : "condition",
	"input values" : [{ "scope": "member", "name" : "there", "type":"vector", "value": [10.1, 11.1, 12.1 ] }],
	"child nodes": [
	"sequence_2E2F81CA483EE531860CC4AAEC229DE8_test14",
	"task_2BA7938546B88B6885D118AD881283DD_test14"
	]
}

//----------------------------message example
{
	"node name" : "xxxxxx",
	"group name" : "npc",
	"parent name" : "",
	"node type" : "message",
	"message id" : 10,
	"child node": "wait"
}

// 전체 구조
{
	"behavior nodes" : [
		{
			"node name" : "xxxxxx",
			"group name" : "npc1"
		},
		{
			"node name" : "xxxxxx",
			"group name" : "npc2"
		}
	]
}

*/

// 호환성을 위해서..
#pragma once
#ifndef __BEHAVIORIMPL_H__
#define __BEHAVIORIMPL_H__

////////////////////////////////////////////////////////////////////////////////
// 내부에서 사용하는.. 정의들
// type
enum class BehaviorType : char
{
	BehaviorType_None = 0,
	BehaviorType_Sequence,						// composite
	BehaviorType_Selector,						// composite
	BehaviorType_RandomSequence,				// composite
	BehaviorType_RandomSelector,				// composite
	BehaviorType_Parallel,						// composite
	BehaviorType_Inverter,						// decorator
	BehaviorType_Succeeder,						// decorator
	BehaviorType_Repeater,						// decorator
	BehaviorType_Failer,						// decorator
	BehaviorType_UntilFailer,					// decorator
	BehaviorType_UntilSucceeder,				// decorator
	BehaviorType_Condition,						// decorator
	BehaviorType_RandomCondition,				// decorator
	BehaviorType_TimeLimit,						// decorator
	BehaviorType_CoolDown,						// decorator
	BehaviorType_Service,						// service
	BehaviorType_Task,							// leaf				(함수들을 만든다, moveTo, Search, Attack, Spawn, Wait, DistanceTo)
	BehaviorType_Message,						// message
	BehaviorType_Call,							// leaf
	BehaviorType_SubModule,						// root
	BehaviorType_Once,							// decorator
};

//enum class BehaviorTask : short
//{
//	BehaviorTask_None = 0,
//	BehaviorTask_MoveTo,						// input (blackboard:vector),				output (none)
//	BehaviorTask_Search,						// input (none),							output (blackboard::IBehaviorObject)
//	BehaviorTask_Skill,							// input (blackboard::IBehaviorObject)		output (none)
//	BehaviorTask_Spawn,							// input (none)								output (none)
//	BehaviorTask_Wait,							// input (blackboard::int)					output (none)
//	BehaviorTask_DistanceTo,					// input (blackboard::vector)				output (blackboard::float)
//};

// parallel모드의 종료 형식
enum class BehaviorParallelQuitType : char
{
	BehaviorParallelQuitType_None,
	BehaviorParallelQuitType_Delayed,
	BehaviorParallelQuitType_Immediately,
};

// blackboard scope
enum class BehaviorBlackBoardScope : char
{
	BehaviorBlackBoardScope_None,
	BehaviorBlackBoardScope_Local,				// 로컬 변수
	BehaviorBlackBoardScope_Member,				// 자기 자신
	BehaviorBlackBoardScope_Global,				// 자신이 활동하는 level instance에서
	BehaviorBlackBoardScope_Const,				// 전체에서
	BehaviorBlackBoardScope_Inherent,			// 노드에 부착된
};

// blackboard type
enum class BehaviorBlackBoardDataType : char
{
	BehaviorBlackBoardDataType_None,
	BehaviorBlackBoardDataType_Float,
	BehaviorBlackBoardDataType_Double,
	BehaviorBlackBoardDataType_Int8,
	BehaviorBlackBoardDataType_Int16,
	BehaviorBlackBoardDataType_Int32,
	BehaviorBlackBoardDataType_Int64,
	BehaviorBlackBoardDataType_Vector,
	BehaviorBlackBoardDataType_Object,
};

enum class BehaviorOperator : char
{
	BehaviorOperator_None,
	BehaviorOperator_Equal,
	BehaviorOperator_NotEqual,
	BehaviorOperator_Less,
	BehaviorOperator_Greater,
	BehaviorOperator_LessOrEqual,
	BehaviorOperator_GreaterOrEqual,
};

// ai Group ID
enum
{
	AiGroupID_Empty = 0,
	AiGroupID_Start = 1,
	NodeID_Empty = 0,
	NodeID_Start = 1,
	Blackboard_Empty = 0,
	Blackboard_Start = 1,
	TaskID_Empty = 0,
	TaskID_Start = 1,
};

// random 생성기..
inline nmsp::random<float>& RandomInstance(float min, float max)
{
	static thread_local nmsp::random<float> rnd(min, max);
	return rnd;
}

// 전방 선언들.. 필요하면 여기에 추가
template <typename ALLOC> class behavior;
template <typename ALLOC> class behavior_tree;
template <typename ALLOC> class behavior_node;
template <typename ALLOC> class message_behavior_node;
template <typename NODE, typename ALLOC> class behavior_context;
//
template <typename ALLOC>
class behavior_blackboard : public nmsp::new_from_pool<ALLOC>
{
	using _allocator_t = ALLOC;
	using _behavior_object_t = nmsp::smartinterface<nmsp::behavior::IBehaviorObject>;
	using _primitive_type_t = boost::variant<double, int64_t, nmsp::Vector3, _behavior_object_t>;		// 순서를 바꾸면 안된다..
	using _array_t = std::vector<_primitive_type_t, nmsp::stl_default_allocator<_primitive_type_t, _allocator_t>>;
	using _this_t = behavior_blackboard<_allocator_t>;

public:
	using _id_t = int;

private:
	template <typename X>
	class access_variant : public boost::static_visitor<bool>
	{
	public:
		access_variant(X& x)
			: m_x(x)
		{
		}
		inline bool operator()(X& operand)
		{
			m_x = operand;
			return true;
		}
		template <typename T> inline bool operator()(T & operand)
		{
			return false;
		}
		X& m_x;
	};
	struct compare_variant : public boost::static_visitor<bool>
	{
		enum class _TYPE : char
		{
			NONE,
			FLOAT,
			INT,
		};
		union _VALUE
		{
			double m_float;
			int64_t m_int;
		};
		compare_variant()
		{
		}
		template <typename T> inline bool operator()(T & operand)
		{
			m_type = _TYPE::NONE;
			return false;
		}
		inline bool operator()(double & operand)
		{
			m_type = _TYPE::FLOAT;
			m_value.m_float = operand;
			return true;
		}
		inline bool operator()(const double & operand)
		{
			m_type = _TYPE::FLOAT;
			m_value.m_float = operand;
			return true;
		}
		inline bool operator()(int64_t & operand)
		{
			m_type = _TYPE::INT;
			m_value.m_int = operand;
			return true;
		}
		inline bool operator()(const int64_t & operand)
		{
			m_type = _TYPE::INT;
			m_value.m_int = operand;
			return true;
		}
		inline bool operator < (const compare_variant& other)
		{
			if (_TYPE::INT == m_type)
			{
				if (_TYPE::INT == other.m_type)
					return m_value.m_int < other.m_value.m_int;
				else
					return m_value.m_int < other.m_value.m_float;
			}

			if (_TYPE::INT == other.m_type)
				return m_value.m_float < other.m_value.m_int;
			else
				return m_value.m_float < other.m_value.m_float;
		}
		inline bool operator <= (const compare_variant& other)
		{
			if (_TYPE::INT == m_type)
			{
				if (_TYPE::INT == other.m_type)
					return m_value.m_int <= other.m_value.m_int;
				else
					return m_value.m_int <= other.m_value.m_float;
			}

			if (_TYPE::INT == other.m_type)
				return m_value.m_float <= other.m_value.m_int;
			else
				return m_value.m_float <= other.m_value.m_float;
		}
		inline bool operator > (const compare_variant& other)
		{
			if (_TYPE::INT == m_type)
			{
				if (_TYPE::INT == other.m_type)
					return m_value.m_int > other.m_value.m_int;
				else
					return m_value.m_int > other.m_value.m_float;
			}

			if (_TYPE::INT == other.m_type)
				return m_value.m_float > other.m_value.m_int;
			else
				return m_value.m_float > other.m_value.m_float;
		}
		inline bool operator >= (const compare_variant& other)
		{
			if (_TYPE::INT == m_type)
			{
				if (_TYPE::INT == other.m_type)
					return m_value.m_int >= other.m_value.m_int;
				else
					return m_value.m_int >= other.m_value.m_float;
			}

			if (_TYPE::INT == other.m_type)
				return m_value.m_float >= other.m_value.m_int;
			else
				return m_value.m_float >= other.m_value.m_float;
		}
		inline bool operator == (const compare_variant& other)
		{
			if (_TYPE::INT == m_type)
			{
				if (_TYPE::INT == other.m_type)
					return m_value.m_int == other.m_value.m_int;
				else
					return m_value.m_int == other.m_value.m_float;
			}

			if (_TYPE::INT == other.m_type)
				return m_value.m_float == other.m_value.m_int;
			else
				return m_value.m_float == other.m_value.m_float;
		}
		inline bool operator != (const compare_variant& other)
		{
			if (_TYPE::INT == m_type)
			{
				if (_TYPE::INT == other.m_type)
					return m_value.m_int != other.m_value.m_int;
				else
					return m_value.m_int != other.m_value.m_float;
			}

			if (_TYPE::INT == other.m_type)
				return m_value.m_float != other.m_value.m_int;
			else
				return m_value.m_float != other.m_value.m_float;
		}
		_TYPE m_type;
		_VALUE m_value;
	};

public:
	struct _data_t
		: public nmsp::behavior::IBehaviorData
		, public nmsp::new_from_pool<ALLOC>
	{
		_data_t()
		{
			m_refs = 0;
			m_resetCheckIdFlag = false;
		}
		~_data_t()
		{
		}
		virtual int AddRef() override
		{
			return ++m_refs;
		}
		virtual int Release() override
		{
			int refs = --m_refs;
			if (0 == refs)
			{
				delete this;
				return 0;
			}
			return refs;
		}
		virtual bool GetType(nmsp::behavior::BehaviorDataType* type) override
		{
			switch (m_value.which())
			{
				case 0:
					*type = nmsp::behavior::BehaviorDataType::BehaviorDataType_Double;
					return true;
				case 1:
					*type = nmsp::behavior::BehaviorDataType::BehaviorDataType_Int64;
					return true;
				case 2:
					*type = nmsp::behavior::BehaviorDataType::BehaviorDataType_Vector;
					return true;
				case 3:
					*type = nmsp::behavior::BehaviorDataType::BehaviorDataType_Object;
					return true;
			}
			return false;
		}
		virtual bool GetValue(double* value) override
		{
			access_variant<double> visitor(*value);
			return boost::apply_visitor(visitor, m_value);
		}
		virtual bool GetValue(int64_t* value) override
		{
			access_variant<int64_t> visitor(*value);
			return boost::apply_visitor(visitor, m_value);
		}
		virtual bool GetValue(float* x, float* y, float* z) override		// vector
		{
			nmsp::Vector3 vector3;
			access_variant<nmsp::Vector3> visitor(vector3);
			if (false == boost::apply_visitor(visitor, m_value))
				return false;

			*x = vector3.X();
			*y = vector3.Y();
			*z = vector3.Z();
			return true;
		}
		virtual bool GetValue(nmsp::behavior::IBehaviorObject** value) override
		{
			access_variant<nmsp::behavior::IBehaviorObject*> visitor(*value);
			if (false == boost::apply_visitor(visitor, m_value))
				return false;

			(*value)->AddRef();
			return true;
		}
		virtual bool SetValue(double value) override
		{
			m_value = value;
			return true;
		}
		virtual bool SetValue(int64_t value) override
		{
			m_value = value;
			return true;
		}
		virtual bool SetValue(float x, float y, float z) override		// vector
		{
			m_value = nmsp::Vector3(x, y, z);
			return true;
		}
		virtual bool SetValue(nmsp::behavior::IBehaviorObject* value) override
		{
			m_value = value;
			return true;
		}
		virtual bool GetResetCheckIdFlag() override
		{
			return m_resetCheckIdFlag;
		}
		virtual int GetResetCheckId() override
		{
			return m_resetCheckId;
		}
		virtual void SetResetCheckId(int resetCheckId) override
		{
			m_resetCheckId = resetCheckId;
			m_resetCheckIdFlag = true;
		}
		inline bool operator < (const _data_t& other)
		{
			compare_variant lhs;
			compare_variant rhs;

			if (false == boost::apply_visitor(lhs, m_value))
				return false;

			if (false == boost::apply_visitor(rhs, other.m_value))
				return false;

			return lhs < rhs;
		}
		inline bool operator < (const _primitive_type_t& other)
		{
			compare_variant lhs;
			compare_variant rhs;

			if (false == boost::apply_visitor(lhs, m_value))
				return false;

			if (false == boost::apply_visitor(rhs, other))
				return false;

			return lhs < rhs;
		}
		inline bool operator > (const _data_t& other)
		{
			compare_variant lhs;
			compare_variant rhs;

			if (false == boost::apply_visitor(lhs, m_value))
				return false;

			if (false == boost::apply_visitor(rhs, other.m_value))
				return false;

			return lhs > rhs;
		}
		inline bool operator > (const _primitive_type_t& other)
		{
			compare_variant lhs;
			compare_variant rhs;

			if (false == boost::apply_visitor(lhs, m_value))
				return false;

			if (false == boost::apply_visitor(rhs, other))
				return false;

			return lhs > rhs;
		}
		inline bool operator <= (const _data_t& other)
		{
			compare_variant lhs;
			compare_variant rhs;

			if (false == boost::apply_visitor(lhs, m_value))
				return false;

			if (false == boost::apply_visitor(rhs, other.m_value))
				return false;

			return lhs <= rhs;
		}
		inline bool operator <= (const _primitive_type_t& other)
		{
			compare_variant lhs;
			compare_variant rhs;

			if (false == boost::apply_visitor(lhs, m_value))
				return false;

			if (false == boost::apply_visitor(rhs, other))
				return false;

			return lhs <= rhs;
		}
		inline bool operator >= (const _data_t& other)
		{
			compare_variant lhs;
			compare_variant rhs;

			if (false == boost::apply_visitor(lhs, m_value))
				return false;

			if (false == boost::apply_visitor(rhs, other.m_value))
				return false;

			return lhs >= rhs;
		}
		inline bool operator >= (const _primitive_type_t& other)
		{
			compare_variant lhs;
			compare_variant rhs;

			if (false == boost::apply_visitor(lhs, m_value))
				return false;

			if (false == boost::apply_visitor(rhs, other))
				return false;

			return lhs >= rhs;
		}
		inline bool operator == (const _data_t& other)
		{
			compare_variant lhs;
			compare_variant rhs;

			if (false == boost::apply_visitor(lhs, m_value))
				return false;

			if (false == boost::apply_visitor(rhs, other.m_value))
				return false;

			return lhs == rhs;
		}
		inline bool operator == (const _primitive_type_t& other)
		{
			compare_variant lhs;
			compare_variant rhs;

			if (false == boost::apply_visitor(lhs, m_value))
				return false;

			if (false == boost::apply_visitor(rhs, other))
				return false;

			return lhs == rhs;
		}
		inline bool operator != (const _data_t& other)
		{
			compare_variant lhs;
			compare_variant rhs;

			if (false == boost::apply_visitor(lhs, m_value))
				return false;

			if (false == boost::apply_visitor(rhs, other.m_value))
				return false;

			return lhs != rhs;
		}
		inline bool operator != (const _primitive_type_t& other)
		{
			compare_variant lhs;
			compare_variant rhs;

			if (false == boost::apply_visitor(lhs, m_value))
				return false;

			if (false == boost::apply_visitor(rhs, other))
				return false;

			return lhs != rhs;
		}

		_primitive_type_t m_value;
		std::atomic_int m_refs;
		int32_t m_resetCheckId;
		bool m_resetCheckIdFlag;
	};
	using _shared_data_t = nmsp::smartinterface<_data_t>;
	using _container_t = std::unordered_map<_id_t, _shared_data_t, std::hash<_id_t>, std::equal_to<_id_t>, nmsp::stl_default_allocator<std::pair<const _id_t, _shared_data_t>, _allocator_t>>;

	inline bool Add(_id_t id)
	{
		auto itr = m_container.find(id);
		if (itr != m_container.end())
			return true;

		_shared_data_t newData = new (std::nothrow) _data_t;
		if (nullptr == newData)
			return false;

		auto pairRet = m_container.emplace(id, newData);
		return pairRet.second;
	}
	inline bool Find(_id_t id, _data_t** data)
	{
		auto itr = m_container.find(id);
		if (itr == m_container.end())
			return false;

		*data = itr->second;
		(*data)->AddRef();
		return true;
	}
	inline bool Add(_id_t id, _shared_data_t&& data)
	{
		auto itr = m_container.find(id);
		if (itr != m_container.end())
			return false;

		auto pairRet = m_container.emplace(id, std::forward<_shared_data_t>(data));
		return pairRet.second;
	}
	inline bool Find(_id_t id, _shared_data_t& data)
	{
		auto itr = m_container.find(id);
		if (itr == m_container.end())
			return false;

		data = itr->second;
		return true;
	}
	inline bool Update(_id_t id, _data_t** data, nmsp::behavior::BehaviorDataType type = nmsp::behavior::BehaviorDataType::BehaviorDataType_None)
	{
		auto itr = m_container.find(id);
		if (itr == m_container.end())
		{
			_shared_data_t newData = new (std::nothrow) _data_t;
			if (nullptr == newData)
				return false;

			switch (type)
			{
				case nmsp::behavior::BehaviorDataType::BehaviorDataType_None:
					break;
				case nmsp::behavior::BehaviorDataType::BehaviorDataType_Double:
					newData->SetValue(static_cast<double>(0));
					break;
				case nmsp::behavior::BehaviorDataType::BehaviorDataType_Int64:
					newData->SetValue(static_cast<int64_t>(0));
					break;
				case nmsp::behavior::BehaviorDataType::BehaviorDataType_Vector:
					newData->SetValue(0.f, 0.f, 0.f);
					break;
				case nmsp::behavior::BehaviorDataType::BehaviorDataType_Object:
					newData->SetValue(nullptr);
					break;
			}

			// 내부적인 초기화 이므로.. false로 설정을..
			auto pairRet = m_container.emplace(id, newData);
			if (false == pairRet.second)
				return false;

			*data = newData;
			(*data)->AddRef();
			return true;
		}

		*data = itr->second;
		(*data)->AddRef();
		return true;
	}
	inline void Del(_id_t id)
	{
		m_container.erase(id);
	}
	template <typename F> bool Check(F& f)
	{
		for (auto& itr : m_container)
		{
			if (false == f(itr.second))
				return false;
		}
		return true;
	}
	void Clear()
	{
		m_container.clear();
	}
	behavior_blackboard() = default;
	behavior_blackboard(_this_t&& other)
	{
		m_container = std::forward<_container_t>(other.m_container);
	}
	behavior_blackboard(const _this_t& other)
	{
		m_container = other.m_container;
	}
	inline void operator =(_this_t&& other)
	{
		m_container = std::forward<_container_t>(other.m_container);
	}
	inline void operator =(const _this_t& other)
	{
		m_container = other.m_container;
	}

private:
	_container_t m_container;
};

// context에 현재 상태를 저장해야 하기 떄문에..그것에 대한 base class를 정의한다
// 각각의 node들은 이것을 계승해서 stack에 넣을때 같이 넣어줘야 한다..
template <typename ALLOC>
class behavior_node_context : public nmsp::new_from_pool<ALLOC>
{
public:
	using _allocator_t = ALLOC;
	using _node_t = behavior_node<_allocator_t>;
	using _return_vector_t = std::vector<nmsp::behavior::BehaviorReturn, nmsp::stl_default_allocator<nmsp::behavior::BehaviorReturn, _allocator_t>>;
	using _context_t = behavior_context<_node_t, _allocator_t>;

public:
	behavior_node_context()
	{
		m_refs = 0;
	}
	virtual ~behavior_node_context()
	{
	}
	inline int AddRef()
	{
		return ++m_refs;
	}
	inline int Release()
	{
		int refs = --m_refs;
		if (0 == refs)
		{
			delete this;
			return 0;
		}
		return refs;
	}
	inline void Return(nmsp::behavior::BehaviorReturn ret)
	{
		m_returns.push_back(ret);
	}
	inline bool IsAllSuccess()
	{
		std::size_t successCount = 0;

		for (const auto& itr : m_returns)
		{
			if (nmsp::behavior::BehaviorReturn::BehaviorReturn_Success == itr)
				++successCount;
		}

		if (successCount == m_returns.size())
			return true;

		return false;
	}
	inline bool IsSuccessIn()
	{
		for (const auto& itr : m_returns)
		{
			if (nmsp::behavior::BehaviorReturn::BehaviorReturn_Success == itr)
				return true;
		}

		return false;
	}
	inline bool IsFailIn()
	{
		for (const auto& itr : m_returns)
		{
			if (nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail == itr)
				return true;
		}

		return false;
	}
	inline bool ReturnState(std::size_t& successCount, std::size_t& failCount, std::size_t& runningCount)
	{
		successCount = 0;
		failCount = 0;
		runningCount = 0;

		for (const auto& itr : m_returns)
		{
			if (nmsp::behavior::BehaviorReturn::BehaviorReturn_Success == itr)
				++successCount;
			else if (nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail == itr)
				++failCount;
			else if (nmsp::behavior::BehaviorReturn::BehaviorReturn_Running == itr)
				++runningCount;
		}
	}
	inline bool IsResult()
	{
		return !m_returns.empty();
	}
	inline std::size_t ResultCount()
	{
		return m_returns.size();
	}
	void ClearReturn()
	{
		m_returns.clear();
	}
	virtual void ExitForce(_context_t* context)
	{
	}
	virtual void NotifyCurrentDebugInfo(nmsp::behavior::BehaviorReturn currRet, nmsp::behavior::IBehaviorObject* object, _node_t* node)
	{
		if (false == object->IsDebugMode())
			return;
		object->CurrentDebugInfo(currRet, node->GetNodeName().c_str(), node->GetGroupName().c_str(), 0, nullptr, nullptr);
	}

private:
	int m_refs;
	_return_vector_t m_returns;
};
//

// 실행에 사용할 stack정의
template <typename FIRST, typename SECOND, typename ALLOC>
class behavior_stack : public nmsp::new_from_pool<ALLOC>
{
	using _allocator_t = ALLOC;
	using _this_t = behavior_stack<FIRST, SECOND, ALLOC>;
	using _stack_value_t = std::pair<FIRST, SECOND>;
	using _stack_t = std::vector<_stack_value_t, nmsp::stl_default_allocator<_stack_value_t, _allocator_t>>;
	using _shared_this_t = nmsp::smartinterface<_this_t>;
	using _child_stack_t = std::vector<_shared_this_t, nmsp::stl_default_allocator<_shared_this_t, _allocator_t>>;

public:
	behavior_stack(int id)
		: m_id(id)
	{
		m_refs = 0;
		m_exitValue = nmsp::behavior::BehaviorReturn::BehaviorReturn_Running;
	}
	~behavior_stack()
	{
	}
	inline int AddRef()
	{
		return ++m_refs;
	}
	inline int Release()
	{
		int refs = --m_refs;
		if (0 == refs)
		{
			delete this;
			return 0;
		}
		return refs;
	}
	inline int RefCount()
	{
		return m_refs;
	}
	inline auto Empty()
	{
		return m_stack.empty();
	}
	inline void Push(FIRST&& f, SECOND&& s)
	{
		m_stack.emplace_back(std::forward<FIRST>(f), std::forward<SECOND>(s));
	}
	inline void Pop()
	{
		m_stack.pop_back();
	}
	inline void Top(FIRST& f, SECOND& s)
	{
		f = m_stack.back().first;
		s = m_stack.back().second;
	}
	inline void Reset()
	{
		m_stack.clear();
		m_childStack.clear();
		m_exitValue = nmsp::behavior::BehaviorReturn::BehaviorReturn_Running;
	}
	inline void ClearStack()
	{
		m_stack.clear();
	}
	inline std::size_t Size()
	{
		return m_stack.size();
	}
	inline bool RefUp(FIRST& f, SECOND& s)
	{
		auto end = m_stack.crbegin();
		if (end == m_stack.crend())
			return false;

		++end;
		if (end == m_stack.crend())
			return false;

		f = (*end).first;
		s = (*end).second;

		return true;
	}
	inline auto Id()
	{
		return m_id;
	}
	inline void SetExitValue(nmsp::behavior::BehaviorReturn code)
	{
		m_exitValue = code;
	}
	inline nmsp::behavior::BehaviorReturn GetExitValue()
	{
		return m_exitValue;
	}
	inline void AddChildStack(_shared_this_t& shardStack)
	{
		m_childStack.push_back(shardStack);
	}
	template <typename F> inline void TraverseChildStack(F f)
	{
		for (auto& itr : m_childStack)
		{
			itr->TraverseChildStack(f);
			f(itr);
		}

		m_childStack.clear();
	}
	template <typename F> void ExitForce(F f)
	{
		for (auto itr = m_stack.rbegin(); itr != m_stack.rend(); ++itr)
			f((*itr).first, (*itr).second);
	}

private:
	int m_id;
	int m_refs;
	_stack_t m_stack;
	_child_stack_t m_childStack;
	nmsp::behavior::BehaviorReturn m_exitValue;
};

// stack을 가지고 있게 된다...
template <typename NODE, typename ALLOC>
class behavior_context : public nmsp::new_from_pool<ALLOC>
{
	using _node_t = NODE;
	using _allocator_t = ALLOC;
	using _this_t = behavior_context<_node_t, _allocator_t>;
	using _shared_node_t = nmsp::smartinterface<_node_t>;
	using _message_node_t = message_behavior_node<_allocator_t>;
	using _shared_message_node_t = nmsp::smartinterface<_message_node_t>;
	using _node_context_t = behavior_node_context<_allocator_t>;
	using _shared_node_context_t = nmsp::smartinterface<_node_context_t>;
	using _stack_t = behavior_stack<_shared_node_t, _shared_node_context_t, _allocator_t>;
	using _shared_stack_t = nmsp::smartinterface<_stack_t>;
	using _stack_list_t = std::list<_shared_stack_t, nmsp::stl_default_allocator<_shared_stack_t, _allocator_t>>;
	using _black_board_t = behavior_blackboard<_allocator_t>;
	using _object_t = nmsp::behavior::IBehaviorObject;
	using _shared_object_t = nmsp::smartinterface<_object_t>;
	using _behavior_tree_t = behavior_tree<_allocator_t>;
	using _shared_behavior_tree_t = nmsp::smartinterface<_behavior_tree_t>;

public:
	behavior_context(_behavior_tree_t* behaviorTree, _node_t* root, _object_t* object, _black_board_t& constBlackBoard, _black_board_t& globalBlackBoard)
		: m_refs(0)
		, m_behaviorTree(behaviorTree)
		, m_root(root)
		, m_object(object)
		, m_constBlackBoard(constBlackBoard)
		, m_globalBlackBoard(globalBlackBoard)
	{
		m_currentStackList = nullptr;
	}
	virtual ~behavior_context()
	{
	}
	bool NewStack(_stack_t* parentStack, _node_t* node, _stack_t** stack)
	{
		_shared_stack_t newStack;
		if (false == m_behaviorTree->AllocateStack(static_cast<_stack_t**>(newStack)))
			return false;

		_shared_node_context_t nodeContext;
		if (false == node->AllocateNodeContext(static_cast<_node_context_t**>(nodeContext), this))
			return false;

		newStack->Push(node, std::move(nodeContext));
		m_currentStackList->emplace_back(newStack);

		if (nullptr != stack)
		{
			*stack = newStack;
			(*stack)->AddRef();
		}

		if (nullptr != parentStack)
			parentStack->AddChildStack(newStack);
		return true;
	}
	void DelStack(_stack_t* stack, bool exitForce)
	{
		for (auto itr = m_currentStackList->begin(); itr != m_currentStackList->end(); ++itr)
		{
			if ((*itr)->Id() != stack->Id())
				continue;

			// 초기화를 해야 한다
			if (true == exitForce)
			{
				(*itr)->ExitForce([this](auto& node, auto& nodeContext) {
					node->ExitForce(this);
					nodeContext->ExitForce(this);
				});
			}

			// 스택을 환원한다
			m_behaviorTree->DeallocateStack((*itr));
			m_currentStackList->erase(itr);
			break;
		}
	}
	inline void DelAllChildStack(_stack_t* parent, bool exitForce = true)
	{
		parent->TraverseChildStack([exitForce, this](_stack_t* child) {
			this->DelStack(child, exitForce);
		});
	}
	bool SubNodeCall(_stack_t* stack, _node_t* node)
	{
		_shared_node_context_t nodeContext;
		if (false == node->AllocateNodeContext(static_cast<_node_context_t**>(nodeContext), this))
			return false;

		stack->Push(node, std::move(nodeContext));
		return true;
	}
	void Process()
	{
		// 시작하기 전에 검사를 한다. 실패인 경우 기존 실행 스택을 초기화 한다!
		auto retCheck = m_object->Check();
		if (retCheck == nmsp::behavior::BehaviorReturn::BehaviorReturn_Cooltime)
			return;

		if (nmsp::behavior::BehaviorReturn::BehaviorReturn_Success != retCheck)
		{
			m_stackList.clear();
			m_messageStackList.clear();
			m_object->Reset();
			return;
		}

		// 실행에 필여한 것
		auto sliceProcessFunc = [this]()
		{
			// 노드가 없는 경우는 그냥 리턴한다!
			if (nullptr == m_currentRoot)
				return;

			// 없으면 새로 시작한다.
			if (true == m_currentStackList->empty())
			{
				if (false == this->NewStack(nullptr, m_currentRoot, nullptr))
					return;
#ifdef _DEBUG
				LOG_DEBUG_INFO(GetComponentImpl()) << "renew behavior!!";
#endif
			}

			// 
			bool debugMode = static_cast<behavior_config&>(*m_behaviorTree->GetComponentImpl()).GetBehaviorDebugFlag();

			//
			_shared_node_t currNode;
			_shared_node_context_t currNodeCtx;

			// 스택에 존재하는 뭔가를 실행하자!
			while (true)
			{
				// 모든 스택에서 실행중인 노드들이 실행상태인지를 확인하기 위한 변수들..
				nmsp::behavior::BehaviorReturn retMain = nmsp::behavior::BehaviorReturn::BehaviorReturn_Running;

				// 병렬 노드나 서비스 노드의 경우 스택이 늘어나게 된다. 각각의 병렬 실행마다 스택을 할당하게 된다
				for (auto itr = m_currentStackList->begin(); itr != m_currentStackList->end();)
				{
					auto& stack = (*itr);

					//  stack이 비어 있다는건 실행할게 없다는 것이므로 task를 삭제한다.
					if (stack->Empty())
					{
						this->DelAllChildStack(stack);

						itr = m_currentStackList->erase(itr);
						continue;
					}

					// 해당 스택의 상태 변화를 마지막에 조사하기 위한 변수들
					nmsp::behavior::BehaviorReturn retSub = nmsp::behavior::BehaviorReturn::BehaviorReturn_Running;

					// 스택이 없어질때까지 실행을 하게 된다.
					while (false == stack->Empty())
					{
						std::size_t stackSize = stack->Size();

						// 최상위 스택에 존재하는 컨텍스트를 가져온다
						stack->Top(currNode, currNodeCtx);

						// 그리고 실행한다..
						retSub = currNode->Process(stack, currNodeCtx, this);

						// 디버그를 위한 호출
						if (true == debugMode)
							currNodeCtx->NotifyCurrentDebugInfo(retSub, m_object, currNode);

						// 실행 결과에 서브루틴이 실행되지 않은 상태에서 Running상태라면 다음 Task의 스택으로 넘기게 된다.
						if (nmsp::behavior::BehaviorReturn::BehaviorReturn_Running == retSub)
						{
							// 새로운 하위노드가 스택에 추가되었다면 일단 실행하고 봅시다!
							if (stackSize != stack->Size())
								continue;

							// running상태라면 종료하고 나옵니다.
							break;
						}

						// 실행이 완료됬다면 스택에서 제거한다.
						stack->Pop();
					}

					// 마지막 실행결과를 검사한다.
					if (nmsp::behavior::BehaviorReturn::BehaviorReturn_Running != retSub)
						retMain = retSub;

					++itr;
				}

				// 모든 스택에 존재하는 노드들의 상태가 Running상태라면 다음 Tick을 기원한다..
				if (nmsp::behavior::BehaviorReturn::BehaviorReturn_Running == retMain)
					break;
			}
		};

		// 메시지가 도착했는가 ?
		if (true == m_object->IsArrivedMessage())
		{
			auto messageId = m_object->GetArrivedMessageId();

			// 이미 실행중이던 것이 있다면..
			if (nullptr != m_messageRoot)
			{
				// 실행되던 것과 다른 메시지라면 초기화를 한다
				if (m_messageRoot->GetMessageId() != messageId)
				{
					m_messageRoot = nullptr;
					m_messageStackList.clear();
				}
			}

			// 실행중이던 메시지 노드가 없다면 찾아야 한다
			if (nullptr == m_messageRoot)
			{
				if (true == m_behaviorTree->FindMessageNode(messageId, m_messageRoot))
				{
					m_currentStackList = &m_messageStackList;
					m_currentRoot = m_messageRoot;
				}
				else
				{
					// 메시지에 해당하는 처리 노드가 없다면 그냥 버린다
					m_object->PopArrivedMessage();

					m_currentStackList = &m_stackList;
					m_currentRoot = m_root;

					// 메인 트리를 처리한다
					sliceProcessFunc();
					return;
				}
			}

			// 메시지를 처리한다
			sliceProcessFunc();

			// 메시지 처리에 대한 실행이 완전히 종료되었다면 도착한 메시지를 지우고 초기화한 후 메인 트리를 실행한다.
			if (true == m_currentStackList->empty())
			{
				m_object->PopArrivedMessage();

				// 옵션을 확인하고 메인트리의 스택을 초기화하게 되어 있다면 초기화 한다
				if (true == m_messageRoot->GetStackResetFlag())
					m_stackList.clear();

				// 사용한 메시지 루트를 초기화 한다.
				m_messageRoot = nullptr;

				// 메인 루트 노드를 실행한다!
				m_currentStackList = &m_stackList;
				m_currentRoot = m_root;

				sliceProcessFunc();
			}
		}
		else
		{
			m_currentStackList = &m_stackList;
			m_currentRoot = m_root;

			sliceProcessFunc();
		}
	}
	inline int AddRef()
	{
		return ++m_refs;
	}
	inline int Release()
	{
		int refs = --m_refs;
		if (0 == refs)
		{
			delete this;
			return 0;
		}
		return refs;
	}
	inline _object_t* Object()
	{
		return m_object;
	}
	inline _behavior_tree_t* Tree()
	{
		return m_behaviorTree;
	}
	inline _black_board_t& BlackBoard(BehaviorBlackBoardScope scope)
	{
		if (scope == BehaviorBlackBoardScope::BehaviorBlackBoardScope_Local)
			return m_localBlackBoard;
		else if (scope == BehaviorBlackBoardScope::BehaviorBlackBoardScope_Member)
			return m_blackBoard;
		else if (scope == BehaviorBlackBoardScope::BehaviorBlackBoardScope_Global)
			return m_globalBlackBoard;
		else if (scope == BehaviorBlackBoardScope::BehaviorBlackBoardScope_Inherent)
			return m_inherentBlackBoard;
		else
			return m_constBlackBoard;
	}
	template <typename T> inline bool SetValueToBlackBoard(BehaviorBlackBoardScope scope, typename _black_board_t::_id_t id, const T& t)
	{
		auto& blackBoard = BlackBoard(scope);

		_black_board_t::_shared_data_t value;
		if (false == blackBoard.Update(id, value))
			return false;

		return value->SetValue(t);
	}
	template <typename T> inline bool GetValueFromBlackBoard(BehaviorBlackBoardScope scope, typename _black_board_t::_id_t id, T& t)
	{
		auto& blackBoard = BlackBoard(scope);

		_black_board_t::_shared_data_t value;
		if (false == blackBoard.Update(id, value))
			return false;

		return value->GetValue(&t);
	}
	template <typename T> inline bool GetValueFromBlackBoard(BehaviorBlackBoardScope scope, typename _black_board_t::_id_t id, T& t, const T& defaultValue)
	{
		auto& blackBoard = BlackBoard(scope);

		_black_board_t::_shared_data_t value;
		if (false == blackBoard.Update(id, value))
			return false;

		if (false == value->GetValue(&t))
			t = defaultValue;

		return true;
	}
	inline const int64_t& GetCurrentGameTime() const
	{
		return m_behaviorTree->GetCurrentGameTime();
	}
	inline void Reset()
	{
		m_stackList.clear();
		m_messageStackList.clear();
		m_blackBoard.Clear();
		m_inherentBlackBoard.Clear();
	}
	inline behavior_component_impl* GetComponentImpl()
	{
		return m_behaviorTree->GetComponentImpl();
	}

private:
	int m_refs;
	_behavior_tree_t* m_behaviorTree;
	_shared_node_t m_currentRoot;
	_shared_node_t m_root;
	_shared_message_node_t m_messageRoot;
	_shared_object_t m_object;
	_stack_list_t* m_currentStackList;
	_stack_list_t m_stackList;
	_stack_list_t m_messageStackList;
	_black_board_t m_localBlackBoard;
	_black_board_t m_blackBoard;
	_black_board_t m_inherentBlackBoard;
	_black_board_t& m_constBlackBoard;
	_black_board_t& m_globalBlackBoard;
};

// 기본 타입
template <typename ALLOC>
class behavior_node : public nmsp::new_from_pool<ALLOC>
{
public:
	using _allocator_t = ALLOC;
	using _id_t = int;
	using _node_t = behavior_node<_allocator_t>;
	using _shared_node_t = nmsp::smartinterface<_node_t>;
	using _children_t = std::vector<_shared_node_t, nmsp::stl_default_allocator<_shared_node_t, _allocator_t>>;
	using _black_board_t = behavior_blackboard<_allocator_t>;
	typedef typename _black_board_t::_shared_data_t _shared_data_t;
	typedef typename _black_board_t::_id_t _blackboard_id_t;
	using _node_context_t = behavior_node_context<_allocator_t>;
	using _shared_node_context_t = nmsp::smartinterface<_node_context_t>;
	using _stack_t = behavior_stack<_shared_node_t, _shared_node_context_t, _allocator_t>;
	using _shared_stack_t = nmsp::smartinterface<_stack_t>;
	using _context_t = behavior_context<_node_t, _allocator_t>;

public:
	behavior_node(BehaviorType type, _id_t id)
		: m_type(type)
		, m_id(id)
	{
		m_refs = 0;
		m_inherentValue = std::make_pair<BehaviorBlackBoardScope, _blackboard_id_t>(BehaviorBlackBoardScope::BehaviorBlackBoardScope_None, 0);
	}
	virtual ~behavior_node()
	{
	}
	// 
	virtual nmsp::behavior::BehaviorReturn Process(_stack_t* stack, _node_context_t* nodeCtx, _context_t* context) = 0;
	virtual bool AllocateNodeContext(_node_context_t** nodeCtx, _context_t* context) = 0;
	inline bool SetInherentValue(BehaviorBlackBoardScope scope, _blackboard_id_t id)
	{
		if (BehaviorBlackBoardScope::BehaviorBlackBoardScope_None != m_inherentValue.first)
			return false;
		m_inherentValue = std::make_pair<BehaviorBlackBoardScope, _blackboard_id_t>(std::forward<BehaviorBlackBoardScope>(scope), std::forward<_blackboard_id_t>(id));
		return true;
	}
	virtual bool Check()
	{
		if (BehaviorBlackBoardScope::BehaviorBlackBoardScope_None == m_inherentValue.first)
			return false;
		return true;
	}
	virtual void ExitForce(_context_t* context)
	{
	}

	//
	inline BehaviorType Type() const
	{
		return m_type;
	}
	inline auto ID() const
	{
		return m_id;
	}
	inline int AddRef()
	{
		return ++m_refs;
	}
	inline int Release()
	{
		int refs = --m_refs;
		if (0 == refs)
		{
			delete this;
			return 0;
		}
		return refs;
	}
	const std::string& GetNodeName() const 
	{ 
		return m_nodeName; 
	}
	void SetNodeName(const std::string& nodeName)
	{
		m_nodeName = nodeName;
	}
	const std::string& GetGroupName() const
	{
		return m_groupName;
	}
	void SetGroupName(const std::string& groupName)
	{
		m_groupName = groupName;
	}

protected:
	// 자신의 상위노드에 결과를 리턴하려고 한다.. 없으면 자신이 최 상위임..
	inline nmsp::behavior::BehaviorReturn ReturnValueToStack(_stack_t* stack, nmsp::behavior::BehaviorReturn ret)
	{
		// Running은 계속 실행을 해야 하므로 상위 호출자에게 결과로 리턴하지 않는다..
		if (nmsp::behavior::BehaviorReturn::BehaviorReturn_Running == ret)
			return ret;

		_shared_node_t f;
		_shared_node_context_t s;

		// 결과를 리턴할 스택값이 없다는 것은 상위 호출자가 없이 자신이 최상위 노드라는 얘기이므로 실행 종료 코드로서 저장한다
		if (false == stack->RefUp(f, s))
		{
			stack->SetExitValue(ret);
			return ret;
		}

		s->Return(ret);
		return ret;
	}

private:
	BehaviorType m_type;
	_id_t m_id;
	std::string m_nodeName;
	std::string m_groupName;
	std::atomic_int m_refs;

protected:
	std::pair<BehaviorBlackBoardScope, _blackboard_id_t> m_inherentValue;
};

// 
template <typename ALLOC>
class task_behavior_node : public behavior_node<ALLOC>
{
	using _black_board_t = behavior_blackboard<ALLOC>;
	using _blackboard_id_t = typename _black_board_t::_id_t;
	using _param_t = std::vector<typename nmsp::behavior::IBehaviorData*, nmsp::stl_default_allocator<typename nmsp::behavior::IBehaviorData*, ALLOC>>;

	struct task_node_context : public behavior_node_context<ALLOC>
	{
		task_node_context()
		{
			m_first = true;
			m_cmdType = 0;
			m_object = nullptr;
			m_lastExecute = 0;
		}
		~task_node_context()
		{
			if (nullptr != m_object)
				m_object->UninitExecute(m_cmdType, static_cast<int>(m_input.size()), m_input.data());

			for (auto itr : m_input)
			{
				if (itr)
					itr->Release();
			}

			for (auto itr : m_output)
			{
				if (itr)
					itr->Release();
			}
		}
		virtual void NotifyCurrentDebugInfo(nmsp::behavior::BehaviorReturn currRet, nmsp::behavior::IBehaviorObject* object, _node_t* node) override
		{
			if (false == object->IsDebugMode())
				return;

			int inputLength = static_cast<int>(m_input.size());
			auto inputData = m_input.data();
			auto outputData = m_output.data();

			object->CurrentDebugInfo(currRet, node->GetNodeName().c_str(), node->GetGroupName().c_str(), inputLength, inputData, outputData == nullptr ? nullptr : *outputData);
		}

		int m_cmdType;
		nmsp::smartinterface<nmsp::behavior::IBehaviorObject> m_object;
		_param_t m_input;
		_param_t m_output;
		int64_t m_lastExecute;
		bool m_first;
	};

public:
	using _param_ref_t = std::vector<std::tuple<BehaviorBlackBoardScope, _blackboard_id_t, nmsp::behavior::BehaviorDataType, std::string>, nmsp::stl_default_allocator<std::tuple<BehaviorBlackBoardScope, _blackboard_id_t, nmsp::behavior::BehaviorDataType, std::string>, ALLOC>>;

public:
	task_behavior_node(_id_t id)
		: behavior_node(BehaviorType::BehaviorType_Task, id)
	{
		m_init = false;
	}
	virtual nmsp::behavior::BehaviorReturn Process(_stack_t* stack, _node_context_t* nodeCtx, _context_t* context) override
	{
		auto currCtx = static_cast<task_node_context*>(nodeCtx);

		int inputLength;
		decltype(currCtx->m_input.data()) inputData;
		decltype(currCtx->m_output.data()) outputData;

		if (true == currCtx->m_first)
		{
			currCtx->m_input.resize(m_refInput.size());
 
			std::size_t count = 0;
			for (const auto& itr : m_refInput)
			{
				auto& blackBoard = context->BlackBoard(std::get<BehaviorBlackBoardScope>(itr));

				_black_board_t::_data_t* data;
 				if (false == blackBoard.Find(std::get<_blackboard_id_t>(itr), static_cast<_black_board_t::_data_t**>(&data)))
					return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

				currCtx->m_input[count++] = data;
			}

			if (false == m_refOutput.empty())
			{
				currCtx->m_output.resize(m_refOutput.size());

				const auto& itr = *m_refOutput.begin();
				auto& blackBoard = context->BlackBoard(std::get<BehaviorBlackBoardScope>(itr));

				_black_board_t::_data_t* data;
				if (false == blackBoard.Update(std::get<_blackboard_id_t>(itr), static_cast<_black_board_t::_data_t**>(&data), std::get<nmsp::behavior::BehaviorDataType>(itr)))
					return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

				currCtx->m_output[0] = data;
			}

			// 실행정보
			currCtx->m_first = false;
			currCtx->m_cmdType = m_cmdType;
			currCtx->m_object = context->Object();

			// 처음 호출이므로 초기화 함수를 호출해 준다
			inputLength = static_cast<int>(currCtx->m_input.size());
			inputData = currCtx->m_input.data();
			outputData = currCtx->m_output.data();

			auto ret = context->Object()->InitExecute(m_cmdType, inputLength, inputData, outputData == nullptr ? nullptr : *outputData);
			if (nmsp::behavior::BehaviorReturn::BehaviorReturn_Success != ret)
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
		}
		else
		{
			// 이미 실행을 한거라면..
			if (currCtx->m_lastExecute == context->GetCurrentGameTime())
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);

			inputLength = static_cast<int>(currCtx->m_input.size());
			inputData = currCtx->m_input.data();
			outputData = currCtx->m_output.data();
		}

		// 실행!
		auto retExe = context->Object()->Execute(m_cmdType, inputLength, inputData, outputData == nullptr ? nullptr : *outputData);

		// 실행했음을.. 기록한다
		currCtx->m_lastExecute = context->GetCurrentGameTime();

		// 자 호출해 봅시다!
		return ReturnValueToStack(stack, retExe);
	}
	virtual bool AllocateNodeContext(_node_context_t** nodeCtx, _context_t* context) override
	{
		*nodeCtx = new (std::nothrow) task_node_context;
		if (nullptr == *nodeCtx)
			return false;
		(*nodeCtx)->AddRef();
		return true;
	}
	inline void SetParam(int cmdType, _param_ref_t&& input, _param_ref_t&& output)
	{
		m_cmdType = cmdType;
		m_refInput = std::forward<_param_ref_t>(input);
		m_refOutput = std::forward<_param_ref_t>(output);
		m_init = true;
	}
	virtual bool Check() override
	{
		if (false == behavior_node<ALLOC>::Check())
			return false;
		return m_init;
	}
	inline _param_ref_t& GetInputParam()
	{
		return m_refInput;
	}
	inline _param_ref_t& GetOutputParam()
	{
		return m_refOutput;
	}
private:
	bool m_init;
	int m_cmdType;
	_param_ref_t m_refInput;
	_param_ref_t m_refOutput;
};

// 
template <typename ALLOC>
class service_behavior_node : public behavior_node<ALLOC>
{
	struct service_node_context : public behavior_node_context<ALLOC>
	{
		service_node_context()
		{
		}
		~service_node_context()
		{
		}
		_shared_stack_t m_subChildStack;
	};

public:
	service_behavior_node(_id_t id)
		: behavior_node(BehaviorType::BehaviorType_Service, id)
	{
	}
	virtual nmsp::behavior::BehaviorReturn Process(_stack_t* stack, _node_context_t* nodeCtx, _context_t* context) override
	{
		auto currCtx = static_cast<service_node_context*>(nodeCtx);

		if (nullptr != currCtx->m_subChildStack)
		{
			// 대기하는 거라면
			if (nmsp::behavior::BehaviorReturn::BehaviorReturn_Running != currCtx->m_subChildStack->GetExitValue())
			{
				context->DelAllChildStack(stack);
				return ReturnValueToStack(stack, currCtx->m_subChildStack->GetExitValue());
			}

			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);
		}

		_shared_stack_t newStack;
		if (false == context->NewStack(stack, m_child, static_cast<_stack_t**>(newStack)))
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

		if (false == context->SubNodeCall(stack, m_childCheck))
		{
			context->DelAllChildStack(stack);
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
		}

		currCtx->m_subChildStack = newStack;
		return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);
	}
	virtual bool AllocateNodeContext(_node_context_t** nodeCtx, _context_t* context) override
	{
		*nodeCtx = new (std::nothrow) service_node_context;
		if (nullptr == *nodeCtx)
			return false;
		(*nodeCtx)->AddRef();
		return true;
	}
	bool AddCheckChild(_node_t* node)
	{
		if (nullptr != m_childCheck)
			return false;
		m_childCheck = node;
		return true;
	}
	_shared_node_t GetCheckChild()
	{
		return m_childCheck;
	}
	bool AddChild(_node_t* node)
	{
		if (nullptr != m_child)
			return false;
		m_child = node;
		return true;
	}
	_shared_node_t GetChild()
	{
		return m_child;
	}
	virtual bool Check() override
	{
		if (false == behavior_node<ALLOC>::Check())
			return false;
		if (nullptr == m_childCheck || nullptr == m_child)
			return false;
		return true;
	}

private:
	_shared_node_t m_childCheck;
	_shared_node_t m_child;
};

// 
template <typename ALLOC>
class timelimit_behavior_node : public behavior_node<ALLOC>
{
	struct timelimit_node_context : public behavior_node_context<ALLOC>
	{
		timelimit_node_context()
		{
		}

		_shared_stack_t m_subChildStack;
		int64_t m_start;
	};

public:
	using _param_ref_t = std::tuple<BehaviorBlackBoardScope, _blackboard_id_t, std::string>;

public:
	timelimit_behavior_node(_id_t id)
		: behavior_node(BehaviorType::BehaviorType_TimeLimit, id)
	{
		m_inputValue = std::make_tuple<BehaviorBlackBoardScope, _blackboard_id_t>(BehaviorBlackBoardScope::BehaviorBlackBoardScope_None, 0, "");
	}
	virtual nmsp::behavior::BehaviorReturn Process(_stack_t* stack, _node_context_t* nodeCtx, _context_t* context) override
	{
		auto currCtx = static_cast<timelimit_node_context*>(nodeCtx);

		if (nullptr != currCtx->m_subChildStack)
		{
			// 대기하는 거라면
			if (nmsp::behavior::BehaviorReturn::BehaviorReturn_Running != currCtx->m_subChildStack->GetExitValue())
			{
				context->DelAllChildStack(stack);

#ifdef _DEBUG
				LOG_INFO_SYS(context->GetComponentImpl()) << "timelimit_behavior_node end!!!" << ", obj=" << (int64_t)currCtx;
#endif
				return ReturnValueToStack(stack, currCtx->m_subChildStack->GetExitValue());
			}

			int64_t limitCount;
			if (false == context->GetValueFromBlackBoard(std::get<BehaviorBlackBoardScope>(m_inputValue), std::get<_blackboard_id_t>(m_inputValue), limitCount))
			{
				context->DelAllChildStack(stack);
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
			}

			// 시간이 경과했다면 실패를 리턴한다!.
			if (limitCount < context->GetCurrentGameTime() - currCtx->m_start)
			{
				context->DelAllChildStack(stack);
#ifdef _DEBUG
				LOG_INFO_SYS(context->GetComponentImpl()) << "timelimit_behavior_node timeout end!!! " << limitCount << ", curr=" << context->GetCurrentGameTime() << ", start=" << currCtx->m_start << ", obj=" << (int64_t)currCtx;
#endif
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
			}

			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);
		}

		_shared_stack_t newStack;
		if (false == context->NewStack(stack, m_child, static_cast<_stack_t**>(newStack)))
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

		currCtx->m_subChildStack = newStack;
		currCtx->m_start = context->GetCurrentGameTime();

#ifdef _DEBUG
		int64_t limitCount;
		if (false == context->GetValueFromBlackBoard(std::get<BehaviorBlackBoardScope>(m_inputValue), std::get<_blackboard_id_t>(m_inputValue), limitCount))
		{
			context->DelAllChildStack(stack);
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
		}

		LOG_INFO_SYS(context->GetComponentImpl()) << "timelimit_behavior_node timeout start!!! " << limitCount << ", curr=" << context->GetCurrentGameTime() << ", start=" << currCtx->m_start << ", obj=" << (int64_t)currCtx;
#endif
		return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);
	}
	virtual bool AllocateNodeContext(_node_context_t** nodeCtx, _context_t* context) override
	{
		*nodeCtx = new (std::nothrow) timelimit_node_context;
		if (nullptr == *nodeCtx)
			return false;
		(*nodeCtx)->AddRef();
#ifdef _DEBUG
		LOG_INFO_SYS(context->GetComponentImpl()) << "timelimit_behavior_node_context creation" << ", obj=" << (int64_t)(*nodeCtx);
#endif
		return true;
	}
	bool AddChild(_node_t* node)
	{
		if (nullptr != m_child)
			return false;
		m_child = node;
		return true;
	}
	_shared_node_t GetChild()
	{
		return m_child;
	}
	inline bool AddInput(BehaviorBlackBoardScope scope, _blackboard_id_t id, std::string name)
	{
		if (BehaviorBlackBoardScope::BehaviorBlackBoardScope_None != std::get<BehaviorBlackBoardScope>(m_inputValue))
			return false;
		m_inputValue = std::make_tuple<BehaviorBlackBoardScope, _blackboard_id_t, std::string>(std::forward<BehaviorBlackBoardScope>(scope), std::forward<_blackboard_id_t>(id), std::forward<std::string>(name));
		return true;
	}
	inline _param_ref_t GetInput()
	{
		return m_inputValue;
	}

	virtual bool Check() override
	{
		if (false == behavior_node<ALLOC>::Check())
			return false;
		if (nullptr == m_child || BehaviorBlackBoardScope::BehaviorBlackBoardScope_None == std::get<BehaviorBlackBoardScope>(m_inputValue))
			return false;
		return true;
	}

private:
	_param_ref_t m_inputValue;
	_shared_node_t m_child;
};

// 
template <typename ALLOC>
class cooldown_behavior_node : public behavior_node<ALLOC>
{
	using _this_t = cooldown_behavior_node<ALLOC>;
	struct cooldown_node_context : public behavior_node_context<ALLOC>
	{
		cooldown_node_context()
		{
			m_start = false;
			m_called = false;
			m_startTime = 0;
		}
		bool m_start;
		bool m_called;
		int64_t m_startTime;
	};

public:
	using _param_ref_t = std::tuple<BehaviorBlackBoardScope, _blackboard_id_t, std::string>;

public:
	cooldown_behavior_node(_id_t id)
		: behavior_node(BehaviorType::BehaviorType_CoolDown, id)
	{
	}
	virtual nmsp::behavior::BehaviorReturn Process(_stack_t* stack, _node_context_t* nodeCtx, _context_t* context) override
	{
		auto currCtx = static_cast<cooldown_node_context*>(nodeCtx);

		// BlackBoard상에서 값을 가져온다
		int64_t limitCount;
		if (false == context->GetValueFromBlackBoard(std::get<BehaviorBlackBoardScope>(m_inputValue), std::get<_blackboard_id_t>(m_inputValue), limitCount))
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

		if (false == currCtx->m_start)
		{
			currCtx->m_start = true;
			currCtx->m_startTime = context->GetCurrentGameTime();
		}

		// 일정 시간이 경과했는지 검사한다!
		if (limitCount > context->GetCurrentGameTime() - currCtx->m_startTime)
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);

		// 시간이 경과되고 서브가 호출이 안됬다면 호출을..
		if (false == currCtx->m_called)
		{
			// 하위노드를 실행한다!
			if (false == context->SubNodeCall(stack, m_child))
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

			currCtx->m_called = true;
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);
		}

		// 이미 실행후라면..
		if (currCtx->IsSuccessIn())
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);

		return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
	}
	virtual bool AllocateNodeContext(_node_context_t** nodeCtx, _context_t* context) override
	{
		*nodeCtx = new (std::nothrow) cooldown_node_context;
		if (nullptr == *nodeCtx)
			return false;
		(*nodeCtx)->AddRef();
		return true;
	}
	bool AddChild(_node_t* node)
	{
		if (nullptr != m_child)
			return false;
		m_child = node;
		return true;
	}
	_shared_node_t GetChild()
	{
		return m_child;
	}
	inline bool AddInput(BehaviorBlackBoardScope scope, _blackboard_id_t id, std::string name)
	{
		if (BehaviorBlackBoardScope::BehaviorBlackBoardScope_None != std::get<BehaviorBlackBoardScope>(m_inputValue))
			return false;
		m_inputValue = std::make_tuple<BehaviorBlackBoardScope, _blackboard_id_t, std::string>(std::forward<BehaviorBlackBoardScope>(scope), std::forward<_blackboard_id_t>(id), std::forward<std::string>(name));
		return true;
	}
	inline _param_ref_t GetInput()
	{
		return m_inputValue;
	}
	virtual bool Check() override
	{
		if (false == behavior_node<ALLOC>::Check())
			return false;
		if (nullptr == m_child || BehaviorBlackBoardScope::BehaviorBlackBoardScope_None == std::get<0>(m_inputValue))
			return false;
		return true;
	}
	virtual void ExitForce(_context_t* context) override
	{
	}

private:
	_param_ref_t m_inputValue;
	_shared_node_t m_child;
};

// 
template <typename ALLOC>
class condition_behavior_node : public behavior_node<ALLOC>
{
	using _param_t = std::vector<typename nmsp::behavior::IBehaviorData*, nmsp::stl_default_allocator<typename nmsp::behavior::IBehaviorData*, ALLOC>>;
	struct condition_node_context : public behavior_node_context<ALLOC>
	{
		condition_node_context()
		{
			m_check = false;
		}
		virtual void NotifyCurrentDebugInfo(nmsp::behavior::BehaviorReturn currRet, nmsp::behavior::IBehaviorObject* object, _node_t* node) override
		{
			if (false == object->IsDebugMode())
				return;

			int inputLength = static_cast<int>(m_input.size());
			auto inputData = m_input.data();

			object->CurrentDebugInfo(currRet, node->GetNodeName().c_str(), node->GetGroupName().c_str(), inputLength, inputData, nullptr);
		}

		_param_t m_input;
		bool m_check;
	};

public:
	using _param_ref_t = std::tuple<BehaviorBlackBoardScope, _blackboard_id_t, std::string>;
public:
	condition_behavior_node(_id_t id)
		: behavior_node(BehaviorType::BehaviorType_Condition, id)
	{
		m_op = BehaviorOperator::BehaviorOperator_None;
		m_leftValue = std::make_tuple<BehaviorBlackBoardScope, _blackboard_id_t, std::string>(BehaviorBlackBoardScope::BehaviorBlackBoardScope_None, 0, "");
		m_rightValue = std::make_tuple<BehaviorBlackBoardScope, _blackboard_id_t, std::string>(BehaviorBlackBoardScope::BehaviorBlackBoardScope_None, 0, "");
	}
	virtual nmsp::behavior::BehaviorReturn Process(_stack_t* stack, _node_context_t* nodeCtx, _context_t* context) override
	{
		auto currCtx = static_cast<condition_node_context*>(nodeCtx);

		// 조건 채크를 위한 노드를 실행
		if (false == currCtx->m_check)
		{
			auto& leftBB = context->BlackBoard(std::get<BehaviorBlackBoardScope>(m_leftValue));
			auto& rightBB = context->BlackBoard(std::get<BehaviorBlackBoardScope>(m_rightValue));

			_black_board_t::_shared_data_t leftValue;
			_black_board_t::_shared_data_t rightValue;

			if (false == leftBB.Find(std::get<_blackboard_id_t>(m_leftValue), static_cast<_black_board_t::_data_t**>(leftValue)))
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

			if (false == rightBB.Find(std::get<_blackboard_id_t>(m_rightValue), static_cast<_black_board_t::_data_t**>(rightValue)))
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

			currCtx->m_input.resize(2);
			currCtx->m_input[0] = leftValue;
			currCtx->m_input[1] = rightValue;

			switch (m_op)
			{
			case BehaviorOperator::BehaviorOperator_Equal:
				if (*static_cast<_black_board_t::_data_t*>(leftValue) == *static_cast<_black_board_t::_data_t*>(rightValue))
				{
#ifdef _DEBUG
					LOG_DEBUG_INFO(context->GetComponentImpl()) << "condition == true" ;
#endif
					if (false == context->SubNodeCall(stack, m_childLeft))
						return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
				}
				else
				{
#ifdef _DEBUG
					LOG_DEBUG_INFO(context->GetComponentImpl()) << "condition == false";
#endif

					if (nullptr != m_childRight)
					{
						if (false == context->SubNodeCall(stack, m_childRight))
							return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
					}
					else
					{
						return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);
					}
				}
				break;
			case BehaviorOperator::BehaviorOperator_NotEqual:
				if (*static_cast<_black_board_t::_data_t*>(leftValue) != *static_cast<_black_board_t::_data_t*>(rightValue))
				{
#ifdef _DEBUG
					LOG_DEBUG_SYS(context->GetComponentImpl()) << "condition != true";
#endif
					if (false == context->SubNodeCall(stack, m_childLeft))
						return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
				}
				else
				{
#ifdef _DEBUG
					LOG_DEBUG_SYS(context->GetComponentImpl()) << "condition != false";
#endif
					if (nullptr != m_childRight)
					{
						if (false == context->SubNodeCall(stack, m_childRight))
							return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
					}
					else
					{
						return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);
					}
				}
				break;
			case BehaviorOperator::BehaviorOperator_Less:
				if (*static_cast<_black_board_t::_data_t*>(leftValue) < *static_cast<_black_board_t::_data_t*>(rightValue))
				{
#ifdef _DEBUG
					LOG_DEBUG_SYS(context->GetComponentImpl()) << "condition < true";
#endif
					if (false == context->SubNodeCall(stack, m_childLeft))
						return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
				}
				else
				{
					if (nullptr != m_childRight)
					{
						if (false == context->SubNodeCall(stack, m_childRight))
							return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
					}
					else
					{
						return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);
					}
				}
				break;
			case BehaviorOperator::BehaviorOperator_Greater:
				if (*static_cast<_black_board_t::_data_t*>(leftValue) > *static_cast<_black_board_t::_data_t*>(rightValue))
				{
					if (false == context->SubNodeCall(stack, m_childLeft))
						return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
				}
				else
				{
					if (nullptr != m_childRight)
					{
						if (false == context->SubNodeCall(stack, m_childRight))
							return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
					}
					else
					{
						return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);
					}
				}
				break;
			case BehaviorOperator::BehaviorOperator_LessOrEqual:
				if (*static_cast<_black_board_t::_data_t*>(leftValue) <= *static_cast<_black_board_t::_data_t*>(rightValue))
				{
					if (false == context->SubNodeCall(stack, m_childLeft))
						return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
				}
				else
				{
					if (nullptr != m_childRight)
					{
						if (false == context->SubNodeCall(stack, m_childRight))
							return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
					}
					else
					{
						return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);
					}
				}
				break;
			case BehaviorOperator::BehaviorOperator_GreaterOrEqual:
				if (*static_cast<_black_board_t::_data_t*>(leftValue) >= *static_cast<_black_board_t::_data_t*>(rightValue))
				{
					if (false == context->SubNodeCall(stack, m_childLeft))
						return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
				}
				else
				{
					if (nullptr != m_childRight)
					{
						if (false == context->SubNodeCall(stack, m_childRight))
							return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
					}
					else
					{
						return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);
					}
				}
				break;
			}

			currCtx->m_check = true;
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);
		}

		if (currCtx->IsSuccessIn())
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);

		return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
	}
	virtual bool AllocateNodeContext(_node_context_t** nodeCtx, _context_t* context) override
	{
		*nodeCtx = new (std::nothrow) condition_node_context;
		if (nullptr == *nodeCtx)
			return false;
		(*nodeCtx)->AddRef();
		return true;
	}
	inline bool AddLeftInput(BehaviorBlackBoardScope scope, _blackboard_id_t id, std::string name)
	{
		if (BehaviorBlackBoardScope::BehaviorBlackBoardScope_None != std::get<BehaviorBlackBoardScope>(m_leftValue))
			return false;
		m_leftValue = std::make_tuple<BehaviorBlackBoardScope, _blackboard_id_t, std::string>(std::forward<BehaviorBlackBoardScope>(scope), std::forward<_blackboard_id_t>(id), std::forward<std::string>(name));
		return true;
	}
	inline bool AddRightInput(BehaviorBlackBoardScope scope, _blackboard_id_t id, std::string name)
	{
		if (BehaviorBlackBoardScope::BehaviorBlackBoardScope_None != std::get<BehaviorBlackBoardScope>(m_rightValue))
			return false;
		m_rightValue = std::make_tuple<BehaviorBlackBoardScope, _blackboard_id_t, std::string>(std::forward<BehaviorBlackBoardScope>(scope), std::forward<_blackboard_id_t>(id), std::forward<std::string>(name));
		return true;
	}
	inline _param_ref_t& GetLeftInput()
	{
		return m_leftValue;
	}
	inline _param_ref_t& GetRightInput()
	{
		return m_rightValue;
	}
	inline void SetOp(BehaviorOperator op)
	{
		m_op = op;
	}
	inline bool AddChildLeft(_node_t* left)
	{
		if (nullptr != m_childLeft)
			return false;
		m_childLeft = left;
		return true;
	}
	inline bool AddChildRight(_node_t* right)
	{
		if (nullptr != m_childRight)
			return false;
		m_childRight = right;
		return true;
	}
	_shared_node_t GetChildLeft()
	{
		return m_childLeft;
	}
	_shared_node_t GetChildRight()
	{
		return m_childRight;
	}
	virtual bool Check() override
	{
		if (false == behavior_node<ALLOC>::Check())
			return false;
		if (BehaviorOperator::BehaviorOperator_None == m_op)
			return false;
		if (BehaviorBlackBoardScope::BehaviorBlackBoardScope_None == std::get<BehaviorBlackBoardScope>(m_leftValue))
			return false;
		if (nullptr == m_childLeft)
			return false;
		if (nullptr != m_childRight)
		{
			if (BehaviorBlackBoardScope::BehaviorBlackBoardScope_None == std::get<BehaviorBlackBoardScope>(m_rightValue))
				return false;
		}
		return true;
	}

private:
	//
	BehaviorOperator m_op;
	_param_ref_t m_leftValue;
	_param_ref_t m_rightValue;
	// condition은 child를 1 ~ 2개 갖는다,
	_shared_node_t m_childLeft;
	_shared_node_t m_childRight;
};

// 
template <typename ALLOC>
class randomcondition_behavior_node : public behavior_node<ALLOC>
{
	struct randomcondition_node_context : public behavior_node_context<ALLOC>
	{
		randomcondition_node_context()
		{
			m_check = false;
		}

		bool m_check;
	};

public:
	using _param_ref_t = std::tuple<BehaviorBlackBoardScope, _blackboard_id_t, std::string>;
public:
	randomcondition_behavior_node(_id_t id)
		: behavior_node(BehaviorType::BehaviorType_RandomCondition, id)
	{
		m_rightValue = std::make_tuple<BehaviorBlackBoardScope, _blackboard_id_t>(BehaviorBlackBoardScope::BehaviorBlackBoardScope_None, 0, "");
	}
	virtual nmsp::behavior::BehaviorReturn Process(_stack_t* stack, _node_context_t* nodeCtx, _context_t* context) override
	{
		auto currCtx = static_cast<randomcondition_node_context*>(nodeCtx);

		// 조건 채크를 위한 노드를 실행
		if (false == currCtx->m_check)
		{
			auto& leftBB = context->BlackBoard(std::get<BehaviorBlackBoardScope>(m_rightValue));

			_black_board_t::_shared_data_t rightValue;

			if (false == leftBB.Find(std::get<_blackboard_id_t>(m_rightValue), static_cast<_black_board_t::_data_t**>(rightValue)))
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

			if (*static_cast<_black_board_t::_data_t*>(rightValue) >= RandomInstance(0.f, 1.f).gen())
			{
				if (false == context->SubNodeCall(stack, m_childLeft))
					return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
			}
			else
			{
				if (nullptr != m_childRight)
				{
					if (false == context->SubNodeCall(stack, m_childRight))
						return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
				}
			}

			currCtx->m_check = true;
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);
		}

		// 조건 체크가 완료되고 아직 서브를 실행하지 않은 경우임
		if (currCtx->IsSuccessIn())
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);

		return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
	}
	virtual bool AllocateNodeContext(_node_context_t** nodeCtx, _context_t* context) override
	{
		*nodeCtx = new (std::nothrow) randomcondition_node_context;
		if (nullptr == *nodeCtx)
			return false;
		(*nodeCtx)->AddRef();
		return true;
	}
	inline bool AddRightInput(BehaviorBlackBoardScope scope, _blackboard_id_t id, std::string name)
	{
		if (BehaviorBlackBoardScope::BehaviorBlackBoardScope_None != std::get<BehaviorBlackBoardScope>(m_rightValue))
			return false;
		m_rightValue = std::make_tuple<BehaviorBlackBoardScope, _blackboard_id_t, std::string>(std::forward<BehaviorBlackBoardScope>(scope), std::forward<_blackboard_id_t>(id), std::forward<std::string>(name));
		return true;
	}
	inline _param_ref_t& GetRightInput()
	{
		return m_rightValue;
	}
	inline bool AddChildLeft(_node_t* left)
	{
		if (nullptr != m_childLeft)
			return false;
		m_childLeft = left;
		return true;
	}
	inline bool AddChildRight(_node_t* right)
	{
		if (nullptr != m_childRight)
			return false;
		m_childRight = right;
		return true;
	}
	_shared_node_t GetChildLeft()
	{
		return m_childLeft;
	}
	_shared_node_t GetChildRight()
	{
		return m_childRight;
	}
	virtual bool Check() override
	{
		if (false == behavior_node<ALLOC>::Check())
			return false;
		if (BehaviorBlackBoardScope::BehaviorBlackBoardScope_None == std::get<BehaviorBlackBoardScope>(m_rightValue))
			return false;
		if (nullptr == m_childLeft)
			return false;
		return true;
	}

private:
	_param_ref_t m_rightValue;
	// condition은 child를 1 ~ 2개 갖는다,
	_shared_node_t m_childLeft;
	_shared_node_t m_childRight;
};

// 
template <typename ALLOC>
class untilsucceeder_behavior_node : public behavior_node<ALLOC>
{
	struct untilsucceeder_node_context : public behavior_node_context<ALLOC>
	{
		untilsucceeder_node_context()
		{
			m_start = false;
			m_lastExecute = 0;
		}

		bool m_start;
		int64_t m_lastExecute;
	};

public:
	untilsucceeder_behavior_node(_id_t id)
		: behavior_node(BehaviorType::BehaviorType_UntilSucceeder, id)
	{
	}
	virtual nmsp::behavior::BehaviorReturn Process(_stack_t* stack, _node_context_t* nodeCtx, _context_t* context) override
	{
		auto currCtx = static_cast<untilsucceeder_node_context*>(nodeCtx);

		// 일정 횟수이상 
		if (true == currCtx->m_start)
		{
			if (currCtx->IsSuccessIn())
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);
		}

		// 이미 실행을 한거라면..
		if (currCtx->m_lastExecute == context->GetCurrentGameTime())
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);

		// sub node를 호출해버린다.
		if (false == context->SubNodeCall(stack, m_child))
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);

		currCtx->m_start = true;
		currCtx->m_lastExecute = context->GetCurrentGameTime();
		currCtx->ClearReturn();

		return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);
	}
	virtual bool AllocateNodeContext(_node_context_t** nodeCtx, _context_t* context) override
	{
		*nodeCtx = new (std::nothrow) untilsucceeder_node_context;
		if (nullptr == *nodeCtx)
			return false;
		(*nodeCtx)->AddRef();
		return true;
	}
	bool AddChild(_node_t* childNode)
	{
		if (nullptr != m_child)
			return false;
		m_child = childNode;
		return true;
	}
	_shared_node_t GetChild()
	{
		return m_child;
	}
	virtual bool Check() override
	{
		if (false == behavior_node<ALLOC>::Check())
			return false;
		if (nullptr == m_child)
			return false;
		return true;
	}

private:
	// decorator는 child를 하나만 갖는다,
	_shared_node_t m_child;
};

// 
template <typename ALLOC>
class untilfailer_behavior_node : public behavior_node<ALLOC>
{
	struct untilfailer_node_context : public behavior_node_context<ALLOC>
	{
		untilfailer_node_context()
		{
			m_start = false;
			m_lastExecute = 0;
		}

		bool m_start;
		int64_t m_lastExecute;
	};

public:
	untilfailer_behavior_node(_id_t id)
		: behavior_node(BehaviorType::BehaviorType_UntilFailer, id)
	{
	}
	virtual nmsp::behavior::BehaviorReturn Process(_stack_t* stack, _node_context_t* nodeCtx, _context_t* context) override
	{
		auto currCtx = static_cast<untilfailer_node_context*>(nodeCtx);

		// 일정 횟수이상 
		if (true == currCtx->m_start)
		{
			if (currCtx->IsFailIn())
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);
		}

		// 이미 실행을 한거라면..
		if (currCtx->m_lastExecute == context->GetCurrentGameTime())
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);

		// sub node를 호출해버린다.
		if (false == context->SubNodeCall(stack, m_child))
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);

		currCtx->m_start = true;
		currCtx->m_lastExecute = context->GetCurrentGameTime();
		currCtx->ClearReturn();

		return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);
	}
	virtual bool AllocateNodeContext(_node_context_t** nodeCtx, _context_t* context) override
	{
		*nodeCtx = new (std::nothrow) untilfailer_node_context;
		if (nullptr == *nodeCtx)
			return false;
		(*nodeCtx)->AddRef();
		return true;
	}
	bool AddChild(_node_t* childNode)
	{
		if (nullptr != m_child)
			return false;
		m_child = childNode;
		return true;
	}
	_shared_node_t GetChild()
	{
		return m_child;
	}
	virtual bool Check() override
	{
		if (false == behavior_node<ALLOC>::Check())
			return false;
		if (nullptr == m_child)
			return false;
		return true;
	}

private:
	// decorator는 child를 하나만 갖는다,
	_shared_node_t m_child;
};

// 
template <typename ALLOC>
class failer_behavior_node : public behavior_node<ALLOC>
{
	struct failer_node_context : public behavior_node_context<ALLOC>
	{
		failer_node_context()
		{
			m_start = false;
		}

		bool m_start;
	};

public:
	failer_behavior_node(_id_t id)
		: behavior_node(BehaviorType::BehaviorType_Failer, id)
	{
	}
	virtual nmsp::behavior::BehaviorReturn Process(_stack_t* stack, _node_context_t* nodeCtx, _context_t* context) override
	{
		auto currCtx = static_cast<failer_node_context*>(nodeCtx);

		if (true == currCtx->m_start)
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

		// sub node를 호출해버린다.
		if (false == context->SubNodeCall(stack, m_child))
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

		currCtx->m_start = true;
		return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);
	}
	virtual bool AllocateNodeContext(_node_context_t** nodeCtx, _context_t* context) override
	{
		*nodeCtx = new (std::nothrow) failer_node_context;
		if (nullptr == *nodeCtx)
			return false;
		(*nodeCtx)->AddRef();
		return true;
	}
	bool AddChild(_node_t* childNode)
	{
		if (nullptr != m_child)
			return false;
		m_child = childNode;
		return true;
	}
	_shared_node_t GetChild()
	{
		return m_child;
	}
	virtual bool Check() override
	{
		if (false == behavior_node<ALLOC>::Check())
			return false;
		if (nullptr == m_child)
			return false;
		return true;
	}

private:
	// decorator는 child를 하나만 갖는다,
	_shared_node_t m_child;
};

// 
template <typename ALLOC>
class repeater_behavior_node : public behavior_node<ALLOC>
{
	struct repeater_node_context : public behavior_node_context<ALLOC>
	{
		repeater_node_context()
		{
			m_count = 0;
			m_lastExecute = 0;
		}

		int m_count;
		int64_t m_lastExecute;
	};

public:
	repeater_behavior_node(_id_t id)
		: behavior_node(BehaviorType::BehaviorType_Repeater, id)
	{
		m_maxCount = 0;
	}
	virtual nmsp::behavior::BehaviorReturn Process(_stack_t* stack, _node_context_t* nodeCtx, _context_t* context) override
	{
		auto currCtx = static_cast<repeater_node_context*>(nodeCtx);

		// 일정 횟수이상 , -1이면 무한데임
		if (-1 != m_maxCount && currCtx->m_count >= m_maxCount)
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);

		// 이미 실행을 한거라면..
		if (currCtx->m_lastExecute == context->GetCurrentGameTime())
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);

		// sub node를 호출해버린다.
		if (false == context->SubNodeCall(stack, m_child))
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);

		currCtx->m_count++;
		currCtx->m_lastExecute = context->GetCurrentGameTime();
		currCtx->ClearReturn();

		return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);
	}
	virtual bool AllocateNodeContext(_node_context_t** nodeCtx, _context_t* context) override
	{
		*nodeCtx = new (std::nothrow) repeater_node_context;
		if (nullptr == *nodeCtx)
			return false;
		(*nodeCtx)->AddRef();
		return true;
	}
	inline void SetMaxLoopCount(int64_t maxCount)
	{
		m_maxCount = maxCount;
	}
	bool AddChild(_node_t* childNode)
	{
		if (nullptr != m_child)
			return false;
		m_child = childNode;
		return true;
	}
	_shared_node_t GetChild()
	{
		return m_child;
	}
	virtual bool Check() override
	{
		if (false == behavior_node<ALLOC>::Check())
			return false;
		if (nullptr == m_child)
			return false;
		return true;
	}

private:
	// decorator는 child를 하나만 갖는다,
	_shared_node_t m_child;
	int64_t m_maxCount;
};

// 
template <typename ALLOC>
class succeeder_behavior_node : public behavior_node<ALLOC>
{
	struct succeeder_node_context : public behavior_node_context<ALLOC>
	{
		succeeder_node_context()
		{
			m_start = false;
		}

		bool m_start;
	};

public:
	succeeder_behavior_node(_id_t id)
		: behavior_node(BehaviorType::BehaviorType_Succeeder, id)
	{
	}
	virtual nmsp::behavior::BehaviorReturn Process(_stack_t* stack, _node_context_t* nodeCtx, _context_t* context) override
	{
		auto currCtx = static_cast<succeeder_node_context*>(nodeCtx);

		if (true == currCtx->m_start)
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);

		// sub node를 호출해버린다.
		if (false == context->SubNodeCall(stack, m_child))
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);

		currCtx->m_start = true;
		return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);
	}
	virtual bool AllocateNodeContext(_node_context_t** nodeCtx, _context_t* context) override
	{
		*nodeCtx = new (std::nothrow) succeeder_node_context;
		if (nullptr == *nodeCtx)
			return false;
		(*nodeCtx)->AddRef();
		return true;
	}
	bool AddChild(_node_t* childNode)
	{
		if (nullptr != m_child)
			return false;
		m_child = childNode;
		return true;
	}
	_shared_node_t GetChild()
	{
		return m_child;
	}
	virtual bool Check() override
	{
		if (false == behavior_node<ALLOC>::Check())
			return false;
		if (nullptr == m_child)
			return false;
		return true;
	}

private:
	// decorator는 child를 하나만 갖는다,
	_shared_node_t m_child;
};

// 
template <typename ALLOC>
class inverter_behavior_node : public behavior_node<ALLOC>
{
	struct inverter_node_context : public behavior_node_context<ALLOC>
	{
		inverter_node_context()
		{
			m_start = false;
		}

		bool m_start;
	};

public:
	inverter_behavior_node(_id_t id)
		: behavior_node(BehaviorType::BehaviorType_Inverter, id)
	{
	}
	virtual nmsp::behavior::BehaviorReturn Process(_stack_t* stack, _node_context_t* nodeCtx, _context_t* context) override
	{
		auto currCtx = static_cast<inverter_node_context*>(nodeCtx);

		if (true == currCtx->m_start)
		{
			// 처리 결과를 반대로 바꿔버리자!
			if (currCtx->IsSuccessIn())
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);
		}

		// sub node를 호출해버린다.
		if (false == context->SubNodeCall(stack, m_child))
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

		currCtx->m_start = true;
		return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);
	}
	virtual bool AllocateNodeContext(_node_context_t** nodeCtx, _context_t* context) override
	{
		*nodeCtx = new (std::nothrow) inverter_node_context;
		if (nullptr == *nodeCtx)
			return false;
		(*nodeCtx)->AddRef();
		return true;
	}
	bool AddChild(_node_t* childNode)
	{
		if (nullptr != m_child)
			return false;
		m_child = childNode;
		return true;
	}
	_shared_node_t GetChild()
	{
		return m_child;
	}
	virtual bool Check() override
	{
		if (false == behavior_node<ALLOC>::Check())
			return false;
		if (nullptr == m_child)
			return false;
		return true;
	}

private:
	// decorator는 child를 하나만 갖는다,
	_shared_node_t m_child;
};

// 
template <typename ALLOC>
class parallel_behavior_node : public behavior_node<ALLOC>
{
	struct parallel_node_context : public behavior_node_context<ALLOC>
	{
		parallel_node_context()
		{
		}

		_shared_stack_t m_subChildStack;
	};

public:
	parallel_behavior_node(_id_t id)
		: behavior_node(BehaviorType::BehaviorType_Parallel, id)
	{
		m_quitType = BehaviorParallelQuitType::BehaviorParallelQuitType_Immediately;
	}
	virtual nmsp::behavior::BehaviorReturn Process(_stack_t* stack, _node_context_t* nodeCtx, _context_t* context) override
	{
		auto currCtx = static_cast<parallel_node_context*>(nodeCtx);

		if (nullptr != currCtx->m_subChildStack)
		{
			// 이상한 상황이다. Process가 호출이 됬다는건 하위에서 결과가 리턴되야 하기 때문이다
			if (false == currCtx->IsResult())
			{
				context->DelAllChildStack(stack);
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
			}

			// 존재한다면 종료타입에 따른다 .. 즉시 종료라면
			if (BehaviorParallelQuitType::BehaviorParallelQuitType_Immediately == m_quitType)
			{
				context->DelAllChildStack(stack);

				if (currCtx->IsSuccessIn())
					return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
			}

			// 대기하는 거라면
			if (nmsp::behavior::BehaviorReturn::BehaviorReturn_Running != currCtx->m_subChildStack->GetExitValue())
			{
				context->DelAllChildStack(stack);

				if (currCtx->IsSuccessIn())
					return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
			}

			// 아직 sub가 실행중이므로 종료되기를 기다려야 한다..
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);
		}

		_shared_stack_t newStack;
		if (false == context->NewStack(stack, m_subChild, static_cast<_stack_t**>(newStack)))
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

		if (false == context->SubNodeCall(stack, m_mainChild))
		{
			context->DelAllChildStack(stack);
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
		}

		currCtx->m_subChildStack = newStack;
		return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);
	}
	virtual bool AllocateNodeContext(_node_context_t** nodeCtx, _context_t* context) override
	{
		*nodeCtx = new (std::nothrow) parallel_node_context;
		if (nullptr == *nodeCtx)
			return false;
		(*nodeCtx)->AddRef();
		return true;
	}
	inline void SetQuitType(BehaviorParallelQuitType type)
	{
		m_quitType = type;
	}
	inline bool AddMainChild(_node_t* mainNode)
	{
		if (nullptr != m_mainChild)
			return false;
		m_mainChild = mainNode;
		return true;
	}
	inline bool AddSubChild(_node_t* subNode)
	{
		if (nullptr != m_subChild)
			return false;
		m_subChild = subNode;
		return true;
	}
	_shared_node_t GetMainChild()
	{
		return m_mainChild;
	}
	_shared_node_t GetSubChild()
	{
		return m_subChild;
	}
	virtual bool Check() override
	{
		if (false == behavior_node<ALLOC>::Check())
			return false;
		if (BehaviorParallelQuitType::BehaviorParallelQuitType_None == m_quitType || nullptr == m_mainChild || nullptr == m_subChild)
			return false;
		return true;
	}

private:
	BehaviorParallelQuitType m_quitType;
	_shared_node_t m_mainChild;			// 단일 노드여야 한다
	_shared_node_t m_subChild;			// 아무거나 상관은 없다.
};

// 
template <typename ALLOC>
class randomselector_behavior_node : public behavior_node<ALLOC>
{
	struct randomselector_node_context : public behavior_node_context<ALLOC>
	{
		randomselector_node_context(const _children_t& src)
		{
			m_index = 0;
			m_children = src;
			std::shuffle(m_children.begin(), m_children.end(), nmsp::RandomInstance());
		}

		int m_index;
		_children_t m_children;
	};

public:
	randomselector_behavior_node(_id_t id)
		: behavior_node(BehaviorType::BehaviorType_RandomSelector, id)
	{
	}
	virtual nmsp::behavior::BehaviorReturn Process(_stack_t* stack, _node_context_t* nodeCtx, _context_t* context) override
	{
		auto currCtx = static_cast<randomselector_node_context*>(nodeCtx);

		// child들이 모두 실행이 되었으므로.. 결과 처리를 해야 한다.
		if (0 < currCtx->m_index)
		{
			if (true == currCtx->IsSuccessIn())
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);

			if (m_children.size() <= currCtx->m_index)
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
		}

		// 자식노드를 호출하는데 실패했다면
		if (false == context->SubNodeCall(stack, currCtx->m_children[currCtx->m_index]))
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

		// 자식노드를 호출하는데 성공했다면.. 실행중을 리턴한다
		currCtx->m_index++;
		return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);
	}
	virtual bool AllocateNodeContext(_node_context_t** nodeCtx, _context_t* context) override
	{
		*nodeCtx = new (std::nothrow) randomselector_node_context(m_children);
		if (nullptr == *nodeCtx)
			return false;
		(*nodeCtx)->AddRef();
		return true;
	}
	bool AddChild(_node_t* childNode)
	{
		for (auto& itr : m_children)
		{
			if (itr->ID() == childNode->ID())
				return false;
		}

		m_children.emplace_back(childNode);
		return true;
	}
	const _children_t& GetChilds()
	{
		return m_children;
	}
	virtual bool Check() override
	{
		if (false == behavior_node<ALLOC>::Check())
			return false;
		return !m_children.empty();
	}

private:
	_children_t m_children;
};

// 
template <typename ALLOC>
class randomsequence_behavior_node : public behavior_node<ALLOC>
{
	struct randomsequence_node_context : public behavior_node_context<ALLOC>
	{
		randomsequence_node_context(const _children_t& src)
		{
			m_index = 0;
			m_children = src;
			std::shuffle(m_children.begin(), m_children.end(), nmsp::RandomInstance());
		}

		std::size_t m_index;
		_children_t m_children;
	};

public:
	randomsequence_behavior_node(_id_t id)
		: behavior_node(BehaviorType::BehaviorType_RandomSequence, id)
	{
	}
	virtual nmsp::behavior::BehaviorReturn Process(_stack_t* stack, _node_context_t* nodeCtx, _context_t* context) override
	{
		auto currCtx = static_cast<randomsequence_node_context*>(nodeCtx);

		// child들이 모두 실행이 되었으므로.. 결과 처리를 해야 한다.
		if (m_children.size() <= currCtx->m_index)
		{
			if (true == currCtx->IsAllSuccess())
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
		}

		// 하나라도 실패가 들어 있다면
		if (true == currCtx->IsFailIn())
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

		// 자식노드를 호출하는데 실패했다면
		if (false == context->SubNodeCall(stack, currCtx->m_children[currCtx->m_index]))
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

		// 자식노드를 호출하는데 성공했다면.. 실행중을 리턴한다
		currCtx->m_index++;
		return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);
	}
	virtual bool AllocateNodeContext(_node_context_t** nodeCtx, _context_t* context) override
	{
		*nodeCtx = new (std::nothrow) randomsequence_node_context(m_children);
		if (nullptr == *nodeCtx)
			return false;
		(*nodeCtx)->AddRef();
		return true;
	}
	bool AddChild(_node_t* childNode)
	{
		for (auto& itr : m_children)
		{
			if (itr->ID() == childNode->ID())
				return false;
		}

		m_children.emplace_back(childNode);
		return true;
	}
	const _children_t& GetChilds()
	{
		return m_children;
	}
	virtual bool Check() override
	{
		if (false == behavior_node<ALLOC>::Check())
			return false;
		return !m_children.empty();
	}

private:
	_children_t m_children;
};

// 
template <typename ALLOC>
class selector_behavior_node : public behavior_node<ALLOC>
{
	struct selector_node_context : public behavior_node_context<ALLOC>
	{
		selector_node_context()
		{
			m_index = 0;
		}
		std::size_t m_index;
	};

public:
	selector_behavior_node(_id_t id)
		: behavior_node(BehaviorType::BehaviorType_Selector, id)
	{
	}
	virtual nmsp::behavior::BehaviorReturn Process(_stack_t* stack, _node_context_t* nodeCtx, _context_t* context) override
	{
		auto currCtx = static_cast<selector_node_context*>(nodeCtx);

		// child들이 모두 실행이 되었으므로.. 결과 처리를 해야 한다.
		if (0 < currCtx->m_index)
		{
			if (true == currCtx->IsSuccessIn())
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);

			if (m_children.size() <= currCtx->m_index)
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
		}

		// 자식노드를 호출하는데 실패했다면
		if (false == context->SubNodeCall(stack, m_children[currCtx->m_index]))
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

		// 자식노드를 호출하는데 성공했다면.. 실행중을 리턴한다
		currCtx->m_index++;
		return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);
	}
	virtual bool AllocateNodeContext(_node_context_t** nodeCtx, _context_t* context) override
	{
		*nodeCtx = new (std::nothrow) selector_node_context;
		if (nullptr == *nodeCtx)
			return false;
		(*nodeCtx)->AddRef();
		return true;
	}
	bool AddChild(_node_t* childNode)
	{
		for (auto& itr : m_children)
		{
			if (itr->ID() == childNode->ID())
				return false;
		}

		m_children.emplace_back(childNode);
		return true;
	}
	const _children_t& GetChilds()
	{
		return m_children;
	}
	virtual bool Check() override
	{
		if (false == behavior_node<ALLOC>::Check())
			return false;
		return !m_children.empty();
	}

private:
	_children_t m_children;
};

// 
template <typename ALLOC>
class sequence_behavior_node : public behavior_node<ALLOC>
{
	struct sequence_node_context : public behavior_node_context<ALLOC>
	{
		sequence_node_context()
		{
			m_index = 0;
		}
		std::size_t m_index;
	};

public:
	sequence_behavior_node(_id_t id)
		: behavior_node(BehaviorType::BehaviorType_Sequence, id)
	{
	}
	virtual nmsp::behavior::BehaviorReturn Process(_stack_t* stack, _node_context_t* nodeCtx, _context_t* context) override
	{
		auto currCtx = static_cast<sequence_node_context*>(nodeCtx);

		// child들이 모두 실행이 되었으므로.. 결과 처리를 해야 한다.
		if (m_children.size() <= currCtx->m_index)
		{
			if (true == currCtx->IsAllSuccess())
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);

			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
		}

		// 하나라도 실패가 들어 있다면
		if (true == currCtx->IsFailIn())
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

		// 자식노드를 호출하는데 실패했다면
		if (false == context->SubNodeCall(stack, m_children[currCtx->m_index]))
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
		
		// 자식노드를 호출하는데 성공했다면.. 실행중을 리턴한다
		currCtx->m_index++;
		return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);
	}
	virtual bool AllocateNodeContext(_node_context_t** nodeCtx, _context_t* context) override
	{
		*nodeCtx = new (std::nothrow) sequence_node_context;
		if (nullptr == *nodeCtx)
			return false;
		(*nodeCtx)->AddRef();
		return true;
	}
	bool AddChild(_node_t* childNode)
	{
		for (auto& itr : m_children)
		{
			if (itr->ID() == childNode->ID())
				return false;
		}

		m_children.emplace_back(childNode);
		return true;
	}
	const _children_t& GetChilds()
	{
		return m_children;
	}

	virtual bool Check() override
	{
		if (false == behavior_node<ALLOC>::Check())
			return false;
		return !m_children.empty();
	}

private:
	_children_t m_children;
};

// 
template <typename ALLOC>
class message_behavior_node : public behavior_node<ALLOC>
{
	struct message_node_context : public behavior_node_context<ALLOC>
	{
		message_node_context()
		{
			m_start = false;
		}
		bool m_start;
	};

public:
	message_behavior_node(_id_t id)
		: behavior_node(BehaviorType::BehaviorType_Message, id)
	{
		m_messageId = std::numeric_limits<decltype(m_messageId)>::max();
		m_stackResetFlag = false;
	}
	virtual nmsp::behavior::BehaviorReturn Process(_stack_t* stack, _node_context_t* nodeCtx, _context_t* context) override
	{
		auto currCtx = static_cast<message_node_context*>(nodeCtx);

		if (true == currCtx->m_start)
		{
			if (currCtx->IsFailIn())
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);
		}

		// sub node를 호출해버린다.
		if (false == context->SubNodeCall(stack, m_child))
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

		currCtx->m_start = true;
		return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);
	}
	virtual bool AllocateNodeContext(_node_context_t** nodeCtx, _context_t* context) override
	{
		*nodeCtx = new (std::nothrow) message_node_context;
		if (nullptr == *nodeCtx)
			return false;
		(*nodeCtx)->AddRef();
		return true;
	}
	inline bool AddChild(_node_t* childNode)
	{
		if (nullptr != m_child)
			return false;
		m_child = childNode;
		return true;
	}
	_shared_node_t GetChild()
	{
		return m_child;
	}
	inline void SetMessageId(int messageId)
	{
		m_messageId = messageId;
	}
	inline int GetMessageId()
	{
		return m_messageId;
	}
	inline void SetStackResetFlag(bool flag)
	{
		m_stackResetFlag = flag;
	}
	inline bool GetStackResetFlag() const
	{
		return m_stackResetFlag;
	}
	virtual bool Check() override
	{
		if (false == behavior_node<ALLOC>::Check())
			return false;
		if (nullptr == m_child)
			return false;
		return true;
	}

private:
	// message는 child를 하나만 갖는다,
	_shared_node_t m_child;
	int m_messageId;
	bool m_stackResetFlag;
};

// 
template <typename ALLOC>
class submodule_behavior_node : public behavior_node<ALLOC>
{
	struct submodule_node_context : public behavior_node_context<ALLOC>
	{
		submodule_node_context()
		{
			m_start = false;
		}
		bool m_start;
	};

public:
	using _param_ref_t = std::tuple<BehaviorBlackBoardScope, _blackboard_id_t, std::string>;

public:
	submodule_behavior_node(_id_t id)
		: behavior_node(BehaviorType::BehaviorType_SubModule, id)
	{
	}
	virtual nmsp::behavior::BehaviorReturn Process(_stack_t* stack, _node_context_t* nodeCtx, _context_t* context) override
	{
		auto currCtx = static_cast<submodule_node_context*>(nodeCtx);

		if (true == currCtx->m_start)
		{
			if (currCtx->IsFailIn())
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);
		}

		// sub node를 호출해버린다.
		if (false == context->SubNodeCall(stack, m_child))
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

		currCtx->m_start = true;
		return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);
	}
	virtual bool AllocateNodeContext(_node_context_t** nodeCtx, _context_t* context) override
	{
		*nodeCtx = new (std::nothrow) submodule_node_context;
		if (nullptr == *nodeCtx)
			return false;
		(*nodeCtx)->AddRef();
		return true;
	}
	inline bool AddChild(_node_t* childNode)
	{
		if (nullptr != m_child)
			return false;
		m_child = childNode;
		return true;
	}
	_shared_node_t GetChild()
	{
		return m_child;
	}
	virtual bool Check() override
	{
		if (false == behavior_node<ALLOC>::Check())
			return false;
		if (nullptr == m_child)
			return false;
		return true;
	}
	inline bool AddInput(BehaviorBlackBoardScope scope, _blackboard_id_t id, std::string name)
	{
		if (BehaviorBlackBoardScope::BehaviorBlackBoardScope_None != std::get<BehaviorBlackBoardScope>(m_inputValue))
			return false;
		m_inputValue = std::make_tuple<BehaviorBlackBoardScope, _blackboard_id_t, std::string>(std::forward<BehaviorBlackBoardScope>(scope), std::forward<_blackboard_id_t>(id), std::forward<std::string>(name));
		return true;
	}
	inline _param_ref_t GetInput()
	{
		return m_inputValue;
	}
	inline const _param_ref_t& GetParamTypes()
	{
		return m_inputValue;
	}

private:
	// child를 하나만 갖는다,
	_shared_node_t m_child;
	_param_ref_t m_inputValue;
};

// 
template <typename ALLOC>
class call_behavior_node : public behavior_node<ALLOC>
{
	using _black_board_t = behavior_blackboard<ALLOC>;
	using _black_board_t = behavior_blackboard<ALLOC>;
	using _blackboard_id_t = typename _black_board_t::_id_t;

	struct call_node_context : public behavior_node_context<ALLOC>
	{
		call_node_context()
		{
			m_start = false;
		}

		bool m_start;
		_black_board_t m_backup;
	};

public:
	using _param_ref_t = typename task_behavior_node<ALLOC>::_param_ref_t;

public:
	call_behavior_node(_id_t id)
		: behavior_node(BehaviorType::BehaviorType_Call, id)
	{
	}
	virtual nmsp::behavior::BehaviorReturn Process(_stack_t* stack, _node_context_t* nodeCtx, _context_t* context) override
	{
		auto currCtx = static_cast<call_node_context*>(nodeCtx);
		auto& prevLocalBlackBoard = context->BlackBoard(BehaviorBlackBoardScope::BehaviorBlackBoardScope_Local);

		if (true == currCtx->m_start)
		{
			// 원래의 것으로 돌려 놓는다!
			prevLocalBlackBoard = std::move(currCtx->m_backup);

			// 처리 결과를 반대로 바꿔버리자!
			if (currCtx->IsAllSuccess())
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);

			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
		}

		// 새로 구성해 봅시다!
		_black_board_t newLocalBlackBoard;

		// 로컬 변수들은 인수 순서와 동일한 개념으로 생각한다..
		_blackboard_id_t localBid = AiGroupID_Start;
		for (const auto& itr : m_refInput)
		{
			auto& blackBoard = context->BlackBoard(std::get<BehaviorBlackBoardScope>(itr));

			_black_board_t::_shared_data_t data;
			if (false == blackBoard.Find(std::get<_blackboard_id_t>(itr), data))
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

			if (false == newLocalBlackBoard.Add(localBid, std::move(data)))
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

			++localBid;
		}

		// 기존것을 복사해 놓는다
		currCtx->m_backup = std::move(prevLocalBlackBoard);
		// 새 것으로 설정한다.
		prevLocalBlackBoard = std::move(newLocalBlackBoard);

		// sub node를 호출해버린다.
		if (false == context->SubNodeCall(stack, m_child))
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

		currCtx->m_start = true;
		return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);
	}
	virtual bool AllocateNodeContext(_node_context_t** nodeCtx, _context_t* context) override
	{
		*nodeCtx = new (std::nothrow) call_node_context;
		if (nullptr == *nodeCtx)
			return false;
		(*nodeCtx)->AddRef();
		return true;
	}
	bool AddChild(_node_t* childNode)
	{
		if (nullptr != m_child)
			return false;

		if (BehaviorType::BehaviorType_SubModule != childNode->Type())
			return false;

		m_child = childNode;
		return true;
	}
	_shared_node_t GetChild()
	{
		return m_child;
	}
	inline void SetParam(_param_ref_t&& input)
	{
		m_refInput = std::forward<_param_ref_t>(input);
	}
	_param_ref_t& GetParam()
	{
		return m_refInput;
	}
	virtual bool Check() override
	{
		if (false == behavior_node<ALLOC>::Check())
			return false;
		if (nullptr == m_child)
			return false;

		//submodule_behavior_node<_allocator_t>* child = static_cast<submodule_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(m_child));
		//const auto& childParam = child->GetParamTypes();

		//if (m_refInput.size() != childParam.size())
		//	return false;

		//auto currArgu = m_refInput.begin();
		//auto currParam = childParam.begin();

		//for (; currArgu != m_refInput.end();)
		//{
		//	if (std::get<2>(*currArgu) != std::get<2>(*currParam))
		//		return false;

		//	++currArgu;
		//	++currParam;
		//}

		return true;
	}

private:
	// decorator는 child를 하나만 갖는다,
	_shared_node_t m_child;
	_param_ref_t m_refInput;
};

// 
template <typename ALLOC>
class once_behavior_node : public behavior_node<ALLOC>
{
	using _black_board_t = behavior_blackboard<ALLOC>;
	using _blackboard_id_t = typename _black_board_t::_id_t;

	struct once_node_context : public behavior_node_context<ALLOC>
	{
		once_node_context()
		{
			m_start = false;
		}
		bool m_start;
	};

public:
	once_behavior_node(_id_t id)
		: behavior_node(BehaviorType::BehaviorType_Once, id)
	{
	}
	virtual nmsp::behavior::BehaviorReturn Process(_stack_t* stack, _node_context_t* nodeCtx, _context_t* context) override
	{
		auto currCtx = static_cast<once_node_context*>(nodeCtx);

		if (true == currCtx->m_start)
		{
			if (currCtx->IsFailIn())
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Success);
		}

		// 이미 실행을 했다면 실패.
		auto checkId = context->Object()->GetResetCheckId();
		auto& blackBoard = context->BlackBoard(std::get<BehaviorBlackBoardScope>(m_inherentValue));

		_black_board_t::_shared_data_t data;
		if (false == blackBoard.Find(std::get<_blackboard_id_t>(m_inherentValue), data))
		{
			if (false == blackBoard.Update(std::get<_blackboard_id_t>(m_inherentValue), data, nmsp::behavior::BehaviorDataType::BehaviorDataType_Int64))
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
		}
		else
		{
			int64_t savedCheckId;
			if (true == data->GetValue(&savedCheckId) && checkId == savedCheckId)
				return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);
		}

		// sub node를 호출해버린다.
		if (false == context->SubNodeCall(stack, m_child))
			return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Fail);

		// 값을 저장한다.
		data->SetValue(static_cast<int64_t>(checkId));

		// 실행했음을..
		currCtx->m_start = true;
		return ReturnValueToStack(stack, nmsp::behavior::BehaviorReturn::BehaviorReturn_Running);
	}
	virtual bool AllocateNodeContext(_node_context_t** nodeCtx, _context_t* context) override
	{
		*nodeCtx = new (std::nothrow) once_node_context;
		if (nullptr == *nodeCtx)
			return false;
		(*nodeCtx)->AddRef();
		return true;
	}
	inline bool AddChild(_node_t* childNode)
	{
		if (nullptr != m_child)
			return false;
		m_child = childNode;
		return true;
	}
	_shared_node_t GetChild()
	{
		return m_child;
	}
	virtual bool Check() override
	{
		if (false == behavior_node<ALLOC>::Check())
			return false;
		if (nullptr == m_child)
			return false;
		return true;
	}

private:
	// child를 하나만 갖는다,
	_shared_node_t m_child;
};

// 
template <typename ALLOC>
class behavior_tree : public nmsp::new_from_pool<ALLOC>
{
	using _allocator_t = ALLOC;
	using _node_t = behavior_node<_allocator_t>;
	typedef typename _node_t::_id_t _id_t;
	using _object_id_t = uint64_t;
	using _group_id_t = int;
	using _shared_node_t = nmsp::smartinterface<_node_t>;
	using _message_node_t = message_behavior_node<_allocator_t>;
	using _shared_message_node_t = nmsp::smartinterface<_message_node_t>;
	using _object_t = nmsp::behavior::IBehaviorObject;
	using _node_context_t = behavior_node_context<_allocator_t>;
	using _shared_node_context_t = nmsp::smartinterface<_node_context_t>;
	using _stack_t = behavior_stack<_shared_node_t, _shared_node_context_t, _allocator_t>;
	using _shared_stack_t = nmsp::smartinterface<_stack_t>;
	using _stack_list_t = std::list<_shared_stack_t, nmsp::stl_default_allocator<_shared_stack_t, _allocator_t>>;
	using _context_t = behavior_context<_node_t, _allocator_t>;
	using _shared_context_t = nmsp::smartinterface<_context_t>;
	using _shared_object_t = nmsp::smartinterface<_object_t>;
	using _black_board_t = behavior_blackboard<_allocator_t>;
	using _ai_value_t = std::tuple<_shared_object_t, _shared_context_t>;
	using _ai_map_t = std::unordered_map<_object_id_t, _ai_value_t, std::hash<_object_id_t>, std::equal_to<_object_id_t>, nmsp::stl_default_allocator<std::pair<const _object_id_t, _ai_value_t>, _allocator_t>>;
	using _behavior_t = behavior<_allocator_t>;
	using _level_behavior_tree_t = typename _behavior_t::_level_behavior_tree_t;

public:
	behavior_tree(_behavior_t* behavior, _level_behavior_tree_t* parant, _node_t* root)
		: m_refs(0)
		, m_root(root)
	{
		m_seq = 0;
		m_behavior = behavior;
		m_parant = parant;
	}
	~behavior_tree()
	{
	}
	inline bool AllocateStack(_stack_t** stack)
	{
		for (auto itr = m_stackFreeList.begin(); itr != m_stackFreeList.end(); ++itr)
		{
			if (1 != (*itr)->RefCount())
				continue;

			(*stack) = (*itr);
			(*stack)->AddRef();
			(*stack)->Reset();

			m_stackFreeList.erase(itr);
			return true;
		}

		*stack = new (std::nothrow) _stack_t(++m_seq);
		if (nullptr == *stack)
			return false;

		(*stack)->AddRef();
		return true;
	}
	inline void DeallocateStack(_stack_t* stack)
	{
		stack->ClearStack();
		m_stackFreeList.emplace_back(stack);
	}
	inline bool Add(_object_id_t oid, _object_t* obj, _group_id_t gid, _black_board_t& constBlackBoard, _black_board_t& globalBlackBoard)
	{
		auto itr = m_aiMap.find(oid);
		if (itr != m_aiMap.end())
			return false;

		_shared_context_t newContext = new (std::nothrow) _context_t(this, m_root, obj, constBlackBoard, globalBlackBoard);
		if (nullptr == newContext)
			return false;

		m_gid = gid;

		auto paieRet = m_aiMap.emplace(oid, std::make_tuple(obj, newContext));
		return paieRet.second;
	}
	inline bool Del(_object_id_t oid)
	{
		auto itr = m_aiMap.find(oid);
		if (itr == m_aiMap.end())
			return false;

		m_aiMap.erase(itr);
		return true;
	}
	inline std::size_t Empty()
	{
		return m_aiMap.empty();
	}
	inline void Process()
	{
		for (auto& itr : m_aiMap)
			std::get<_shared_context_t>(itr.second)->Process();
	}
	inline void Process(uint64_t oid)
	{
		auto itr = m_aiMap.find(oid);
		if (itr == m_aiMap.end())
			return;

		std::get<_shared_context_t>(itr->second)->Process();
	}
	inline int AddRef()
	{
		return ++m_refs;
	}
	inline int Release()
	{
		int refs = --m_refs;
		if (0 == refs)
		{
			delete this;
			return 0;
		}
		return refs;
	}
	inline const int64_t& GetCurrentGameTime() const
	{
		return m_parant->GetCurrentGameTime();
	}
	inline void Reset(uint64_t oid)
	{
		auto itr = m_aiMap.find(oid);
		if (itr == m_aiMap.end())
			return;

		std::get<_shared_context_t>(itr->second)->Reset();
	}
	inline auto FindMessageNode(typename const _behavior_t::_message2node_t::key_type& key, _shared_message_node_t& messageNode)
	{
		return m_behavior->FindMessageNode(key, messageNode);
	}
	inline behavior_component_impl* GetComponentImpl()
	{
		return m_behavior->GetComponentImpl();
	}

private:
	std::atomic_int m_refs;
	_shared_node_t m_root;
	_stack_list_t m_stackFreeList;
	_ai_map_t m_aiMap;
	int m_seq;
	_group_id_t m_gid;
	_behavior_t* m_behavior;
	_level_behavior_tree_t* m_parant;
};

// 
template <typename ALLOC>
class behavior: public nmsp::behavior::IBehavior
{
public:
	using _allocator_t = ALLOC;
	using _fileset_t = std::vector<std::string>;
	using _this_t = behavior<_allocator_t>;
	typedef typename behavior_node<_allocator_t>::_id_t _id_t;
	using _group_id_t = int;
	using _object_id_t = uint64_t;
	using _black_board_t = behavior_blackboard<_allocator_t>;
	typedef typename _black_board_t::_id_t _blackboard_id_t;
	using _node_t = behavior_node<_allocator_t>;
	using _shared_node_t = nmsp::smartinterface<_node_t>;
	using _message_node_t = message_behavior_node<_allocator_t>;
	using _shared_message_node_t = nmsp::smartinterface<_message_node_t>;
	using _object_t = nmsp::behavior::IBehaviorObject;
	using _shared_object_t = nmsp::smartinterface<_object_t>;
	using _name2node_t = std::unordered_map<std::string, _shared_node_t>;
	using _groupname2gid_t = std::unordered_map<std::string, _group_id_t>;
	using _gid2node_t = std::unordered_map<_group_id_t, _shared_node_t>;
	using _message2node_t = std::unordered_map<int, _shared_message_node_t>;
	using _name2bid_t = std::unordered_map<std::string, std::tuple<_blackboard_id_t, BehaviorBlackBoardDataType, BehaviorBlackBoardScope>>;
	using _name2boardbid_t = std::vector<std::tuple<_blackboard_id_t, BehaviorBlackBoardDataType, BehaviorBlackBoardScope, std::string>>;
	using _name_t = std::set<std::string>;

	using _name2cmd_t = std::unordered_map<std::string, int>;
	using _boardset_t = std::vector<std::string>;
	using _name2board_t = std::unordered_map<std::string, _boardset_t>;
	using _name2mem_t = std::unordered_map<std::string, _blackboard_id_t>;

	using _behavior_tree_t = behavior_tree<_allocator_t>;
	using _shared_behavior_tree_t = nmsp::smartinterface<_behavior_tree_t>;

public:
	class _level_behavior_tree_t : public std::unordered_map<_group_id_t, _shared_behavior_tree_t, std::hash<_group_id_t>, std::equal_to<_group_id_t>, nmsp::stl_default_allocator<std::pair<const _group_id_t, _shared_behavior_tree_t>, _allocator_t>>
	{
	public:
		_level_behavior_tree_t()
			: m_refs(0)
		{
			m_currentGameTime = 0;
		}
		inline int AddRef()
		{
			return ++m_refs;
		}
		inline int Release()
		{
			int refs = --m_refs;
			if (0 == refs)
			{
				delete this;
				return 0;
			}
			return refs;
		}
		inline void Process(int64_t currentGameTime)
		{
			m_currentGameTime = currentGameTime;

			for (auto itr = this->begin(); itr != this->end(); ++itr)
				itr->second->Process();
		}
		inline _black_board_t& GlobalBlackBoard()
		{
			return m_blackBoard;
		}
		inline const int64_t& GetCurrentGameTime() const
		{
			return m_currentGameTime;
		}
	private:
		std::atomic_int m_refs;
		int64_t m_currentGameTime;
		_black_board_t m_blackBoard;					// global
	};
	using _shared_level_behavior_tree_t = nmsp::smartinterface<_level_behavior_tree_t>;
	using _level_container_t = std::unordered_map<int64_t, _shared_level_behavior_tree_t, std::hash<int64_t>, std::equal_to<int64_t>, nmsp::stl_default_allocator<std::pair<const int64_t, _shared_level_behavior_tree_t>, _allocator_t>>;
	// 명령 정보..
	class behavior_command_info
		: public nmsp::behavior::IBehaviorCommandInfo
		, public nmsp::new_from_pool<_allocator_t>
	{
	public:
		behavior_command_info(_name2cmd_t& name2Cmd)
			: m_refs(0)
		{
			m_name2Cmd = name2Cmd;
			m_itr = m_name2Cmd.cbegin();
		}
		inline int AddRef()
		{
			return ++m_refs;
		}
		inline int Release()
		{
			int refs = --m_refs;
			if (0 == refs)
			{
				delete this;
				return 0;
			}
			return refs;
		}
		virtual int Size() override
		{
			return static_cast<int>(m_name2Cmd.size());
		}
		virtual bool Current(const char** name, int* id) override
		{
			if (m_itr == m_name2Cmd.end())
				return false;
			*name = m_itr->first.c_str();
			*id = m_itr->second;
			return true;
		}
		virtual bool MoveNext() override
		{
			if (m_itr == m_name2Cmd.end())
				return false;
			++m_itr;
			return true;
		}
		virtual void Reset() override
		{
			m_itr = m_name2Cmd.cbegin();
		}

	private:
		_name2cmd_t m_name2Cmd;
		_name2cmd_t::const_iterator m_itr;
		std::atomic_int m_refs;
	};

private:
	// 읽을 파일 목록을 검색한다!
	// OS독립적으로 만들려는.. 인터넷의 어딘가에서 가져왔는데 잊었음..ㅜㅜ
	void FindFiles(const std::string & filesearch, _fileset_t& fileset)
	{
		// Initialize path p (if necessary prepend with ./ so current dir is used) 
		boost::filesystem::path p(filesearch);
		if (!boost::filesystem::path(filesearch).has_parent_path())
		{
			p = "./";
			p /= filesearch;
		}

		// Initialize regex filter - use *.* as default if nothing is given in filesearch
		std::string f;

		if (p.has_filename())
			f = p.filename().string();
		else
			f = "*.*";

		// Make replacements:
		// 1: Replace . with \. (i.e. escape it)
		// 2: Replace any ? with .
		// 3: Replace any * with .* 
		f = boost::regex_replace(f, boost::regex("(\\.)|(\\?)|(\\*)"), "(?1\\\\.)(?2.)(?3.*)", boost::match_default | boost::format_all);

		const boost::regex filter(f);

		boost::filesystem::path dir(boost::filesystem::system_complete(p).parent_path());
		if (boost::filesystem::is_directory(dir))
		{
			// Iterate through contents (files/directories) of directory...
			for (boost::filesystem::directory_iterator it(dir); it != boost::filesystem::directory_iterator(); ++it)
			{
				// If match
				if (boost::regex_match(it->path().leaf().string(), filter))
					fileset.push_back(it->path().string());
			}
		}
	}
	bool GetFullPath(const _fileset_t& fileSet, const std::string& moduleName, std::string& fullPath)
	{		
		for(auto& file : fileSet)
		{
			std::string path;
			path = file.substr(file.find_last_of("/\\") + 1);
			path = path.substr(0, path.find_last_of("."));
			if(0 == moduleName.compare(path))
			{
				fullPath = file;
				return true;
			}
		}
		return false;
	}
	// 노드의 타입을 구분하는 함수
	BehaviorType CheckNodeType(const std::string& nodeType)
	{
		if (!nodeType.compare("sequence"))
			return BehaviorType::BehaviorType_Sequence;
		else if (!nodeType.compare("selector"))
			return BehaviorType::BehaviorType_Selector;
		else if (!nodeType.compare("randomsequence"))
			return BehaviorType::BehaviorType_RandomSequence;
		else if (!nodeType.compare("randomselector"))
			return BehaviorType::BehaviorType_RandomSelector;
		else if (!nodeType.compare("parallel"))
			return BehaviorType::BehaviorType_Parallel;
		else if (!nodeType.compare("inverter"))
			return BehaviorType::BehaviorType_Inverter;
		else if (!nodeType.compare("succeeder"))
			return BehaviorType::BehaviorType_Succeeder;
		else if (!nodeType.compare("repeater"))
			return BehaviorType::BehaviorType_Repeater;
		else if (!nodeType.compare("failer"))
			return BehaviorType::BehaviorType_Failer;
		else if (!nodeType.compare("untilfailer"))
			return BehaviorType::BehaviorType_UntilFailer;
		else if (!nodeType.compare("untilsucceeder"))
			return BehaviorType::BehaviorType_UntilSucceeder;
		else if (!nodeType.compare("condition"))
			return BehaviorType::BehaviorType_Condition;
		else if (!nodeType.compare("randomcondition"))
			return BehaviorType::BehaviorType_RandomCondition;
		else if (!nodeType.compare("cooldown"))
			return BehaviorType::BehaviorType_CoolDown;
		else if (!nodeType.compare("timelimit"))
			return BehaviorType::BehaviorType_TimeLimit;
		else if (!nodeType.compare("task"))
			return BehaviorType::BehaviorType_Task;
		else if (!nodeType.compare("service"))
			return BehaviorType::BehaviorType_Service;
		else if (!nodeType.compare("receivemessage"))
			return BehaviorType::BehaviorType_Message;
		else if (!nodeType.compare("call"))
			return BehaviorType::BehaviorType_Call;
		else if (!nodeType.compare("submodule"))
			return BehaviorType::BehaviorType_SubModule;
		else if (!nodeType.compare("once"))
			return BehaviorType::BehaviorType_Once;

		return BehaviorType::BehaviorType_None;
	}
	// scope
	BehaviorBlackBoardScope CheckBlackBoardScope(const std::string& scope)
	{
		if (!scope.compare("local"))
			return BehaviorBlackBoardScope::BehaviorBlackBoardScope_Local;
		else if (!scope.compare("member"))
			return BehaviorBlackBoardScope::BehaviorBlackBoardScope_Member;
		else if (!scope.compare("global"))
			return BehaviorBlackBoardScope::BehaviorBlackBoardScope_Global;
		else if (!scope.compare("const"))
			return BehaviorBlackBoardScope::BehaviorBlackBoardScope_Const;

		return BehaviorBlackBoardScope::BehaviorBlackBoardScope_None;
	}
	BehaviorBlackBoardDataType CheckBlackBoardDataType(const std::string& dataType)
	{
		if (!dataType.compare("float"))
			return BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_Float;
		else if (!dataType.compare("double"))
			return BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_Double;
		else if (!dataType.compare("int8_t"))
			return BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_Int8;
		else if (!dataType.compare("int16_t"))
			return BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_Int16;
		else if (!dataType.compare("int32_t"))
			return BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_Int32;
		else if (!dataType.compare("int64_t"))
			return BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_Int64;
		else if (!dataType.compare("vector"))
			return BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_Vector;
		else if (!dataType.compare("object"))
			return BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_Object;

		return BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_None;
	}
	BehaviorParallelQuitType CheckParallelQuitType(const std::string& quitType)
	{
		if (!quitType.compare("Delayed"))
			return BehaviorParallelQuitType::BehaviorParallelQuitType_Delayed;
		else if (!quitType.compare("Immediately"))
			return BehaviorParallelQuitType::BehaviorParallelQuitType_Immediately;
		return BehaviorParallelQuitType::BehaviorParallelQuitType_None;
	}
	BehaviorOperator CheckBehaviorOperator(const std::string& op)
	{
		if (!op.compare("="))
			return BehaviorOperator::BehaviorOperator_Equal;
		else if (!op.compare("!="))
			return BehaviorOperator::BehaviorOperator_NotEqual;
		else if (!op.compare("<"))
			return BehaviorOperator::BehaviorOperator_Less;
		else if (!op.compare(">"))
			return BehaviorOperator::BehaviorOperator_Greater;
		else if (!op.compare("<="))
			return BehaviorOperator::BehaviorOperator_LessOrEqual;
		else if (!op.compare(">="))
			return BehaviorOperator::BehaviorOperator_GreaterOrEqual;
		return BehaviorOperator::BehaviorOperator_None;
	}
	nmsp::behavior::BehaviorDataType GetBehaviorDataType(BehaviorBlackBoardDataType dataType)
	{
		switch (dataType)
		{
			case BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_None:
				return nmsp::behavior::BehaviorDataType::BehaviorDataType_None;;
			case BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_Float:
			case BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_Double:
				return nmsp::behavior::BehaviorDataType::BehaviorDataType_Double;
			case BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_Int8:
			case BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_Int16:
			case BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_Int32:
			case BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_Int64:
				return nmsp::behavior::BehaviorDataType::BehaviorDataType_Int64;
			case BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_Vector:
				return nmsp::behavior::BehaviorDataType::BehaviorDataType_Vector;
			case BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_Object:
				return nmsp::behavior::BehaviorDataType::BehaviorDataType_Object;
		}
		return nmsp::behavior::BehaviorDataType::BehaviorDataType_None;
	}

	// 모든 노드들을 읽어 들인다
	bool OnePassLoad(
		const _fileset_t& fileSet,
		const boost::property_tree::ptree& props,
		_name2node_t& name2Node, 
		_name2node_t& name2SubNode,
		_groupname2gid_t& gname2Gid, 
		_gid2node_t& gid2Node, 
		_message2node_t& message2Node,
		_name2bid_t& globalName2Bid,
		_name2bid_t& inherentName2Bid,
		_black_board_t& constBlackBoard,
		_name2cmd_t& name2Cmd,
		_id_t& id,
		_group_id_t& gid,
		_blackboard_id_t& bid,
		int& cmd,
		bool isMainNode,
		_shared_node_t* rootNode)
	{
		// 블랙보드 변수
		auto _OnePassInputVariable = [this, &globalName2Bid, &constBlackBoard, &bid]
		(const std::string& nodeName, const std::string& groupName, const std::string& nodeType, const std::string& scope, const std::string& name, const std::string& type, auto& value, auto& name2BoardBid) -> bool
		{
			auto dataType = CheckBlackBoardDataType(type);
			auto dataScope = CheckBlackBoardScope(scope);

			switch (dataScope)
			{
			case BehaviorBlackBoardScope::BehaviorBlackBoardScope_None:
				{
					LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::invalid scope -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", scope : " << scope;
					return false;
				}
				break;
			case BehaviorBlackBoardScope::BehaviorBlackBoardScope_Const:
				{
					if (!value.is_initialized())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::invalid input argument -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", scope : " << scope;
						return false;
					}

					if (BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_None == dataType)
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::invalid black board datatype -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", scope : " << scope << ", varname : " << name << ", dataType : " << type;
						return false;
					}

					name2BoardBid.emplace_back(std::make_tuple(bid, dataType, dataScope, name));
					
					_black_board_t::_shared_data_t data;
					if (false == constBlackBoard.Update(bid, static_cast<_black_board_t::_data_t**>(data)))
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::invalid black board update -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", scope : " << scope << ", varname : " << name;
						return false;
					}
					++bid;

					switch (dataType)
					{
						case BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_Float:
						case BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_Double:
							data->SetValue(value->get_value<double>());
							break;
						case BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_Int8:
						case BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_Int16:
						case BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_Int32:
						case BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_Int64:
							data->SetValue(value->get_value<int64_t>());
							break;
						case BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_Vector:
							{
								auto itrSub = value->begin();
								auto currX = itrSub->second.get_value<float>();
								++itrSub;
								auto currY = itrSub->second.get_value<float>();
								++itrSub;
								auto currZ = itrSub->second.get_value<float>();

								data->SetValue(currX, currY, currZ);
							}
							break;
						case BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_Object:			// 객체를 입력할 수 없다!
							LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::invalid black board datatype(object) -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", scope : " << scope << ", varname : " << name << ", dataType : " << type;
							break;
					}
				}
				break;
			case BehaviorBlackBoardScope::BehaviorBlackBoardScope_Member:
				{
					name2BoardBid.emplace_back(std::make_tuple(0, dataType, dataScope,  name));
				}
				break;
			case BehaviorBlackBoardScope::BehaviorBlackBoardScope_Global:
				{
					name2BoardBid.emplace_back(std::make_tuple(0, dataType, dataScope,  name));
				}
				break;
			}
			return true;
		};

		auto OnePassInputVariable = [&_OnePassInputVariable](const std::string& nodeName, const std::string& groupName, const std::string& nodeType, auto& input, auto& name2BoardBid) -> bool
		{
			if (false == input.is_initialized())
				return false;

			auto scope = input->get<std::string>("scope");
			auto name = input->get<std::string>("name");
			auto type = input->get<std::string>("type");
			auto value = input->get_child_optional("value");

			return _OnePassInputVariable(nodeName, groupName, nodeType, scope, name, type, value, name2BoardBid);
		};
		auto OnePassInputVariables = [&_OnePassInputVariable](const std::string& nodeName, const std::string& groupName, const std::string& nodeType, auto& input, auto& name2BoardBid) -> bool
		{
			// input이 없을수도 있으므로..
			if (false == input.is_initialized())
				return true;

			for (auto& inputArg : *input)
			{
				auto scope = inputArg.second.get<std::string>("scope");
				auto name = inputArg.second.get<std::string>("name");
				auto type = inputArg.second.get<std::string>("type");
				auto value = inputArg.second.get_child_optional("value");

				if(false == _OnePassInputVariable(nodeName, groupName, nodeType, scope, name, type, value, name2BoardBid))
				{
					return false;
				}
			}
			return true;
		};

		// 블랙보드 변수
		auto OnePassOutputVariables = [this, &globalName2Bid, &constBlackBoard, &bid](const std::string& nodeName, const std::string& groupName, const std::string& nodeType, auto& output, auto& name2Bid) -> bool
		{
			// output이 없을수도 있으므로..
			if (false == output.is_initialized())
				return true;
			
			auto scope = output->get<std::string>("scope");
			auto name = output->get<std::string>("name");
			auto type = output->get<std::string>("type");
						
			auto dataType = CheckBlackBoardDataType(type);
			auto dataScope = CheckBlackBoardScope(scope);

			if (BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_None == dataType)
			{
				LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::invalid output DataType -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", scope : " << scope << ", type : " << type;
				return false;
			}
			
			switch (dataScope)
			{
			case BehaviorBlackBoardScope::BehaviorBlackBoardScope_None:
			case BehaviorBlackBoardScope::BehaviorBlackBoardScope_Const:
				LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::invalid output scope -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", scope : " << scope;
				return false;
			case BehaviorBlackBoardScope::BehaviorBlackBoardScope_Member:
				{
					name2Bid.emplace(name, std::make_tuple(0, dataType, dataScope));
				}
				break;
			case BehaviorBlackBoardScope::BehaviorBlackBoardScope_Global:
				{
					auto pairRetGlobal = globalName2Bid.emplace(name, std::make_tuple(bid, dataType, dataScope));
					if (pairRetGlobal.second == true)
					{						
						++bid;
					}
					_blackboard_id_t nowBid = std::get<_blackboard_id_t>(pairRetGlobal.first->second);
					name2Bid.emplace(name, std::make_tuple(nowBid, dataType, dataScope));
				}
				break;
			default: break;
			}
			return true;
		};

		auto behaviorNode = props.get_child("behavior nodes");
		for (const auto& node : behaviorNode)
		{
			std::string nodeName = node.second.get<std::string>("node name");
			std::string groupName = node.second.get<std::string>("group name");			
			std::string nodeType = node.second.get<std::string>("node type");
			auto isRoot = node.second.get_child_optional("is root");

			// 이미 등록된 이름이 있는지 확인해 보자
			if (name2Node.count(nodeName))
			{
				LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::dup -> node Name : " << nodeName << ", group Name : " << groupName;
				return false;
			}

			// 고유의 변수값들을 할당하려고 한다!
			auto pairRetInherentValue = inherentName2Bid.emplace(nodeName + groupName + nodeType, std::make_tuple(bid, BehaviorBlackBoardDataType::BehaviorBlackBoardDataType_None, BehaviorBlackBoardScope::BehaviorBlackBoardScope_Inherent));
			if (pairRetInherentValue.second == false)
			{
				LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::dup in Inherent BlackBoard-> node Name : " << nodeName << ", group Name : " << groupName;
				return false;
			}

			++bid;

			//
			_shared_node_t currWorkNode;

			switch (CheckNodeType(nodeType))
			{
			case BehaviorType::BehaviorType_None:
				LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::invalid type -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
				return false;
			case BehaviorType::BehaviorType_Sequence:
				{
					nmsp::smartinterface<sequence_behavior_node<_allocator_t>> currTmp = new (std::nothrow) sequence_behavior_node<_allocator_t>(id);
					if (nullptr == currTmp)
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::memory -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					currWorkNode = currTmp;
				}
				break;
			case BehaviorType::BehaviorType_Selector:
				{
					nmsp::smartinterface<selector_behavior_node<_allocator_t>> currTmp = new (std::nothrow) selector_behavior_node<_allocator_t>(id);
					if (nullptr == currTmp)
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::memory -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					currWorkNode = currTmp;
				}
				break;
			case BehaviorType::BehaviorType_RandomSequence:
				{
					nmsp::smartinterface<randomsequence_behavior_node<_allocator_t>> currTmp = new (std::nothrow) randomsequence_behavior_node<_allocator_t>(id);
					if (nullptr == currTmp)
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::memory -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					currWorkNode = currTmp;
				}
				break;
			case BehaviorType::BehaviorType_RandomSelector:
				{
					nmsp::smartinterface<randomselector_behavior_node<_allocator_t>> currTmp = new (std::nothrow) randomselector_behavior_node<_allocator_t>(id);
					if (nullptr == currTmp)
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::memory -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					currWorkNode = currTmp;
				}
				break;
			case BehaviorType::BehaviorType_Parallel:
				{
					nmsp::smartinterface<parallel_behavior_node<_allocator_t>> currTmp = new (std::nothrow) parallel_behavior_node<_allocator_t>(id);
					if (nullptr == currTmp)
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::memory -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					currWorkNode = currTmp;
				}
				break;
			case BehaviorType::BehaviorType_Inverter:
				{
					nmsp::smartinterface<inverter_behavior_node<_allocator_t>> currTmp = new (std::nothrow) inverter_behavior_node<_allocator_t>(id);
					if (nullptr == currTmp)
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::memory -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					currWorkNode = currTmp;
				}
				break;
			case BehaviorType::BehaviorType_Succeeder:
				{
					nmsp::smartinterface<succeeder_behavior_node<_allocator_t>> currTmp = new (std::nothrow) succeeder_behavior_node<_allocator_t>(id);
					if (nullptr == currTmp)
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::memory -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					currWorkNode = currTmp;
				}
				break;
			case BehaviorType::BehaviorType_Repeater:
				{
					nmsp::smartinterface<repeater_behavior_node<_allocator_t>> currTmp = new (std::nothrow) repeater_behavior_node<_allocator_t>(id);
					if (nullptr == currTmp)
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::memory -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					currWorkNode = currTmp;
				}
				break;
			case BehaviorType::BehaviorType_Failer:
				{
					nmsp::smartinterface<failer_behavior_node<_allocator_t>> currTmp = new (std::nothrow) failer_behavior_node<_allocator_t>(id);
					if (nullptr == currTmp)
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::memory -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					currWorkNode = currTmp;
				}
				break;
			case BehaviorType::BehaviorType_UntilFailer:
				{
					nmsp::smartinterface<untilfailer_behavior_node<_allocator_t>> currTmp = new (std::nothrow) untilfailer_behavior_node<_allocator_t>(id);
					if (nullptr == currTmp)
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::memory -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					currWorkNode = currTmp;
				}
				break;
			case BehaviorType::BehaviorType_UntilSucceeder:
				{
					nmsp::smartinterface<untilsucceeder_behavior_node<_allocator_t>> currTmp = new (std::nothrow) untilsucceeder_behavior_node<_allocator_t>(id);
					if (nullptr == currTmp)
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::memory -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					currWorkNode = currTmp;
				}
				break;
			case BehaviorType::BehaviorType_Condition:
				{
					nmsp::smartinterface<condition_behavior_node<_allocator_t>> currTmp = new (std::nothrow) condition_behavior_node<_allocator_t>(id);
					if (nullptr == currTmp)
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::memory -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					condition_behavior_node<_allocator_t>* curr = static_cast<condition_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(currTmp));

					_name2boardbid_t name2BoardBidLeft;
					if (false == OnePassInputVariable(nodeName, groupName, nodeType, node.second.get_child_optional("left input value"), name2BoardBidLeft))
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::input value -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}
					if(0 == name2BoardBidLeft.size())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::input Size value -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}
					auto iterLeft = name2BoardBidLeft.begin();
					curr->AddLeftInput(std::get<BehaviorBlackBoardScope>(*iterLeft), std::get<_blackboard_id_t>(*iterLeft), std::get<std::string>(*iterLeft));

					// Right 는 없을 수도 있습니다.
					_name2boardbid_t name2BoardBidRight;
					OnePassInputVariable(nodeName, groupName, nodeType, node.second.get_child_optional("right input value"), name2BoardBidRight);
					if(0 < name2BoardBidRight.size())
					{	
						auto iterRight = name2BoardBidRight.begin();
						curr->AddRightInput(std::get<BehaviorBlackBoardScope>(*iterRight), std::get<_blackboard_id_t>(*iterRight), std::get<std::string>(*iterRight));
					}					

					currWorkNode = currTmp;
				}
				break;
			case BehaviorType::BehaviorType_RandomCondition:
				{
					nmsp::smartinterface<randomcondition_behavior_node<_allocator_t>> currTmp = new (std::nothrow) randomcondition_behavior_node<_allocator_t>(id);
					if (nullptr == currTmp)
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::memory -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					_name2boardbid_t name2BoardBid;
					if (false == OnePassInputVariable(nodeName, groupName, nodeType, node.second.get_child_optional("right input value"), name2BoardBid))
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::input value -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}
					if(0 == name2BoardBid.size())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::input Size value -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}
					auto iter = name2BoardBid.begin();

					randomcondition_behavior_node<_allocator_t>* curr = static_cast<randomcondition_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(currTmp));
					curr->AddRightInput(std::get<BehaviorBlackBoardScope>(*iter), std::get<_blackboard_id_t>(*iter), std::get<std::string>(*iter));

					currWorkNode = currTmp;
				}
				break;
			case BehaviorType::BehaviorType_TimeLimit:
				{
					nmsp::smartinterface<timelimit_behavior_node<_allocator_t>> currTmp = new (std::nothrow) timelimit_behavior_node<_allocator_t>(id);
					if (nullptr == currTmp)
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::memory -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					_name2boardbid_t name2BoardBid;
					if (false == OnePassInputVariable(nodeName, groupName, nodeType, node.second.get_child_optional("input value"), name2BoardBid))
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::input value -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}
					if(0 == name2BoardBid.size())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::input Size value -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}
					auto iter = name2BoardBid.begin();

					timelimit_behavior_node<_allocator_t>* curr = static_cast<timelimit_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(currTmp));
					curr->AddInput(std::get<BehaviorBlackBoardScope>(*iter), std::get<_blackboard_id_t>(*iter), std::get<std::string>(*iter));

					currWorkNode = currTmp;
				}
				break;
			case BehaviorType::BehaviorType_CoolDown:
				{
					nmsp::smartinterface<cooldown_behavior_node<_allocator_t>> currTmp = new (std::nothrow) cooldown_behavior_node<_allocator_t>(id);
					if (nullptr == currTmp)
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::memory -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					_name2boardbid_t name2BoardBid;
					if (false == OnePassInputVariable(nodeName, groupName, nodeType, node.second.get_child_optional("input value"), name2BoardBid))
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::input value -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}
					if(0 == name2BoardBid.size())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::input Size value -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}
					auto iter = name2BoardBid.begin();

					cooldown_behavior_node<_allocator_t>* curr = static_cast<cooldown_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(currTmp));
					curr->AddInput(std::get<BehaviorBlackBoardScope>(*iter), std::get<_blackboard_id_t>(*iter), std::get<std::string>(*iter));

					currWorkNode = currTmp;
				}
				break;
			case BehaviorType::BehaviorType_Service:
				{
					nmsp::smartinterface<service_behavior_node<_allocator_t>> currTmp = new (std::nothrow) service_behavior_node<_allocator_t>(id);
					if (nullptr == currTmp)
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::memory -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					currWorkNode = currTmp;
				}
				break;
			case BehaviorType::BehaviorType_Message:
				{
					nmsp::smartinterface<message_behavior_node<_allocator_t>> currTmp = new (std::nothrow) message_behavior_node<_allocator_t>(id);
					if (nullptr == currTmp)
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::memory -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					currWorkNode = currTmp;
				}
				break;
			case BehaviorType::BehaviorType_Call:
				{
					nmsp::smartinterface<call_behavior_node<_allocator_t>> currTmp = new (std::nothrow) call_behavior_node<_allocator_t>(id);
					if (nullptr == currTmp)
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::memory -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					// input
					_name2boardbid_t name2BoardBid;
					if (false == OnePassInputVariables(nodeName, groupName, nodeType, node.second.get_child_optional("input values"), name2BoardBid))
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::input value -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					task_behavior_node<_allocator_t>::_param_ref_t inputRef;
					for(auto& iter : name2BoardBid)
					{
						inputRef.emplace_back(std::get<BehaviorBlackBoardScope>(iter), std::get<_blackboard_id_t>(iter), GetBehaviorDataType(std::get<BehaviorBlackBoardDataType>(iter)), std::get<std::string>(iter));
					}

					call_behavior_node<_allocator_t>* curr = static_cast<call_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(currTmp));
					curr->SetParam(std::move(inputRef));

					currWorkNode = currTmp;
				}
				break;
			case BehaviorType::BehaviorType_SubModule:
				{
					nmsp::smartinterface<submodule_behavior_node<_allocator_t>> currTmp = new (std::nothrow) submodule_behavior_node<_allocator_t>(id);
					if (nullptr == currTmp)
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::memory -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}
										
					currWorkNode = currTmp;
					
					auto input = node.second.get_child_optional("input values");
					if(false == input.is_initialized())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::no input -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}
					
					for (auto& inputArg : *input)
					{
						auto value = inputArg.second.get_child_optional("value");

						std::string moduleName = value->get_value<std::string>();

						auto subModule = name2SubNode.find(moduleName);
						if(subModule == name2SubNode.end())
						{
							std::string filePath;
							if(false == GetFullPath(fileSet, moduleName, filePath))
							{
								LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::no submodule -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", Submodule : " << moduleName;
								return false;
							}

							boost::property_tree::ptree subProps;
							boost::property_tree::read_json(filePath, subProps);

							_shared_node_t rootNode;
							if(false == OnePassLoad(fileSet, subProps, name2Node, name2SubNode, gname2Gid, gid2Node, message2Node, globalName2Bid, inherentName2Bid, constBlackBoard, name2Cmd, id, gid, bid, cmd, false, &rootNode))
							{
								// 내부에서 Log 남김
								return false;
							}
							name2SubNode.emplace(moduleName, rootNode);
						}
					}
				}
				break;
			case BehaviorType::BehaviorType_Once:
				{
					nmsp::smartinterface<once_behavior_node<_allocator_t>> currTmp = new (std::nothrow) once_behavior_node<_allocator_t>(id);
					if (nullptr == currTmp)
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::memory -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					currWorkNode = currTmp;
				}
				break;
			case BehaviorType::BehaviorType_Task:
				{
					nmsp::smartinterface<task_behavior_node<_allocator_t>> currTmp = new (std::nothrow) task_behavior_node<_allocator_t>(id);
					if (nullptr == currTmp)
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::memory -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					auto functionType = node.second.get<std::string>("function type");
					auto pairName2Cmd = name2Cmd.emplace(functionType, cmd);
					if (true == pairName2Cmd.second)
					{
						++cmd;
					}
					int cmdType = pairName2Cmd.first->second;

					// Get InputData
					_name2boardbid_t name2BoardBid;
					if (false == OnePassInputVariables(nodeName, groupName, nodeType, node.second.get_child_optional("input values"), name2BoardBid))
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::input value -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					task_behavior_node<_allocator_t>::_param_ref_t inputRef;
					for(auto& iter : name2BoardBid)
					{
						inputRef.emplace_back(std::get<BehaviorBlackBoardScope>(iter), std::get<_blackboard_id_t>(iter), GetBehaviorDataType(std::get<BehaviorBlackBoardDataType>(iter)), std::get<std::string>(iter));
					}
					
					_name2bid_t name2Bid;
					if(false == OnePassOutputVariables(nodeName, groupName, nodeType, node.second.get_child_optional("output value"), name2Bid))
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::output value -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					task_behavior_node<_allocator_t>::_param_ref_t outputRef;
					for(auto& iter : name2Bid)
					{
						outputRef.emplace_back(std::get<BehaviorBlackBoardScope>(iter.second), std::get<_blackboard_id_t>(iter.second), GetBehaviorDataType(std::get<BehaviorBlackBoardDataType>(iter.second)), iter.first);
					}

					task_behavior_node<_allocator_t>* curr = static_cast<task_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(currTmp));
					curr->SetParam(cmdType, std::move(inputRef), std::move(outputRef));

					currWorkNode = currTmp;
				}
				break;
			}
			
			if (nullptr == currWorkNode)
			{
				LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::invalid node type -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
				return false;
			}

			currWorkNode->SetNodeName(nodeName);
			currWorkNode->SetGroupName(groupName);

			// 본인이 root인 경우임 
			if (true == isRoot.is_initialized())
			{
				if(isMainNode)
				{
					auto isRootValue = node.second.get<bool>("is root");
					if (true == isRootValue)
					{
						auto pairRetG2G = gname2Gid.emplace(groupName, gid);
						if (false == pairRetG2G.second)
						{
							LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::dup group name -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
							return false;
						}
						//
						auto pairRetG2N = gid2Node.emplace(gid, currWorkNode);
						if (false == pairRetG2N.second)
						{
							LOG_ERROR_SYS(m_componentImpl) << "behavior::OnePass::dup group -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
							return false;
						}

						++gid;
					}
				}
				else
				{
					*rootNode = currWorkNode;
				}
			}

			// 
			name2Node.emplace(nodeName, currWorkNode);

			++id;
		}

		return true;
	}
	bool TwoPassLoad(
		const _fileset_t& fileSet,
		const boost::property_tree::ptree& props,
		_name2node_t& name2Node,
		_name2node_t& name2SubNode,
		_groupname2gid_t& gname2Gid,
		_gid2node_t& gid2Node,
		_message2node_t& message2Node,
		_name2bid_t& inherentName2Bid,
		_black_board_t& constBlackBoard,
		_name2cmd_t& name2Cmd,
		_name_t& subNodeCompleted)
	{
		auto behaviorNodes = props.get_child("behavior nodes");
		for (const auto& node : behaviorNodes)
		{
			auto nodeName = node.second.get<std::string>("node name");
			auto groupName = node.second.get<std::string>("group name");
			auto nodeType = node.second.get<std::string>("node type");

			// 등록된게 아니라면...
			auto itrCurrNode = name2Node.find(nodeName);
			if (itrCurrNode == name2Node.end())
			{
				LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
				return false;
			}

			// 고유의 변수를 노드에 할당하기 위한 것임.
			{
				auto itrBid = inherentName2Bid.find(nodeName + groupName + nodeType);
				if (itrBid == inherentName2Bid.end())
				{
					LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no inherent blackboard var -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", varname : " << nodeName;
					return false;
				}

				if (false == itrCurrNode->second->SetInherentValue(std::get<BehaviorBlackBoardScope>(itrBid->second), std::get<_blackboard_id_t>(itrBid->second)))
				{
					LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::dup inherent variable -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", varname : " << nodeName;
					return false;
				}
			}

			// 하위연결..
			switch (itrCurrNode->second->Type())
			{
			case BehaviorType::BehaviorType_None:
				LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::invalid node type -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
				return false;
			case BehaviorType::BehaviorType_Sequence:
				{
					sequence_behavior_node<_allocator_t>* curr = static_cast<sequence_behavior_node<_allocator_t>*>(static_cast<sequence_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(itrCurrNode->second)));

					auto childNodes = node.second.get_child_optional("child nodes");
					if (childNodes.is_initialized())
					{
						for (auto child : *childNodes)
						{
							auto childName = child.second.get_value<std::string>();
							auto itrChildNode = name2Node.find(childName);
							if (itrChildNode == name2Node.end())
							{
								LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child : " << childName;
								return false;
							}

							curr->AddChild(itrChildNode->second);
						}
					}
				}
				break;
			case BehaviorType::BehaviorType_Selector:
				{
					selector_behavior_node<_allocator_t>* curr = static_cast<selector_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(itrCurrNode->second));

					auto childNodes = node.second.get_child_optional("child nodes");
					if (childNodes.is_initialized())
					{
						for (auto child : *childNodes)
						{
							auto childName = child.second.get_value<std::string>();
							auto itrChildNode = name2Node.find(childName);
							if (itrChildNode == name2Node.end())
							{
								LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child : " << childName;
								return false;
							}

							curr->AddChild(itrChildNode->second);
						}
					}
				}
				break;
			case BehaviorType::BehaviorType_RandomSequence:
				{
					randomsequence_behavior_node<_allocator_t>* curr = static_cast<randomsequence_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(itrCurrNode->second));

					auto childNodes = node.second.get_child_optional("child nodes");
					if (childNodes.is_initialized())
					{
						for (auto child : *childNodes)
						{
							auto childName = child.second.get_value<std::string>();
							auto itrChildNode = name2Node.find(childName);
							if (itrChildNode == name2Node.end())
							{
								LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child : " << childName;
								return false;
							}

							curr->AddChild(itrChildNode->second);
						}
					}
				}
				break;
			case BehaviorType::BehaviorType_RandomSelector:
				{
					randomselector_behavior_node<_allocator_t>* curr = static_cast<randomselector_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(itrCurrNode->second));

					auto childNodes = node.second.get_child_optional("child nodes");
					if (childNodes.is_initialized())
					{
						for (auto child : *childNodes)
						{
							auto childName = child.second.get_value<std::string>();
							auto itrChildNode = name2Node.find(childName);
							if (itrChildNode == name2Node.end())
							{
								LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child : " << childName;
								return false;
							}

							curr->AddChild(itrChildNode->second);
						}
					}
				}
				break;
			case BehaviorType::BehaviorType_Parallel:
				{
					parallel_behavior_node<_allocator_t>* curr = static_cast<parallel_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(itrCurrNode->second));

					auto quitType = CheckParallelQuitType(node.second.get<std::string>("quit type"));
					if (BehaviorParallelQuitType::BehaviorParallelQuitType_None == quitType)
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::invalid quit type -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					auto childNodes = node.second.get_child_optional("child nodes");
					if (false == childNodes.is_initialized())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no child nodes -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					// main
					auto itrCurrChild = childNodes->begin();
					auto nodeMain = itrCurrChild->second.get_value<std::string>();

					auto itrMainNode = name2Node.find(nodeMain);
					if (itrMainNode == name2Node.end())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no main child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child : " << nodeMain;
						return false;
					}

					++itrCurrChild;
					if (itrCurrChild == childNodes->end())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no sub child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child : " << nodeMain;
						return false;
					}

					auto nodeSub = itrCurrChild->second.get_value<std::string>();

					auto itrSubNode = name2Node.find(nodeSub);
					if (itrSubNode == name2Node.end())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no sub child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child : " << nodeSub;
						return false;
					}

					curr->SetQuitType(quitType);

					if (false == curr->AddMainChild(itrMainNode->second))
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::dup child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child : " << nodeMain;
						return false;
					}

					if (false == curr->AddSubChild(itrSubNode->second))
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::dup child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child : " << nodeSub;
						return false;
					}
				}
				break;
			case BehaviorType::BehaviorType_Inverter:
				{
					inverter_behavior_node<_allocator_t>* curr = static_cast<inverter_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(itrCurrNode->second));

					auto childName = node.second.get<std::string>("child node");
					auto itrChildNode = name2Node.find(childName);
					if (itrChildNode == name2Node.end())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child : " << childName;
						return false;
					}

					curr->AddChild(itrChildNode->second);
				}
				break;
			case BehaviorType::BehaviorType_Succeeder:
				{
					succeeder_behavior_node<_allocator_t>* curr = static_cast<succeeder_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(itrCurrNode->second));

					auto childName = node.second.get<std::string>("child node");
					auto itrChildNode = name2Node.find(childName);
					if (itrChildNode == name2Node.end())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child : " << childName;
						return false;
					}

					curr->AddChild(itrChildNode->second);
				}
				break;
			case BehaviorType::BehaviorType_Repeater:
				{
					repeater_behavior_node<_allocator_t>* curr = static_cast<repeater_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(itrCurrNode->second));

					auto childName = node.second.get<std::string>("child node");
					auto itrChildNode = name2Node.find(childName);
					if (itrChildNode == name2Node.end())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child : " << childName;
						return false;
					}

					curr->AddChild(itrChildNode->second);
	
					auto maxCount = node.second.get<std::size_t>("repeat cout");

					curr->SetMaxLoopCount(maxCount);
				}
				break;
			case BehaviorType::BehaviorType_Failer:
				{
					failer_behavior_node<_allocator_t>* curr = static_cast<failer_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(itrCurrNode->second));

					auto childName = node.second.get<std::string>("child node");
					auto itrChildNode = name2Node.find(childName);
					if (itrChildNode == name2Node.end())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child : " << childName;
						return false;
					}

					curr->AddChild(itrChildNode->second);
				}
				break;
			case BehaviorType::BehaviorType_UntilFailer:
				{
					untilfailer_behavior_node<_allocator_t>* curr = static_cast<untilfailer_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(itrCurrNode->second));

					auto childName = node.second.get<std::string>("child node");
					auto itrChildNode = name2Node.find(childName);
					if (itrChildNode == name2Node.end())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child : " << childName;
						return false;
					}

					curr->AddChild(itrChildNode->second);
				}
				break;
			case BehaviorType::BehaviorType_UntilSucceeder:
				{
					untilsucceeder_behavior_node<_allocator_t>* curr = static_cast<untilsucceeder_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(itrCurrNode->second));

					auto childName = node.second.get<std::string>("child node");
					auto itrChildNode = name2Node.find(childName);
					if (itrChildNode == name2Node.end())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child : " << childName;
						return false;
					}

					curr->AddChild(itrChildNode->second);
				}
				break;
			case BehaviorType::BehaviorType_Condition:
				{
					condition_behavior_node<_allocator_t>* curr = static_cast<condition_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(itrCurrNode->second));

					// operator
					auto op = CheckBehaviorOperator(node.second.get<std::string>("operator"));
					if (BehaviorOperator::BehaviorOperator_None == op)
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::invalid operator -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					curr->SetOp(op);

					auto childNodes = node.second.get_child_optional("child nodes");
					if (false == childNodes.is_initialized())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no child nodes -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					//
					auto itrCurrChild = childNodes->begin();
					auto leftNode = itrCurrChild->second.get_value<std::string>();

					auto itrLeftNode = name2Node.find(leftNode);
					if (itrLeftNode == name2Node.end())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child : " << leftNode;
						return false;
					}

					if (false == curr->AddChildLeft(itrLeftNode->second))
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::dup child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child : " << leftNode;
						return false;
					}

					++itrCurrChild;

					if (itrCurrChild != childNodes->end())
					{
						auto rightNode = itrCurrChild->second.get_value<std::string>();

						auto itrRightNode = name2Node.find(rightNode);
						if (itrRightNode == name2Node.end())
						{
							LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child : " << rightNode;
							return false;
						}

						if (false == curr->AddChildRight(itrRightNode->second))
						{
							LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::dup child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child : " << rightNode;
							return false;
						}
					}
				}
				break;
			case BehaviorType::BehaviorType_RandomCondition:
				{
					randomcondition_behavior_node<_allocator_t>* curr = static_cast<randomcondition_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(itrCurrNode->second));

					auto childNodes = node.second.get_child_optional("child nodes");
					if (false == childNodes.is_initialized())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no child nodes -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					//
					auto itrCurrChild = childNodes->begin();
					auto leftNode = itrCurrChild->second.get_value<std::string>();

					auto itrLeftNode = name2Node.find(leftNode);
					if (itrLeftNode == name2Node.end())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child : " << leftNode;
						return false;
					}

					if (false == curr->AddChildLeft(itrLeftNode->second))
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::dup child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child : " << leftNode;
						return false;
					}

					++itrCurrChild;

					if (itrCurrChild != childNodes->end())
					{
						auto rightNode = itrCurrChild->second.get_value<std::string>();

						auto itrRightNode = name2Node.find(rightNode);
						if (itrRightNode == name2Node.end())
						{
							LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child : " << rightNode;
							return false;
						}

						if (false == curr->AddChildRight(itrRightNode->second))
						{
							LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::dup child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child : " << rightNode;
							return false;
						}
					}
				}
				break;
			case BehaviorType::BehaviorType_TimeLimit:
				{
					timelimit_behavior_node<_allocator_t>* curr = static_cast<timelimit_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(itrCurrNode->second));

					auto childName = node.second.get<std::string>("child node");
					auto itrChildNode = name2Node.find(childName);
					if (itrChildNode == name2Node.end())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child node : " << childName;
						return false;
					}

					if (false == curr->AddChild(itrChildNode->second))
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::dup child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child node : " << childName;
						return false;
					}
				}
				break;
			case BehaviorType::BehaviorType_CoolDown:
				{
					cooldown_behavior_node<_allocator_t>* curr = static_cast<cooldown_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(itrCurrNode->second));

					auto childName = node.second.get<std::string>("child node");
					auto itrChildNode = name2Node.find(childName);
					if (itrChildNode == name2Node.end())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child node : " << childName;
						return false;
					}

					if (false == curr->AddChild(itrChildNode->second))
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::dup child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child node : " << childName;
						return false;
					}
				}
				break;
			case BehaviorType::BehaviorType_Service:
				{
					service_behavior_node<_allocator_t>* curr = static_cast<service_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(itrCurrNode->second));

					auto childNodes = node.second.get_child_optional("child nodes");
					if (false == childNodes.is_initialized())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no child nodes -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					auto itrCurrChild = childNodes->begin();
					auto checkNode = itrCurrChild->second.get_value<std::string>();

					auto itrCheckNode = name2Node.find(checkNode);
					if (itrCheckNode == name2Node.end())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no check child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child node : " << checkNode;
						return false;
					}

					if (false == curr->AddCheckChild(itrCheckNode->second))
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::dup child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child node : " << checkNode;
						return false;
					}

					++itrCurrChild;
					if (itrCurrChild == childNodes->end())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no main child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					auto mainNode = itrCurrChild->second.get_value<std::string>();

					auto itrMainNode = name2Node.find(mainNode);
					if (itrMainNode == name2Node.end())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child node : " << mainNode;
						return false;
					}

					if (false == curr->AddChild(itrMainNode->second))
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::dup child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child node : " << mainNode;
						return false;
					}
				}
				break;
			case BehaviorType::BehaviorType_Message:
				{
					auto messageId = node.second.get<int>("message id");
					auto childName = node.second.get<std::string>("child node");
					auto stackResetFlag = node.second.get<bool>("stack reset flag", false);
					message_behavior_node<_allocator_t>* curr = static_cast<message_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(itrCurrNode->second));

					auto itrGroupId = gname2Gid.find(groupName);
					if (itrGroupId == gname2Gid.end())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no group -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}

					auto itrMessageRootNode = message2Node.find(messageId);
					if (itrMessageRootNode != message2Node.end())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::dup message2Node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", messageId : " << messageId;
						return false;
					}

					message2Node.emplace(messageId, curr);

					auto itrChildNode = name2Node.find(childName);
					if (itrChildNode == name2Node.end())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child : " << childName;
						return false;
					}

					curr->AddChild(itrChildNode->second);
					curr->SetMessageId(messageId);
					curr->SetStackResetFlag(stackResetFlag);
				}
				break;
			case BehaviorType::BehaviorType_Call:
				{
					call_behavior_node<_allocator_t>* curr = static_cast<call_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(itrCurrNode->second));

					auto subModule = node.second.get<std::string>("submodule");

					auto itrGroupId = gname2Gid.find(subModule);
					if (itrGroupId == gname2Gid.end())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no group -> node Name : " << nodeName << ", SubModule Name : " << subModule << ", type : " << nodeType;
						return false;
					}
				
					auto itrNode = gid2Node.find(itrGroupId->second);
					if (itrNode == gid2Node.end())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no group2 -> node Name : " << nodeName << ", SubModule Name : " << subModule << ", type : " << nodeType;
						return false;
					}

					if (false == curr->AddChild(itrNode->second))
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::dup or invalid sumodule node type, node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", submodule node : " << subModule;
						return false;
					}
				}
				break;
			case BehaviorType::BehaviorType_SubModule:
				{
					submodule_behavior_node<_allocator_t>* curr = static_cast<submodule_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(itrCurrNode->second));

					auto input = node.second.get_child_optional("input values");
					if(false == input.is_initialized())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no input -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType;
						return false;
					}
					
					for (auto& inputArg : *input)
					{
						auto value = inputArg.second.get_child_optional("value");

						std::string moduleName = value->get_value<std::string>();

						std::string filePath;
						if(false == GetFullPath(fileSet, moduleName, filePath))
						{
							LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no submodule -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", Submodule : " << moduleName;
							return false;
						}

						auto subNode = name2SubNode.find(moduleName);
						if(subNode == name2SubNode.end())
						{
							LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::not find submodule -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", Submodule : " << moduleName;
							return false;
						}
						if (false == curr->AddChild(subNode->second))
						{
							LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::dup child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child node : " << moduleName;
							return false;
						}

						auto completed = subNodeCompleted.find(moduleName);
						if(completed == subNodeCompleted.end())
						{
							boost::property_tree::ptree subProps;
							boost::property_tree::read_json(filePath, subProps);

							if(false == TwoPassLoad(fileSet, subProps, name2Node, name2SubNode, gname2Gid, gid2Node, message2Node, inherentName2Bid, constBlackBoard, name2Cmd, subNodeCompleted))
							{
								// 내부에서 Log 남김
								return false;
							}
							subNodeCompleted.emplace(moduleName);
						}
					}
				}
				break;
			case BehaviorType::BehaviorType_Once:
				{
					once_behavior_node<_allocator_t>* curr = static_cast<once_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(itrCurrNode->second));

					auto childName = node.second.get<std::string>("child node");
					auto itrChildNode = name2Node.find(childName);
					if (itrChildNode == name2Node.end())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::no child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child node : " << childName;
						return false;
					}

					if (false == curr->AddChild(itrChildNode->second))
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::TwoPass::dup child node -> node Name : " << nodeName << ", group Name : " << groupName << ", type : " << nodeType << ", child node : " << childName;
						return false;
					}
				}
				break;
			case BehaviorType::BehaviorType_Task:
				{
				}
				break;
			}
		}
		return true;
	}

	bool ThreePassLoad(
		_shared_node_t node,
		_name2mem_t& name2Mem,
		_name2bid_t& globalName2Bid,
		_blackboard_id_t& bid)
	{
		if(nullptr == node)
		{
			return true;
		}	

		auto ThreePassBid = [this, node, &name2Mem, &globalName2Bid, &bid](auto scope, std::string& name, _blackboard_id_t& insertBid) -> bool
		{
			switch(scope)
			{
			case BehaviorBlackBoardScope::BehaviorBlackBoardScope_Global:
				{
					auto itrBid = globalName2Bid.find(name);
					if (itrBid == globalName2Bid.end())
					{
						LOG_ERROR_SYS(m_componentImpl) << "behavior::ThreePass::no blackboard mem -> node Name : " << node->GetNodeName() << ", group Name : " << node->GetGroupName() << ", scope : " << static_cast<int32_t>(scope) << ", name : " << name;
						return false;
					}
					insertBid = std::get<_blackboard_id_t>(itrBid->second);
				}
				break;
			case BehaviorBlackBoardScope::BehaviorBlackBoardScope_Member:
				{
					auto pairRet = name2Mem.emplace(name, bid);
					if(pairRet.second)
					{
						++bid;
					}
					insertBid = pairRet.first->second;
				}
				break;
			default: break;;
			}
			return true;
		};

		BehaviorType nodeType = node->Type();

		switch(nodeType)
		{
		case BehaviorType::BehaviorType_None:
			LOG_ERROR_SYS(m_componentImpl) << "behavior::ThreePassLoad::invalid node type -> node Name : " << node->GetNodeName() << ", group Name : " << node->GetGroupName() << ", type : " << static_cast<int32_t>(nodeType);
			return false;
		case BehaviorType::BehaviorType_Sequence:
			{
				sequence_behavior_node<_allocator_t>* curr = static_cast<sequence_behavior_node<_allocator_t>*>(static_cast<sequence_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(node)));

				// Tree Find
				for(auto childNode : curr->GetChilds())
				{
					if(false == ThreePassLoad(childNode, name2Mem, globalName2Bid, bid))
					{
						return false;
					}
				}
			}
			break;
		case BehaviorType::BehaviorType_Selector:
			{
				selector_behavior_node<_allocator_t>* curr = static_cast<selector_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(node));

				// Tree Find
				for(auto childNode : curr->GetChilds())
				{
					if(false == ThreePassLoad(childNode, name2Mem, globalName2Bid, bid))
					{
						return false;
					}
				}
			}
			break;
		case BehaviorType::BehaviorType_RandomSequence:
			{
				randomsequence_behavior_node<_allocator_t>* curr = static_cast<randomsequence_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(node));

				// Tree Find
				for(auto childNode : curr->GetChilds())
				{
					if(false == ThreePassLoad(childNode, name2Mem, globalName2Bid, bid))
					{
						return false;
					}
				}
			}
			break;
		case BehaviorType::BehaviorType_RandomSelector:
			{
				randomselector_behavior_node<_allocator_t>* curr = static_cast<randomselector_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(node));

				// Tree Find
				for(auto childNode : curr->GetChilds())
				{
					if(false == ThreePassLoad(childNode, name2Mem, globalName2Bid, bid))
					{
						return false;
					}
				}
			}
			break;
		case BehaviorType::BehaviorType_Parallel:
			{
				parallel_behavior_node<_allocator_t>* curr = static_cast<parallel_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(node));

				// Tree Find
				if(false == ThreePassLoad(curr->GetMainChild(), name2Mem, globalName2Bid, bid))
				{
					return false;
				}
				if(false == ThreePassLoad(curr->GetSubChild(), name2Mem, globalName2Bid, bid))
				{
					return false;
				}
			}
			break;
		case BehaviorType::BehaviorType_Inverter:
			{
				inverter_behavior_node<_allocator_t>* curr = static_cast<inverter_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(node));

				// Tree Find
				if(false == ThreePassLoad(curr->GetChild(), name2Mem, globalName2Bid, bid))
				{
					return false;
				}
			}
			break;
		case BehaviorType::BehaviorType_Succeeder:
			{
				succeeder_behavior_node<_allocator_t>* curr = static_cast<succeeder_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(node));

				// Tree Find
				if(false == ThreePassLoad(curr->GetChild(), name2Mem, globalName2Bid, bid))
				{
					return false;
				}
			}
			break;
		case BehaviorType::BehaviorType_Repeater:
			{
				repeater_behavior_node<_allocator_t>* curr = static_cast<repeater_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(node));

				// Tree Find
				if(false == ThreePassLoad(curr->GetChild(), name2Mem, globalName2Bid, bid))
				{
					return false;
				}
			}
			break;
		case BehaviorType::BehaviorType_Failer:
			{
				failer_behavior_node<_allocator_t>* curr = static_cast<failer_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(node));

				// Tree Find
				if(false == ThreePassLoad(curr->GetChild(), name2Mem, globalName2Bid, bid))
				{
					return false;
				}
			}
			break;
		case BehaviorType::BehaviorType_UntilFailer:
			{
				untilfailer_behavior_node<_allocator_t>* curr = static_cast<untilfailer_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(node));

				// Tree Find
				if(false == ThreePassLoad(curr->GetChild(), name2Mem, globalName2Bid, bid))
				{
					return false;
				}
			}
			break;
		case BehaviorType::BehaviorType_UntilSucceeder:
			{
				untilsucceeder_behavior_node<_allocator_t>* curr = static_cast<untilsucceeder_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(node));

				// Tree Find
				if(false == ThreePassLoad(curr->GetChild(), name2Mem, globalName2Bid, bid))
				{
					return false;
				}
			}
			break;
		case BehaviorType::BehaviorType_Condition:
			{
				condition_behavior_node<_allocator_t>* curr = static_cast<condition_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(node));
				
				// Input Member Setting
				{
					auto& input = curr->GetLeftInput();

					_blackboard_id_t insertBid = std::get<_blackboard_id_t>(input);
					if(false == ThreePassBid(std::get<BehaviorBlackBoardScope>(input), std::get<std::string>(input), insertBid))
					{
						return false;
					}
					std::get<_blackboard_id_t>(input) = insertBid;;
				}
				{
					auto& input = curr->GetRightInput();
					
					_blackboard_id_t insertBid = std::get<_blackboard_id_t>(input);
					if(false == ThreePassBid(std::get<BehaviorBlackBoardScope>(input), std::get<std::string>(input), insertBid))
					{
						return false;
					}
					std::get<_blackboard_id_t>(input) = insertBid;
				}

				// Tree Find
				if(false == ThreePassLoad(curr->GetChildLeft(), name2Mem, globalName2Bid, bid))
				{
					return false;
				}
				if(false == ThreePassLoad(curr->GetChildRight(), name2Mem, globalName2Bid, bid))
				{
					return false;
				}
			}
			break;
		case BehaviorType::BehaviorType_RandomCondition:
			{
				randomcondition_behavior_node<_allocator_t>* curr = static_cast<randomcondition_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(node));

				auto& input = curr->GetRightInput();
				
				_blackboard_id_t insertBid = std::get<_blackboard_id_t>(input);
				if(false == ThreePassBid(std::get<BehaviorBlackBoardScope>(input), std::get<std::string>(input), insertBid))
				{
					return false;
				}
				std::get<_blackboard_id_t>(input) = insertBid;

				// Tree Find
				if(false == ThreePassLoad(curr->GetChildLeft(), name2Mem, globalName2Bid, bid))
				{
					return false;
				}
				if(false == ThreePassLoad(curr->GetChildRight(), name2Mem, globalName2Bid, bid))
				{
					return false;
				}
			}
			break;
		case BehaviorType::BehaviorType_TimeLimit:
			{
				timelimit_behavior_node<_allocator_t>* curr = static_cast<timelimit_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(node));

				auto& input = curr->GetInput();
				
				_blackboard_id_t insertBid = std::get<_blackboard_id_t>(input);
				if(false == ThreePassBid(std::get<BehaviorBlackBoardScope>(input), std::get<std::string>(input), insertBid))
				{
					return false;
				}
				std::get<_blackboard_id_t>(input) = insertBid;

				// Tree Find
				if(false == ThreePassLoad(curr->GetChild(), name2Mem, globalName2Bid, bid))
				{
					return false;
				}
			}
			break;
		case BehaviorType::BehaviorType_CoolDown:
			{
				cooldown_behavior_node<_allocator_t>* curr = static_cast<cooldown_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(node));

				auto& input = curr->GetInput();
				
				_blackboard_id_t insertBid = std::get<_blackboard_id_t>(input);
				if(false == ThreePassBid(std::get<BehaviorBlackBoardScope>(input), std::get<std::string>(input), insertBid))
				{
					return false;
				}
				std::get<_blackboard_id_t>(input) = insertBid;

				// Tree Find
				if(false == ThreePassLoad(curr->GetChild(), name2Mem, globalName2Bid, bid))
				{
					return false;
				}
			}
			break;
		case BehaviorType::BehaviorType_Service:
			{
				service_behavior_node<_allocator_t>* curr = static_cast<service_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(node));

				// Tree Find
				if(false == ThreePassLoad(curr->GetCheckChild(), name2Mem, globalName2Bid, bid))
				{
					return false;
				}
				if(false == ThreePassLoad(curr->GetChild(), name2Mem, globalName2Bid, bid))
				{
					return false;
				}
			}
			break;
		case BehaviorType::BehaviorType_Message:
			{
				message_behavior_node<_allocator_t>* curr = static_cast<message_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(node));

				// Tree Find
				if(false == ThreePassLoad(curr->GetChild(), name2Mem, globalName2Bid, bid))
				{
					return false;
				}
			}
			break;
		case BehaviorType::BehaviorType_Call:
			{
				call_behavior_node<_allocator_t>* curr = static_cast<call_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(node));

				auto& param = curr->GetParam();			

				for(auto& input : param)
				{
					_blackboard_id_t insertBid = std::get<_blackboard_id_t>(input);
					if(false == ThreePassBid(std::get<BehaviorBlackBoardScope>(input), std::get<std::string>(input), insertBid))
					{
						return false;
					}
					std::get<_blackboard_id_t>(input) = insertBid;
				}

				// Tree Find
				if(false == ThreePassLoad(curr->GetChild(), name2Mem, globalName2Bid, bid))
				{
					return false;
				}
			}
			break;
		case BehaviorType::BehaviorType_SubModule:
			{
				submodule_behavior_node<_allocator_t>* curr = static_cast<submodule_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(node));

				// Tree Find
				if(false == ThreePassLoad(curr->GetChild(), name2Mem, globalName2Bid, bid))
				{
					return false;
				}
			}
			break;
		case BehaviorType::BehaviorType_Once:
			{
				once_behavior_node<_allocator_t>* curr = static_cast<once_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(node));

				// Tree Find
				if(false == ThreePassLoad(curr->GetChild(), name2Mem, globalName2Bid, bid))
				{
					return false;
				}
			}
			break;
		case BehaviorType::BehaviorType_Task:
			{
				task_behavior_node<_allocator_t>* curr = static_cast<task_behavior_node<_allocator_t>*>(static_cast<behavior_node<_allocator_t>*>(node));

				{
					auto& param = curr->GetInputParam();			

					for(auto& input : param)
					{
						_blackboard_id_t insertBid = std::get<_blackboard_id_t>(input);
						if(false == ThreePassBid(std::get<BehaviorBlackBoardScope>(input), std::get<std::string>(input), insertBid))
						{
							return false;
						}
						std::get<_blackboard_id_t>(input) = insertBid;
					}
				}
				{
					auto& param = curr->GetOutputParam();			

					for(auto& output : param)
					{
						_blackboard_id_t insertBid = std::get<_blackboard_id_t>(output);
						if(false == ThreePassBid(std::get<BehaviorBlackBoardScope>(output), std::get<std::string>(output), insertBid))
						{
							return false;
						}
						std::get<_blackboard_id_t>(output) = insertBid;
					}
				}
			}
			break;
		}

		if (false == node->Check())
		{
			LOG_ERROR_SYS(m_componentImpl) << "behavior::ThreePass::invalid node -> node Name : " << node->GetNodeName();
			return false;
		}

		return true;
	}

	bool FourPassLoad(_name2node_t& name2Node, _black_board_t& constBlackBoard)
	{
		for (auto& itr : name2Node)
		{
			if (false == itr.second->Check())
			{
				LOG_ERROR_SYS(m_componentImpl) << "behavior::ThreePass::invalid node -> node Name : " << itr.first;
				return false;
			}
		}

		return true;
	}

public:
	behavior(behavior_component_impl* componentImpl)
		: m_componentImpl(componentImpl)
	{
	}
	~behavior()
	{
	}
	bool Load(const char* path)
	{
		std::string currentWorkFile;

		try
		{
			_name2bid_t globalName2Bid;				// blackboard id in Global scope
			_groupname2gid_t gname2Gid;				// 그룹이름, group id
			_gid2node_t gid2Node;					// group id, 노드 객체
			_message2node_t message2Node;			// message id, 노드 객체
			_black_board_t constBlackBoard;			// const blackboard
			_name2cmd_t name2Cmd;					// function type, function id
			
			_id_t id = NodeID_Start;
			_group_id_t gid = AiGroupID_Start;
			_blackboard_id_t bid = Blackboard_Start;
			int cmd = TaskID_Start;

			// 
			_fileset_t fileSet;
			FindFiles(path, fileSet);

			if (fileSet.empty())
			{
				LOG_ERROR_SYS(GetComponentImpl()) << " no files " << path;
				return false;
			}

			for (const auto& filename: fileSet)
			{
				currentWorkFile = filename;

				_name2node_t name2Node;					// 노드이름, 노드 객체
				_name2bid_t inherentName2Bid;			// blackboard id in inherent scope
				_name2node_t name2SubNode;				// SubNode
				_name_t subNodeCompleted;		// SubNode
				_shared_node_t rootNode;

				boost::property_tree::ptree props;
				boost::property_tree::read_json(filename, props);

				// 1 pass
				// node Load, blockboard data Load
				if (false == OnePassLoad(fileSet,
										props,
										name2Node,
										name2SubNode,
										gname2Gid,
										gid2Node,
										message2Node,
										globalName2Bid,
										inherentName2Bid,
										constBlackBoard,
										name2Cmd,
										id,
										gid,
										bid,
										cmd,
										true,
										&rootNode))
					return false;

				if (false == TwoPassLoad(fileSet,
										props,
										name2Node,
										name2SubNode,
										gname2Gid,
										gid2Node,
										message2Node,
										inherentName2Bid,
										constBlackBoard,
										name2Cmd,
										subNodeCompleted))
					return false;
			}

			for(auto& node : gid2Node)
			{
				_name2mem_t name2Mem;
				
				//// 2 pass
				if (false == ThreePassLoad(node.second,
										name2Mem,
										globalName2Bid,
										bid))
					return false;
			}

			// 0번 할당 오류
			auto retEmpty = gid2Node.emplace(AiGroupID_Empty, nullptr);
			if (false == retEmpty.second)
				return false;

			//
			m_gname2Gid = gname2Gid;
			m_gid2Node = gid2Node;
			m_message2Node = message2Node;
			m_name2Cmd = name2Cmd;
			m_blackBoard = constBlackBoard;
		}
		catch (const std::exception& e)
		{
			LOG_ERROR_SYS(m_componentImpl) << "behavior:: exception " << e.what() << ", filename=" << currentWorkFile;
			return false;
		}
		return true;
	}
	void Unload()
	{
		std::unique_lock<std::shared_mutex> lock(m_lock);

		m_levelContainer.clear();
		m_gname2Gid.clear();
		m_gid2Node.clear();
		m_name2Cmd.clear();
		m_blackBoard.Clear();
	}
	virtual void Process(int64_t currentGameTime, int64_t level) override
	{
		_shared_level_behavior_tree_t levelBehaviorTree;
		{
			std::shared_lock<std::shared_mutex> lock(m_lock);

			auto itr = m_levelContainer.find(level);
			if (itr == m_levelContainer.end())
				return;

			levelBehaviorTree = itr->second;
		}

		levelBehaviorTree->Process(currentGameTime);
	}
	virtual void Process(int64_t currentGameTime, int64_t level, int gid, uint64_t oid) override
	{
		_shared_level_behavior_tree_t levelBehaviorTree;
		{
			std::shared_lock<std::shared_mutex> lock(m_lock);

			auto itr = m_levelContainer.find(level);
			if (itr == m_levelContainer.end())
				return;

			levelBehaviorTree = itr->second;
		}

		auto itrBt = levelBehaviorTree->find(gid);
		if (itrBt == levelBehaviorTree->end())
			return;

		itrBt->second->Process(oid);
	}
	virtual int Add(int64_t level, _group_id_t gid, _object_id_t oid, _object_t* object) override
	{
		_shared_level_behavior_tree_t levelBehaviorTree;
		_shared_node_t rootNode;

		{
			std::shared_lock<std::shared_mutex> lock(m_lock);

			auto itrLevel = m_levelContainer.find(level);
			if (itrLevel != m_levelContainer.end())
				levelBehaviorTree = itrLevel->second;

			auto itrNode = m_gid2Node.find(gid);
			if (itrNode == m_gid2Node.end())
				return nmsp::make_nmsp_error(m_componentImpl->GetServiceType(), _BEHAVIOR_ERROR_NO_GROUPID);

			rootNode = itrNode->second;
		}

		// 아무것도 등록된 레벨이 없는 경우
		if (nullptr == levelBehaviorTree)
		{
			_shared_level_behavior_tree_t newLbt = new (std::nothrow) _level_behavior_tree_t;
			if (false == newLbt)
				return nmsp::make_nmsp_error(m_componentImpl->GetServiceType(), _BEHAVIOR_ERROR_MEMORY);

			_shared_behavior_tree_t newBt = new _behavior_tree_t(this, newLbt, rootNode);
			if (nullptr == newBt)
				return nmsp::make_nmsp_error(m_componentImpl->GetServiceType(), _BEHAVIOR_ERROR_MEMORY);

			auto pairRetBt = newLbt->emplace(gid, newBt);
			if (false == pairRetBt.second)
				return nmsp::make_nmsp_error(m_componentImpl->GetServiceType(), _BEHAVIOR_ERROR_DUP_GROUPID);

			if (false == newBt->Add(oid, object, gid, ConstBlackBoard(), newLbt->GlobalBlackBoard()))
				return nmsp::make_nmsp_error(m_componentImpl->GetServiceType(), _BEHAVIOR_ERROR_DUP_OBJECTID);

			// 여기서 lock을...
			{
				std::unique_lock<std::shared_mutex> lock(m_lock);

				auto pairRetLbt = m_levelContainer.emplace(level, newLbt);
				if (false == pairRetLbt.second)
					return nmsp::make_nmsp_error(m_componentImpl->GetServiceType(), _BEHAVIOR_ERROR_DUP_LEVEL);
			}

			return nmsp::_NMSP_NOERROR;
		}

		// 등록된 behavior tree가 없는 경우
		auto itrBt = levelBehaviorTree->find(gid);
		if (itrBt == levelBehaviorTree->end())
		{
			_shared_behavior_tree_t newBt = new _behavior_tree_t(this, levelBehaviorTree, rootNode);
			if (nullptr == newBt)
				return nmsp::make_nmsp_error(m_componentImpl->GetServiceType(), _BEHAVIOR_ERROR_MEMORY);

			auto pairRetBt = levelBehaviorTree->emplace(gid, newBt);
			if (false == pairRetBt.second)
				return nmsp::make_nmsp_error(m_componentImpl->GetServiceType(), _BEHAVIOR_ERROR_DUP_GROUPID);

			if (false == newBt->Add(oid, object, gid, ConstBlackBoard(), levelBehaviorTree->GlobalBlackBoard()))
				return nmsp::make_nmsp_error(m_componentImpl->GetServiceType(), _BEHAVIOR_ERROR_DUP_OBJECTID);

			return nmsp::_NMSP_NOERROR;
		}

		// 
		if (false == itrBt->second->Add(oid, object, gid, ConstBlackBoard(), levelBehaviorTree->GlobalBlackBoard()))
			return nmsp::make_nmsp_error(m_componentImpl->GetServiceType(), _BEHAVIOR_ERROR_DUP_OBJECTID);

		return nmsp::_NMSP_NOERROR;
	}
	virtual int Del(int64_t level, _group_id_t gid, _object_id_t oid) override
	{
		_shared_level_behavior_tree_t levelBehaviorTree;

		{
			std::shared_lock<std::shared_mutex> lock(m_lock);

			auto itrLevel = m_levelContainer.find(level);
			if (itrLevel == m_levelContainer.end())
				return nmsp::make_nmsp_error(m_componentImpl->GetServiceType(), _BEHAVIOR_ERROR_NO_LEVEL);

			levelBehaviorTree = itrLevel->second;
		}

		auto itrBt = levelBehaviorTree->find(gid);
		if (itrBt == levelBehaviorTree->end())
		{
			if (true == levelBehaviorTree->empty())
			{
				std::unique_lock<std::shared_mutex> lock(m_lock);
				m_levelContainer.erase(level);
			}

			return nmsp::make_nmsp_error(m_componentImpl->GetServiceType(), _BEHAVIOR_ERROR_NO_GROUP);
		}

		if (false == itrBt->second->Del(oid))
			return nmsp::make_nmsp_error(m_componentImpl->GetServiceType(), _BEHAVIOR_ERROR_NO_OBJECT);

		if (itrBt->second->Empty())
		{
			levelBehaviorTree->erase(itrBt);

			if (true == levelBehaviorTree->empty())
			{
				std::unique_lock<std::shared_mutex> lock(m_lock);
				m_levelContainer.erase(level);
			}
		}

		return nmsp::_NMSP_NOERROR;
	}
	virtual int Del(int64_t level) override
	{
		std::unique_lock<std::shared_mutex> lock(m_lock);

		auto itrLevel = m_levelContainer.find(level);
		if (itrLevel == m_levelContainer.end())
			return nmsp::make_nmsp_error(m_componentImpl->GetServiceType(), _BEHAVIOR_ERROR_NO_LEVEL);

		m_levelContainer.erase(itrLevel);
		return nmsp::_NMSP_NOERROR;
	}
	virtual int Reset(int64_t level, int gid, uint64_t oid) override
	{
		_shared_level_behavior_tree_t levelBehaviorTree;

		{
			std::shared_lock<std::shared_mutex> lock(m_lock);

			auto itrLevel = m_levelContainer.find(level);
			if (itrLevel == m_levelContainer.end())
				return nmsp::make_nmsp_error(m_componentImpl->GetServiceType(), _BEHAVIOR_ERROR_NO_LEVEL);

			levelBehaviorTree = itrLevel->second;
		}

		auto itrBt = levelBehaviorTree->find(gid);
		if (itrBt == levelBehaviorTree->end())
		{
			if (true == levelBehaviorTree->empty())
			{
				std::unique_lock<std::shared_mutex> lock(m_lock);
				m_levelContainer.erase(level);
			}

			return nmsp::make_nmsp_error(m_componentImpl->GetServiceType(), _BEHAVIOR_ERROR_NO_GROUP);
		}

		itrBt->second->Reset(oid);
		return nmsp::_NMSP_NOERROR;
	}
	inline _black_board_t& ConstBlackBoard()
	{
		return m_blackBoard;
	}
	inline behavior_component_impl* GetComponentImpl()
	{
		return m_componentImpl;
	}
	virtual int QueryInterface(const nmsp::UUID* iid, void **ppvObject) override
	{
		return m_componentImpl->QueryInterface(iid, ppvObject);
	}
	virtual int AddRef() override
	{
		return m_componentImpl->AddRef();
	}
	virtual int Release() override
	{
		return m_componentImpl->Release();
	}
	virtual int ConvertGroupNameToId(const char* groupName, int* griupId) override
	{
		// 그룹이 비어 있는 경우라도 그냥 준다
		if (nullptr == groupName || '\0' == groupName[0])
		{
			*griupId = AiGroupID_Empty;
			return nmsp::_NMSP_NOERROR;
		}

		// 그룹이름에 해당하는 GroupID를 찾는다
		auto itr = m_gname2Gid.find(std::string(groupName));
		if (itr == m_gname2Gid.end())
			return nmsp::make_nmsp_error(m_componentImpl->GetServiceType(), _BEHAVIOR_ERROR_NO_GROUPID);

		*griupId = itr->second;
		return nmsp::_NMSP_NOERROR;
	}
	virtual int GetCommandInfo(nmsp::behavior::IBehaviorCommandInfo** info) override
	{
		std::shared_lock<std::shared_mutex> lock(m_lock);

		*info = new behavior_command_info(m_name2Cmd);
		if (nullptr == *info)
			return nmsp::make_nmsp_error(m_componentImpl->GetServiceType(), _BEHAVIOR_ERROR_MEMORY);

		(*info)->AddRef();
		return nmsp::_NMSP_NOERROR;
	}
	
	virtual void DebugReloadData() override
	{
		Unload();

		behavior_config& config = *m_componentImpl;
		Load(config.GetBehaviorPath().c_str());
	}


	bool FindMessageNode(typename const _message2node_t::key_type& key, _shared_message_node_t& messageRootNode)
	{
		std::shared_lock<std::shared_mutex> lock(m_lock);

		auto itr = m_message2Node.find(key);
		if (itr == m_message2Node.end())
			return false;

		messageRootNode = itr->second;
		return true;
	}

private:
	std::shared_mutex m_lock;
	_groupname2gid_t m_gname2Gid;
	_gid2node_t m_gid2Node;
	_message2node_t m_message2Node;
	_name2cmd_t m_name2Cmd;
	_level_container_t m_levelContainer;
	_black_board_t m_blackBoard;					// const
	behavior_component_impl* m_componentImpl;
};

#endif
