﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 가능하면 이것 하나로..
#include "behaviorbase.h"

// 이 정의가 꼭 필요하다..
IMPLEMENT_NMSPMODULE(behavior_component_impl)

//
std::shared_ptr<nmsp::logger::logger>  behavior_component_impl::m_logger;

////////////////////////////////////////////////////////////////////////////////
// 
behavior_component_impl::behavior_component_impl()
	: m_refs(1)
	, m_self(nmsp::_NMSP_RESERVED_SERVICETYPE_NULL)
	, m_config(this)
	, m_behavior(this)
	, m_outConsole(false)
{
	if (nullptr == m_logger)
	{
		m_logger = std::make_shared<nmsp::logger::logger>();
		m_logInit = true;
	}
	else
	{
		m_logInit = false;
	}
}

behavior_component_impl::~behavior_component_impl()
{
	// 로그 정리는 마지막에..
	if (nullptr != m_logInf)
		m_logInf = nullptr;
}

int behavior_component_impl::QueryInterface(const nmsp::UUID* iid, void** pInterface)
{
	// 모든 정의된 인터페이스에서는 어떤 다른 인터페이스라도 QueryInterface가 성공해야 한다
	// 이 Component에서 지원하는 인터페이스를 다 모아놓았음.
	if (*iid == nmsp::UUID_IComponentBase)
	{
		*pInterface = static_cast<nmsp::IComponentBase*>(this);
		reinterpret_cast<nmsp::IComponentBase*>(*pInterface)->AddRef();
		return nmsp::_NMSP_NOERROR;
	}
	else
	if (*iid == nmsp::UUID_IComponent)
	{
		*pInterface = static_cast<nmsp::IComponent*>(this);
		reinterpret_cast<nmsp::IComponent*>(*pInterface)->AddRef();
		return nmsp::_NMSP_NOERROR;
	}
	else
	if (*iid == nmsp::behavior::UUID_IBehavior)
	{
		*pInterface = static_cast<nmsp::behavior::IBehavior*>(&m_behavior);
		reinterpret_cast<nmsp::behavior::IBehavior*>(*pInterface)->AddRef();
		return nmsp::_NMSP_NOERROR;
	}

	return nmsp::make_nmsp_error(m_self, _BEHAVIOR_ERROR_INVALID_INTERFACE_REQ);
}

int behavior_component_impl::AddRef(void)
{
	return ++m_refs;
}

int behavior_component_impl::Release(void)
{
	int nLastRef = --m_refs;
	if (0 == nLastRef)
	{
		delete this;
		return 0;
	}

	return nLastRef;
}

int behavior_component_impl::SetBaseInfo(unsigned short uiServiceType, nmsp::IComponentContainer* pISink, int nLenPath, const char* pszCfgPath, int logLevel, bool outConsole, const char* timeZoneName)
{
	m_self = uiServiceType;

	int nRet = pISink->QueryInterface(&nmsp::UUID_IComponentContainer, static_cast<void**>(m_containerInf));
	if (nmsp::_NMSP_NOERROR != nRet)
		return nRet;

	// 설정
	m_configPath.assign(pszCfgPath, nLenPath);

	m_logLevel = static_cast<nmsp::logger::lv::severity_level>(logLevel);
	m_outConsole = outConsole;

	return nmsp::_NMSP_NOERROR;
}

int behavior_component_impl::PreInit()
{
	// 로그 컴포넌트가 있나 ?
	m_containerInf->QueryComponent(nmsp::_SERVICETYPE_LOG, &nmsp::log::UUID_ILog, static_cast<void**>(m_logInf));

	// 한번만 초기화 하기 위해서임..
	if (m_logInit)
	{
		if (false == m_logger->init(m_self, m_logInf, m_logLevel, "", m_outConsole))
			return nmsp::make_nmsp_error(m_self, _BEHAVIOR_ERROR_INIT_LOG);
	}

	if (false == m_config.Load(m_configPath.c_str()))
		return nmsp::make_nmsp_error(m_self, _BEHAVIOR_ERROR_CONFIG);

	if (false == m_behavior.Load(m_config.GetBehaviorPath().c_str()))
		return nmsp::make_nmsp_error(m_self, _BEHAVIOR_ERROR_LOAD_BEHAVIOR);

	return nmsp::_NMSP_NOERROR;
}

#ifdef _DEBUG
struct test_object 
	: public nmsp::behavior::IBehaviorObject
	, nmsp::new_from_pool<_behavior_allocator_t>
{
public:
	test_object()
	{
		m_refs = 0;
	}
	~test_object()
	{
	}
	virtual int AddRef(void)
	{
		return ++m_refs;
	}
	virtual int Release(void)
	{
		int refs = --m_refs;
		if (0 == refs)
		{
			delete this;
			return 0;
		}
		return refs;
	}
	virtual nmsp::behavior::BehaviorReturn InitExecute(int command)
	{
		return nmsp::behavior::BehaviorReturn::BehaviorReturn_Success;
	}
	virtual nmsp::behavior::BehaviorReturn Execute(int command, int argCount, nmsp::behavior::IBehaviorData** input, nmsp::behavior::IBehaviorData* output)
	{
		return nmsp::behavior::BehaviorReturn::BehaviorReturn_Success;
	}
	virtual nmsp::behavior::BehaviorReturn UninitExecute(int command) 
	{
		return nmsp::behavior::BehaviorReturn::BehaviorReturn_Success;
	}

private:
	std::atomic_int m_refs;
};
#endif

int behavior_component_impl::Init()
{
#ifdef _DEBUG
	//nmsp::smartinterface<test_object> object = new test_object;

	//m_behavior.Add(1, 1, 1, object);

	//// 
	//m_behavior.Process(0, 1);
	//m_behavior.Process(25, 1);
	////

	//m_behavior.Del(1, 1, 1);
#endif
	return nmsp::_NMSP_NOERROR;
}

void behavior_component_impl::Uninit()
{
}

void behavior_component_impl::PostUninit()
{
	m_behavior.Unload();
}
