////////////////////////////////////////////////////////////////////////////////
// �ۼ���: huelee
// ��  ��:
//
//

// ȣȯ���� ���ؼ�..
#pragma once
#ifndef __BEHAVIORCONFIG_H__
#define __BEHAVIORCONFIG_H__

// ���������� �д´�.
class behavior_config
{
	enum
	{
	};

public:
	behavior_config(behavior_component_impl* componentImpl);
	virtual ~behavior_config();

	bool Load(const char* configPath);

public:
	inline const std::string& GetBehaviorPath()
	{
		return m_behaviorPath;
	}
	inline bool GetBehaviorDebugFlag() const
	{
		return m_debugFlag;
	}

private:
	std::string m_behaviorPath;
	bool m_debugFlag;
	behavior_component_impl* m_componentImpl;
};

#endif
