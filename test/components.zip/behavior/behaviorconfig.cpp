﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 가능하면 이것 하나로..
#include "behaviorbase.h"

//
behavior_config::behavior_config(behavior_component_impl* componentImpl)
	: m_componentImpl(componentImpl)
{
}

behavior_config::~behavior_config()
{
}

bool behavior_config::Load(const char* configPath)
{
	try
	{
		boost::property_tree::ptree props;
		boost::property_tree::read_json(configPath, props);

		m_behaviorPath = props.get<std::string>("behavior");
		m_debugFlag = props.get<bool>("behavior debug", false);
	}
	catch (const std::exception& e)
	{
		LOG_ERROR_SYS(m_componentImpl) << "config:: exception " << e.what();
		return false;
	}

	LOG_INFO_SYS(m_componentImpl) << "config:: ok ";
	return true;
}
