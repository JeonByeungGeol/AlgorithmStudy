﻿////////////////////////////////////////////////////////////////////////////////
//
// 작자 :
// 설명 : 
//

//
#include <string>
#include "nmspinterface.h"
#include "httpinterface.h"

namespace nmsp { namespace http {

// {1FA3F7E7-6ABD-464F-89C6-5FEB04EDF504}
const UUID UUID_IHTTPRequest = { 0x1fa3f7e7, 0x6abd, 0x464f, { 0x89, 0xc6, 0x5f, 0xeb, 0x4, 0xed, 0xf5, 0x4 } };

// {DB43F5DC-E936-41AB-BA25-0E9A93710317}
const UUID UUID_IHTTPResponse = { 0xdb43f5dc, 0xe936, 0x41ab,{ 0xba, 0x25, 0xe, 0x9a, 0x93, 0x71, 0x3, 0x17 } };

// {32E1E130-AF98-4A49-8645-B2E7A56F3D1A}
const UUID UUID_IHttpClient = { 0x32e1e130, 0xaf98, 0x4a49,{ 0x86, 0x45, 0xb2, 0xe7, 0xa5, 0x6f, 0x3d, 0x1a } };

} }		// http // nmsp