////////////////////////////////////////////////////////////////////////////////
//
// �ۼ��� : huelee
// ��  �� : 
//

//
#include <string>
#include "nmspinterface.h"
#include "mapinterface.h"

namespace nmsp { namespace map {

// {FB60A0DB-0E10-4CAC-BEF9-C9908AC0B696}
const UUID UUID_IMap = { 0xfb60a0db, 0xe10, 0x4cac,{ 0xbe, 0xf9, 0xc9, 0x90, 0x8a, 0xc0, 0xb6, 0x96 } };

// {EFD40F87-45AD-4CC4-9AFA-3E1B0ED9F733}
const UUID UUID_IMapCrowd = { 0xefd40f87, 0x45ad, 0x4cc4,{ 0x9a, 0xfa, 0x3e, 0x1b, 0xe, 0xd9, 0xf7, 0x33 } };

} }		// map // nmsp
