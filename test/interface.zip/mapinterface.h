﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __MAPINTERFACE_H__
#define __MAPINTERFACE_H__

namespace nmsp { namespace map {

//
typedef int32_t _zoneid_t;
typedef int32_t _mapid_t;
typedef int32_t _territoryid_t;
typedef int32_t _npcid_t;
typedef uint64_t _entityid_t;

//
const _zoneid_t _ZONEID_IS_NULL = 0;
const _territoryid_t _TERRITORYID_IS_NULL = -1;
const _mapid_t _AREAGROUPID_IS_NULL = 99;				// 99인 경우 null로 처리한다

// areaID정의
typedef uint16_t _mapgroupid_t;
typedef uint8_t _navareaid_t;
enum class NavAreaIdType: _navareaid_t
{
	NavAreaIdType_Null_Area = 0xFF,
	NavAreaIdType_Default_Area	= 0,
	NavAreaIdType_Wall = 14,
	NavAreaIdType_SafeRoute	= 15,
	NavAreaIdType_Max_Areas = 16,
};

// 길찾기에 사용되는 옵션들
enum class PathOption : uint8_t
{
	PathOption_None		= 0x00,
	PathOption_Area		= 0x01,	///< Add a vertex at every polygon edge crossing where area changes.
	PathOption_All		= 0x02,	///< Add a vertex at every polygon edge crossing.
	PathOption_Height	= 0x04, ///< Add a vertex at every polygon edge by diff y -axis
};

enum class ZoneType : uint8_t
{
	ZoneType_SingleZone	= 0x00,
	ZoneType_MultiZone	= 0x01,
	ZoneType_PersistentZone = 0x02,
	ZoneType_All		= 0xff,
};

enum class SpawnType : uint8_t
{
	SpawnType_NPCSpawn,
	SpawnType_PCFirstStart,
	SpawnType_PCLandingPoint,
	SpawnType_PCRespawn,
};

enum class CrowdAgentWalkMode : uint8_t
{
	DT_CROWDAGENT_WALKMODE_NONE = 0x00,
	DT_CROWDAGENT_WALKMODE_WALK = 0x01,		///< 기존 
	DT_CROWDAGENT_WALKMODE_FLIGHT = 0x02,	///< y축을 사용한 이동
};

enum class CrowdAgentWalkModeSub : uint8_t
{
	normal = 0,
	jump = 1,
	falling = 2,
	fallingEnd = 3,
	drop = 4,
	move = 5,
};

enum class AniSpawnType : uint8_t
{
	AniSpawnType_Default = 0,
	AniSpawnType_AniSpawn1 = 1,
	AniSpawnType_AniSpawn2 = 2,
	AniSpawnType_AniSpawn3 = 3,
};

enum class AIType : uint8_t
{
	AIType_Around = 0,
	AIType_Hold = 1,
	AIType_Roaming = 2,
	AIType_Fixed = 3,
};

enum class RoamingMoveType : uint8_t
{
	RoamingMoveType_Walk = 0,				
	RoamingMoveType_Run = 1,				
	RoamingMoveType_FastRun = 2,			
};

enum class PathCostCalcOption : uint8_t
{
	PathCostCalcOption_Greedy = 0,
	PathCostCalcOption_Normal = 1,
};

enum class PathFindingType : uint8_t
{
	PathFindingType_Normal = 0,
	PathFindingType_WalkableraycastWithoutFall = 1,
	PathFindingType_Jump = 2,
};

// bitwise or, Jump의 끝과 Fall의 시작이 겹칠수도 있음.
enum class PathOffConnectionType : uint8_t
{
	PathOffConnectionType_Walk = 0,					// walk/flight 상태에서 일반적인 이동
	PathOffConnectionType_StartJump = 1,			// walk/flight 일반이동중 점프 시작
	PathOffConnectionType_Jump = 2,					// walk/flight 일반이동중 점프 중
	PathOffConnectionType_EndJump = 4,				// walk/flight 일반이동중 점프 끝
	PathOffConnectionType_StartFall = 8,			// walk/flight 일반이동중 낙하 시작
	PathOffConnectionType_Fall = 16,				// walk/flight 일반이동중 낙하 
	PathOffConnectionType_EndFall = 32,				// walk/flight 일반이동중 낙하 끝
	PathOffConnectionType_LegacyMove = 64,			// StartOffConnectionXXX함수들에 의해 진행되는 이동상태
	PathOffConnectionType_Flight = 128,				// flight 시작
};

// 길찾기 결과처리를 위한 것..
struct IMapResult
{
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
	virtual int Size() = 0;
	virtual const float* GetPos(int idx) = 0;
	virtual const float* GetCurrent() = 0;
	virtual const float* GetNext() = 0;
	virtual bool MoveNext() = 0;
	virtual void Reset() = 0;
	virtual uint64_t GetRef(int idx) = 0;
	virtual uint64_t GetCurrentRef() = 0;
};

// zone정보 : pc spawn
struct IMapZonePcSpawnInfo
{
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
	virtual int Size() = 0;
	virtual bool MoveNext() = 0;
	virtual void Reset() = 0;
	virtual bool Find(int32_t spawnID) = 0;
	virtual int32_t GetCurrSpawnID() = 0;
	virtual int32_t GetCurrRaduis() = 0;
	virtual float GetCurrYaw() = 0;
	virtual const float* GetCurrLocation() = 0;
	virtual void GetCurrTerritoryIDs(int32_t* count, const int32_t** ids) = 0;
};

// zone정보 : pc respawn 
struct IMapZonePcRespawnInfo
{
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
	virtual int Size() = 0;
	virtual bool MoveNext() = 0;
	virtual void Reset() = 0;
	virtual bool Find(int32_t respawnID) = 0;
	virtual int32_t GetCurrSpawnID() = 0;
	virtual int32_t GetCurrRaduis() = 0;
	virtual float GetCurrYaw() = 0;
	virtual const float* GetCurrLocation() = 0;
	virtual void GetCurrTerritoryIDs(int32_t* count, const _territoryid_t** ids) = 0;
};

// zone정보 : npc Random spawn
struct IMapZoneNpcRandomSpawnInfo
{
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
	virtual int Size() = 0;
	virtual bool MoveNext() = 0;
	virtual void Reset() = 0;
	virtual int32_t GetCurrNpcID() = 0;
	virtual int32_t GetCurrNpcNum() = 0;
	virtual int32_t GetCurrNpcLinkID() = 0;
	virtual int32_t GetCurrNpcRoamingID() = 0;
	virtual int32_t GetCurrAniSpawnType() = 0;
	virtual int32_t GetCurrNpcSight() = 0;
	virtual int32_t GetCurrAIType() = 0;
};

// zone정보 : npc Fixed spawn
struct IMapZoneNpcFixedSpawnInfo
{
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
	virtual int Size() = 0;
	virtual bool MoveNext() = 0;
	virtual void Reset() = 0;
	virtual bool Find(int32_t spawnID) = 0;
	virtual int32_t GetCurrSpawnID() = 0;
	virtual int32_t GetCurrSpawnMinCount() = 0;
	virtual int32_t GetCurrSpawnMaxCount() = 0;
	virtual int32_t GetCurrRadius() = 0;
	virtual float GetCurrYaw() = 0;
	virtual const float* GetCurrLocation() = 0;
	virtual int32_t GetCurrRoamingID() = 0;
	virtual int32_t GetCurrNpcID() = 0;
	virtual int32_t GetCurrAniSpawnType() = 0;
	virtual int32_t GetCurrNpcSight() = 0;
	virtual int32_t GetCurrAIType() = 0;
	virtual int32_t GetCurrSPointDelay() = 0;
	virtual int32_t GetCurrAnimationIndex() = 0;
};

// zone정보 : npc roaming
struct IMapZoneNpcRoamingInfo
{
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
	virtual int Size() = 0;
	virtual bool MovePrev() = 0;
	virtual bool MoveNext() = 0;
	virtual void Reset() = 0;
	virtual void ResetEnd() = 0;
	virtual bool Find(int32_t index) = 0;
	virtual int32_t GetRoamingID() = 0;
	virtual int32_t GetRoamingType() = 0; 
	virtual int32_t GetCurrWaitTime() = 0;
	virtual const float* GetCurrLocation() = 0; 
	virtual int32_t GetCurrMoveType() = 0;
	virtual int32_t GetCurrIndex() = 0;
	virtual bool GetNextInfo(int32_t* waitTime, const float** location, int32_t* moveType, int32_t* index) = 0;
	virtual bool GetPrevInfo(int32_t* waitTime, const float** location, int32_t* moveType, int32_t* index) = 0;
	virtual void WrapMovePrev() = 0;
	virtual void WrapMoveNext() = 0;
	virtual bool GetWrapNextInfo(int32_t* waitTime, const float** location, int32_t* moveType, int32_t* index) = 0;
	virtual bool GetWrapPrevInfo(int32_t* waitTime, const float** location, int32_t* moveType, int32_t* index) = 0;
	virtual bool GetInfo(int32_t index, int32_t* waitTime, const float** location, int32_t* moveType) = 0;
};

// zone정보 : pc territory
struct IMapZonePcTerritoryInfo
{
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
	virtual int Size() = 0;
	virtual bool MoveNext() = 0;
	virtual void Reset() = 0;
	virtual bool Find(_territoryid_t pcTerritoryID) = 0;
	virtual _territoryid_t GetCurrTerritoryID() = 0;
	virtual int32_t GetCurrPcSpawnCount() = 0;
	virtual int32_t GetCurrPcRespawnCount() = 0;
	virtual bool GetCurrPcSpawnIDs(int32_t* count, const int32_t** ids) = 0;
	virtual bool GetCurrPcRespawnIDs(int32_t* count, const int32_t** ids) = 0;
	virtual bool GetPcRespawnID(int32_t& respawnID) = 0;
	virtual bool GetPcSpawnID(int32_t& spawnID) = 0;
	virtual bool IsCurrRandomSpawn() = 0;
	virtual float GetCurrYaw() = 0;
	virtual bool GetCurrRandomPointInTerritory(int seed, float(point)[3]) = 0;
};

// zone정보 : npc territory
struct IMapZoneNpcTerritoryInfo
{
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
	virtual int Size() = 0;
	virtual bool MoveNext() = 0;
	virtual void Reset() = 0;
	virtual bool Find(int32_t npcTerritoryID) = 0;
	virtual _territoryid_t GetCurrTerritoryID() = 0;
	virtual int32_t GetCurrTerritorytype() = 0;
	virtual int32_t GetCurrTerritorygrade() = 0;
	virtual int32_t GetCurrSpawnEvent() = 0;
	virtual int32_t GetCurrRespawntype() = 0;
	virtual int32_t GetCurrRespawntime() = 0;
	virtual int32_t GetCurrRespawncount() = 0;
	virtual int32_t GetCurrMaxdistance() = 0;
	virtual int32_t GetCurrMindistance() = 0;
	virtual int32_t GetCurrReturndistance() = 0;
	virtual int32_t GetCurrLinkId() = 0;
	virtual int32_t GetCurrLinkdistance() = 0;
	virtual int32_t GetCurrTerritoryVolumeCount() = 0;
	virtual void GetCurrTerritoryVolume(int32_t* count, const float*** points) = 0;
	virtual const float* GetCurrCenterOfTerritoryVolume() = 0;
	virtual const float GetCurrMaxXofTerritoryVolume() = 0;
	virtual const float GetCurrMaxZofTerritoryVolume() = 0;
	virtual const float GetCurrMaxYofTerritoryVolume() = 0;
	virtual bool GetCurrRandomPointInTerritory(int seed, float (point)[3]) = 0;
	virtual bool GetCurrRandomPointRadius(float* radius) = 0;
	virtual int GetCurrRandomPointCount() = 0;
	virtual int GetCurrEventType() = 0;
	virtual int GetCurrEventID() = 0;
	//virtual int GetCurrSpawnType() = 0;
	virtual int32_t GetCurrRandomTime() = 0;
	virtual int32_t GetCurrRespawnNumMin() = 0;
	virtual bool IsCurrConnectingTerritoryInfo() = 0;
	virtual void GetCurrConnectingTerritoryInfo(int32_t* condition, int32_t* conditionParam, int32_t* count, const _territoryid_t** ids) = 0;
	virtual _territoryid_t GetCurrConnectedTerritoryInfo() = 0;
	virtual int32_t GetCurrRandomSpawnDelay() = 0;
	virtual int32_t GetCurrRandomSpawnDivide() = 0;
	virtual int32_t GetCurrMaxNpcSpawnCount() = 0;
	virtual bool IsInPosition(const float * position) = 0;
};

//zone 정보 : triggr
struct IMapZoneTriggerInfo
{
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
	virtual int Size() = 0;
	virtual bool MoveNext() = 0;
	virtual void Reset() = 0;
	virtual bool Find(int32_t triggerID) = 0;
	virtual int32_t GetCurrTriggerID() = 0;
	virtual int32_t GetCurrRadius() = 0;
	virtual float GetCurrYaw() = 0;
	virtual const float* GetCurrLocation() = 0;
	virtual const float* GetEndLocation(int id) = 0;
	virtual float GetEndTime(int id) = 0;
	virtual int32_t GetCurrTriggerType() = 0;
	virtual int32_t GetCurrEnable() = 0;
};

//zone 정보 : mission
struct IMapZoneMissionInfo
{
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
	virtual int Size() = 0;
	virtual bool MoveNext() = 0;
	virtual void Reset() = 0;
	virtual bool Find(int64_t locationID) = 0;
	virtual int64_t GetCurrMissionLocationID() = 0;
	virtual const float* GetCurrLocation() = 0;
	virtual int32_t GetCurrRadius() = 0;
};

// map 정보(IMap이 존재하여 ZoneList로 사용)
struct IMapZoneList
{
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
	virtual int Size() = 0;
	virtual bool MoveNext() = 0;
	virtual void Reset() = 0;
	virtual _zoneid_t GetCurrZoneID() = 0;
	virtual int GetMapID() = 0;
	virtual bool IsZone(_zoneid_t zoneId) = 0;
};

// map 정보 : gimmick spawn controller
struct IMapZoneGimmickSpawnController
{
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
	virtual bool Find(_territoryid_t territory_id) = 0; // 관리되는 gimmick entity 인지 검사.
	virtual int32_t MaxSpawnCount(_territoryid_t territory_id) = 0;
	virtual bool GetTerritoryList(nmsp::map::_territoryid_t territory_id, int32_t* count, const _territoryid_t** ids) = 0;
};

// 존에서 스폰되는 npcID 리스트
struct IMapZoneSpawnNpcIDList
{
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
	virtual int Size() = 0;
	virtual bool MoveNext() = 0;
	virtual void Reset() = 0;
	virtual _npcid_t GetCurrNpcID() = 0;
};

// zone정보
struct IMapZoneInfo
{
	// 존정보
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
	virtual _zoneid_t ZoneID() = 0;
	virtual int MaxUser() = 0;
	
	// SPAWN 가능한 NPC수 
	virtual int MaxNpc() = 0;

	// 입장 가능 여부 체크
	virtual bool CanEnter(int32_t level) = 0;
	virtual int32_t GetCheckMissionID() = 0;
	virtual int32_t GetCheckMissionType() = 0;
	virtual int32_t GetCheckLevel() = 0;
	virtual int32_t GetSequenceID() = 0;
	virtual int32_t GetZoneSequenceType() = 0;
	virtual int32_t GetSequenceConditionID() = 0;

	// AREAID
	virtual int MapGroupID() = 0;
	// 각종 존의 spawn정보들
	virtual bool GetPcSpawnInfo(IMapZonePcSpawnInfo** pcSpawnInfo) = 0;
	virtual bool GetPcRespawnInfo(IMapZonePcRespawnInfo** pcRespawnInfo) = 0;
	virtual bool GetNpcRandomSpawnInfo(int32_t territoryID, IMapZoneNpcRandomSpawnInfo** npcRandomSpawnInfo) = 0;
	virtual bool GetNpcFixedSpawnInfo(int32_t territoryID, IMapZoneNpcFixedSpawnInfo** npcFixedSpawnInfo) = 0;
	virtual bool GetNpcRoamingInfo(int32_t territoryID, int32_t roamingID, IMapZoneNpcRoamingInfo** npcRoamingInfo) = 0;
	virtual bool GetPcTerritoryInfo(IMapZonePcTerritoryInfo** pcTerritoryInfo) = 0;
	virtual bool GetNpcTerritoryInfo(IMapZoneNpcTerritoryInfo** npcTerritoryInfo) = 0;
	virtual bool GetTriggerInfo(IMapZoneTriggerInfo** triggerInfo) = 0;
	virtual bool GetGimmickSpawnControlInfo(IMapZoneGimmickSpawnController** gimmickSpawnControl) = 0;
	
	// 타일정보
	// 2차원기준으로 height가 없는것임 
	virtual bool TileZoneInfo(float originX, float originY, float originZ, int32_t* count, const _zoneid_t** ids) = 0;
	virtual bool TileZoneInfo(const float* origin, int32_t* count, const _zoneid_t** ids) = 0;
	virtual bool TilePcTerritoryInfo(float originX, float originY, float originZ, int32_t* count, const _territoryid_t** ids) = 0;
	virtual bool TilePcTerritoryInfo(const float* origin, int32_t* count, const _territoryid_t** ids) = 0;
	virtual bool TileTriggerInfo(float originX, float originY, float originZ, int32_t* count, const int32_t** ids) = 0;
	virtual bool TileTriggerInfo(const float* origin, int32_t* count, const int32_t** ids) = 0;
	virtual bool TileNpcTerritoryInfo(float originX, float originY, float originZ, int32_t* count, const _territoryid_t** ids) = 0;
	virtual bool TileNpcTerritoryInfo(const float* origin, int32_t* count, const _territoryid_t** ids) = 0;
	// 존타입
	virtual int ZoneBattleType() = 0;
	// mission 
	virtual bool GetMissionInfo(IMapZoneMissionInfo** missionInfo) = 0;
	// AREA GROUP ID
	virtual _mapid_t MapID() = 0;
	virtual bool GetZoneIDs(IMapZoneList** zoneGroup) = 0;
	virtual int GetZoneType() = 0;
	virtual bool CreateMap(_zoneid_t zoneId, IMapZoneList** zoneGroup) = 0;
	// 존별 이벤트 관련한 NPC테러토리 정보
	virtual bool GetEventNpcTerritoryInfo(IMapZoneNpcTerritoryInfo** npcTerritoryInfo) = 0;
	virtual bool GetDayEventNpcTerritoryInfo(IMapZoneNpcTerritoryInfo** npcTerritoryInfo) = 0;
	virtual bool GetNightEventNpcTerritoryInfo(IMapZoneNpcTerritoryInfo** npcTerritoryInfo) = 0;
	virtual bool GetSpawnNpcIDList(IMapZoneSpawnNpcIDList** spawnNpcIDList) = 0;
	virtual int GetZoneCullingDistance() = 0;
	// 원전을..
	virtual void GetOriginPos(float* originX, float* originY, float* originZ) = 0;
};

struct IMapZoneInfoList
{
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
	virtual int Size() = 0;
	virtual bool MoveNext() = 0;
	virtual void Reset() = 0;
	virtual bool Find(_zoneid_t zoneID) = 0;
	virtual bool Current(IMapZoneInfo** zoneinfo) = 0;
};

// 
struct IMap : public IComponentBase
{
	// IMapResult는 thread safety하지 않으므로.. thread간에 공유하면 안됨.
	virtual int CalculatePath(const CrowdAgentWalkMode walkMode, _zoneid_t zoneId, const float (source)[3], const float (target)[3], PathOption pathOption, int pathMask, const float areaCosts[NavAreaIdType::NavAreaIdType_Max_Areas], IMapResult** path) = 0;
	virtual int Raycast(const CrowdAgentWalkMode walkMode, _zoneid_t zoneId, const float (source)[3], const float (target)[3], int pathMask, const float areaCosts[NavAreaIdType::NavAreaIdType_Max_Areas], float (position)[3], float (normal)[3], float* distance) = 0;
	virtual int WalkableRaycast(const CrowdAgentWalkMode walkMode, nmsp::map::_zoneid_t zoneId, const float(source)[3], const float(target)[3], int pathMask, const float areaCosts[nmsp::map::NavAreaIdType::NavAreaIdType_Max_Areas], float(position)[3], float(normal)[3], float* distance, float* height) = 0;
	virtual int SamplePosition(const CrowdAgentWalkMode walkMode, _zoneid_t zoneId, const float (source)[3], int pathMask, const float areaCosts[NavAreaIdType::NavAreaIdType_Max_Areas], float(position)[3]) = 0;
	// Zone정보를 조회한다.
	virtual int GetZoneInfo(_zoneid_t zoneId, IMapZoneInfo** zoneinfo) = 0;
	virtual int GetZoneInfo(ZoneType zoneType, IMapZoneInfoList** zoneinfoList) = 0;
	virtual int SamplePosition(const CrowdAgentWalkMode walkMode, _zoneid_t zoneId, const float(source)[3], const float(extentValue)[3], int pathMask, const float areaCosts[NavAreaIdType::NavAreaIdType_Max_Areas], float(position)[3]) = 0;
	virtual int WalkableNearestPosition(const CrowdAgentWalkMode walkMode, _zoneid_t zoneId, const float(source)[3], const float(target)[3], const float(extentValue)[3], PathOption pathOption, int pathMask, const float areaCosts[NavAreaIdType::NavAreaIdType_Max_Areas], float(position)[3]) = 0;
	virtual int PositionHeight(const CrowdAgentWalkMode walkMode, _zoneid_t zoneId, const float(source)[3], const float(extentValue)[3], int pathMask, const float areaCosts[NavAreaIdType::NavAreaIdType_Max_Areas], float* height) = 0;
	virtual int LandingPoint(_zoneid_t zoneId, const float(source)[3], int pathMask, const float areaCosts[NavAreaIdType::NavAreaIdType_Max_Areas], IMapResult** path) = 0;
	virtual int CheckPos(const CrowdAgentWalkMode walkMode, _zoneid_t zoneId, const float(source)[3], int pathMask, const float areaCosts[NavAreaIdType::NavAreaIdType_Max_Areas], float(position)[3]) = 0;
	virtual int NearestUpsidePositionOnFlight(_zoneid_t zoneId, const float(source)[3], int pathMask, const float areaCosts[NavAreaIdType::NavAreaIdType_Max_Areas], float(position)[3]) = 0;
	virtual int NearestSurfaceOnFlight(_zoneid_t zoneId, const float(source)[3], int pathMask, const float areaCosts[NavAreaIdType::NavAreaIdType_Max_Areas], float(position)[3]) = 0;
	virtual int NearestSurfaceOnWalking(_zoneid_t zoneId, const float(source)[3], const float(extentValue)[3], int pathMask, const float areaCosts[NavAreaIdType::NavAreaIdType_Max_Areas], float(position)[3]) = 0;
	virtual int CalculatePath(const CrowdAgentWalkMode walkMode, _zoneid_t zoneId, const float(source)[3], const float(target)[3], const float(extentValue)[3], PathOption pathOption, int pathMask, const float areaCosts[NavAreaIdType::NavAreaIdType_Max_Areas], IMapResult** path) = 0;
	virtual int LandingPoint(_zoneid_t zoneId, const float(source)[3], const float(extentValue)[3], int pathMask, const float areaCosts[NavAreaIdType::NavAreaIdType_Max_Areas], IMapResult** path) = 0;
	virtual bool IsZoneInfo(_zoneid_t zoneId) = 0;
	//virtual int RaycastOnFlight(_zoneid_t zoneId, const CrowdAgentWalkMode sourceWalkMode, const float(source)[3], const float sourceHeight, const CrowdAgentWalkMode targetWalkMode, const float(target)[3], int pathMask, const float areaCosts[NavAreaIdType::NavAreaIdType_Max_Areas], float(position)[3], float(normal)[3], float* distance, bool* isArrived) = 0;
	virtual bool GetZoneIDs(_mapid_t mapID, IMapZoneList** zoneGroup) = 0;
	virtual bool FindAreaGroupID(_zoneid_t zoneId, _mapid_t* mapID) = 0;
	virtual bool CreateMap(_mapid_t areaGroupID, _zoneid_t zoneId, IMapZoneList** zoneGroup) = 0;
	// ref에 의해 참조되는 곳의 타입을.. 조회한다. 둘다 walk만 지원
	virtual int QueryPositionAreaType(_zoneid_t zoneId, const uint64_t ref) = 0;
	virtual int QueryPositionAreaId(_zoneid_t zoneId, int pathMask, const float areaCosts[NavAreaIdType::NavAreaIdType_Max_Areas], const float(source)[3]) = 0;
	virtual int FixedPositionHeight(const CrowdAgentWalkMode walkMode, _zoneid_t zoneId, const float(source)[3], const float(extentValue)[3], int pathMask, const float areaCosts[NavAreaIdType::NavAreaIdType_Max_Areas], float* height) = 0;
	//특정 방향으로 랜딩포인트를 찾는다. (source -> target y축 무시)
	virtual int LandingPointWith2DDirection(_zoneid_t zoneId, int pathMask, const float areaCosts[NavAreaIdType::NavAreaIdType_Max_Areas], const float(source)[3], const float(dir)[3], float(position)[3]) = 0;
	// FULL Path Finder
	virtual int CalculatePath(const CrowdAgentWalkMode walkMode, _zoneid_t zoneId, const float(source)[3], const float(target)[3], const float(extentValue)[3], int maxOpenList, PathCostCalcOption calcOption, PathOption pathOption, int pathMask, const float areaCosts[NavAreaIdType::NavAreaIdType_Max_Areas], IMapResult** path) = 0;
	virtual bool IsBottom(_zoneid_t zoneId, int pathMask, const float areaCosts[nmsp::map::NavAreaIdType::NavAreaIdType_Max_Areas], const float(source)[3]) = 0;
	virtual bool FindBottom(_zoneid_t zoneId, int pathMask, const float areaCosts[nmsp::map::NavAreaIdType::NavAreaIdType_Max_Areas], const float(source)[3], float outBottomPos[3]) = 0;
	// 지연로딩
	virtual bool IsDeferedVoxelResource(_zoneid_t zoneId) = 0;
	virtual bool DeferedVoxelResourceLoading(_zoneid_t zoneId) = 0;
	virtual bool DeferedVoxelResourceUnloading(_zoneid_t zoneId) = 0;
	virtual bool IsDeferedTileResource(_zoneid_t zoneId) = 0;
	virtual bool DeferedTileResourceLoading(_zoneid_t zoneId) = 0;
	virtual bool DeferedTileResourceUnloading(_zoneid_t zoneId) = 0;
	// 추가된 
	virtual int WalkableRaycast(const CrowdAgentWalkMode walkMode, nmsp::map::_zoneid_t zoneId, const float(source)[3], const float(target)[3], int pathMask, const float areaCosts[nmsp::map::NavAreaIdType::NavAreaIdType_Max_Areas], float(position)[3], float(normal)[3], float* distance, float* height, nmsp::map::PathFindingType pathFindingType) = 0;
};

// ----------
// crowd관련
// 길찾기 결과처리를 위한 것..
struct IMapCrowdPathResult
{
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
	virtual int Size() const = 0;
	virtual const float* GetPos(int idx) const = 0;
	virtual const float* GetCurrent() const = 0;
	virtual const float* GetNext() const = 0;
	virtual const int64_t GetElapsedTime(int idx) const = 0;
	virtual const int64_t GetCurrentElapsedTime() const = 0;
	virtual const int64_t GetNextElapsedTime() const = 0;
	virtual const float GetSpeed(int idx) const = 0;
	virtual const float GetCurrentSpeed() const = 0;
	virtual const float GetNextSpeed() const = 0;
	virtual bool MoveNext() = 0;
	virtual void Reset() = 0;
	virtual int GetIndex() const = 0;
	virtual const int64_t GetTotalElapsedTime() const = 0;
	virtual const float GetTotalDistance() const = 0;
	virtual bool IsArrived() const = 0;
	virtual PathOffConnectionType GetPathOffConnection(int idx) const = 0;
	virtual PathOffConnectionType GetCurrentPathOffConnection() const = 0;
	virtual PathOffConnectionType GetNextPathOffConnection() const = 0;
	virtual const uint64_t GetRef(int idx) const = 0;
	virtual const uint64_t GetCurrentRef() const = 0;
	virtual const uint64_t GetNextRef() const = 0;
	virtual const int64_t GetWaitTime(int idx) const = 0;
	virtual const int64_t GetCurrentWaitTime() const = 0;
	virtual const int64_t GetNextWaitTime() const = 0;
	virtual void AddPath(const float pos[3], const float speed, const int64_t elapsedTime, uint64_t ref, int64_t waitTime, PathOffConnectionType pathOffConnectionType) = 0;
	virtual void AddPath(const float pos[3], const float speed, const int64_t elapsedTime, int64_t waitTime, PathOffConnectionType pathOffConnectionType) = 0;
	virtual PathFindingType GetPathFindingType() const = 0;
	virtual void SetPathFindingType(PathFindingType pathFindingType) = 0;
	virtual void SetSourcePosition(const float pos[3]) = 0;
	virtual void SetDestinationPosition(const float pos[3]) = 0;
	virtual const float* GetSourcePosition() const = 0;
	virtual const float* GetDestinationPosition() const = 0;
	virtual void AddPath(const float pos[3], const float speed, const int64_t elapsedTime, uint64_t ref, int64_t waitTime, PathOffConnectionType pathOffConnectionType, bool stepFlag) = 0;
	virtual bool GetCurrentStepFlag() = 0;
	virtual bool GetStepFlag(int idx) = 0;
};

struct IMapCrowdInfo
{
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
	// filter에 대한 처리를 여기서 하는 이유는 전체 crowd에 공통으로 하나만 사용하려고 하는게 목적임..
	// SetAreaCost를 사용하여 특정 agent의 areacost를 수정하면 애초에 공통으로 하나만 사용하는 것이므로.. 그것만 수정하게 됨
	virtual bool Init(const _zoneid_t zoneId, const int maxAgents, const float maxAgentRadius, const unsigned short filterMask, const float areaCosts[NavAreaIdType::NavAreaIdType_Max_Areas]) = 0;
	virtual void Uninit() = 0;
	virtual bool AddAgent(
				const float(position)[3], 
				const float(extentValue)[3],
				const float radius, 
				const float height, 
				const float weight,
				const float maxAcceleration, 
				const float maxSpeed, 
				const float collisionQueryRange, 
				const float pathOptimizationRange,
				const float separationWeight,
				const float avoidanceQueryMultiplier,
				const unsigned short updateFlags,
				const unsigned char avoidanceGroupId,
				const unsigned char groupsToAvoid,
				const unsigned char groupsToIgnore,
				const PathOption pathOption,
				const void* userData,
				const CrowdAgentWalkMode walkMode,
				const bool positionIgnore,
				const bool overlaped,
				const _navareaid_t freepassAreaId,				// 무조건 갈 수 있는 곳 (0이면 무시)
				const _navareaid_t noPermissionAreaId,			// 무조건 갈 수 없는 곳 (0이면 무시)
				int* index) = 0;
	virtual bool AddAgent(
				const float(position)[3],
				const float(extentValue)[3],
				const float radius,
				const float height,
				const float weight,
				const float maxAcceleration,
				const float maxSpeed,
				const float collisionQueryRange,
				const float pathOptimizationRange,
				const float separationWeight,
				const float avoidanceQueryMultiplier,
				const unsigned short updateFlags,
				const unsigned char avoidanceGroupId,
				const unsigned char groupsToAvoid,
				const unsigned char groupsToIgnore,
				const PathOption pathOption,
				const void* userData,
				const CrowdAgentWalkMode walkMode,
				const bool positionIgnore,
				const bool overlaped,
				const _navareaid_t freepassAreaId,				// 무조건 갈 수 있는 곳 (0이면 무시)
				const _navareaid_t noPermissionAreaId,			// 무조건 갈 수 없는 곳 (0이면 무시)
				const bool weNeedBottom,					// false인 경우는 spawn위치에 대해 바닥에 붙이지 않는다. true인 경우는 walkmode에 따라서 WALK인 경우는 붙이고, FLIGHT인 경우는 붙이지 않는다.
				int* index) = 0;
	virtual bool RequestMoveTarget(const int index, const float(position)[3], float(newPosition)[3]) = 0;
	virtual bool RequestMoveVelocity(const int index, const float(velocity)[3]) = 0;
	virtual bool RequestMoveSpeed(const int index, const float maxAcceleration, const float maxSpeed, int* newIndex) = 0;
	virtual bool ResetMoveTarget(const int index) = 0;
	virtual bool ResetAgentVelocity(const int index) = 0;
	virtual void RemoveAgent(const int index) = 0;
	virtual bool UpdatePosition(const int index, const float(position)[3], int* newIndex) = 0;
	virtual void Update(const float dt) = 0;
	virtual int QueryAgentPosition(const int index, float (position)[3], float(velocity)[3]) = 0;
	virtual bool RequestMoveTarget(const int index, const float(extentValue)[3], const float(position)[3], float(newPosition)[3]) = 0;
	//virtual bool UpdateState(const int index, bool repath) = 0;
	virtual bool ChangeGroupId(const int index, const unsigned char groupId) = 0;
	virtual int QueryAgentPosition(const int index, float(position)[3], float(velocity)[3], float(target)[3], int* targetCount) = 0;
	virtual int QueryAgentPosition(const int index, float(position)[3], float(velocity)[3], float(viaTarget)[3], float(viaTarget2)[3], float(target)[3], int* targetCount) = 0;
	virtual bool UpdatePosition(const int index, const float(position)[3], float(newPosition)[3], int* newIndex) = 0;
	virtual bool UpdatePosition(const int index, const CrowdAgentWalkMode walkMode, const float(position)[3], float(newPosition)[3], int* newIndex) = 0;
	virtual int GetMaxAgentCount() = 0;
	virtual int GetActiveAgentCount() = 0;
	virtual int GetEmptyAgentSlotCount() = 0;
	virtual int Expansion() = 0;
	virtual bool ChangeWalkMode(const int index, const CrowdAgentWalkMode walkMode, const float(currPos)[3], float(newPos)[3]) = 0;
	virtual CrowdAgentWalkMode GetWalkMode(const int index) = 0;
	virtual bool SetAreaCost(const int index, const _navareaid_t id, const float cost) = 0;		// 0은 설정하지 말자! FLT_MAX값이면 이동 불가임
	virtual bool GetAreaCost(const int index, const _navareaid_t id, float* cost) = 0;				// FLT_MAX값이면 이동 불가임
	virtual bool SamplePosition(const int index, const float(source)[3], const float(extentValue)[3], float(position)[3]) = 0;
	virtual bool SamplePosition(const CrowdAgentWalkMode walkMode, const float(source)[3], const float(extentValue)[3], float(position)[3]) = 0;
	virtual bool Raycast(const CrowdAgentWalkMode walkMode, const float(source)[3], const float(target)[3], float(position)[3], float(normal)[3], float* distance) = 0;
	virtual bool Raycast(const int index, const CrowdAgentWalkMode walkMode, const float(source)[3], const float(target)[3], float(position)[3], float(normal)[3], float* distance) = 0;
	virtual bool Raycast(const CrowdAgentWalkMode walkMode, const float(source)[3], const float(target)[3], int pathMask, const float areaCosts[NavAreaIdType::NavAreaIdType_Max_Areas], float(position)[3], float(normal)[3], float* distance) = 0;
	virtual bool RaycastForAttack(const CrowdAgentWalkMode sourceWalkMode, const float(source)[3], const float sourceHeight, const CrowdAgentWalkMode targetWalkMode, const float(target)[3], const float targetHeight, float(position)[3], float(normal)[3], float* distance, bool* isArrived) = 0;
	virtual bool RaycastForAttack(const CrowdAgentWalkMode sourceWalkMode, const float(source)[3], const float sourceHeight, const CrowdAgentWalkMode targetWalkMode, const float(target)[3], const float targetHeight, int pathMask, const float areaCosts[NavAreaIdType::NavAreaIdType_Max_Areas], float(position)[3], float(normal)[3], float* distance, bool* isArrived) = 0;
	virtual void GetAllAreaCost(float areaCosts[NavAreaIdType::NavAreaIdType_Max_Areas]) = 0;				// FLT_MAX값이면 이동 불가임
	virtual bool LandingPoint(const int index, const float(source)[3], float(position)[3], bool ignoreWalkMode = false) = 0;
	virtual bool NearestSurfaceOnFlight(const float(source)[3], float(position)[3]) = 0;
	virtual bool RequestMoveVelocity(const int index, const float(velocity)[3], const float maxAcceleration, const float maxSpeed, int* newIndex) = 0;
	virtual void SetAllFilterAreaCost(const _navareaid_t id, const float cost) = 0;		// 0은 설정하지 말자! FLT_MAX값이면 이동 불가임
	//virtual bool RaycastOnFlight(const int index, const CrowdAgentWalkMode sourceWalkMode, const float(source)[3], const float sourceHeight, const CrowdAgentWalkMode targetWalkMode, const float(target)[3], float(position)[3], float(normal)[3], float* distance, bool* isArrived) = 0;
	//virtual bool RaycastOnFlight(const CrowdAgentWalkMode sourceWalkMode, const float(source)[3], const float sourceHeight, const CrowdAgentWalkMode targetWalkMode, const float(target)[3], float(position)[3], float(normal)[3], float* distance, bool* isArrived) = 0;
	virtual bool WalkableNearestPosition(const int index, const float(source)[3], const float(target)[3], const float(extentValue)[3], float(position)[3]) = 0;
	virtual bool NearestDownsidePositionOnFlight(const float(source)[3], float(position)[3]) = 0;
	virtual bool RequestMoveShortestTarget(const int index, const float(extentValue)[3], const float(position)[3], float(newPosition)[3]) = 0;
	virtual int QueryAgentPosition(const int index, float(position)[3], float(viaVelocity)[3], float(viaTarget)[3], float(viaVelocity2)[3], float(viaTarget2)[3], float(targetVelocity)[3], float(target)[3], float(lastTarget)[3], int* targetCount, CrowdAgentWalkMode* walkMode, CrowdAgentWalkModeSub* walkmodeSub) = 0;
	virtual int QueryCurrentVIaTargetType(const int index) = 0;
	virtual bool SamplePosition2D(const CrowdAgentWalkMode walkMode, const float(source)[3], const float(extentValue)[3], float(position)[3]) = 0;
	virtual bool NearestUpsidePositionOnFlight(const float(source)[3], float(position)[3]) = 0;
	virtual bool NearestEnablePositionOnFlight(const float(source)[3], bool* upResult, float(UpPosition)[3], bool* downResult, float(downPosition)[3]) = 0;
	virtual bool NearestDownsideLastPositionOnFlight(const float(source)[3], float(position)[3]) = 0;
	virtual bool NearestUpsideLastPositionOnFlight(const float(source)[3], float(position)[3]) = 0;
	virtual bool PositionHeight(const CrowdAgentWalkMode walkMode, const float(source)[3], const float(extentValue)[3], float* height) = 0;
	// 최적화된 path가 아님. crowd에 의해 이동하는 패스를 미리 획득하는데 사용
	virtual bool MoveTargetPath(const int index, const CrowdAgentWalkMode sourceWalkMode, const float(extentValue)[3], const float(source)[3], const float(destination)[3], IMapCrowdPathResult** path) = 0;
	virtual bool MoveTargetPath(const int index, const CrowdAgentWalkMode sourceWalkMode, const float(extentValue)[3], const float(source)[3], const float(destination)[3], bool overWriteLoc, IMapCrowdPathResult** path) = 0;
	virtual bool RequestMoveTarget(const int index, const float(extentValue)[3], const float(position)[3], float(newPosition)[3], bool overWriteLoc) = 0;
	virtual bool RequestMoveShortestTarget(const int index, const float(extentValue)[3], const float(position)[3], float(newPosition)[3], bool overWriteLoc) = 0;
	virtual bool FixedPositionHeight(const int index, const float(source)[3], const float(extentValue)[3], float* height) = 0;
	virtual bool FixedPositionHeight(const CrowdAgentWalkMode sourceWalkMode, const float(source)[3], const float(extentValue)[3], float* height) = 0;
	// raycast가 2D (x,z) walkable 기반이라 휘어진 공간도 성공으로
	virtual bool WalkableRaycast(const CrowdAgentWalkMode walkMode, const float(source)[3], const float(target)[3], float(position)[3], float(normal)[3], float* distance, float* height) = 0;
	virtual bool WalkableRaycast(const int index, const CrowdAgentWalkMode walkMode, const float(source)[3], const float(target)[3], float(position)[3], float(normal)[3], float* distance, float* height) = 0;
	// 특정한 위치에서 위치로 navmesh를 연결하는데 사용하는 함수들
	virtual bool StartOffConnectionJump(const int idx, const float* start, const float* end, const float* velocity, const float* forward) = 0;
	virtual bool StartOffConnectionJump(const int idx, const float* start, const float* end, const float* velocity, const float* forward, float(viaVel)[3], float(viaNewTarget)[3], float(targetVel)[3], float(newTarget)[3], float* viaElapsedTime, float* targetElapsedTime) = 0;
	virtual bool StartOffConnectionFallingEnd(const int idx, const float* start, const float* end, float(viaVel)[3], float(viaNewTarget)[3], float(targetVel)[3], float(newTarget)[3], float* viaElapsedTime, float* targetElapsedTime) = 0;
	virtual bool StartOffConnectionDrop(const int idx, const float* start, const float* end, const float dropTime, const float waitTime, const float fallingSpeed, float(viaVel)[3], float(viaNewTarget)[3], float(targetVel)[3], float(newTarget)[3], float* viaElapsedTime, float* targetElapsedTime) = 0;
	virtual bool StartOffConnectionMove(const int idx, const float* start, const float* end, const float moveTime, const float waitTime, float(targetVel)[3], float(newTarget)[3], float* targetElapsedTime) = 0;
	virtual bool StartOffConnectionMove(const int idx, const float* start, const int positionCount, const float* position, const float* moveTime, const float* waitTime, int* resultCount, float* targetVel, float* newTarget, float* targetElapsedTime) = 0;
	virtual bool ResetOffConnection(const int idx) = 0;
	// 이동에 필요한 열려 있는 공간을 찾는다.
	virtual bool NearestCorriderPositionOnFlight(const float(source)[3], const float(direction)[3], bool* upResult, float(UpPosition)[3], bool* downResult, float(downPosition)[3]) = 0;
	//특정 방향으로 랜딩포인트를 찾는다. (source -> target y축 무시)
	virtual bool LandingPointWith2DDirection(const int index, const float(source)[3], const float(dir)[3], float(position)[3]) = 0;
	virtual bool FixedPositionHeightForDownSide(const int index, const float(source)[3], const float(extentValue)[3], float* height) = 0;
	virtual bool FixedPositionHeightForDownSide(const CrowdAgentWalkMode sourceWalkMode, const float(source)[3], const float(extentValue)[3], float* height) = 0;
	virtual bool IsBottom(const float(source)[3], bool* bottom) = 0;
	virtual bool FindBottom(const float(pos)[3], float* outBottomPos) = 0;
	virtual bool FindSkillBottom(const float(pos)[3], float* outBottomPos) = 0;
	virtual bool GetBottomPos(const float(pos)[3], bool* isBottom, float* outBottomPos) = 0;
	virtual float GetVoxelWidth() = 0;
	virtual float GetVoxelHeight() = 0;
	// 복셀 단차 확인 함수
	virtual int GetDiffHeightInVoxel(const float(source)[3], const float(target)[3]) = 0;
	// debug hpaInfo
	virtual void PrintHpaInfo(const float(source)[3], int level) = 0;
	virtual bool GetHeightFromTheGround(const int idx, const float(source)[3], float* height) = 0;
	virtual bool CheckPos(const int idx, const float(source)[3]) = 0;
	// 요철에서의 Raycast 
	virtual bool RuggednessRaycast(const int index, const float(source)[3], const float(target)[3], const float(forward)[3], float(position)[3], IMapResult** path) = 0;
	// 요철에서의 Move
	virtual bool StartOffConnectionRuggednessMove(const int idx, const float* start, const float* forward, const int positionCount, const float* position, const float* moveTime, const float* waitTime, int* resultCount, float* targetVel, float* newTarget, float* targetElapsedTime) = 0;
	// 미리 OffConnection을 만들어보자
	virtual bool PathOffConnectionJump(const int idx, const float* start, const float* end, const float* velocity, const float* forward, IMapCrowdPathResult** path) = 0;
	virtual bool PathOffConnectionJump(const int idx, const float* start, const float* end, const float* velocity, const float* forward, float(viaVel)[3], float(viaNewTarget)[3], float(targetVel)[3], float(newTarget)[3], float* viaElapsedTime, float* targetElapsedTime, IMapCrowdPathResult** path) = 0;
	virtual bool PathOffConnectionFallingEnd(const int idx, const float* start, const float* end, float(viaVel)[3], float(viaNewTarget)[3], float(targetVel)[3], float(newTarget)[3], float* viaElapsedTime, float* targetElapsedTime, IMapCrowdPathResult** path) = 0;
	virtual bool PathOffConnectionDrop(const int idx, const float* start, const float* end, const float dropTime, const float waitTime, const float fallingSpeed, float(viaVel)[3], float(viaNewTarget)[3], float(targetVel)[3], float(newTarget)[3], float* viaElapsedTime, float* targetElapsedTime, IMapCrowdPathResult** path) = 0;
	virtual bool PathOffConnectionMove(const int idx, const float* start, const float* end, const float moveTime, const float waitTime, float(targetVel)[3], float(newTarget)[3], float* targetElapsedTime, IMapCrowdPathResult** path) = 0;
	virtual bool PathOffConnectionMove(const int idx, const float* start, const int positionCount, const float* position, const float* moveTime, const float* waitTime, int* resultCount, float* targetVel, float* newTarget, float* targetElapsedTime, IMapCrowdPathResult** path) = 0;
	virtual bool PathOffConnectionRuggednessMove(const int idx, const float* start, const float* forward, const int positionCount, const float* position, const float* moveTime, const float* waitTime, int* resultCount, float* targetVel, float* newTarget, float* targetElapsedTime, IMapCrowdPathResult** path) = 0;
	virtual bool CheckDepth(const int idx, const float(source)[3], int* depthCount) = 0;
	virtual bool RequestMoveTarget(const int index, const float(extentValue)[3], const float(position)[3], float(newPosition)[3], bool overWriteLoc, PathFindingType pathFindingType) = 0;
	virtual bool RequestMoveShortestTarget(const int index, const float(extentValue)[3], const float(position)[3], float(newPosition)[3], bool overWriteLoc, PathFindingType pathFindingType) = 0;
	virtual bool MoveTargetPath(const int index, const CrowdAgentWalkMode sourceWalkMode, const float(extentValue)[3], const float(source)[3], const float(destination)[3], bool overWriteLoc, bool partial, PathFindingType pathFindingType, IMapCrowdPathResult** path) = 0;
	virtual bool CurrentPath(const int index, IMapCrowdPathResult** path) = 0;
	// 지연로딩
	virtual bool IsDeferedVoxelResource() = 0;
	virtual bool DeferedVoxelResourceLoading() = 0;
	virtual bool DeferedVoxelResourceUnloading() = 0;
	virtual bool IsDeferedTileResource() = 0;
	virtual bool DeferedTileResourceLoading() = 0;
	virtual bool DeferedTileResourceUnloading() = 0;
	// raycast가 2D (x,z) walkable 기반이라 휘어진 공간도 성공으로, 옵션 추가
	virtual bool WalkableRaycast(const CrowdAgentWalkMode walkMode, const float(source)[3], const float(target)[3], float(position)[3], float(normal)[3], float* distance, float* height, PathFindingType pathFindingType) = 0;
	virtual bool WalkableRaycast(const int index, const CrowdAgentWalkMode walkMode, const float(source)[3], const float(target)[3], float(position)[3], float(normal)[3], float* distance, float* height, PathFindingType pathFindingType) = 0;
	//  OffMesh상태인가 ?
	virtual bool IsStartOffConnectionState(const int index) = 0;
	// 속력 추가된 버젼
	virtual bool MoveTargetPath(const int index, const CrowdAgentWalkMode sourceWalkMode, const float(extentValue)[3], const float(source)[3], const float(destination)[3], bool overWriteLoc, bool partial, PathFindingType pathFindingType, const float speed, IMapCrowdPathResult** path) = 0;
	// 패스를 설정해 보자,
	virtual bool AllocateMoveTargetPath(IMapCrowdPathResult** path) = 0;
	virtual bool SetMoveTargetPath(const int index, const CrowdAgentWalkMode sourceWalkMode, const IMapCrowdPathResult* path, const float startElapsedTime) = 0;
	virtual bool GetCurrentRef(const int idx, uint64_t* currRef) = 0;
};

//
struct IMapCrowd : public IComponentBase
{
	virtual int AllocateCrowd(IMapCrowdInfo** crowdInfo) = 0;
};

//
extern "C" const UUID UUID_IMap;
extern "C" const UUID UUID_IMapCrowd;

} }	// map	// nmsp

#endif
