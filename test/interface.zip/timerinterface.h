////////////////////////////////////////////////////////////////////////////////
// �ۼ���: huelee
// ��  ��:
//
//

// ȣȯ���� ���ؼ�..
#pragma once
#ifndef __TIMERINTERFACE_H__
#define __TIMERINTERFACE_H__

namespace nmsp { namespace timer {

////////////////////////////////////////////////////////////////////////////////
//
typedef unsigned long long _TIMER_REL_KEY_T;
typedef unsigned long long _TIMER_VALUE_T;
typedef unsigned long long _TIMER_KEY_T;

////////////////////////////////////////////////////////////////////////////////
//
struct ITimerSink: public IComponentBase
{
	virtual int OnTimer(
					const _TIMER_KEY_T& tkTimerKey,
					const _TIMER_REL_KEY_T& rkVal,
					const _TIMER_VALUE_T& _tvCurrTime, 
					const _TIMER_VALUE_T& _tvFixedCurrTime,
					const _TIMER_VALUE_T& _tvElapsedTime,
					const _TIMER_VALUE_T& _tvScaleCurrTime) = 0; 
};

////////////////////////////////////////////////////////////////////////////////
//
struct ITimer: public IComponentBase
{
	virtual int RegTimer(_TIMER_KEY_T* ptkTimerKey, const _TIMER_REL_KEY_T& rkVal, ITimerSink* pISink) = 0;
	virtual int UnregTimer(const _TIMER_KEY_T& tkTimerKey) = 0;
	virtual int ChangeResolution(const _TIMER_KEY_T& tkTimerKey, int nResolution) = 0;
	virtual int GetTimeInfo(
						const _TIMER_KEY_T& tkTimerKey,
						_TIMER_REL_KEY_T& rkVal,
						_TIMER_VALUE_T& _tvCurrTime,
						_TIMER_VALUE_T& _tvFixedCurrTime,
						_TIMER_VALUE_T& _tvElapsedTime,
						_TIMER_VALUE_T& _tvScaleCurrTime) = 0; 
};

////////////////////////////////////////////////////////////////////////////////
//
extern "C" const UUID UUID_ITimerSink;
extern "C" const UUID UUID_ITimer;

} } // timer // nmsp

#endif
