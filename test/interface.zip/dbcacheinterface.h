﻿
#pragma once
#ifndef __DBCACHEINTERFACE_H__
#define __DBCACHEINTERFACE_H__

//#include "nmspsmart.h"

#include <string>
#include <list>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <tuple>

#ifdef _WIN32
#include <memory>
#else
#include <tr1/memory>
#endif
#include <functional>

namespace nmsp { namespace dbcache {

////////////////////////////////////////////////////////////////////////////////
//

enum class MSG_TYPE : uint16_t
{
	None = 0,
	SET,
	GET,
	REMOVE,
	FLUSH,
	FLUSHALL,
};

enum class CACHE_STATUS : int16_t
{
	None = 0,
	LOAD_HISTORY,
	SYNC_REQ,
	SYNC_ING,
	ACTIVE,
};

enum class TOUCH_KEEP_TYPE : int16_t
{
	None = 0,
	Add,
	Change
};

struct IDBCacheObject
{
	IDBCacheObject() : tick(0) { }
	virtual ~IDBCacheObject() { }

	virtual bool SetData(char *, int32_t, bool) = 0;
	virtual char * GetData() = 0;
	virtual int32_t GetDataLen() = 0;

	virtual bool IsDummy() = 0;

	void SetTick(uint64_t _tick) { tick = _tick; }
	uint64_t GetTick() { return tick; }
	uint64_t tick;
};


typedef std::function<void(const char *, const uint64_t &, const char *, const uint64_t &)> fnDestroyPtr;
struct IDBCacheIntegrity
{
	virtual void SetDestroyFunc(fnDestroyPtr _fnDestroy, const char * group_name, const uint64_t & key_number, const char * key_string, const uint64_t & keep_sec) = 0;
	virtual void CallDestroyFunc() = 0;

	virtual std::shared_ptr<IDBCacheObject> CreateCacheObject() = 0;
	virtual std::shared_ptr<IDBCacheObject> GetCacheObject() = 0;
	virtual void SetCacheObject(std::shared_ptr<IDBCacheObject> data) = 0;
};

struct IDBCache : public IComponentBase
{
	virtual CACHE_STATUS GetStatus() = 0;

	virtual bool Set(const char *, const uint64_t, char *, int32_t, uint64_t = 0) = 0;
	virtual bool Set(const char *, const uint64_t, IDBCacheObject *, uint64_t = 0) = 0;
	virtual bool Set(const char *, const uint64_t, std::shared_ptr<IDBCacheObject>, uint64_t = 0) = 0;

	virtual bool Set(const char *, const char *, char *, int32_t, uint64_t = 0) = 0;
	virtual bool Set(const char *, const char *, IDBCacheObject *, uint64_t = 0) = 0;
	virtual bool Set(const char *, const char *, std::shared_ptr<IDBCacheObject>, uint64_t = 0) = 0;

	virtual bool Get(const char *, const uint64_t, IDBCacheObject *, TOUCH_KEEP_TYPE = TOUCH_KEEP_TYPE::None, uint64_t = 0) = 0;
	virtual bool Get(const char *, const uint64_t, std::shared_ptr<IDBCacheObject>, TOUCH_KEEP_TYPE = TOUCH_KEEP_TYPE::None, uint64_t = 0) = 0;
							
	virtual bool Get(const char *, const char *, IDBCacheObject *, TOUCH_KEEP_TYPE = TOUCH_KEEP_TYPE::None, uint64_t = 0) = 0;
	virtual bool Get(const char *, const char *, std::shared_ptr<IDBCacheObject>, TOUCH_KEEP_TYPE = TOUCH_KEEP_TYPE::None, uint64_t = 0) = 0;

	virtual void Set(const char *, const uint64_t, IDBCacheIntegrity *, uint64_t = 0) = 0;
	virtual void Set(const char *, const char *, IDBCacheIntegrity *, uint64_t = 0) = 0;
	virtual bool Get(const char *, const uint64_t, IDBCacheIntegrity *, TOUCH_KEEP_TYPE = TOUCH_KEEP_TYPE::None, uint64_t = 0) = 0;
	virtual bool Get(const char *, const char *, IDBCacheIntegrity *, TOUCH_KEEP_TYPE = TOUCH_KEEP_TYPE::None, uint64_t = 0) = 0;

	virtual bool Remove(const char *, const uint64_t) = 0;
	virtual bool Remove(const char *, const char *) = 0;

	virtual void Flush(const char *) = 0;
	virtual void FlushAll() = 0;

	virtual uint64_t GetGroupKeyCount(const char *) = 0; // in : group name, out : key count
	virtual void GetGroupName(std::vector<std::string> &) = 0;	// in&out : all group name
	virtual void GetKeyCount(std::map<std::string, size_t> &) = 0; // in&out : all group name and key count
};

////////////////////////////////////////////////////////////////////////////////
//
extern "C" const UUID UUID_IDBCache;

} }

#endif




/*
typedef std::function<std::shared_ptr<IDBCacheObject>()> fnCreatePtr;
typedef std::function<const char *, const char *, const uint64_t &, const uint64_t &)> fnDestroyPtr;
struct IDBCacheIntegrity : public IComponentBase
{
	IDBCacheIntegrity(fnCreatePtr fnCreate) : m_fnCreatePtr(fnCreate), m_fnDestroyPtr(nullptr), m_group_name(""), m_key_string(""), m_key_number(0), m_keep_sec(0) {}
	virtual ~IDBCacheIntegrity() { CallDestroyFunc(); }

	bool CreateCacheObject()
	{
		if (m_fnCreatePtr == nullptr)
			return false;

		cacheObject = m_fnCreatePtr();
		return true;
	}

	void SetCacheObject(fnDestroyPtr _fnDestroy, const char * group_name, const char * key_string, const uint64_t & key_number, const uint64_t & keep_sec)
	{
		m_fnDestroyPtr = _fnDestroy;
		m_group_name = group_name;
		m_key_string = key_string;
		m_key_number = key_number;
		m_keep_sec = keep_sec;
	}
	void CallDestroyFunc()
	{
		if (m_fnDestroyPtr != nullptr)
			m_fnDestroyPtr(m_group_name.c_str(), m_key_string.c_str(), m_key_number, m_keep_sec);
	}

public:
	std::shared_ptr<IDBCacheObject> cacheObject;

private:
	fnCreatePtr		m_fnCreatePtr;
	fnDestroyPtr	m_fnDestroyPtr;
	std::string		m_group_name;
	std::string		m_key_string;
	uint64_t		m_key_number;
	uint64_t		m_keep_sec;
};
*/
