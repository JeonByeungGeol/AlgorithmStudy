﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __SHEETINTERFACE_H__
#define __SHEETINTERFACE_H__

namespace nmsp { namespace sheet {

// 추후에 쉬트가 변했을때 리로딩된 것을 통보해 주기 위해 사용..
struct ISheetSink : public IComponentBase
{
	virtual int NotifyReload() = 0;
	virtual int NotifyRollback() = 0;
	virtual int NotifyCommit() = 0;
};

// 
struct ISheets : public IComponentBase
{
	// SINK인터페이스를 설정한다.
	virtual int SetSinkInterface(unsigned short uiServiceType, ISheetSink* piSink) = 0;
	// SINK인터페이스를 제거한다..
	virtual int ResetSinkInterface(unsigned short uiServiceType) = 0;
	// 로딩
	virtual int SheetReload() = 0;
	virtual int SheetCommit() = 0;
	virtual int SheetRollback() = 0;
};

//
extern "C" const UUID UUID_ISheetSink;
extern "C" const UUID UUID_ISheets;

} } // sheet	// nmsp

#endif
