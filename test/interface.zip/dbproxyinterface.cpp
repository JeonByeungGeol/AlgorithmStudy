////////////////////////////////////////////////////////////////////////////////
//
// �ۼ��� : sjkim
// ��  �� : 
//
//

#include <string>
#include <vector>
#include "nmspinterface.h"
#include "dbproxyinterface.h"

namespace nmsp { namespace dbproxy {

	// {C986B339-805F-4FE5-AB2A-25C756D54E3D}
	const UUID UUID_IDBProxy = { 0xc986b339, 0x805f, 0x4fe5, { 0xab, 0x2a, 0x25, 0xc7, 0x56, 0xd5, 0x4e, 0x3d } };

} }		// dbproxy // nmsp
