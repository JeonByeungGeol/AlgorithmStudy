////////////////////////////////////////////////////////////////////////////////
//
// �ۼ��� : huelee
// ��  �� : 
//

//
#include <string>
#include "nmspinterface.h"
#include "uniqueidinterface.h"

namespace nmsp { namespace uniqueid {

// {4D1CCADA-8FB1-4C51-98C6-C335B3C6CD7D}
const UUID UUID_IUniqueID = { 0x4d1ccada, 0x8fb1, 0x4c51,{ 0x98, 0xc6, 0xc3, 0x35, 0xb3, 0xc6, 0xcd, 0x7d } };

} }		// uniqueid // nmsp
