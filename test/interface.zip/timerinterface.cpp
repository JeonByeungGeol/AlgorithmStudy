////////////////////////////////////////////////////////////////////////////////
//
// �ۼ��� : huelee
// ��  �� : 
//

//
#include <string>
#include "nmspinterface.h"
#include "timerinterface.h"

namespace nmsp { namespace timer {

// {4E260E19-CA9B-4A7C-BFC1-F6EA79F08BE2}
const UUID UUID_ITimerSink = { 0x4e260e19, 0xca9b, 0x4a7c,{ 0xbf, 0xc1, 0xf6, 0xea, 0x79, 0xf0, 0x8b, 0xe2 } };

// {BED805E4-D1B2-4310-886E-DFCB90BBC30D}
const UUID UUID_ITimer = { 0xbed805e4, 0xd1b2, 0x4310,{ 0x88, 0x6e, 0xdf, 0xcb, 0x90, 0xbb, 0xc3, 0xd } };

} }		// timer // nmsp
