////////////////////////////////////////////////////////////////////////////////
//
// �ۼ��� : huelee
// ��  �� : 
//

//
#include <string>
#include "nmspinterface.h"
#include "loginterface.h"

namespace nmsp { namespace log {

//
// {986F049F-5492-49C6-98E6-3F4311EA4835}
const UUID UUID_ILog = { 0x986f049f, 0x5492, 0x49c6,{ 0x98, 0xe6, 0x3f, 0x43, 0x11, 0xea, 0x48, 0x35 } };

} }		// log // nmsp
