﻿////////////////////////////////////////////////////////////////////////////////
// 작자: 
// 설명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __HTTPINTERFACE_H__
#define __HTTPINTERFACE_H__

#include <unordered_map>

namespace nmsp { namespace http {

class IRequest : public IComponentBase
{
public:
	virtual const char* Schema() = 0;
	virtual void Schema(const char*) = 0;

	virtual const char* Host() = 0;
	virtual void Host(const char*) = 0;

	virtual unsigned short Port() = 0;
	virtual void Port(unsigned short) = 0;

	virtual const char* Path() = 0;
	virtual void Path(const char*) = 0;

	virtual const wchar_t* Body() = 0;
	virtual int GetBodyLenth() = 0;
	virtual void Body(const wchar_t*, int) = 0;

	virtual const char* Method() = 0;
	virtual void Method(const char*) = 0;

	virtual const std::unordered_map<std::string, std::string> Reserved() = 0;
	virtual void Reserved(const std::unordered_map<std::string, std::string>) = 0;
	virtual std::string FindReservedValue(const std::string&) = 0;
};

class IResponse : public IComponentBase
{
public:
	virtual void Process(IRequest* request, int code, const char* message) = 0;
	virtual void Exception(const bool& bException) = 0;
	virtual bool IsException() = 0;
};

class IHttpClient : public IComponentBase
{
public:
	virtual void Init(int threadCount, int sessionPoolCount) = 0;
	virtual void Uninit() = 0;

	virtual bool Request(http::IRequest*, http::IResponse*, const uint32_t& timeOutMilliSeconds = 20000) = 0;
};

extern "C" const UUID UUID_IHttpRequest;
extern "C" const UUID UUID_IHttpResponse;
extern "C" const UUID UUID_IHttpClient;

} }		// http // nmsp

#endif
