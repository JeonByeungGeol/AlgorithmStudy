////////////////////////////////////////////////////////////////////////////////
//
// �ۼ��� : huelee
// ��  �� : 
//

//
#include <string>
#include "nmspinterface.h"
#include "networkinterface.h"

namespace nmsp { namespace network {

// {49C57D68-0602-459D-B78B-B4D660B41598}
const UUID UUID_INetwork = { 0x49c57d68, 0x602, 0x459d,{ 0xb7, 0x8b, 0xb4, 0xd6, 0x60, 0xb4, 0x15, 0x98 } };

// {BA738603-ABBE-4BC6-A9D2-040FCF3C648A}
const UUID UUID_INetworkParse = { 0xba738603, 0xabbe, 0x4bc6,{ 0xa9, 0xd2, 0x4, 0xf, 0xcf, 0x3c, 0x64, 0x8a } };

// {3B196E71-3FEF-4F2C-96B7-202DF6EA4CAF}
const UUID UUID_INetworkSink = { 0x3b196e71, 0x3fef, 0x4f2c,{ 0x96, 0xb7, 0x20, 0x2d, 0xf6, 0xea, 0x4c, 0xaf } };

} }		// network // nmsp
