////////////////////////////////////////////////////////////////////////////////
//
// �ۼ��� : huelee
// ��  �� : 
//

//
#include <string>
#include "nmspinterface.h"
#include "sheetinterface.h"

namespace nmsp { namespace sheet {

// {C6C5C0AE-1EDD-4281-B410-3BFD8CC21530}
const UUID UUID_ISheetSink = { 0xc6c5c0ae, 0x1edd, 0x4281,{ 0xb4, 0x10, 0x3b, 0xfd, 0x8c, 0xc2, 0x15, 0x30 } };

// {F43C48FA-E356-4FB3-AE71-75A2783E550E}
const UUID UUID_ISheets = { 0xf43c48fa, 0xe356, 0x4fb3,{ 0xae, 0x71, 0x75, 0xa2, 0x78, 0x3e, 0x55, 0xe } };

} } // sheet // nmsp
