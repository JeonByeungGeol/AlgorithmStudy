﻿////////////////////////////////////////////////////////////////////////////////
//
// 작성자 : huelee
// 설  명 : 
//

//
#include <string>
#include "nmspinterface.h"
#include "nmbsdkinterface.h"

namespace nmsp { namespace nmbsdk {

// {FD400023-3446-44EA-9D65-7CD33E917C8E}
const UUID UUID_INMBAuth = { 0xfd400023, 0x3446, 0x44ea,{ 0x9d, 0x65, 0x7c, 0xd3, 0x3e, 0x91, 0x7c, 0x8e } };

} }		// nmbauth // nmsp
