﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __NETWORKINTERFACE_H__
#define __NETWORKINTERFACE_H__

#include <vector>

namespace nmsp { namespace network {

// 
typedef long long int _client_t;

// sink interface 정의
// 어딘가에서 데이터가 전달되어 졌을때.. 이것을 통해서 받아볼 수 있다
struct INetworkSink : public nmsp::IComponentBase
{
	virtual int Bind(const _client_t& session, int nLen, const char* pchAddr) = 0;
	virtual int Unbind(const _client_t& session) = 0;
	virtual int In(const _client_t& session, int nLen, const unsigned char* pchData) = 0;
	virtual int Posted(const _client_t& session, int nOption, int nLen, const unsigned char* pchData) = 0;
	virtual int Time(int id) = 0;
};

// packet parser
struct INetworkParse : public nmsp::IComponentBase
{
	// 패킷을 묶는다
	virtual int Assemble(int nPktLen, int nMaxHdLen, int* pnLen, unsigned char* pchHd) = 0;
	// 패킷을 분해한다.
	virtual int DisAssemble(const _client_t& session, int nLen, const unsigned char* pchData, int* pnTotalLen, int* pnHdLen, int* pnDataLen) = 0;
};

// INetworkMessage 에서 사용될 버퍼
struct INetworkMessageBuffer
{
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
	virtual unsigned char* GetData() = 0;
	virtual int GetSize() = 0;
	virtual bool Append(const void* src, size_t len) = 0;
	virtual int Allocate(int nLen) = 0;
	virtual void Reset() = 0;
};

// 여러개의 메시지를 한번 Notify하게 되면 Put했던 모든 것은 clear된다..
struct INetworkMessage
{
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
	virtual int Put(nmsp::network::INetworkMessageBuffer* buffer) = 0;
	virtual int Put(int nLen, const unsigned char* pchData) = 0;
	virtual int Merge(INetworkMessage* pOtherMessage) = 0;
	virtual int Total() = 0;
};

struct IConfigInfo
{
	virtual void SetUrl(const std::string & url) { server_url = url; }
	virtual void SetPort(const int32_t & port) { server_port = port; }
	virtual void PushLocalIPv4(const std::string & IP) { vec_local_ipv4.emplace_back(IP); }
	virtual void PushLocalIPv6(const std::string & IP) { vec_local_ipv6.emplace_back(IP); }

	std::string server_url;
	int32_t server_port;
	std::vector<std::string> vec_local_ipv4;
	std::vector<std::string> vec_local_ipv6;

};

// interface 정의
// 
struct INetwork : public nmsp::IComponentBase
{
	virtual int SetSink(unsigned short uiServiceType, INetworkParse* piParser, INetworkSink* piSink) = 0;
	virtual void ResetSink(unsigned short uiServiceType) = 0;
	virtual int Out(const _client_t& session, int nLen, const unsigned char* pchData) = 0;
	virtual int Close(const _client_t& session) = 0;
	virtual int Post(const _client_t& session, int nOption, int nLen, const unsigned char* pchData) = 0;
	// id는 0이 아닌 값으로...
	virtual int SetTimer(int id, int milisec) = 0;
	virtual int ResetTimer(int id) = 0;

	virtual void GetConfigInfo(IConfigInfo & info) = 0;

	// 여러개의 메시지를 묶어 한번에 전송하고자 할때 사용한다..
	virtual int GetNetworkMessage(INetworkMessage** ppiConnectorMessage) = 0;
	virtual int GetNetworkMessageBuffer(int nLen, INetworkMessageBuffer** ppiConnectorMessage) = 0;
	
	// INetworkMessage은 GetNetworkMessage에 의해 발급된 것만 사용해야 한다..
	virtual int Out(const _client_t& session, INetworkMessage* piNetworkMessage) = 0;
	virtual int Out(const _client_t& session, int nLen, const unsigned char* pchData, int nLen2, const unsigned char* pchData2) = 0;
};

//
extern "C" const UUID UUID_INetworkSink;
extern "C" const UUID UUID_INetworkParse;
extern "C" const UUID UUID_INetwork;

} } // network // nmsp

#endif
