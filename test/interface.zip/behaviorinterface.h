﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __BEHAVIORINTERFACE_H__
#define __BEHAVIORINTERFACE_H__

namespace nmsp { namespace behavior {

// 전방 선언
struct IBehaviorObject;

// 
enum class BehaviorReturn
{
	BehaviorReturn_Fail,
	BehaviorReturn_Success,
	BehaviorReturn_Running,
	BehaviorReturn_Cooltime,
};

//
enum class BehaviorDataType
{
	BehaviorDataType_None = 0,
	BehaviorDataType_Double = 1,
	BehaviorDataType_Int64 = 2,
	BehaviorDataType_Vector = 3,
	BehaviorDataType_Object = 4,
};

// 데이터 타입
// 모두는 array일수 있음
struct IBehaviorData
{
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
	virtual bool GetType(BehaviorDataType* type) = 0;							// BehaviorDataType double(1), int64_t(2), nmsp::Vector3(3), _behavior_object_t(4)
	virtual bool GetValue(double* value) = 0;
	virtual bool GetValue(int64_t* value) = 0;
	virtual bool GetValue(float* x, float* y, float* z) = 0;		// vector
	virtual bool GetValue(IBehaviorObject** value) = 0;
	virtual bool SetValue(double value) = 0;
	virtual bool SetValue(int64_t value) = 0;
	virtual bool SetValue(float x, float y, float z) = 0;			// vector
	virtual bool SetValue(IBehaviorObject* value) = 0;
	virtual bool GetResetCheckIdFlag() = 0;
	virtual int GetResetCheckId() = 0;
	virtual void SetResetCheckId(int resetCheckId) = 0;
};

// 실행의 주체들! 서로를 참조할 수도 있다!
// 
struct IBehaviorObject
{
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
	virtual BehaviorReturn InitExecute(int command, int argCount, IBehaviorData** input, IBehaviorData* output) = 0;
	virtual BehaviorReturn Execute(int command, int argCount, IBehaviorData** input, IBehaviorData* output) = 0;
	virtual BehaviorReturn UninitExecute(int command, int argCount, IBehaviorData** input) = 0;
	virtual BehaviorReturn Check() = 0;
	virtual void Reset() = 0;
	virtual void BehaviorLog(const char* log) = 0;
	virtual bool IsDebugMode() = 0;
	virtual void CurrentDebugInfo(BehaviorReturn currRet, const char* nodeName, const char* groupName, int argCount, IBehaviorData** input, IBehaviorData* output) = 0;
	virtual bool IsArrivedMessage() = 0;
	virtual int GetArrivedMessageId() = 0;
	virtual void PopArrivedMessage() = 0;
	virtual int GetResetCheckId() = 0;
};

// command정보 (이름/ID)
struct IBehaviorCommandInfo
{
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
	virtual int Size() = 0;
	virtual bool Current(const char** name, int* id) = 0;
	virtual bool MoveNext() = 0;
	virtual void Reset() = 0;
};

//
struct IBehavior : public IComponentBase
{
	// 같은 레벨은 오직 같은 쓰레드에서만 호출해야 한다
	virtual void Process(int64_t currentGameTime, int64_t level) = 0;
	virtual void Process(int64_t currentGameTime, int64_t level, int groupId, uint64_t objectId) = 0;
	// 같은 레벨은 오직 같은 쓰레드에서만 호출해야 한다
	virtual int Add(int64_t level, int groupId, uint64_t objectId, IBehaviorObject* object) = 0;
	// 같은 레벨은 오직 같은 쓰레드에서만 호출해야 한다
	virtual int Del(int64_t level, int groupId, uint64_t objectId) = 0;
	virtual int Del(int64_t level) = 0;
	// 같은 레벨은 오직 같은 쓰레드에서만 호출해야 한다 (모든 behavior 스택들을 리셋한다)
	virtual int Reset(int64_t level, int groupId, uint64_t objectId) = 0;
	// 조회함수들
	virtual int ConvertGroupNameToId(const char* groupName, int* griupId) = 0;
	virtual int GetCommandInfo(IBehaviorCommandInfo** info) = 0;

	// 디버그용 함수
	virtual void DebugReloadData() = 0;
};

extern "C" const UUID UUID_IBehavior;

} }		// behavior // nmsp

#endif
