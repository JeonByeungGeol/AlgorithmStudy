////////////////////////////////////////////////////////////////////////////////
//
// �ۼ��� : huelee
// ��  �� : 
//

//
#include <string>
#include "nmspinterface.h"
#include "behaviorinterface.h"

namespace nmsp { namespace behavior {

//
// {876FB00F-B01A-4429-B416-7E09D50649E6}
const UUID UUID_IBehavior = { 0x876fb00f, 0xb01a, 0x4429,{ 0xb4, 0x16, 0x7e, 0x9, 0xd5, 0x6, 0x49, 0xe6 } };

} }		// behavior // nmsp
