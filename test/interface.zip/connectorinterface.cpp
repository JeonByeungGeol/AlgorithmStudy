////////////////////////////////////////////////////////////////////////////////
//
// �ۼ��� : huelee
// ��  �� : 
//

//
#include <string>
#include "nmspinterface.h"
#include "connectorinterface.h"

namespace nmsp { namespace connector {

//
// {1CBD9B61-2292-4ED6-A1A6-F9755D12F4CC}
const UUID UUID_IConnectorSink = { 0x1cbd9b61, 0x2292, 0x4ed6,{ 0xa1, 0xa6, 0xf9, 0x75, 0x5d, 0x12, 0xf4, 0xcc } };

//
// {A72378E4-19FB-47EC-A70E-78F45FED8B3E}
const UUID UUID_IConnector = { 0xa72378e4, 0x19fb, 0x47ec,{ 0xa7, 0xe, 0x78, 0xf4, 0x5f, 0xed, 0x8b, 0x3e } };

} }		// connector // nmsp
