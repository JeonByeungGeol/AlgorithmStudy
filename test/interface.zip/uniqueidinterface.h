////////////////////////////////////////////////////////////////////////////////
// �ۼ���: huelee
// ��  ��:
//
//

// ȣȯ���� ���ؼ�..
#pragma once
#ifndef __UNIQUEIDINTERFACE_H__
#define __UNIQUEIDINTERFACE_H__

namespace nmsp { namespace uniqueid {

//
typedef uint64_t _uuid_t;

////////////////////////////////////////////////////////////////////////////////
//
struct IUniqueID: public IComponentBase
{
	virtual int GenerateUuid(bool signbit, uint16_t id, _uuid_t* val) = 0;
};

////////////////////////////////////////////////////////////////////////////////
//
extern "C" const UUID UUID_IUniqueID;

} } // timer // nmsp

#endif
