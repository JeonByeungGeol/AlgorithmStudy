#include <string>
#include "nmspinterface.h"
#include "messagequeueinterface.h"

namespace nmsp {
	namespace messagequeue {
		// {218397A3-6562-443D-BDE6-26A443088D13}
		const UUID UUID_IMessageQueueSink = { 0x218397a3, 0x6562, 0x443d,{ 0xbd, 0xe6, 0x26, 0xa4, 0x43, 0x8, 0x8d, 0x13 } };

		// {482C46B1-3778-4794-8652-8A165E833A58}
		const UUID UUID_IMessageQueue = { 0x482c46b1, 0x3778, 0x4794,{ 0x86, 0x52, 0x8a, 0x16, 0x5e, 0x83, 0x3a, 0x58 } };
	}
}