﻿////////////////////////////////////////////////////////////////////////////////
//
// 작성자: sjkim
// 설  명: 
//
//

#pragma once
#ifndef __DBPROXYINTERFACE_H__
#define __DBPROXYINTERFACE_H__

#ifdef _WIN32
#include <memory>
#else
#include <tr1/memory>
#endif

namespace nmsp { namespace dbproxy {

//
typedef uint64_t _uuid_t;
typedef long long _sql_len_t;
typedef int16_t _sql_c_type_t;

////////////////////////////////////////////////////////////////////////////////
//

struct IDBObject
{
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;

	virtual void Clear() = 0;
	virtual bool MoveNext() = 0;
	virtual bool NextRecordSet() = 0;

	virtual void SetQueryString(std::string query) = 0;
	virtual std::string GetQueryString() = 0;

	virtual bool PutData(char * value, _sql_len_t len) = 0;
	virtual bool PutData(const char* value, _sql_len_t len) = 0;
	virtual bool PutData(wchar_t* value, _sql_len_t len) = 0;
	virtual bool PutData(const wchar_t* value, _sql_len_t len) = 0;

	virtual bool AddParam(char & value) = 0;
	virtual bool AddParam(wchar_t & value) = 0;
	virtual bool AddParam(char * value, _sql_len_t len) = 0;
	virtual bool AddParam(wchar_t * value, _sql_len_t len) = 0;

	virtual bool AddParam(bool& value) = 0;

	virtual bool AddParam(int8_t & value) = 0;
	virtual bool AddParam(uint8_t & value) = 0;

	virtual bool AddParam(int16_t & value) = 0;
	virtual bool AddParam(uint16_t & value) = 0;

	virtual bool AddParam(int32_t & value) = 0;
	virtual bool AddParam(uint32_t & value) = 0;

	virtual bool AddParam(int64_t & value) = 0;
	virtual bool AddParam(uint64_t & value) = 0;

	virtual bool AddParam(long & value) = 0;
	virtual bool AddParam(unsigned long & value) = 0;

	virtual bool AddParam(double & value) = 0;
	virtual bool AddParam(float & value) = 0;

	virtual bool AddParam(std::string & value) = 0;
	virtual bool AddParam(std::wstring & value) = 0;

	/*
	virtual bool AddParam_Date(std::string& value) = 0;
	virtual bool AddParam_Date(std::wstring& value) = 0;
	virtual bool AddParam_Time(std::string& value) = 0;
	virtual bool AddParam_Time(std::wstring& value) = 0;
	virtual bool AddParam_DateTime(std::string& value) = 0;
	virtual bool AddParam_DateTime(std::wstring& value) = 0;

	virtual bool AddParam_TimeStamp(std::string & value) = 0;
	virtual bool AddParam_TimeStamp(std::wstring & value) = 0;
	*/

	virtual bool AddParam_Binary(char * value, _sql_len_t &len) = 0;
	virtual bool AddParam_Binary(const char * value, _sql_len_t &len) = 0;

	virtual bool ReadData(char & out_value) = 0;
	virtual bool ReadData(wchar_t & out_value) = 0;
	virtual bool ReadData(char * out_value, _sql_len_t len) = 0;
	virtual bool ReadData(wchar_t * out_value, _sql_len_t len) = 0;

	virtual bool ReadData(bool& value) = 0;

	virtual bool ReadData(int8_t & out_value) = 0;
	virtual bool ReadData(uint8_t & out_value) = 0;

	virtual bool ReadData(int16_t & out_value) = 0;
	virtual bool ReadData(uint16_t & out_value) = 0;

	virtual bool ReadData(int32_t & out_value) = 0;
	virtual bool ReadData(uint32_t & out_value) = 0;

	virtual bool ReadData(int64_t & out_value) = 0;
	virtual bool ReadData(uint64_t & out_value) = 0;

	virtual bool ReadData(long & out_value) = 0;
	virtual bool ReadData(unsigned long & out_value) = 0;

	virtual bool ReadData(double & out_value) = 0;
	virtual bool ReadData(float & out_value) = 0;

	virtual bool ReadData(std::string & out_value) = 0;
	virtual bool ReadData(std::wstring & out_value) = 0;

	/*
	virtual bool ReadData_Date(std::string& out_value) = 0;
	virtual bool ReadData_Date(std::wstring& out_value) = 0;
	virtual bool ReadData_Time(std::string& out_value) = 0;
	virtual bool ReadData_Time(std::wstring& out_value) = 0;
	virtual bool ReadData_DateTime(std::string& out_value) = 0;
	virtual bool ReadData_DateTime(std::wstring& out_value) = 0;

	virtual bool ReadData_TimeStamp(std::string & out_value) = 0;
	virtual bool ReadData_TimeStamp(std::wstring & out_value) = 0;
	*/
	virtual bool ReadData_TimeStamp(struct tm & timeinfo) = 0;

	virtual bool ReadData_Binary(std::string & out_value) = 0;
	virtual bool ReadData_Binary(void * out_value, _sql_len_t len, _sql_len_t & out_len) = 0;

	virtual _sql_len_t GetDataSize(int32_t col_num) = 0;

	virtual void GetErrorString(std::string & out_error) = 0;
	virtual int32_t GetParamIndex() = 0;
	virtual int32_t GetReadIndex() = 0;
};

struct IDBCommand
{
	typedef void * SQL_H_STMT;

	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
		
	virtual void OnInit(IDBObject * object) = 0;
	virtual bool ReCommandCall() { return false; }

	virtual bool OnNeedData(IDBObject * object, void * value) = 0;

	virtual int32_t OnResult(bool is_first_null, IDBObject * object) = 0;
	virtual void OnResultProcess(int32_t result) = 0;
};


struct IDBProxy : public IComponentBase
{
	virtual bool Execute_Async(int32_t, int32_t, std::shared_ptr<IDBCommand>&&) = 0;
	virtual bool Execute_Sync(int32_t, int32_t, std::shared_ptr<IDBCommand>&&) = 0;
};


////////////////////////////////////////////////////////////////////////////////
//
extern "C" const UUID UUID_IDBProxy;

}}

#endif
