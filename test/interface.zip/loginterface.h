////////////////////////////////////////////////////////////////////////////////
// �ۼ���: huelee
// ��  ��:
//
//

// ȣȯ���� ���ؼ�..
#pragma once
#ifndef __LOGINTERFACE_H__
#define __LOGINTERFACE_H__

namespace nmsp { namespace log {

// ���� ����ִ�.. 
struct ILog : public IComponentBase
{
	virtual int LogAnsi(unsigned short uiServiceType, int nSeverity, const char* achData) = 0;							// null terminated string
	virtual int Log2Ansi(unsigned short uiServiceType, int nSeverity, int nLen, const char* achData) = 0;
	virtual int LogUnicode(unsigned short uiServiceType, int nSeverity, const wchar_t* awcData) = 0;					// null terminated wide character string
	virtual int Log2Unicode(unsigned short uiServiceType, int nSeverity, int nLen, const wchar_t* awcData) = 0;
	virtual int SetSeverity(unsigned short uiServiceType, int nNewSeverity, int* pnOldLevel) = 0;
	virtual int GetSeverity(unsigned short uiServiceType, int* pnOldLevel) = 0;
};

// 
extern "C" const UUID UUID_ILog;

} }		// log // nmsp

#endif
