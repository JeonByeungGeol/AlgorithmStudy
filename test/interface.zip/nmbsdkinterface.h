﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: 
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __NMBAUTHINTERFACE_H__
#define __NMBAUTHINTERFACE_H__

namespace nmsp { namespace nmbsdk {
	
class INMBVerifyObject : public IComponentBase
{
public:
	virtual bool Exec(const char* pid) = 0;
	virtual void OnError(const char* pid, int errorCode, const char* message) = 0;
};
//
class INMBAuth : public IComponentBase
{
public:
	virtual void RegisterVerifyCallback(INMBVerifyObject* obj) = 0;
	virtual void Connect() = 0;
	virtual bool Verify(const char* pid, const char* gameToken) = 0;
};

extern "C" const UUID UUID_INMBAuth;

} }		// nmbsdk // nmsp

#endif
