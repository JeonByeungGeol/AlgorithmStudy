#include <string>
#include <vector>
#include "nmspinterface.h"

#include "dbcacheinterface.h"

namespace nmsp {
	namespace dbcache {

		// {7BE4A7D7-515E-4E41-845D-7E5CE953D331}
		const UUID UUID_IDBCache = { 0x7be4a7d7, 0x515e, 0x4e41,{ 0x84, 0x5d, 0x7e, 0x5c, 0xe9, 0x53, 0xd3, 0x31 } };

	}
}		// dbcache // nmsp
