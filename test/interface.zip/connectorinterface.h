﻿////////////////////////////////////////////////////////////////////////////////
// 작성자: huelee
// 설  명:
//
//

// 호환성을 위해서..
#pragma once
#ifndef __CONNECTORINTERFACE_H__
#define __CONNECTORINTERFACE_H__

namespace nmsp { namespace connector {

//
typedef unsigned short _serverid_t;
typedef unsigned short _servicetype_t;

enum group_layer : unsigned short
{
	none = 0x00,
	region = 0x01,
	local = 0x02
};

using _group_id_t = unsigned short;
using _group_layer_t = unsigned short;
// 
enum
{
	SERVERID_NULL = 0,
};

//
struct IConnectorSink : public IComponentBase
{
	virtual int NotifiedOnLineService(_serverid_t serverId, int nLen, unsigned short* puiServiceType) = 0;
	virtual int NotifiedActivation(_serverid_t serverId, int nLen, unsigned short* puiServiceType, const char* serverAddress, unsigned short serverPort) = 0;			// 패킷 처리가 가능한 상태를 알림 받음.
	virtual int NotifiedOffLineService(_serverid_t serverId, int nLen, unsigned short* puiServiceType) = 0;
	virtual int NotifiedMessage(_serverid_t fromServerId, unsigned short uiFromServiceType, int nOption, int nLen, const unsigned char* pbyData) = 0;
	virtual int NotifiedPost(_serverid_t fromServerId, int nOption, int nLen, const unsigned char* pchData) = 0;
	virtual int NotifiedTimer(int id) = 0;
};

// 여러개의 메시지를 한번 Notify하게 되면 Put했던 모든 것은 clear된다..
struct IConnectorMessage
{
	virtual int AddRef(void) = 0;
	virtual int Release(void) = 0;
	virtual int Put(int nLen, const unsigned char* pchData) = 0;
	virtual int Merge(IConnectorMessage* pOtherMessage) = 0;
	virtual int Count() = 0;
};

//
struct IConnector : public IComponentBase
{
	virtual int SetSink(unsigned short uiServiceType, IConnectorSink* piSink) = 0;
	virtual int ResetSink(unsigned short uiServiceType) = 0;
	virtual int Activate(unsigned short uiServiceType) = 0;

	// coordinator에 등록된 자신의 serverid를 반환한다.
	virtual int GetServerID(_serverid_t* pServerId) = 0;
	virtual int GetServerGroupID(_serverid_t serverID, _group_id_t* pServerGroupID) = 0;
	virtual int GetServerGroupLayer(_serverid_t serverID, _group_layer_t* layer) = 0;
	virtual bool GetServerInfo(_serverid_t serverid, std::string & addr, int32_t & port) = 0;

	virtual int GetAllServerIDs(int* pulLen, _serverid_t** ppuiServerIDs) = 0;
	virtual int ResetAllServerIDs(_serverid_t* puiServerIDs) = 0;

	virtual int GetAllServerIDsByServiceType(unsigned short uiServiceType, int* pulLen, _serverid_t** ppuiServerIDs) = 0;
	virtual int GetAllServerIDsByServiceTypeAndGroupID(unsigned short uiServiceType, _group_id_t groupID, int* pulLen, _serverid_t** ppuiServerIDs) = 0;
	virtual int ResetAllServerIDsByServiceType(_serverid_t* puiServerIDs) = 0;
	
	virtual int IsServiceInServer(_serverid_t serverId, unsigned short uiServiceType, bool* pbIs) = 0;
	virtual int GetServerIdCount(int* pnServerIdCount) = 0;
	virtual int GetServiceTypeCount(_serverid_t serverId, int* pnServiceTypeCount) = 0;
	virtual int IsOnline(_serverid_t serverId, unsigned short uiServiceType, bool* pbIsOnline) = 0;
	
	virtual int NotifyMessage(_serverid_t toServerId, unsigned short toServiceType, unsigned short fromServiceType, int nOption, int nLen, const unsigned char* pbyData) = 0;
	virtual int NotifyMessage(_serverid_t toServerId, unsigned short toServiceType, unsigned short fromServiceType, int nOption, int nLen, const unsigned char* pbyData, int nLen2, const unsigned char* pbyData2) = 0;
	virtual int NotifyPost(_serverid_t toServerId, int nOption, int nLen, const unsigned char* pchData) = 0;

	// id는 0이 아닌 값으로...
	virtual int SetTimer(int id, int milisec) = 0;
	virtual int ResetTimer(int id) = 0;

	// 여러개의 메시지를 묶어 한번에 전송하고자 할때 사용한다..
	virtual int GetConnectorMessage(IConnectorMessage** ppiConnectorMessage) = 0;
	// IConnectorMessage은 GetConnectorMessage에 의해 발급된 것만 사용해야 한다..
	virtual int NotifyMessage(_serverid_t toServerId, unsigned short toServiceType, unsigned short fromServiceType, int nOption, IConnectorMessage* piConnectorMessage) = 0;
};

// 
extern "C" const UUID UUID_IConnectorSink;
extern "C" const UUID UUID_IConnector;

} }		// connector // nmsp

#endif
